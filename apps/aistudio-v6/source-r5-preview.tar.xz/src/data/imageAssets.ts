import { FunctionalGroupId } from '../types';

export interface CanonicalImageAsset {
  id: string;
  title: string;
  category:
    | FunctionalGroupId
    | 'crafts'
    | 'covers'
    | 'logos'
    | 'products';
  sectorId: FunctionalGroupId;
  assetType: 'logo' | 'cover' | 'product';
  isSectorDefault?: boolean;
  url: string;
}

export interface SectorDefaultImagePack {
  sectorId: FunctionalGroupId;
  sectorName: string;
  emoji: string;
  logoUrl: string;
  coverUrl: string;
  productUrl: string;
}

/**
 * Legacy generic fallback URLs that should be upgraded to the sector's fixed default image
 */
const LEGACY_GENERIC_URLS = new Set([
  '',
  'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=240&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1400&auto=format&fit=crop&q=80',
]);

/**
 * Fixed Default Logo, Cover, and Product Images for all 15 Functional Sectors
 * Guaranteed to appear even if the business owner has not uploaded any image.
 */
export const SECTOR_DEFAULT_IMAGES: Record<FunctionalGroupId, SectorDefaultImagePack> = {
  dining: {
    sectorId: 'dining',
    sectorName: 'مطاعم وكافيهات وأغذية',
    emoji: '🍽️',
    logoUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80',
  },
  retail: {
    sectorId: 'retail',
    sectorName: 'تجزئة وملابس وإلكترونيات',
    emoji: '🛍️',
    logoUrl: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80',
  },
  services: {
    sectorId: 'services',
    sectorName: 'خدمات عامة وحجز مواعيد',
    emoji: '📅',
    logoUrl: 'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&auto=format&fit=crop&q=80',
  },
  healthcare: {
    sectorId: 'healthcare',
    sectorName: 'رعاية طبية وصيدليات',
    emoji: '🩺',
    logoUrl: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&auto=format&fit=crop&q=80',
  },
  crafts_maintenance: {
    sectorId: 'crafts_maintenance',
    sectorName: 'حرف وصيانة وتشطيبات',
    emoji: '🔧',
    logoUrl: 'https://images.unsplash.com/photo-1581092921461-eab62e97a780?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=600&auto=format&fit=crop&q=80',
  },
  education_training: {
    sectorId: 'education_training',
    sectorName: 'تعليم وأكاديميات وتدريب',
    emoji: '🎓',
    logoUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600&auto=format&fit=crop&q=80',
  },
  real_estate: {
    sectorId: 'real_estate',
    sectorName: 'عقارات ومقاولات واستثمار',
    emoji: '🏢',
    logoUrl: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&auto=format&fit=crop&q=80',
  },
  tourism_hotels: {
    sectorId: 'tourism_hotels',
    sectorName: 'سياحة وفنادق وضيافة',
    emoji: '🧭',
    logoUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=600&auto=format&fit=crop&q=80',
  },
  transport_logistics: {
    sectorId: 'transport_logistics',
    sectorName: 'نقل وشحن ولوجستيات',
    emoji: '🚚',
    logoUrl: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?w=600&auto=format&fit=crop&q=80',
  },
  agriculture_livestock: {
    sectorId: 'agriculture_livestock',
    sectorName: 'زراعة ومشاتل وإنتاج حيواني',
    emoji: '🌱',
    logoUrl: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&auto=format&fit=crop&q=80',
  },
  technology_software: {
    sectorId: 'technology_software',
    sectorName: 'تكنولوجيا وبرمجيات وحلول رقمية',
    emoji: '💻',
    logoUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600&auto=format&fit=crop&q=80',
  },
  sports_fitness: {
    sectorId: 'sports_fitness',
    sectorName: 'رياضة وجيم ولياقة بدنية',
    emoji: '🏋️',
    logoUrl: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&auto=format&fit=crop&q=80',
  },
  events_entertainment: {
    sectorId: 'events_entertainment',
    sectorName: 'مناسبات وقاعات وترفيه',
    emoji: '🎉',
    logoUrl: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=600&auto=format&fit=crop&q=80',
  },
  legal_financial: {
    sectorId: 'legal_financial',
    sectorName: 'استشارات قانونية ومحاسبة',
    emoji: '⚖️',
    logoUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600&auto=format&fit=crop&q=80',
  },
  industrial_manufacturing: {
    sectorId: 'industrial_manufacturing',
    sectorName: 'صناعة ومصانع وتوريدات',
    emoji: '🏭',
    logoUrl: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=300&auto=format&fit=crop&q=80',
    coverUrl: 'https://images.unsplash.com/photo-1565514020179-026b92b84bb6?w=1600&auto=format&fit=crop&q=80',
    productUrl: 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=600&auto=format&fit=crop&q=80',
  },
};

/**
 * Rich Selectable Default Image Library across all 15 Sectors (Logos, Covers, and Products)
 * Includes the sector-fixed defaults plus additional curated choices per sector.
 */
const EXTRA_SELECTABLE_ASSETS: CanonicalImageAsset[] = [
  // Dining extras
  {
    id: 'dining_cover_cafe',
    title: 'واجهة مقهى ومحمصة قهوة مختصة',
    category: 'covers',
    sectorId: 'dining',
    assetType: 'cover',
    url: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'dining_cover_grill',
    title: 'غلاف مطعم مشويات ومأكولات شرقية',
    category: 'covers',
    sectorId: 'dining',
    assetType: 'cover',
    url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'dining_logo_coffee',
    title: 'شعار كافيه ومشروبات ساخنة',
    category: 'logos',
    sectorId: 'dining',
    assetType: 'logo',
    url: 'https://images.unsplash.com/photo-1509785307050-d4066910ec1e?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'dining_prod_espresso',
    title: 'قهوة اسبريسو ومشروبات كافيه',
    category: 'dining',
    sectorId: 'dining',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80',
  },
  {
    id: 'dining_prod_burger',
    title: 'وجبة برجر وبطاطس ساخنة',
    category: 'dining',
    sectorId: 'dining',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
  },
  {
    id: 'dining_prod_pizza',
    title: 'بيتزا إيطالية ومخبوزات طازجة',
    category: 'dining',
    sectorId: 'dining',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&auto=format&fit=crop&q=80',
  },
  {
    id: 'dining_prod_sweets',
    title: 'حلويات شرقية وغربية فاخرة',
    category: 'dining',
    sectorId: 'dining',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=600&auto=format&fit=crop&q=80',
  },

  // Retail extras
  {
    id: 'retail_cover_fashion',
    title: 'غلاف معرض أزياء وملابس حديثة',
    category: 'covers',
    sectorId: 'retail',
    assetType: 'cover',
    url: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'retail_logo_fashion',
    title: 'شعار بوتيك ملابس وأزياء',
    category: 'logos',
    sectorId: 'retail',
    assetType: 'logo',
    url: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'retail_prod_phone',
    title: 'هواتف ذكية وإلكترونيات حديثة',
    category: 'retail',
    sectorId: 'retail',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&auto=format&fit=crop&q=80',
  },
  {
    id: 'retail_prod_shoes',
    title: 'أحذية وملابس رياضية وكاجوال',
    category: 'retail',
    sectorId: 'retail',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=80',
  },
  {
    id: 'retail_prod_supermarket',
    title: 'منتجات سوبر ماركت وبقالة يومية',
    category: 'retail',
    sectorId: 'retail',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&auto=format&fit=crop&q=80',
  },

  // Healthcare extras
  {
    id: 'health_cover_pharmacy',
    title: 'غلاف صيدلية ومركز دوائي متكامل',
    category: 'covers',
    sectorId: 'healthcare',
    assetType: 'cover',
    url: 'https://images.unsplash.com/photo-1576602976047-174e57a47881?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'health_logo_clinic',
    title: 'شعار عيادة طبية تخصصية',
    category: 'logos',
    sectorId: 'healthcare',
    assetType: 'logo',
    url: 'https://images.unsplash.com/photo-1586015555751-63bb77f4322a?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'health_prod_vitamins',
    title: 'فيتامينات ومكملات وعناية طبية',
    category: 'healthcare',
    sectorId: 'healthcare',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1577401239170-897942555fb3?w=600&auto=format&fit=crop&q=80',
  },
  {
    id: 'health_prod_checkup',
    title: 'كشف طبي وفحص شامل بالعيادة',
    category: 'healthcare',
    sectorId: 'healthcare',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=600&auto=format&fit=crop&q=80',
  },

  // Services extras
  {
    id: 'services_cover_salon',
    title: 'غلاف مركز تجميل وعناية شخصية',
    category: 'covers',
    sectorId: 'services',
    assetType: 'cover',
    url: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'services_prod_consultation',
    title: 'جلسة خدمة وحجز موعد فوري',
    category: 'services',
    sectorId: 'services',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=600&auto=format&fit=crop&q=80',
  },

  // Crafts & Maintenance extras
  {
    id: 'crafts_cover_workshop',
    title: 'غلاف مركز صيانة وتشطيبات هندسية',
    category: 'covers',
    sectorId: 'crafts_maintenance',
    assetType: 'cover',
    url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'crafts_prod_ac',
    title: 'صيانة أجهزة منزلية وتكييفات وكهرباء',
    category: 'crafts_maintenance',
    sectorId: 'crafts_maintenance',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600&auto=format&fit=crop&q=80',
  },

  // Real estate extras
  {
    id: 'realestate_cover_villa',
    title: 'غلاف كمبوند ومشروعات سكنية حديثة',
    category: 'covers',
    sectorId: 'real_estate',
    assetType: 'cover',
    url: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'realestate_prod_apt',
    title: 'وحدة سكنية / إدارية متكاملة التشطيب',
    category: 'real_estate',
    sectorId: 'real_estate',
    assetType: 'product',
    url: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=600&auto=format&fit=crop&q=80',
  },

  // Technology extras
  {
    id: 'tech_cover_agency',
    title: 'غلاف شركة برمجيات وتصميم مواقع',
    category: 'covers',
    sectorId: 'technology_software',
    assetType: 'cover',
    url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1600&auto=format&fit=crop&q=80',
  },
  {
    id: 'tech_logo_digital',
    title: 'شعار شركة حلول رقمية وتطبيقات',
    category: 'logos',
    sectorId: 'technology_software',
    assetType: 'logo',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&auto=format&fit=crop&q=80',
  },
];

/**
 * Automatically build the complete canonical library from all 15 sector default packs + extra selectable assets
 */
export const CANONICAL_IMAGE_LIBRARY: CanonicalImageAsset[] = [
  ...Object.values(SECTOR_DEFAULT_IMAGES).flatMap((pack): CanonicalImageAsset[] => [
    {
      id: `default_logo_${pack.sectorId}`,
      title: `الشعار الافتراضي — ${pack.sectorName}`,
      category: 'logos',
      sectorId: pack.sectorId,
      assetType: 'logo',
      isSectorDefault: true,
      url: pack.logoUrl,
    },
    {
      id: `default_cover_${pack.sectorId}`,
      title: `الغلاف الافتراضي (Cover) — ${pack.sectorName}`,
      category: 'covers',
      sectorId: pack.sectorId,
      assetType: 'cover',
      isSectorDefault: true,
      url: pack.coverUrl,
    },
    {
      id: `default_product_${pack.sectorId}`,
      title: `صورة المنتج/الخدمة الافتراضية — ${pack.sectorName}`,
      category: pack.sectorId,
      sectorId: pack.sectorId,
      assetType: 'product',
      isSectorDefault: true,
      url: pack.productUrl,
    },
  ]),
  ...EXTRA_SELECTABLE_ASSETS,
];

/**
 * Returns the fixed default Logo URL for any sector (defaults to 'services' if unknown)
 */
export function getSectorDefaultLogo(sectorId?: FunctionalGroupId | string | null): string {
  if (sectorId && sectorId in SECTOR_DEFAULT_IMAGES) {
    return SECTOR_DEFAULT_IMAGES[sectorId as FunctionalGroupId].logoUrl;
  }
  return SECTOR_DEFAULT_IMAGES.services.logoUrl;
}

/**
 * Returns the fixed default Cover URL for any sector (defaults to 'services' if unknown)
 */
export function getSectorDefaultCover(sectorId?: FunctionalGroupId | string | null): string {
  if (sectorId && sectorId in SECTOR_DEFAULT_IMAGES) {
    return SECTOR_DEFAULT_IMAGES[sectorId as FunctionalGroupId].coverUrl;
  }
  return SECTOR_DEFAULT_IMAGES.services.coverUrl;
}

/**
 * Returns the fixed default Product/Service Image URL for any sector (defaults to 'services' if unknown)
 */
export function getSectorDefaultProductImage(sectorId?: FunctionalGroupId | string | null): string {
  if (sectorId && sectorId in SECTOR_DEFAULT_IMAGES) {
    return SECTOR_DEFAULT_IMAGES[sectorId as FunctionalGroupId].productUrl;
  }
  return SECTOR_DEFAULT_IMAGES.services.productUrl;
}

/**
 * Resolves a business logo URL, guaranteeing the sector's fixed default logo if empty or legacy generic
 */
export function resolveBusinessLogo(
  business?: { logoUrl?: string | null; functionalGroupId?: FunctionalGroupId | string | null } | null
): string {
  const raw = business?.logoUrl?.trim() || '';
  if (raw && !LEGACY_GENERIC_URLS.has(raw)) {
    return raw;
  }
  return getSectorDefaultLogo(business?.functionalGroupId);
}

/**
 * Resolves a business cover URL, guaranteeing the sector's fixed default cover if empty or legacy generic
 */
export function resolveBusinessCover(
  business?: { coverUrl?: string | null; functionalGroupId?: FunctionalGroupId | string | null } | null
): string {
  const raw = business?.coverUrl?.trim() || '';
  if (raw && !LEGACY_GENERIC_URLS.has(raw)) {
    return raw;
  }
  return getSectorDefaultCover(business?.functionalGroupId);
}

/**
 * Resolves a product/service image URL, guaranteeing the sector's fixed default product image if empty
 */
export function resolveProductImage(
  product?: { imageUrl?: string | null } | null,
  sectorId?: FunctionalGroupId | string | null
): string {
  const raw = product?.imageUrl?.trim() || '';
  if (raw && !LEGACY_GENERIC_URLS.has(raw)) {
    return raw;
  }
  return getSectorDefaultProductImage(sectorId);
}

/**
 * Returns selectable preset images filtered by sector and/or assetType ('logo' | 'cover' | 'product')
 */
export function getSelectableImagesForSector(
  sectorId: FunctionalGroupId | 'all' = 'all',
  assetType: 'logo' | 'cover' | 'product' | 'all' = 'all'
): CanonicalImageAsset[] {
  return CANONICAL_IMAGE_LIBRARY.filter((item) => {
    const matchesSector = sectorId === 'all' || item.sectorId === sectorId;
    const matchesType = assetType === 'all' || item.assetType === assetType;
    return matchesSector && matchesType;
  });
}
