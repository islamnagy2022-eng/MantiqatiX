import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { DirectoryView } from './components/DirectoryView';
import { MedicalDirectoryView } from './components/medical/MedicalDirectoryView';
import { ContactUsView } from './components/ContactUsView';
import { BusinessProfileHeader } from './components/storefront/BusinessProfileHeader';
import { CatalogSection } from './components/storefront/CatalogSection';
import { LoginModal } from './components/auth/LoginModal';

const MainContent: React.FC = () => {
  const { currentView, currentBusiness } = useApp();

  return (
    <div className="flex min-h-screen flex-col bg-slate-50/70 text-slate-800">
      <Navbar />
      <main className="flex-1">
        {currentView === 'medical_directory' ? (
          <MedicalDirectoryView />
        ) : currentView === 'contact_us' ? (
          <ContactUsView />
        ) : currentView === 'public_storefront' ? (
          <BusinessProfileHeader>
            {currentBusiness ? <CatalogSection /> : <DirectoryView />}
          </BusinessProfileHeader>
        ) : (
          <DirectoryView />
        )}
      </main>
      <footer className="mt-auto border-t border-slate-200 bg-white px-4 py-6" dir="rtl">
        <div className="mx-auto flex max-w-[1720px] flex-col items-center justify-between gap-2 text-center text-xs text-slate-500 sm:flex-row sm:text-right">
          <span className="font-bold text-slate-800">MantiqatiX — دليل الأنشطة والكتالوجات</span>
          <span>© {new Date().getFullYear()} جميع الحقوق محفوظة</span>
        </div>
      </footer>
      <LoginModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
