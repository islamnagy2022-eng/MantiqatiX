export type FunctionalGroupId =
  | 'dining'
  | 'retail'
  | 'services'
  | 'healthcare'
  | 'crafts_maintenance'
  | 'education_training'
  | 'real_estate'
  | 'tourism_hotels'
  | 'transport_logistics'
  | 'agriculture_livestock'
  | 'technology_software'
  | 'sports_fitness'
  | 'events_entertainment'
  | 'legal_financial'
  | 'industrial_manufacturing';

export interface FunctionalGroup {
  id: FunctionalGroupId;
  name: string; // e.g. "قطاع الأغذية والمطاعم"
  shortName: string; // e.g. "مطاعم وأغذية"
  englishName: string; // e.g. "Food & Dining"
  icon: string; // Lucide icon name indicator
  badgeColor: string; // Tailwind color class combo
  description: string;
  futureFeatures: {
    title: string;
    description: string;
    status: 'active' | 'in_development' | 'planned';
  }[];
}

export interface ActivityCategory {
  id: string;
  name: string; // e.g. "مطاعم ومقاهي", "سوبرماركت وبقالة"
  functionalGroupId: FunctionalGroupId;
  description?: string;
  icon?: string;
  isCustom?: boolean;
}

export interface MedicalSpecialty {
  id: string;
  name: string; // e.g. "أمراض الباطنة والسكر", "طب الأطفال وحديثي الولادة"
  icon: string;
  description: string;
  doctorCount?: number;
}

export type PaymobChannel = 'card' | 'wallet' | 'kiosk';
export type PaymobFeeType = 'percentage_and_fixed' | 'percentage_plus_fixed' | 'percentage' | 'fixed';

export interface PaymobConfig {
  enabled: boolean;
  feeType: PaymobFeeType;
  feePercentage: number;
  feeFixed: number;
  acceptedChannels: PaymobChannel[];
  merchantApiKey?: string;
  integrationIdCard?: string;
  integrationIdWallet?: string;
  iframeId?: string;
  notesForCustomer?: string;
}

export type VerificationStatus =
  | 'unverified'    // غير موثق
  | 'under_review'  // قيد المراجعة
  | 'verified'      // موثق رسمياً
  | 'rejected'      // مرفوض
  | 'suspended';    // موقوف

export interface GeoLocation {
  country: string;
  countryCode: string;
  regionState?: string;
  governorate: string;
  markaz: string;
  village: string;
  address?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export interface Business {
  id: string;
  name: string;
  slug: string;
  category: string;
  categoryId?: string;
  functionalGroupId: FunctionalGroupId;
  logoUrl: string;
  coverUrl: string;
  coverImages?: string[];
  bio: string;
  ownerWhatsApp: string;
  phone?: string;
  email?: string;
  address: string;

  // Geographic Hierarchy (Multi-country scale)
  country?: string;
  countryCode?: string;
  regionState?: string;
  governorate: string;
  markaz: string;
  village: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
  googleMapsUrl?: string;

  workingHours: string;

  // 5-Tier Verification System (Enterprise Grade)
  verificationStatus?: VerificationStatus;
  isVerified: boolean; // Backward compatibility
  verifiedAt?: string;
  verificationNotes?: string;
  verificationBadgeLevel?: 'standard' | 'silver' | 'gold';

  // Healthcare / Medical Directory Specifics
  isMedical?: boolean;
  medicalType?: 'doctor' | 'pharmacy' | 'clinic' | 'hospital' | 'lab' | 'radiology';
  medicalSpecialtyId?: string;
  doctorTitle?: string; // e.g. "استشاري", "أستاذ دكتور", "أخصائي أول"
  consultationFee?: number; // ج.م

  maxProductsLimit: number; // default 150
  createdAt: string;

  // Paymob Payment Gateway
  paymobConfig?: PaymobConfig;

  // Billing, Registration & Monthly Subscription System
  registrationDate: string;
  paymentDueDay: number;
  paymentDueDate: string;
  commissionPerOrder: number;
  totalOrdersCount: number;
  paymentStatus: 'paid' | 'pending' | 'overdue' | 'frozen';
  overdueDaysCount: number;
  isFrozen: boolean;
  lastPaymentDate?: string;
  paymentConfirmedByAdmin: boolean;
  ownerSubscriberId?: string;
  commissionType?: 'percentage' | 'fixed' | 'percentage_plus_fixed' | 'subscription_only' | 'all_combined';
  commissionPercentage?: number;
  commissionFixed?: number;
  commissionFixedPerItem?: number;
  monthlySubscriptionFee?: number;

  // Telemetry & Metrics
  viewsCount?: number;
  distanceKm?: number; // Runtime computed relative to user
  employees?: {
    id: string;
    name: string;
    role: string;
    phone: string;
    shift: string;
  }[];
  socialLinks?: {
    name: string;
    url: string;
    status: 'pending' | 'approved';
  }[] & {
    facebook?: string;
    instagram?: string;
    website?: string;
  };
  customLinks?: {
    label: string;
    url: string;
    type: 'link' | 'phone' | 'whatsapp';
  }[];

  // Subscription Plan, Permissions, Multi-Business Quota & Credit Limit
  subscriptionTier?: SubscriptionPlanTier;
  sectorPackageLevel?: SectorPackageLevel;
  maxAllowedBusinesses?: number;
  creditLimit?: number;
  usedCredit?: number;
  usedCreditBalance?: number;
  totalSalesAmount?: number;
  totalServicesSalesAmount?: number;
  permissions?: BusinessPermissions;
  walletId?: string;
  messagingPrivacy?: MessagingPrivacyConfig;
}

export type MessagingPrivacyMode =
  | 'public_all'
  | 'members_only'
  | 'same_governorate_only'
  | 'same_markaz_only'
  | 'disabled';

export interface MessagingPrivacyConfig {
  enabled: boolean;
  privacyMode: MessagingPrivacyMode;
  allowedGovernorates: string[];
  allowedMarkazList?: string[];
  hidePhoneNumberInMessages: boolean;
  allowWhatsAppForward: boolean;
  autoReplyText?: string;
  updatedAt?: string;
}

export interface MemberDirectMessage {
  id: string;
  recipientType: 'business' | 'subscriber';
  recipientId: string;
  recipientName: string;
  recipientGovernorate: string;
  recipientMarkaz?: string;
  senderName: string;
  senderPhone: string;
  senderGovernorate: string;
  senderMarkaz: string;
  senderRole: 'subscriber' | 'visitor' | 'admin';
  senderSubscriberId?: string;
  subject: string;
  content: string;
  category: 'order_inquiry' | 'partnership' | 'member_message' | 'consultation' | 'support';
  isRead: boolean;
  replyText?: string;
  repliedAt?: string;
  createdAt: string;
}

export type SubscriptionPlanTier = 'free' | 'regular' | 'advanced';
export type SectorPackageLevel = 1 | 2 | 3;

export interface SectorInteractiveTool {
  id: string;
  title: string;
  description: string;
  actionLabel: string;
  placeholderHint: string;
  requiredLevel: SectorPackageLevel;
  kpiImpact: string;
}

export interface SectorTierPackageSpec {
  level: SectorPackageLevel;
  tierKey: SubscriptionPlanTier;
  name: string;
  badgeText: string;
  monthlyFeeEgp: number;
  annualFeeEgp: number;
  commissionPercentage: number;
  commissionFixedEgp: number;
  maxProducts: number;
  maxBranches: number;
  creditLimitEgp: number;
  freeSponsoredAdsPerMonth: number;
  operationalPowerSummary: string;
  sectorExclusiveFeatures: string[];
  isRecommended?: boolean;
}

export interface SectorDevelopmentBlueprint {
  functionalGroupId: FunctionalGroupId;
  emoji: string;
  shortName: string;
  fullName: string;
  heroTagline: string;
  valueProposition: string;
  basePlatformCapabilities: string[];
  interactiveTools: SectorInteractiveTool[];
  tiers: [SectorTierPackageSpec, SectorTierPackageSpec, SectorTierPackageSpec];
  growthMetrics: {
    avgSalesBoost: string;
    operationalSaving: string;
    retentionRate: string;
  };
}

export interface BusinessPermissions {
  enableWhatsAppCart: boolean;
  enablePaymob: boolean;
  enableEmployees: boolean;
  enableCustomLinks: boolean;
  enableSponsoredAds: boolean;
  enableFinancialSystem: boolean;
  enableAiTools: boolean;
}

export interface SaleRecord {
  id: string;
  businessId: string;
  itemType: 'product' | 'service';
  itemName: string;
  quantity: number;
  unitPrice: number;
  totalAmount: number;
  platformCommission: number;
  netRevenue: number;
  customerName: string;
  customerPhone: string;
  createdAt: string;
  status: 'completed' | 'pending' | 'cancelled';
}

export interface CreditLimitAccount {
  businessId: string;
  creditLimit: number;
  currentBalance: number;
  usedCredit: number;
  status: 'normal' | 'warning' | 'exceeded' | 'frozen';
  lastUpdated: string;
}

export interface Product {
  id: string;
  businessId: string;
  name: string;
  category: string;
  type: 'product' | 'service';
  price: number;
  comparePrice?: number;
  description: string;
  imageUrl: string;
  isAvailable: boolean;
  unit?: string;
}

export interface PersonalSiteBookmark {
  id: string;
  title: string;
  url: string;
  category?: string;
  approvedByAdmin?: boolean;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface Subscriber {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  businessId: string;
  status: 'active' | 'pending' | 'suspended';
  username?: string;
  password?: string;
  authMethod: 'direct_password' | 'gmail_invite';
  invitedAt?: string;
  inviteStatus: 'sent' | 'pending' | 'direct_created';
  notes?: string;
  joinedDate: string;
  walletBalance?: number; // رصيد محفظة المشترك / المشتري
  maxAllowedBusinesses?: number;
  subscriptionTier?: SubscriptionPlanTier;
  personalSites?: PersonalSiteBookmark[]; // حتى 15 موقع لحفظ اهتمامات المشترك (لا يراه إلا المشترك والإدارة)
  governorate?: string;
  markaz?: string;
  messagingPrivacy?: MessagingPrivacyConfig;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface SiteMapConfig {
  heroTitle: string;
  heroSubtitle: string;
  platformImportanceText: string;
  developmentStatusTitle: string;
  developmentProgressPercent: number;
  developmentPhaseLabel: string;
  developmentNotes: string;
  visitorBenefits: string[];
  merchantBenefits: string[];
  lastUpdated: string;
}

export interface AdminSettings {
  adminWhatsApp: string;
  adminPassword: string;
  defaultCategories: string[];
  categories: ActivityCategory[];
  functionalGroups: FunctionalGroup[];
  currency: string;
  platformName: string;
  platformEmail: string;
  maxAllowedProductsPerBusiness: number;
  defaultCommissionPerOrder: number;
  overdueGracePeriodDays: number;
  defaultPaymobFeePercentage: number;
  defaultPaymobFeeFixed: number;
  activeCountry: string;
  activeGovernorate: string;
  aiStudioApiKey?: string;
  aiDevelopmentOptions?: {
    enableImageGeneration: boolean;
    enableSmartAssistant: boolean;
    enableAutoDescriptions: boolean;
    modelAlias: string;
  };
  siteMapConfig?: SiteMapConfig;
  siteVisitorsCount?: number;
  todayVisitorsCount?: number;
}

export interface CustomerOrderData {
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  deliveryNotes?: string;
  paymentMethod: 'cash_on_delivery' | 'cod' | 'paymob';
  paymobChannel?: PaymobChannel;
  paymobFee?: number;
  paymobTotalPaid?: number;
  paymobTransactionRef?: string;
  paymobPaidAt?: string;
}

export type AuthRole =
  | 'super_admin'
  | 'regional_manager'
  | 'subscriber'
  | 'medical_staff'
  | 'customer'
  | 'guest'
  | 'admin'; // Backward compatibility

export interface AuthSession {
  role: AuthRole;
  subscriberId?: string;
  businessId?: string;
  subscriberName?: string;
  userEmail?: string;
  userPhone?: string;
  assignedRegion?: string;
  isTwoFactorVerified?: boolean;
  userId?: string;
  // Server-resolved Supabase membership context. These fields must never be
  // populated from user_metadata or browser-provided role/business values.
  membershipId?: string;
  tenantId?: string;
  organizationId?: string;
  branchId?: string;
  backendRole?: string;
  membershipPermissions?: Record<string, unknown>;
}

// Enterprise Observability & Hyperscale Simulation Types
export interface TelemetryMetrics {
  cpu: number;
  memory: number;
  activeConnections: number;
  maxConnections: number;
  cacheHitRatio: number;
  queueDepth: number;
  reqPerSec: number;
  errorRate: number;
  readLatencyP50: number;
  readLatencyP95: number;
  readLatencyP99: number;
  writeLatencyP95: number;

  // Compatibility & Display aliases
  globalRPS: number;
  dbConnectionPoolActive: number;
  dbConnectionPoolMax: number;
  latencyP50Ms: number;
  latencyP95Ms: number;
  latencyP99Ms: number;
  activePods: number;
}

export interface LoadTestBenchmarkResult {
  vus: number;
  label: string;
  rps: number;
  p50: number;
  p95: number;
  p99: number;
  errorRate: number;
  cacheHitRate: number;
  status: 'passed' | 'warning' | 'bottleneck';
  bottleneckReason?: string;
  executedAt: string;

  // Additional fields for interactive display
  virtualUsers: number;
  requestsPerSecond: number;
  p95LatencyMs: number;
  p99LatencyMs: number;
  errorRatePercent: number;
  cacheHitRatio: number;
  degradationLevel: 'none' | 'degraded' | 'heavy';
  scalingRecommendation: string;
}

export interface UserAccount100M {
  id: string;
  email: string;
  phone: string;
  fullName: string;
  role: AuthRole;
  status: 'active' | 'suspended' | 'pending_otp';
  registeredDevicesCount: number;
  lastLoginIp: string;
  registeredAt: string;
  country: string;
}

export type AdRequestType = 'sponsored_ad' | 'billboard_banner';
export type AdRequestStatus = 'pending' | 'approved' | 'rejected';

export interface AdRequest {
  id: string;
  type: AdRequestType;
  title: string;
  description: string;
  imageUrl?: string;
  durationDays: number;
  budgetOrPrice?: number;
  businessId?: string;
  businessName: string;
  contactPhone: string;
  contactWhatsApp?: string;
  status: AdRequestStatus;
  createdAt: string;
  adminNotes?: string;
  isFreeAdminSponsored?: boolean;
  generatedCampaignId?: string;
  promoCode?: string;
  ctaText?: string;
}

export type ContactMessageType = 'message' | 'request' | 'complaint' | 'inquiry';

export interface ContactMessage {
  id: string;
  senderName: string;
  senderPhone: string;
  senderEmail?: string;
  senderRole: 'visitor' | 'subscriber' | 'merchant';
  messageType: ContactMessageType;
  subject: string;
  content: string;
  relatedBusinessName?: string;
  isRead: boolean;
  createdAt: string;
  adminReplyNotes?: string;
}

export interface SubscriptionRequest {
  id: string;
  businessId: string;
  businessName: string;
  ownerName?: string;
  phoneOrWhatsApp: string;
  governorate: string;
  markaz: string;
  detailedAddress?: string;
  functionalGroupId: FunctionalGroupId;
  category: string;
  notes?: string;
  status: 'pending_review' | 'pending' | 'approved' | 'rejected';
  assignedTier: SubscriptionPlanTier;
  requestedTier?: SubscriptionPlanTier;
  isUnverifiedFreeDirectory?: boolean;
  maxAllowedBusinesses: number;
  assignedMaxAllowedBusinesses?: number;
  maxProductsLimit: number;
  commissionType: 'percentage' | 'fixed' | 'percentage_plus_fixed' | 'subscription_only' | 'all_combined';
  monthlySubscriptionFee: number;
  assignedMonthlyFee?: number;
  commissionPercentage: number;
  assignedCommissionPercentage?: number;
  commissionFixed: number;
  assignedCommissionFixed?: number;
  creditLimit: number;
  permissions: BusinessPermissions;
  assignedPermissions?: BusinessPermissions;
  createdAt: string;
  reviewedAt?: string;
}

// ============================================================================
// ENTERPRISE WALLET, LEDGER & AUTOMATED MARKETING CONTENT SYSTEM
// ============================================================================

export type WalletOwnerType = 'admin' | 'business' | 'subscriber';

export type WalletTransactionType =
  | 'deposit'
  | 'withdrawal'
  | 'commission_deduction'
  | 'ad_payment'
  | 'admin_free_ad_grant'
  | 'cashback'
  | 'credit_settlement';

export type WalletPaymentChannel =
  | 'vodafone_cash'
  | 'instapay'
  | 'paymob_card'
  | 'bank_transfer'
  | 'admin_grant'
  | 'internal_ledger';

export interface WalletAccount {
  id: string;
  ownerType: WalletOwnerType;
  ownerId: string;
  ownerName: string;
  availableBalance: number;
  pendingBalance: number;
  creditLimit: number;
  usedCredit: number;
  adGrantBalance: number;
  totalDeposited: number;
  totalSpentOnAds: number;
  currency: string;
  isFreeSponsoredAdsEnabled: boolean;
  status: 'active' | 'frozen';
  updatedAt: string;
}

export interface WalletTransaction {
  id: string;
  walletId: string;
  ownerName: string;
  type: WalletTransactionType;
  amount: number;
  balanceAfter: number;
  description: string;
  paymentMethod: WalletPaymentChannel;
  referenceId?: string;
  isFreeAdminGrant?: boolean;
  status: 'completed' | 'pending' | 'rejected';
  createdAt: string;
}

export type MarketingCampaignGoal =
  | 'sales_boost'
  | 'grand_opening'
  | 'seasonal_offer'
  | 'brand_awareness'
  | 'service_booking';

export interface GeneratedMarketingCampaign {
  id: string;
  businessId: string;
  businessName: string;
  category: string;
  functionalGroupId: FunctionalGroupId;
  governorate: string;
  markaz: string;
  goal: MarketingCampaignGoal;
  headline: string;
  subheadline: string;
  sponsoredAdCopy: string;
  facebookInstagramCopy: string;
  whatsappBroadcastCopy: string;
  reelsVideoScript: string;
  billboardBannerText: string;
  ctaText: string;
  promoCode: string;
  discountPercent: number;
  targetAudience: string[];
  seoKeywords: string[];
  estimatedReach: number;
  adCostEgp: number;
  isFreeForAdmin: boolean;
  publishedAdId?: string;
  createdAt: string;
}

export interface EnterpriseStateArchitectureSummary {
  schemaVersion: string;
  totalBusinesses: number;
  verifiedBusinesses: number;
  freeDirectoryBusinesses: number;
  totalProducts: number;
  totalWallets: number;
  totalLedgerTransactions: number;
  totalGeneratedCampaigns: number;
  activeSponsoredAds: number;
  totalPlatformLiquidityEgp: number;
  lastSyncedAt: string;
}



