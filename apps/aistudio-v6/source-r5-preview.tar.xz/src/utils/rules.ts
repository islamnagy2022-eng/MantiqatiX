import {
  ActivityCategory,
  AdminSettings,
  AdRequest,
  AuthRole,
  AuthSession,
  Business,
  BusinessPermissions,
  CartItem,
  ContactMessageType,
  CustomerOrderData,
  EnterpriseStateArchitectureSummary,
  FunctionalGroup,
  FunctionalGroupId,
  GeneratedMarketingCampaign,
  MarketingCampaignGoal,
  MemberDirectMessage,
  MessagingPrivacyConfig,
  MessagingPrivacyMode,
  PaymobConfig,
  Product,
  SectorDevelopmentBlueprint,
  SectorInteractiveTool,
  SectorPackageLevel,
  SectorTierPackageSpec,
  Subscriber,
  SubscriptionPlanTier,
  WalletAccount,
  WalletPaymentChannel,
  WalletTransaction,
  WalletTransactionType,
} from '../types';
import { SECTOR_DEVELOPMENT_BLUEPRINTS } from '../data/sectorBlueprints';
import {
  SECTOR_DEFAULT_IMAGES,
  getSectorDefaultLogo,
  getSectorDefaultCover,
  getSectorDefaultProductImage,
  resolveBusinessLogo,
  resolveBusinessCover,
  resolveProductImage,
  getSelectableImagesForSector,
} from '../data/imageAssets';

export {
  SECTOR_DEFAULT_IMAGES,
  getSectorDefaultLogo,
  getSectorDefaultCover,
  getSectorDefaultProductImage,
  resolveBusinessLogo,
  resolveBusinessCover,
  resolveProductImage,
  getSelectableImagesForSector,
};

export const MAX_PRODUCTS_PER_BUSINESS = 150;
export const DEFAULT_COMMISSION_PER_ORDER = 0.01; // 0.01 ج.م
export const OVERDUE_GRACE_PERIOD_DAYS = 5; // 5 أيام إشعار يومي قبل التجميد
export const DEFAULT_CURRENCY = 'ج.م';
export const DEFAULT_PLATFORM_NAME = 'MantiqatiX';
export const DEFAULT_PAYMOB_FEE_PERCENTAGE = 2.75; // 2.75%
export const DEFAULT_PAYMOB_FEE_FIXED = 3.0; // 3.00 ج.م

// صورة شعار ثابتة وغلاف ثابت لكل نشاط منذ لحظة تسجيله لحين تغييره من مالك النشاط
export const DEFAULT_BUSINESS_LOGO_URL =
  'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=400&auto=format&fit=crop&q=80';
export const DEFAULT_BUSINESS_COVER_URL =
  'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1600&auto=format&fit=crop&q=80';


/**
 * Validates if a merchant can add another product according to the 150 quota limit.
 */
export function canAddProduct(currentCount: number, limit: number = MAX_PRODUCTS_PER_BUSINESS): boolean {
  return currentCount < limit;
}

/**
 * Calculates remaining allowed products for a business.
 */
export function getRemainingProductsCount(currentCount: number, limit: number = MAX_PRODUCTS_PER_BUSINESS): number {
  return Math.max(0, limit - currentCount);
}

/**
 * Sanitizes phone number for WhatsApp wa.me links.
 * Removes spaces, dashes, parentheses and leading '+' signs.
 */
export function cleanPhoneNumber(phone: string): string {
  if (!phone) return '';
  return phone.replace(/[^\d]/g, '');
}

/**
 * Calculates cart totals including item count and subtotal amount.
 */
export function calculateCartTotals(items: CartItem[]): { subtotal: number; totalCount: number; originalSubtotal: number } {
  let subtotal = 0;
  let totalCount = 0;
  let originalSubtotal = 0;

  for (const item of items) {
    const qty = Math.max(1, item.quantity);
    totalCount += qty;
    subtotal += item.product.price * qty;
    originalSubtotal += (item.product.comparePrice ?? item.product.price) * qty;
  }

  return { subtotal, totalCount, originalSubtotal };
}

/**
 * Calculates Paymob payment gateway surcharge fee based on business configuration set by Admin.
 */
export function calculatePaymobFee(
  subtotal: number,
  config?: PaymobConfig
): { fee: number; totalWithFee: number; percentage: number; fixed: number } {
  if (!config || !config.enabled || subtotal <= 0) {
    return { fee: 0, totalWithFee: subtotal, percentage: 0, fixed: 0 };
  }

  const percentage = config.feePercentage ?? DEFAULT_PAYMOB_FEE_PERCENTAGE;
  const fixed = config.feeFixed ?? DEFAULT_PAYMOB_FEE_FIXED;

  let fee = 0;
  if (config.feeType === 'percentage') {
    fee = (subtotal * percentage) / 100;
  } else if (config.feeType === 'fixed') {
    fee = fixed;
  } else {
    // percentage_and_fixed
    fee = (subtotal * percentage) / 100 + fixed;
  }

  // Round to 2 decimal places
  fee = Math.round(fee * 100) / 100;
  const totalWithFee = Math.round((subtotal + fee) * 100) / 100;

  return { fee, totalWithFee, percentage, fixed };
}

/**
 * Formats a currency string in Arabic Egyptian locale with ج.م.
 */
export function formatPrice(amount: number, currency: string = DEFAULT_CURRENCY): string {
  return `${amount.toLocaleString('ar-EG')} ${currency}`;
}

/**
 * Generates WhatsApp URL to place an order with the business owner in Egyptian Pounds (ج.م)
 * including Paymob payment details if chosen.
 */
export function generateWhatsAppOrderUrl(
  ownerPhone: string,
  businessName: string,
  cartItems: CartItem[],
  customer: CustomerOrderData,
  currency: string = DEFAULT_CURRENCY
): string {
  const cleanPhone = cleanPhoneNumber(ownerPhone);
  const { subtotal } = calculateCartTotals(cartItems);

  let message = `🛒 *طلب جديد من كتالوج (${businessName}) عبر MantiqatiX*\n`;
  message += `━━━━━━━━━━━━━━━━━━━━\n\n`;

  message += `👤 *بيانات العميل:*\n`;
  message += `▫️ الاسم: ${customer.customerName.trim()}\n`;
  message += `▫️ الجوال: ${customer.customerPhone.trim()}\n`;
  if (customer.customerAddress?.trim()) {
    message += `▫️ العنوان: ${customer.customerAddress.trim()}\n`;
  }
  if (customer.deliveryNotes?.trim()) {
    message += `▫️ ملاحظات: ${customer.deliveryNotes.trim()}\n`;
  }

  message += `\n📦 *تفاصيل المنتجات والخدمات المطلوبة:*\n`;
  cartItems.forEach((item, index) => {
    const lineTotal = item.product.price * item.quantity;
    const typeLabel = item.product.type === 'service' ? 'خدمة' : 'منتج';
    message += `${index + 1}. *${item.product.name}* [${typeLabel}]\n`;
    message += `   الكمية: ${item.quantity} × ${item.product.price} = ${lineTotal} ${currency}\n`;
  });

  message += `\n━━━━━━━━━━━━━━━━━━━━\n`;
  message += `▫️ قيمة المنتجات: ${subtotal} ${currency}\n`;

  // Paymob Payment Method & Gateway Fee Details
  if (customer.paymentMethod === 'paymob') {
    const channelLabel =
      customer.paymobChannel === 'wallet'
        ? 'محفظة إلكترونية (فودافون كاش / وي باي / أورانج / إتصالات)'
        : customer.paymobChannel === 'kiosk'
        ? 'منافذ دفع (أمان / مصاري)'
        : 'بطاقة بنكية (Visa / Mastercard / ميزة)';

    const fee = customer.paymobFee || 0;
    const finalTotal = customer.paymobTotalPaid ?? subtotal + fee;

    message += `💳 *طريقة الدفع:* مدفوع إلكترونياً عبر Paymob\n`;
    message += `▫️ القناة: ${channelLabel}\n`;
    if (fee > 0) {
      message += `▫️ تكلفة الدفع الإلكتروني (Paymob): ${fee} ${currency}\n`;
    }
    message += `💰 *إجمالي المبلغ المسدد:* ${finalTotal} ${currency}\n`;
    if (customer.paymobTransactionRef) {
      message += `▫️ رقم المعاملة المرجعي: ${customer.paymobTransactionRef}\n`;
    }
    message += `✅ *حالة السداد:* تم الدفع بنجاح إلكترونياً عبر بي موب\n`;
  } else {
    message += `💵 *طريقة الدفع:* الدفع عند الاستلام (نقداً)\n`;
    message += `💰 *إجمالي المطلوب سداده:* ${subtotal} ${currency}\n`;
  }

  message += `📅 التاريخ: ${new Date().toLocaleDateString('ar-EG')}\n\n`;
  message += `يرجى تأكيد استلام الطلب وتجهيزه. شكراً لكم!`;

  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}

/**
 * Generates WhatsApp URL for the header button "طلب كتالوج النشاط",
 * which redirects the customer directly to the MantiqatiX SITE ADMINISTRATION WhatsApp.
 */
export function generateAdminCatalogRequestWhatsAppUrl(
  adminPhone: string,
  businessName: string,
  businessCategory: string
): string {
  const cleanPhone = cleanPhoneNumber(adminPhone);
  
  let message = `مرحباً إدارة MantiqatiX 👋\n\n`;
  message += `أرغب في الحصول على النسخة الرسمية / الكتالوج الكامل للنشاط التجاري التالي:\n`;
  message += `🏢 *اسم النشاط:* ${businessName}\n`;
  message += `🏷️ *التصنيف:* ${businessCategory}\n\n`;
  message += `يرجى إرسال ملف الكتالوج أو تفاصيل النشاط المتاحة عبر المنصة. شكراً لكم!`;

  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}

/**
 * Generates Gmail Web compose URL to invite a subscriber.
 */
export function generateGmailInviteUrl(
  subscriberEmail: string,
  subscriberName: string,
  businessName: string,
  portalUrl: string = 'https://mantiqatix.com',
  username?: string,
  password?: string
): string {
  const subject = `دعوة رسمية وبيانات الدخول لمنصة MantiqatiX - نشاط (${businessName})`;
  
  let body = `عزيزي/عزيزتي ${subscriberName}،\n\n`;
  body += `يسرنا دعوتك وتفعيل حسابك في منصة MantiqatiX للأنشطة التجارية والكتالوجات الذكية لنشاطك: "${businessName}".\n\n`;
  if (username && password) {
    body += `🔑 *بيانات تسجيل الدخول الخاصة بك:*\n`;
    body += `▫️ اسم المستخدم / البريد: ${username}\n`;
    body += `▫️ كلمة المرور: ${password}\n\n`;
  }
  body += `من خلال حسابك يمكنك:\n`;
  body += `1. تخصيص غلاف وشعار نشاطك التجاري (Cover & Logo).\n`;
  body += `2. إضافة وإدارة حتى 150 منتج أو خدمة بأسعارك بالجنيه المصري (ج.م) وتصنيفاتك المخصصة.\n`;
  body += `3. استقبال طلبات الزبائن مباشرة في سلة مخصصة تحوّل فوراً إلى رقم واتساب الخاص بك مع دعم السداد الإلكتروني بـ Paymob.\n`;
  body += `4. الاستفادة من التصنيف الوظيفي المتخصص لنشاطك لتمكين الخصائص المتقدمة.\n\n`;
  body += `🔗 رابط الدخول المباشر لإدارة نشاطك:\n${portalUrl}\n\n`;
  body += `مع أطيب التحيات،\nإدارة منصة MantiqatiX`;

  const encodedTo = encodeURIComponent(subscriberEmail);
  const encodedSubject = encodeURIComponent(subject);
  const encodedBody = encodeURIComponent(body);

  return `https://mail.google.com/mail/?view=cm&fs=1&to=${encodedTo}&su=${encodedSubject}&body=${encodedBody}`;
}

/**
 * Formats direct credentials text for Admin to copy/share with subscriber directly (without sending email)
 */
export function formatDirectCredentialsText(
  subscriberName: string,
  businessName: string,
  identifier: string,
  password: string,
  portalUrl: string
): string {
  let text = `مرحباً ${subscriberName} 👋\n`;
  text += `تم تعيين وتفعيل حساب نشاطك التجاري (${businessName}) بنجاح على منصة MantiqatiX.\n\n`;
  text += `🔐 *بيانات تسجيل الدخول للوحة التحكم:*\n`;
  text += `• البريد / اسم المستخدم: ${identifier}\n`;
  text += `• كلمة المرور: ${password}\n`;
  text += `• رابط تسجيل الدخول:\n${portalUrl}\n\n`;
  text += `يمكنك الآن الدخول وإدارة حتى 150 منتج أو خدمة وتخصيص الغلاف والشعار وتلقي طلبات الواتساب مباشرة.`;
  return text;
}

/**
 * Authenticates a subscriber by email/username and password.
 */
export function authenticateSubscriber(
  subscribers: Subscriber[],
  identifier: string,
  passwordInput: string
): Subscriber | null {
  const cleanId = identifier.trim().toLowerCase();
  const found = subscribers.find((s) => {
    const matchesEmail = s.email.trim().toLowerCase() === cleanId;
    const matchesUsername = s.username && s.username.trim().toLowerCase() === cleanId;
    return matchesEmail || matchesUsername;
  });

  if (!found) return null;
  if (found.password && found.password === passwordInput) {
    return found;
  }
  return null;
}

/**
 * Tenant isolation check:
 * Ensures a subscriber cannot view or edit any business other than their own assigned business!
 */
export function canSubscriberAccessBusiness(
  session: AuthSession,
  targetBusinessId: string
): boolean {
  if (session.role === 'admin') return true;
  if (session.role === 'subscriber') {
    return session.businessId === targetBusinessId;
  }
  return false;
}

/**
 * Generates public customer storefront link with isolated query param
 */
export function generateStorePublicUrl(origin: string, businessSlugOrId: string): string {
  return `${origin}/?store=${encodeURIComponent(businessSlugOrId)}`;
}

/**
 * Filters products based on search term and selected category.
 */
export function filterProducts(products: Product[], searchTerm: string, selectedCategory: string): Product[] {
  return products.filter((prod) => {
    const matchesSearch =
      !searchTerm.trim() ||
      prod.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prod.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory =
      !selectedCategory || selectedCategory === 'all' || prod.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });
}

/**
 * Filters businesses by Functional Group, Category, and text query.
 */
export function filterBusinessesByTaxonomy(
  businesses: Business[],
  functionalGroupId: string = 'all',
  categoryIdOrName: string = 'all',
  searchQuery: string = ''
): Business[] {
  const cleanQuery = searchQuery.trim().toLowerCase();

  return businesses.filter((b) => {
    const matchesGroup =
      functionalGroupId === 'all' || b.functionalGroupId === functionalGroupId;

    const matchesCategory =
      categoryIdOrName === 'all' ||
      b.categoryId === categoryIdOrName ||
      b.category === categoryIdOrName;

    const matchesQuery =
      !cleanQuery ||
      b.name.toLowerCase().includes(cleanQuery) ||
      b.bio.toLowerCase().includes(cleanQuery) ||
      b.category.toLowerCase().includes(cleanQuery) ||
      b.governorate.toLowerCase().includes(cleanQuery) ||
      b.markaz.toLowerCase().includes(cleanQuery) ||
      b.village.toLowerCase().includes(cleanQuery);

    return matchesGroup && matchesCategory && matchesQuery;
  });
}

export interface BackupPayload {
  version: string;
  exportedAt: string;
  platformName: string;
  businesses: Business[];
  products: Product[];
  subscribers: Subscriber[];
  adminSettings: AdminSettings;
}

/**
 * Creates formatted JSON string for backup export.
 */
export function createBackupPayload(
  businesses: Business[],
  products: Product[],
  subscribers: Subscriber[],
  adminSettings: AdminSettings
): string {
  const payload: BackupPayload = {
    version: '3.0',
    exportedAt: new Date().toISOString(),
    platformName: adminSettings.platformName || DEFAULT_PLATFORM_NAME,
    businesses,
    products,
    subscribers,
    adminSettings,
  };
  return JSON.stringify(payload, null, 2);
}

/**
 * Validates a backup payload before restoring.
 */
export function validateAndParseBackup(jsonString: string): {
  valid: boolean;
  data?: BackupPayload;
  error?: string;
} {
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed || typeof parsed !== 'object') {
      return { valid: false, error: 'ملف النسخة الاحتياطية غير صالح أو تالف.' };
    }
    if (!Array.isArray(parsed.businesses)) {
      return { valid: false, error: 'ملف النسخة الاحتياطية يفتقد لقائمة الأنشطة التجارية.' };
    }
    if (!Array.isArray(parsed.products)) {
      return { valid: false, error: 'ملف النسخة الاحتياطية يفتقد لبيانات الكتالوج والمنتجات.' };
    }
    if (!Array.isArray(parsed.subscribers)) {
      return { valid: false, error: 'ملف النسخة الاحتياطية يفتقد لقائمة المشتركين.' };
    }
    return { valid: true, data: parsed as BackupPayload };
  } catch (err: any) {
    return { valid: false, error: `فشل قراءة ملف النسخة الاحتياطية: ${err.message || 'صيغة غير صحيحة'}` };
  }
}

/**
 * Formats Egyptian administrative location string:
 * المحافظة - المركز / القسم - القرية / الحي
 */
export function formatEgyptianLocation(
  governorate?: string,
  markaz?: string,
  village?: string,
  detailedAddress?: string
): string {
  const parts: string[] = [];
  if (governorate?.trim()) parts.push(`محافظة ${governorate.trim()}`);
  if (markaz?.trim()) parts.push(`مركز ${markaz.trim()}`);
  if (village?.trim()) parts.push(`قرية ${village.trim()}`);
  if (detailedAddress?.trim()) parts.push(detailedAddress.trim());

  return parts.length > 0 ? parts.join(' • ') : 'الموقع غير محدد';
}

/**
 * Calculates admin commission for a business based on order count and commission per order (e.g. 0.01 EGP).
 * Strictly hidden from subscriber/merchant view.
 */
export function calculateBusinessCommission(
  ordersCount: number,
  commissionPerOrder: number = DEFAULT_COMMISSION_PER_ORDER
): { totalCommission: number; rate: number; ordersCount: number } {
  const safeCount = Math.max(0, ordersCount);
  const safeRate = commissionPerOrder >= 0 ? commissionPerOrder : DEFAULT_COMMISSION_PER_ORDER;
  const total = Math.round(safeCount * safeRate * 100) / 100;
  return {
    totalCommission: total,
    rate: safeRate,
    ordersCount: safeCount,
  };
}

/**
 * Evaluates payment overdue and page freeze state based on 5-day warning rule:
 * - Days 1 to 5: Daily warning notifications to merchant; storefront still accessible.
 * - Days > 5: Automatic page freeze (isFrozen = true) until Admin confirms payment.
 */
export function evaluatePaymentFreezeStatus(
  paymentStatus: 'paid' | 'pending' | 'overdue' | 'frozen',
  overdueDaysCount: number,
  maxGraceDays: number = OVERDUE_GRACE_PERIOD_DAYS
): {
  isFrozen: boolean;
  effectiveStatus: 'paid' | 'pending' | 'overdue' | 'frozen';
  warningMessage: string | null;
  dayCounterText: string | null;
  canAcceptOrders: boolean;
} {
  if (paymentStatus === 'paid') {
    return {
      isFrozen: false,
      effectiveStatus: 'paid',
      warningMessage: null,
      dayCounterText: null,
      canAcceptOrders: true,
    };
  }

  if (paymentStatus === 'frozen' || overdueDaysCount > maxGraceDays) {
    return {
      isFrozen: true,
      effectiveStatus: 'frozen',
      warningMessage: 'تم تجميد صفحة هذا النشاط مؤقتاً لعدم سداد المستحقات بعد انقضاء مهلة الـ 5 أيام. يرجى مراجعة إدارة المنصة لتأكيد السداد.',
      dayCounterText: `انتهت مهلة السداد (متأخر ${overdueDaysCount} أيام - النشاط مجمد)`,
      canAcceptOrders: false,
    };
  }

  if (overdueDaysCount > 0 && overdueDaysCount <= maxGraceDays) {
    const daysLeft = maxGraceDays - overdueDaysCount;
    return {
      isFrozen: false,
      effectiveStatus: 'overdue',
      warningMessage: `تنبيه سداد دوري: اليوم ${overdueDaysCount} من ${maxGraceDays} للسداد. يرجى سداد المستحقات لإدارة المنصة لتجنب تجميد صفحة الكتالوج بعد ${daysLeft === 0 ? 'نهاية اليوم' : `${daysLeft} أيام`}.`,
      dayCounterText: `إشعار يومي: اليوم ${overdueDaysCount} من ${maxGraceDays}`,
      canAcceptOrders: true,
    };
  }

  return {
    isFrozen: false,
    effectiveStatus: paymentStatus,
    warningMessage: null,
    dayCounterText: 'بانتظار موعد الاستحقاق',
    canAcceptOrders: true,
  };
}

/**
 * Admin action: Confirms payment reception for a business.
 */
export function applyAdminPaymentConfirmation(
  business: Business,
  confirmationDate: string = new Date().toISOString().split('T')[0]
): Business {
  const nextDueDate = new Date(confirmationDate);
  nextDueDate.setMonth(nextDueDate.getMonth() + 1);
  const formattedNextDueDate = nextDueDate.toISOString().split('T')[0];

  return {
    ...business,
    paymentStatus: 'paid',
    isFrozen: false,
    overdueDaysCount: 0,
    paymentConfirmedByAdmin: true,
    lastPaymentDate: confirmationDate,
    paymentDueDate: formattedNextDueDate,
  };
}

/**
 * Simulates daily overdue tick:
 */
export function advanceOverdueDay(
  business: Business,
  maxGraceDays: number = OVERDUE_GRACE_PERIOD_DAYS
): Business {
  const newDays = business.overdueDaysCount + 1;
  const shouldFreeze = newDays > maxGraceDays;

  return {
    ...business,
    overdueDaysCount: newDays,
    paymentStatus: shouldFreeze ? 'frozen' : 'overdue',
    isFrozen: shouldFreeze,
    paymentConfirmedByAdmin: false,
  };
}

/**
 * Ensures every business has a fixed default logo and cover image tailored to its sector from registration until changed by the owner.
 */
export function ensureBusinessStaticImages(
  logoUrl?: string,
  coverUrl?: string,
  functionalGroupId?: FunctionalGroupId | string
): {
  logoUrl: string;
  coverUrl: string;
} {
  return {
    logoUrl: resolveBusinessLogo({ logoUrl, functionalGroupId }),
    coverUrl: resolveBusinessCover({ coverUrl, functionalGroupId }),
  };
}

/**
 * Merges saved functional groups with the canonical 15 DEFAULT_FUNCTIONAL_GROUPS
 * so all 15 sectors and their parenthetical shortNames are always available.
 */
export function mergeFunctionalGroups(
  savedGroups: FunctionalGroup[] | undefined,
  defaultGroups: FunctionalGroup[]
): FunctionalGroup[] {
  if (!savedGroups || !Array.isArray(savedGroups) || savedGroups.length === 0) {
    return defaultGroups;
  }
  return defaultGroups.map((defGroup) => {
    const existing = savedGroups.find((g) => g.id === defGroup.id);
    if (!existing) return defGroup;
    return {
      ...defGroup,
      ...existing,
      // Always enforce the exact parenthetical shortName requested for the main screen
      shortName: defGroup.shortName,
      name: defGroup.name,
    };
  });
}

/**
 * Returns default permissions and limits for each subscription tier ('free' | 'regular' | 'advanced').
 */
export function getDefaultTierConfiguration(tier: SubscriptionPlanTier): {
  maxAllowedBusinesses: number;
  maxProductsLimit: number;
  monthlySubscriptionFee: number;
  commissionPercentage: number;
  commissionFixed: number;
  creditLimit: number;
  permissions: BusinessPermissions;
} {
  if (tier === 'free') {
    return {
      maxAllowedBusinesses: 1,
      maxProductsLimit: 25,
      monthlySubscriptionFee: 0,
      commissionPercentage: 2.0,
      commissionFixed: 2.0,
      creditLimit: 500,
      permissions: {
        enableWhatsAppCart: true,
        enablePaymob: false,
        enableEmployees: false,
        enableCustomLinks: true,
        enableSponsoredAds: false,
        enableFinancialSystem: true,
        enableAiTools: false,
      },
    };
  }
  if (tier === 'advanced') {
    return {
      maxAllowedBusinesses: 5,
      maxProductsLimit: 300,
      monthlySubscriptionFee: 1000,
      commissionPercentage: 0.5,
      commissionFixed: 1.0,
      creditLimit: 10000,
      permissions: {
        enableWhatsAppCart: true,
        enablePaymob: true,
        enableEmployees: true,
        enableCustomLinks: true,
        enableSponsoredAds: true,
        enableFinancialSystem: true,
        enableAiTools: true,
      },
    };
  }
  // 'regular'
  return {
    maxAllowedBusinesses: 2,
    maxProductsLimit: 150,
    monthlySubscriptionFee: 500,
    commissionPercentage: 1.0,
    commissionFixed: 2.0,
    creditLimit: 3000,
    permissions: {
      enableWhatsAppCart: true,
      enablePaymob: true,
      enableEmployees: true,
      enableCustomLinks: true,
      enableSponsoredAds: false,
      enableFinancialSystem: true,
      enableAiTools: false,
    },
  };
}

/**
 * Validates the "أرغب في اشتراك نشاطي" / Free Directory registration form.
 * Requires at minimum: Business Name, Phone/WhatsApp, Governorate, and Markaz.
 */
export function validateSubscriptionRequestInput(input: {
  businessName: string;
  phoneOrWhatsApp: string;
  governorate: string;
  markaz: string;
}): { valid: boolean; error?: string } {
  if (!input.businessName || !input.businessName.trim()) {
    return { valid: false, error: 'يرجى إدخال اسم النشاط التجاري أو الخدمي.' };
  }
  const cleanPhone = cleanPhoneNumber(input.phoneOrWhatsApp);
  if (!cleanPhone || cleanPhone.length < 8) {
    return { valid: false, error: 'يرجى إدخال رقم هاتف أو واتساب صحيح للتواصل.' };
  }
  if (!input.governorate || !input.governorate.trim()) {
    return { valid: false, error: 'يرجى تحديد المحافظة.' };
  }
  if (!input.markaz || !input.markaz.trim()) {
    return { valid: false, error: 'يرجى إدخال المركز أو المدينة.' };
  }
  return { valid: true };
}

/**
 * Generates formatted WhatsApp URL for the "تواصل معنا" form submission.
 */
export function generateContactUsWhatsAppUrl(
  adminPhone: string,
  data: {
    senderName: string;
    senderPhone: string;
    messageType: ContactMessageType;
    subject: string;
    content: string;
    relatedBusinessName?: string;
  }
): string {
  const cleanAdmin = cleanPhoneNumber(adminPhone);
  const typeLabels: Record<ContactMessageType, string> = {
    message: 'رسالة عامة ✉️',
    request: 'طلب خدمة أو اشتراك 📋',
    complaint: 'شكوى أو بلاغ ⚠️',
    inquiry: 'استفسار فني أو تجاري ❓',
  };

  let text = `📬 *تواصل جديد عبر منصة MantiqatiX*\n`;
  text += `━━━━━━━━━━━━━━━━━━━━\n`;
  text += `🏷️ *نوع المراسلة:* ${typeLabels[data.messageType] || 'رسالة'}\n`;
  text += `👤 *الاسم:* ${data.senderName.trim()}\n`;
  text += `📱 *الهاتف / الواتساب:* ${data.senderPhone.trim()}\n`;
  if (data.relatedBusinessName?.trim()) {
    text += `🏢 *النشاط المرتبط:* ${data.relatedBusinessName.trim()}\n`;
  }
  text += `📌 *الموضوع:* ${data.subject.trim()}\n`;
  text += `📝 *التفاصيل:*\n${data.content.trim()}\n`;
  text += `━━━━━━━━━━━━━━━━━━━━\n`;
  text += `📅 التاريخ: ${new Date().toLocaleDateString('ar-EG')}`;

  return `https://wa.me/${cleanAdmin}?text=${encodeURIComponent(text)}`;
}

// ============================================================================
// ENTERPRISE WALLET, LEDGER & SMART MARKETING ENGINE
// ============================================================================

export const ADMIN_MAIN_WALLET_ID = 'wallet_admin_main';

/**
 * Initializes normalized multi-tier wallets for Platform Admin, Businesses, and Subscribers.
 */
export function createInitialPlatformWallets(
  businesses: Business[],
  subscribers: Subscriber[] = []
): WalletAccount[] {
  const nowStr = new Date().toISOString().split('T')[0];

  const adminWallet: WalletAccount = {
    id: ADMIN_MAIN_WALLET_ID,
    ownerType: 'admin',
    ownerId: 'admin_root',
    ownerName: 'محفظة الإدارة العامة (MantiqatiX)',
    availableBalance: 48500,
    pendingBalance: 3200,
    creditLimit: 1000000,
    usedCredit: 0,
    adGrantBalance: 999999,
    totalDeposited: 55000,
    totalSpentOnAds: 0,
    currency: DEFAULT_CURRENCY,
    isFreeSponsoredAdsEnabled: true,
    status: 'active',
    updatedAt: nowStr,
  };

  const businessWallets: WalletAccount[] = businesses.map((b, idx) => ({
    id: `wallet_biz_${b.id}`,
    ownerType: 'business',
    ownerId: b.id,
    ownerName: `محفظة نشاط: ${b.name}`,
    availableBalance: b.isVerified ? 1200 + (idx % 5) * 450 : 250,
    pendingBalance: b.isVerified ? 150 : 0,
    creditLimit: b.creditLimit ?? (b.subscriptionTier === 'advanced' ? 10000 : b.subscriptionTier === 'regular' ? 3000 : 500),
    usedCredit: b.usedCreditBalance ?? b.usedCredit ?? 0,
    adGrantBalance: b.subscriptionTier === 'advanced' ? 500 : 100,
    totalDeposited: b.isVerified ? 2000 : 250,
    totalSpentOnAds: b.isVerified ? 300 : 0,
    currency: DEFAULT_CURRENCY,
    isFreeSponsoredAdsEnabled: false,
    status: b.isFrozen ? 'frozen' : 'active',
    updatedAt: nowStr,
  }));

  const subscriberWallets: WalletAccount[] = subscribers.map((s) => ({
    id: `wallet_sub_${s.id}`,
    ownerType: 'subscriber',
    ownerId: s.id,
    ownerName: `محفظة المشترك: ${s.fullName}`,
    availableBalance: s.walletBalance ?? 850,
    pendingBalance: 0,
    creditLimit: 2000,
    usedCredit: 0,
    adGrantBalance: 150,
    totalDeposited: s.walletBalance ?? 850,
    totalSpentOnAds: 0,
    currency: DEFAULT_CURRENCY,
    isFreeSponsoredAdsEnabled: false,
    status: s.status === 'suspended' ? 'frozen' : 'active',
    updatedAt: nowStr,
  }));

  return [adminWallet, ...businessWallets, ...subscriberWallets];
}

/**
 * Pure atomic ledger processor for Wallet operations.
 * Guarantees 0 EGP charge for Admin Free Sponsored Ad Grants.
 */
export function executeWalletLedgerOperation(
  wallet: WalletAccount,
  input: {
    type: WalletTransactionType;
    amount: number;
    description: string;
    paymentMethod?: WalletPaymentChannel;
    referenceId?: string;
    isFreeAdminGrant?: boolean;
  }
): {
  success: boolean;
  error?: string;
  updatedWallet: WalletAccount;
  transaction?: WalletTransaction;
} {
  if (wallet.status === 'frozen' && input.type !== 'deposit' && input.type !== 'credit_settlement') {
    return {
      success: false,
      error: 'هذه المحفظة مجمدة حالياً؛ يرجى شحن الرصيد أو تسوية المديونية أولاً.',
      updatedWallet: wallet,
    };
  }

  const safeAmount = Math.max(0, Math.round(input.amount * 100) / 100);
  const nowStr = new Date().toLocaleString('ar-EG', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });

  // Free Admin Ad Grant or Admin-owned wallet publishing Sponsored Ad -> 0 EGP deducted
  if (
    input.type === 'admin_free_ad_grant' ||
    input.isFreeAdminGrant ||
    (input.type === 'ad_payment' && wallet.isFreeSponsoredAdsEnabled)
  ) {
    const tx: WalletTransaction = {
      id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      walletId: wallet.id,
      ownerName: wallet.ownerName,
      type: 'admin_free_ad_grant',
      amount: 0,
      balanceAfter: wallet.availableBalance,
      description: input.description || 'إعلان ممول مجاني 100% معتمد من إدارة المنصة (0 ج.م)',
      paymentMethod: 'admin_grant',
      referenceId: input.referenceId,
      isFreeAdminGrant: true,
      status: 'completed',
      createdAt: nowStr,
    };

    return {
      success: true,
      updatedWallet: {
        ...wallet,
        updatedAt: nowStr,
      },
      transaction: tx,
    };
  }

  if (safeAmount <= 0) {
    return {
      success: false,
      error: 'يرجى إدخال قيمة مالية صحيحة أكبر من صفر.',
      updatedWallet: wallet,
    };
  }

  let newBalance = wallet.availableBalance;
  let newUsedCredit = wallet.usedCredit;
  let newTotalDeposited = wallet.totalDeposited;
  let newTotalSpentOnAds = wallet.totalSpentOnAds;

  if (input.type === 'deposit' || input.type === 'cashback') {
    newBalance = Math.round((wallet.availableBalance + safeAmount) * 100) / 100;
    newTotalDeposited = Math.round((wallet.totalDeposited + safeAmount) * 100) / 100;
  } else if (input.type === 'credit_settlement') {
    if (wallet.availableBalance < safeAmount) {
      return {
        success: false,
        error: 'الرصيد المتاح غير كافٍ لتسوية هذا المبلغ من الائتمان.',
        updatedWallet: wallet,
      };
    }
    newBalance = Math.round((wallet.availableBalance - safeAmount) * 100) / 100;
    newUsedCredit = Math.max(0, Math.round((wallet.usedCredit - safeAmount) * 100) / 100);
  } else {
    // withdrawal, commission_deduction, ad_payment
    const remainingCredit = Math.max(0, wallet.creditLimit - wallet.usedCredit);
    const totalPurchasingPower = wallet.availableBalance + remainingCredit;

    if (safeAmount > totalPurchasingPower) {
      return {
        success: false,
        error: `الرصيد المتاح وحد الائتمان غير كافيين لإتمام العملية (${safeAmount} ${wallet.currency}).`,
        updatedWallet: wallet,
      };
    }

    if (wallet.availableBalance >= safeAmount) {
      newBalance = Math.round((wallet.availableBalance - safeAmount) * 100) / 100;
    } else {
      const shortfall = safeAmount - wallet.availableBalance;
      newBalance = 0;
      newUsedCredit = Math.round((wallet.usedCredit + shortfall) * 100) / 100;
    }

    if (input.type === 'ad_payment') {
      newTotalSpentOnAds = Math.round((wallet.totalSpentOnAds + safeAmount) * 100) / 100;
    }
  }

  const updatedWallet: WalletAccount = {
    ...wallet,
    availableBalance: newBalance,
    usedCredit: newUsedCredit,
    totalDeposited: newTotalDeposited,
    totalSpentOnAds: newTotalSpentOnAds,
    updatedAt: nowStr,
  };

  const tx: WalletTransaction = {
    id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    walletId: wallet.id,
    ownerName: wallet.ownerName,
    type: input.type,
    amount: safeAmount,
    balanceAfter: newBalance,
    description: input.description,
    paymentMethod: input.paymentMethod || 'vodafone_cash',
    referenceId: input.referenceId,
    isFreeAdminGrant: false,
    status: 'completed',
    createdAt: nowStr,
  };

  return {
    success: true,
    updatedWallet,
    transaction: tx,
  };
}

/**
 * Generates an integrated multi-channel marketing campaign package for any Business.
 * Sponsored Ads generated by Admin are 100% FREE (adCostEgp = 0).
 */
export function generateBusinessMarketingCampaign(
  business: Business,
  options?: {
    goal?: MarketingCampaignGoal;
    discountPercent?: number;
    customOfferText?: string;
    isAdminMode?: boolean;
    featuredProducts?: Product[];
  }
): GeneratedMarketingCampaign {
  const goal: MarketingCampaignGoal = options?.goal || 'sales_boost';
  const discount = options?.discountPercent ?? 25;
  const isAdminMode = options?.isAdminMode ?? true;
  const locationText = `${business.governorate}${business.markaz ? ` - ${business.markaz}` : ''}`;
  const cleanPhone = business.phone || business.ownerWhatsApp || '01010171770';
  const slugCode = (business.slug || business.id).replace(/[^a-zA-Z0-9]/g, '').toUpperCase().slice(0, 4) || 'MX';
  const promoCode = `${slugCode}${discount}`;

  const topItems =
    options?.featuredProducts && options.featuredProducts.length > 0
      ? options.featuredProducts
          .slice(0, 3)
          .map((p) => `${p.name} (${p.price} ج.م)`)
          .join(' • ')
      : business.bio || `أفضل خدمات ومنتجات ${business.category}`;

  const goalHeadlines: Record<MarketingCampaignGoal, { headline: string; sub: string; cta: string }> = {
    sales_boost: {
      headline: `🔥 عرض حصري من ${business.name} — خصم ${discount}% لفترة محدودة!`,
      sub: `أقوى العروض والأسعار في ${locationText} ضمن قطاع ${business.category}`,
      cta: 'اطلب العرض الآن عبر واتساب',
    },
    grand_opening: {
      headline: `🎉 انطلاقة كبرى وباقات ترحيبية خاصة في ${business.name}`,
      sub: `ندعوكم لزيارتنا في ${locationText} والاستمتاع بخصم الافتتاح ${discount}%`,
      cta: 'احجز هديتك وتعرف علينا',
    },
    seasonal_offer: {
      headline: `✨ مهرجان التوفير الموسمى لدى ${business.name} بخصم ${discount}%`,
      sub: `تشكيلة متكاملة وجودة مضمونة لعملائنا في ${locationText}`,
      cta: 'اغتنم العرض قبل النفاد',
    },
    brand_awareness: {
      headline: `⭐ ${business.name} — الاسم الأول للثقة والجودة في ${business.category}`,
      sub: `خدمة احترافية معتمدة في ${locationText} (${business.workingHours || 'يومياً'})`,
      cta: 'تصفح الكتالوج وتواصل معنا',
    },
    service_booking: {
      headline: `📅 احجز موعدك أو خدمتك فوراً مع ${business.name} بخصم ${discount}%`,
      sub: `استجابة فورية وخدمة مميزة في ${locationText} — كود الخصم: ${promoCode}`,
      cta: 'احجز موعدك الآن',
    },
  };

  const selectedGoalMeta = goalHeadlines[goal];
  const customNote = options?.customOfferText?.trim()
    ? ` ${options.customOfferText.trim()}`
    : '';

  const sponsoredAdCopy = `${selectedGoalMeta.headline} — ${topItems}.${customNote} استخدم كود (${promoCode}) واحصل على خصم ${discount}% فوري عند الطلب من ${business.name} (${locationText}).`;

  const facebookInstagramCopy = [
    `${selectedGoalMeta.headline}`,
    `📍 الموقع: ${locationText} ${business.address ? `- ${business.address}` : ''}`,
    `✨ لماذا تختار ${business.name}؟`,
    `• ${topItems}`,
    customNote ? `• عرض إضافي: ${customNote}` : `• جودة عالية وأسعار تنافسية في ${business.category}`,
    `🎁 كود الخصم الحصري لعملاء منصة MantiqatiX: [${promoCode}] (خصم ${discount}%)`,
    `📲 للطلب والاستفسار واتساب أو اتصال: ${cleanPhone}`,
    `#${business.category.replace(/\s+/g, '_')} #${business.governorate.replace(/\s+/g, '_')} #MantiqatiX #عروض_مميزة`,
  ].join('\n');

  const whatsappBroadcastCopy = [
    `مرحباً بك من *${business.name}* 👋`,
    `يسعدنا تقديم عرضنا الحصري لعملاء *منصة MantiqatiX*:`,
    `🔥 *${selectedGoalMeta.headline}*`,
    `📦 أبرز ما نقدمه: ${topItems}`,
    `🎟️ كود الخصم الفوري: *${promoCode}*`,
    `📍 العنوان: ${locationText} ${business.address ? `- ${business.address}` : ''}`,
    `📞 للتواصل المباشر والطلب السريع: ${cleanPhone}`,
  ].join('\n');

  const reelsVideoScript = [
    `🎬 [المشهد 1 - أول 3 ثوانٍ جذب انتباه]: هل تبحث عن أفضل ${business.category} في ${locationText}؟`,
    `🎥 [المشهد 2 - استعراض المميزات]: في "${business.name}" وفرنا لك (${topItems}) بأعلى جودة وأسرع خدمة!`,
    `💥 [المشهد 3 - المفاجأة والعرض]: اطلب الآن عبر دليل MantiqatiX واستخدم كود (${promoCode}) لخصم ${discount}% فوري!`,
    `📲 [الخاتمة Call To Action]: اضغط على زر النشاط أو تواصل معنا على ${cleanPhone}.`,
  ].join('\n');

  const billboardBannerText = `${business.name} (${business.category}) • خصم ${discount}% بكود ${promoCode} • ${locationText}`;

  return {
    id: `mkt_cmp_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    businessId: business.id,
    businessName: business.name,
    category: business.category,
    functionalGroupId: business.functionalGroupId,
    governorate: business.governorate,
    markaz: business.markaz,
    goal,
    headline: selectedGoalMeta.headline,
    subheadline: selectedGoalMeta.sub,
    sponsoredAdCopy,
    facebookInstagramCopy,
    whatsappBroadcastCopy,
    reelsVideoScript,
    billboardBannerText,
    ctaText: selectedGoalMeta.cta,
    promoCode,
    discountPercent: discount,
    targetAudience: [
      `سكان محافظة ${business.governorate}`,
      business.markaz ? `أهالي مركز ${business.markaz}` : 'المراكز المجاورة',
      `المهتمون بقطاع ${business.category}`,
      'المتسوقون عبر الكتالوجات الرقمية والواتساب',
    ],
    seoKeywords: [
      business.name,
      business.category,
      `${business.category} في ${business.governorate}`,
      `عروض ${business.name}`,
      'MantiqatiX',
    ],
    estimatedReach: business.isVerified ? 28500 : 12400,
    adCostEgp: isAdminMode ? 0 : 150,
    isFreeForAdmin: isAdminMode,
    createdAt: new Date().toISOString().split('T')[0],
  };
}

/**
 * Curates "اخترنا لك" (Picked For You) businesses for the Home Screen,
 * prioritizing verified businesses across diverse functional groups.
 */
export function getPickedForYouBusinesses(businesses: Business[], limit: number = 6): Business[] {
  const verifiedActive = businesses.filter((b) => b.isVerified && !b.isFrozen);
  const selected: Business[] = [];
  const seenGroups = new Set<string>();

  for (const biz of verifiedActive) {
    if (!seenGroups.has(biz.functionalGroupId)) {
      selected.push(biz);
      seenGroups.add(biz.functionalGroupId);
      if (selected.length >= limit) return selected;
    }
  }

  for (const biz of verifiedActive) {
    if (!selected.some((s) => s.id === biz.id)) {
      selected.push(biz);
      if (selected.length >= limit) return selected;
    }
  }

  return selected;
}

/**
 * Ranks "الأكثر طلباً" (Most Requested) businesses for the Home Screen
 * sorted descending by totalOrdersCount and viewsCount.
 */
export function getMostRequestedBusinesses(businesses: Business[], limit: number = 6): Business[] {
  return [...businesses]
    .filter((b) => !b.isFrozen)
    .sort((a, b) => {
      const scoreA = (a.totalOrdersCount || 0) * 10 + (a.viewsCount || 0) + (a.isVerified ? 500 : 0);
      const scoreB = (b.totalOrdersCount || 0) * 10 + (b.viewsCount || 0) + (b.isVerified ? 500 : 0);
      return scoreB - scoreA;
    })
    .slice(0, limit);
}

/**
 * Builds an enterprise-grade normalized state architecture summary.
 */
export function buildEnterpriseStateSummary(params: {
  businesses: Business[];
  products: Product[];
  wallets: WalletAccount[];
  transactions: WalletTransaction[];
  campaigns: GeneratedMarketingCampaign[];
  adRequests: AdRequest[];
}): EnterpriseStateArchitectureSummary {
  const verifiedCount = params.businesses.filter((b) => b.isVerified).length;
  const liquidity = params.wallets.reduce((sum, w) => sum + (w.availableBalance || 0), 0);

  return {
    schemaVersion: '4.0.0-enterprise',
    totalBusinesses: params.businesses.length,
    verifiedBusinesses: verifiedCount,
    freeDirectoryBusinesses: params.businesses.length - verifiedCount,
    totalProducts: params.products.length,
    totalWallets: params.wallets.length,
    totalLedgerTransactions: params.transactions.length,
    totalGeneratedCampaigns: params.campaigns.length,
    activeSponsoredAds: params.adRequests.filter((a) => a.status === 'approved').length,
    totalPlatformLiquidityEgp: Math.round(liquidity * 100) / 100,
    lastSyncedAt: new Date().toISOString(),
  };
}

// ============================================================================
// 15-SECTOR SPECIALIZED DEVELOPMENT & 3-TIER PACKAGE ENGINE
// ============================================================================

/**
 * Returns the specialized 3-tier blueprint and operational tools for any of the 15 sectors.
 */
export function getSectorDevelopmentBlueprint(
  functionalGroupId: FunctionalGroupId
): SectorDevelopmentBlueprint {
  return (
    SECTOR_DEVELOPMENT_BLUEPRINTS[functionalGroupId] ||
    SECTOR_DEVELOPMENT_BLUEPRINTS.dining
  );
}

/**
 * Returns all 15 sector blueprints in canonical order.
 */
export function getAllSectorDevelopmentBlueprints(): SectorDevelopmentBlueprint[] {
  return Object.values(SECTOR_DEVELOPMENT_BLUEPRINTS);
}

/**
 * Resolves the active 3-tier package level (1 | 2 | 3) for a business.
 */
export function resolveBusinessSectorLevel(business: Business): SectorPackageLevel {
  if (business.sectorPackageLevel === 1 || business.sectorPackageLevel === 2 || business.sectorPackageLevel === 3) {
    return business.sectorPackageLevel;
  }
  if (business.subscriptionTier === 'advanced') return 3;
  if (business.subscriptionTier === 'regular') return 2;
  if (business.subscriptionTier === 'free') return 1;
  // Default verified businesses to Level 2 (Growth Pro) if not explicitly set, and unverified to Level 1
  return business.isVerified ? 2 : 1;
}

/**
 * Returns the active SectorTierPackageSpec for a given business.
 */
export function getBusinessActiveSectorTierSpec(business: Business): SectorTierPackageSpec {
  const blueprint = getSectorDevelopmentBlueprint(business.functionalGroupId);
  const level = resolveBusinessSectorLevel(business);
  return blueprint.tiers.find((t) => t.level === level) || blueprint.tiers[0];
}

/**
 * Returns unlocked and locked sector-specific interactive tools for a business based on its package level.
 */
export function getUnlockedSectorToolsForBusiness(business: Business): {
  activeLevel: SectorPackageLevel;
  activeTierSpec: SectorTierPackageSpec;
  unlockedTools: SectorInteractiveTool[];
  lockedTools: SectorInteractiveTool[];
  allCumulativeFeatures: string[];
} {
  const blueprint = getSectorDevelopmentBlueprint(business.functionalGroupId);
  const activeLevel = resolveBusinessSectorLevel(business);
  const activeTierSpec = blueprint.tiers.find((t) => t.level === activeLevel) || blueprint.tiers[0];

  const unlockedTools = blueprint.interactiveTools.filter((t) => t.requiredLevel <= activeLevel);
  const lockedTools = blueprint.interactiveTools.filter((t) => t.requiredLevel > activeLevel);

  const allCumulativeFeatures = blueprint.tiers
    .filter((t) => t.level <= activeLevel)
    .flatMap((t) => t.sectorExclusiveFeatures);

  return {
    activeLevel,
    activeTierSpec,
    unlockedTools,
    lockedTools,
    allCumulativeFeatures,
  };
}

/**
 * Upgrades or sets a business to a specific 3-tier sector package level (1, 2, or 3),
 * automatically updating its subscriptionTier, limits, commissions, credit limit, and permissions.
 */
export function applySectorPackageUpgradeToBusiness(
  business: Business,
  targetLevel: SectorPackageLevel
): Business {
  const blueprint = getSectorDevelopmentBlueprint(business.functionalGroupId);
  const spec = blueprint.tiers.find((t) => t.level === targetLevel) || blueprint.tiers[0];
  const baseConfig = getDefaultTierConfiguration(spec.tierKey);

  return {
    ...business,
    isVerified: targetLevel >= 2 ? true : business.isVerified,
    verificationStatus: targetLevel >= 2 ? 'verified' : business.verificationStatus || 'unverified',
    sectorPackageLevel: targetLevel,
    subscriptionTier: spec.tierKey,
    maxProductsLimit: spec.maxProducts,
    maxAllowedBusinesses: spec.maxBranches,
    monthlySubscriptionFee: spec.monthlyFeeEgp,
    commissionPercentage: spec.commissionPercentage,
    commissionFixed: spec.commissionFixedEgp,
    creditLimit: spec.creditLimitEgp,
    permissions: baseConfig.permissions,
  };
}

/**
 * Generates a formatted WhatsApp action URL when a customer or business owner triggers
 * one of the sector-specific interactive tools.
 */
export function generateSectorToolWhatsAppActionUrl(
  business: Business,
  tool: SectorInteractiveTool,
  customDetails: string,
  customerName?: string,
  customerPhone?: string
): string {
  const blueprint = getSectorDevelopmentBlueprint(business.functionalGroupId);
  const cleanPhone = cleanPhoneNumber(business.ownerWhatsApp || business.phone || '201010171770');

  let text = `${blueprint.emoji} *طلب خدمة قطاعية متخصصة عبر منصة MantiqatiX*\n`;
  text += `━━━━━━━━━━━━━━━━━━━━\n`;
  text += `🏢 *النشاط:* ${business.name}\n`;
  text += `📂 *القطاع:* ${blueprint.shortName} (${blueprint.fullName})\n`;
  text += `⚡ *الأداة / الخدمة المطلوبة:* ${tool.title}\n`;
  text += `🏅 *مستوى الباقة:* المستوى ${tool.requiredLevel}\n`;
  if (customerName?.trim()) {
    text += `👤 *اسم العميل:* ${customerName.trim()}\n`;
  }
  if (customerPhone?.trim()) {
    text += `📱 *رقم التواصل:* ${customerPhone.trim()}\n`;
  }
  text += `\n📝 *التفاصيل المطلوبة:*\n${customDetails.trim() || tool.placeholderHint}\n`;
  text += `━━━━━━━━━━━━━━━━━━━━\n`;
  text += `📅 التاريخ: ${new Date().toLocaleDateString('ar-EG')}`;

  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
}

// ============================================================================
// NON-COMPETING & COMPLEMENTARY CROSS-SECTOR SPONSORED ADS ENGINE
// (منع التعارض والمنافسة المباشرة داخل صفحات الأنشطة والصفحات العامة)
// ============================================================================

/**
 * Defines complementary (non-competing) sectors for each of the 15 functional groups.
 * Example: Inside a Restaurant ('dining'), never show another Restaurant; instead show
 * Healthcare (Pharmacies), Retail (Fashion/Electronics), Events, Fitness, or Transport.
 */
export const COMPLEMENTARY_SECTOR_AFFINITY: Record<FunctionalGroupId, FunctionalGroupId[]> = {
  dining: ['retail', 'healthcare', 'events_entertainment', 'transport_logistics', 'sports_fitness', 'technology_software'],
  retail: ['dining', 'services', 'transport_logistics', 'healthcare', 'events_entertainment', 'real_estate'],
  services: ['retail', 'dining', 'technology_software', 'legal_financial', 'education_training', 'healthcare'],
  healthcare: ['sports_fitness', 'dining', 'retail', 'education_training', 'services', 'tourism_hotels'],
  crafts_maintenance: ['real_estate', 'retail', 'industrial_manufacturing', 'transport_logistics', 'dining', 'technology_software'],
  education_training: ['technology_software', 'retail', 'sports_fitness', 'dining', 'healthcare', 'services'],
  real_estate: ['crafts_maintenance', 'industrial_manufacturing', 'legal_financial', 'retail', 'transport_logistics', 'services'],
  tourism_hotels: ['dining', 'transport_logistics', 'events_entertainment', 'retail', 'healthcare', 'services'],
  transport_logistics: ['retail', 'industrial_manufacturing', 'agriculture_livestock', 'dining', 'crafts_maintenance', 'real_estate'],
  agriculture_livestock: ['transport_logistics', 'industrial_manufacturing', 'healthcare', 'legal_financial', 'retail', 'crafts_maintenance'],
  technology_software: ['services', 'legal_financial', 'education_training', 'retail', 'industrial_manufacturing', 'dining'],
  sports_fitness: ['healthcare', 'dining', 'retail', 'education_training', 'tourism_hotels', 'events_entertainment'],
  events_entertainment: ['dining', 'tourism_hotels', 'retail', 'services', 'transport_logistics', 'healthcare'],
  legal_financial: ['real_estate', 'industrial_manufacturing', 'technology_software', 'services', 'retail', 'transport_logistics'],
  industrial_manufacturing: ['transport_logistics', 'legal_financial', 'real_estate', 'technology_software', 'agriculture_livestock', 'crafts_maintenance'],
};

/**
 * Checks whether a candidate ad (or its linked business) directly competes with a host business.
 * Returns true if the ad belongs to a DIFFERENT business in the SAME functionalGroupId or SAME category.
 */
export function isAdCompetingWithHostBusiness(
  hostBusiness: Business,
  candidateBusiness?: Business | null,
  adTextOrTitle?: string
): boolean {
  if (!candidateBusiness) {
    // Check if the ad text mentions the exact same category as the host business
    if (adTextOrTitle && hostBusiness.category && adTextOrTitle.includes(hostBusiness.category)) {
      return true;
    }
    return false;
  }

  // Never show the host business's direct competitors (different business ID, same sector or category)
  if (candidateBusiness.id === hostBusiness.id) {
    // Self-ad is not a competitor, though for cross-promotion we also prefer complementary businesses
    return false;
  }

  if (candidateBusiness.functionalGroupId === hostBusiness.functionalGroupId) {
    return true;
  }

  if (
    candidateBusiness.category &&
    hostBusiness.category &&
    candidateBusiness.category.trim() === hostBusiness.category.trim()
  ) {
    return true;
  }

  return false;
}

export interface ContextualSponsoredAdItem extends AdRequest {
  resolvedBusiness?: Business;
  sectorBlueprint: SectorDevelopmentBlueprint;
  affinityLabel: string;
  isNonCompetingVerified: boolean;
  isVerifiedSubscriber?: boolean;
  subscriberName?: string;
  subscriberId?: string;
  verifiedQuotaLabel?: string;
  // Smart Package, Product Discount & Image
  discountedProduct?: Product;
  discountPercent?: number;
  discountSavingsEgp?: number;
  packageTierLevel?: SectorPackageLevel;
  packageTierName?: string;
  oneLineSummary?: string;
  smartRankingScore?: number;
}

/**
 * Returns non-competing, complementary square (1:1) sponsored ads for ANY business storefront
 * or platform page (Directory, Medical Directory, Site Map, Contact Us).
 * Guarantees:
 * 1. Zero competing businesses in the same sector.
 * 2. Smart exchange: >= 50% guaranteed verified subscribers, ranked intelligently by:
 *    - Package tier (Level 3 VIP > Level 2 Pro > Level 1 Free)
 *    - Active products with discounts (comparePrice > price)
 *    - High-quality photo/image
 * 3. Dynamic expansion: As more ads exist, positions increase automatically.
 */
export function getNonCompetingSponsoredAdsForContext(params: {
  adRequests: AdRequest[];
  businesses: Business[];
  subscribers?: Subscriber[];
  products?: Product[];
  hostBusiness?: Business | null;
  excludeFunctionalGroupId?: FunctionalGroupId | null;
  limit?: number;
}): {
  ads: ContextualSponsoredAdItem[];
  blockedCompetitorsCount: number;
  hostSectorShortName?: string;
  verifiedSubscribersCount: number;
  verifiedSubscribersRatioPercent: number;
  totalAvailableAdsCount: number;
} {
  const minLimit = params.limit ?? 5; // Default minimum pool of 5 sponsored ads
  const {
    adRequests,
    businesses,
    subscribers = [],
    products = [],
    hostBusiness,
    excludeFunctionalGroupId,
  } = params;
  const approvedAds = adRequests.filter((a) => a.status === 'approved');

  const forbiddenGroup: FunctionalGroupId | null =
    hostBusiness?.functionalGroupId || excludeFunctionalGroupId || null;

  const preferredComplementaryGroups: FunctionalGroupId[] = forbiddenGroup
    ? COMPLEMENTARY_SECTOR_AFFINITY[forbiddenGroup] || []
    : [];

  let blockedCompetitorsCount = 0;
  const usedBizIds = new Set<string>();
  if (hostBusiness) {
    usedBizIds.add(hostBusiness.id); // Keep cross-network ads strictly from other non-competing businesses
  }

  // 1. Gather all Verified Subscriber businesses candidates (المشتركين الموثقين)
  const verifiedSubscriberCandidates = businesses.filter((b) => {
    if (b.isFrozen) return false;
    if (!b.isVerified) return false;
    if (usedBizIds.has(b.id)) return false;
    if (hostBusiness && isAdCompetingWithHostBusiness(hostBusiness, b)) {
      blockedCompetitorsCount++;
      return false;
    }
    if (forbiddenGroup && b.functionalGroupId === forbiddenGroup) {
      blockedCompetitorsCount++;
      return false;
    }
    return true;
  });

  // Helper to score and rank verified businesses intelligently by:
  // (A) Package Tier (المستوى 3 الذهبي > المستوى 2 > المستوى 1)
  // (B) Products with discounts (comparePrice > price)
  // (C) Availability of crisp product image / photo
  // (D) Geographic / Sector affinity
  const getCandidateScoreAndBestProduct = (biz: Business) => {
    const tierLevel: SectorPackageLevel =
      biz.sectorPackageLevel ||
      (biz.subscriptionTier === 'advanced' ? 3 : biz.subscriptionTier === 'regular' ? 2 : 1);
    const tierWeight = tierLevel === 3 ? 350 : tierLevel === 2 ? 220 : 100;

    // Look for products belonging to this business
    const bizProducts = products.filter((p) => p.businessId === biz.id && p.isAvailable);
    const discountedProducts = bizProducts.filter(
      (p) => typeof p.comparePrice === 'number' && p.comparePrice > p.price
    );

    // Sort by largest discount savings
    discountedProducts.sort((a, b) => {
      const aSavings = (a.comparePrice || a.price) - a.price;
      const bSavings = (b.comparePrice || b.price) - b.price;
      return bSavings - aSavings;
    });

    const bestDiscountProd = discountedProducts[0] || null;
    const hasPhoto = Boolean(
      (bestDiscountProd && bestDiscountProd.imageUrl) || (biz.coverUrl && biz.coverUrl.trim().length > 0)
    );

    let discountBonus = 0;
    let discountPct = 0;
    if (bestDiscountProd && bestDiscountProd.comparePrice) {
      discountPct = Math.round(
        ((bestDiscountProd.comparePrice - bestDiscountProd.price) / bestDiscountProd.comparePrice) * 100
      );
      discountBonus = 150 + Math.min(50, discountPct);
    } else if (bizProducts.length > 0) {
      discountBonus = 40;
    }

    const aPref = preferredComplementaryGroups.indexOf(biz.functionalGroupId);
    const affinityBonus =
      (aPref !== -1 ? 80 - aPref * 10 : 10) +
      (hostBusiness && biz.governorate === hostBusiness.governorate ? 30 : 0);

    const totalScore = tierWeight + discountBonus + (hasPhoto ? 80 : 0) + affinityBonus;

    return {
      totalScore,
      tierLevel,
      bestDiscountProd,
      discountPct,
      hasPhoto,
    };
  };

  // Sort candidates by smart exchange score descending
  verifiedSubscriberCandidates.sort((a, b) => {
    const scoreA = getCandidateScoreAndBestProduct(a).totalScore;
    const scoreB = getCandidateScoreAndBestProduct(b).totalScore;
    return scoreB - scoreA;
  });

  // Helper to map a verified business to a ContextualSponsoredAdItem
  const makeVerifiedSubscriberAd = (biz: Business): ContextualSponsoredAdItem => {
    usedBizIds.add(biz.id);
    const sub = subscribers.find((s) => s.id === biz.ownerSubscriberId || s.businessId === biz.id);
    const bp = getSectorDevelopmentBlueprint(biz.functionalGroupId);
    const { tierLevel, bestDiscountProd, discountPct, totalScore } = getCandidateScoreAndBestProduct(biz);

    const subName = sub?.fullName || biz.name;
    const tierName =
      tierLevel === 3
        ? 'باقة المستوى 3 (VIP الذهبية)'
        : tierLevel === 2
        ? 'باقة المستوى 2 (الاحترافية)'
        : 'باقة المستوى 1 (الأساسية)';

    // Determine ad visual and text: prefer the real discounted product photo and title
    let adTitle = `🔥 عرض خاص من ${biz.name}`;
    let adDesc = `أقوى العروض والخدمات الموثقة من ${biz.name} في ${bp.shortName}.`;
    let adImg = biz.coverUrl || DEFAULT_BUSINESS_COVER_URL;
    let savingsEgp: number | undefined;
    let promoCode = `PROMO${Math.max(10, discountPct || 20)}`;

    if (bestDiscountProd) {
      adTitle = `${bestDiscountProd.name} — خصم ${discountPct}%`;
      adDesc = `${bestDiscountProd.description || biz.bio} — متوفر الآن بسعر ${bestDiscountProd.price} ج.م بدلاً من ${bestDiscountProd.comparePrice} ج.م.`;
      if (bestDiscountProd.imageUrl && bestDiscountProd.imageUrl.trim().length > 0) {
        adImg = bestDiscountProd.imageUrl;
      }
      savingsEgp = (bestDiscountProd.comparePrice || bestDiscountProd.price) - bestDiscountProd.price;
    }

    // Sleek single line text for the square screen (سطر واحد لا يؤثر على إضاءة الإعلان)
    const oneLineSummary = bestDiscountProd
      ? `${biz.name}: ${bestDiscountProd.name} بسعر ${bestDiscountProd.price} ج.م (خصم ${discountPct}%)`
      : `${biz.name} (${bp.shortName}) • ${tierName} • عرض موثق`;

    return {
      id: `verified_sub_ad_${biz.id}`,
      type: 'sponsored_ad',
      title: adTitle,
      description: adDesc,
      imageUrl: adImg,
      durationDays: 30,
      budgetOrPrice: 0,
      businessId: biz.id,
      businessName: biz.name,
      contactPhone: biz.phone || biz.ownerWhatsApp,
      contactWhatsApp: biz.ownerWhatsApp || biz.phone,
      status: 'approved',
      createdAt: new Date().toISOString(),
      isFreeAdminSponsored: true,
      promoCode,
      ctaText: bestDiscountProd ? 'عرض المنتج والطلب' : 'عرض النشاط',
      resolvedBusiness: biz,
      sectorBlueprint: bp,
      isNonCompetingVerified: true,
      isVerifiedSubscriber: true,
      subscriberName: subName,
      subscriberId: sub?.id,
      verifiedQuotaLabel: 'مشترك موثق 🌟 (حصة 50% من الإعلانات)',
      discountedProduct: bestDiscountProd || undefined,
      discountPercent: discountPct > 0 ? discountPct : undefined,
      discountSavingsEgp: savingsEgp,
      packageTierLevel: tierLevel,
      packageTierName: tierName,
      oneLineSummary,
      smartRankingScore: totalScore,
      affinityLabel: hostBusiness
        ? `مشترك موثق تكميلي • ${bp.emoji} ${bp.shortName}`
        : `مشترك موثق معتمد • ${bp.emoji} ${bp.shortName}`,
    };
  };

  // Helper to map an approved AdRequest or platform ad
  const makeGeneralAd = (ad: AdRequest, resolvedBiz?: Business): ContextualSponsoredAdItem => {
    if (resolvedBiz) usedBizIds.add(resolvedBiz.id);
    const groupId: FunctionalGroupId = resolvedBiz?.functionalGroupId || 'services';
    const bp = getSectorDevelopmentBlueprint(groupId);

    const oneLineSummary = `${ad.businessName} • ${ad.title}`;

    return {
      ...ad,
      imageUrl: ad.imageUrl || resolvedBiz?.coverUrl || DEFAULT_BUSINESS_COVER_URL,
      resolvedBusiness: resolvedBiz,
      sectorBlueprint: bp,
      isNonCompetingVerified: true,
      isVerifiedSubscriber: false,
      verifiedQuotaLabel: 'إعلان ممول معتمد • رعاية المنصة',
      oneLineSummary,
      affinityLabel: hostBusiness
        ? `إعلان تكميلي غير منافس • ${bp.emoji} ${bp.shortName}`
        : `إعلان ممول معتمد • ${bp.emoji} ${bp.shortName}`,
    };
  };

  // 2. Filter approved AdRequests that are non-competing
  const eligibleApprovedAds: ContextualSponsoredAdItem[] = [];
  for (const ad of approvedAds) {
    const resolvedBiz = businesses.find(
      (b) => b.id === ad.businessId || b.name === ad.businessName
    );
    if (hostBusiness) {
      if (resolvedBiz && resolvedBiz.id === hostBusiness.id) continue;
      if (isAdCompetingWithHostBusiness(hostBusiness, resolvedBiz, `${ad.title} ${ad.description}`)) {
        blockedCompetitorsCount++;
        continue;
      }
    } else if (forbiddenGroup && resolvedBiz?.functionalGroupId === forbiddenGroup) {
      blockedCompetitorsCount++;
      continue;
    }
    eligibleApprovedAds.push(makeGeneralAd(ad, resolvedBiz));
  }

  // 3. Construct all verified candidate ads with smart exchange priority
  const allVerifiedAds: ContextualSponsoredAdItem[] = verifiedSubscriberCandidates.map((biz) =>
    makeVerifiedSubscriberAd(biz)
  );

  const allGeneralAds: ContextualSponsoredAdItem[] = [...eligibleApprovedAds];

  // If there are more verified businesses, also allow synthesizing non-competing campaigns for the general pool
  for (const biz of verifiedSubscriberCandidates) {
    if (usedBizIds.has(biz.id)) continue;
    allGeneralAds.push(makeVerifiedSubscriberAd(biz));
  }

  // 4. Assemble with Smart Alternating Exchange:
  // Guarantees >= 50% Verified Subscribers in every window, and allows list to grow dynamically
  // so that "كلما زادت زاد موضع اعلان اتوماتيكيا"
  const finalAds: ContextualSponsoredAdItem[] = [];
  let vIdx = 0;
  let gIdx = 0;

  const totalDesired = Math.max(minLimit, allVerifiedAds.length + allGeneralAds.length);

  while (finalAds.length < totalDesired && (vIdx < allVerifiedAds.length || gIdx < allGeneralAds.length)) {
    // 50%+ ratio: take verified first, then general, alternating
    if (finalAds.length % 2 === 0 || gIdx >= allGeneralAds.length) {
      if (vIdx < allVerifiedAds.length) {
        finalAds.push(allVerifiedAds[vIdx++]);
      } else if (gIdx < allGeneralAds.length) {
        finalAds.push(allGeneralAds[gIdx++]);
      }
    } else {
      if (gIdx < allGeneralAds.length) {
        finalAds.push(allGeneralAds[gIdx++]);
      } else if (vIdx < allVerifiedAds.length) {
        finalAds.push(allVerifiedAds[vIdx++]);
      }
    }
  }

  const actualVerifiedCount = finalAds.filter((a) => a.isVerifiedSubscriber).length;
  const verifiedRatioPercent =
    finalAds.length > 0 ? Math.round((actualVerifiedCount / finalAds.length) * 100) : 50;

  const hostBp = hostBusiness
    ? getSectorDevelopmentBlueprint(hostBusiness.functionalGroupId)
    : forbiddenGroup
    ? getSectorDevelopmentBlueprint(forbiddenGroup)
    : undefined;

  return {
    ads: finalAds,
    blockedCompetitorsCount,
    hostSectorShortName: hostBp?.shortName,
    verifiedSubscribersCount: actualVerifiedCount,
    verifiedSubscribersRatioPercent: verifiedRatioPercent,
    totalAvailableAdsCount: finalAds.length,
  };
}

// ============================================================================
// MEMBER & BUSINESS MESSAGING INBOX WITH PRIVACY & LOCATION CONTROLS
// ============================================================================

export function getDefaultMessagingPrivacyConfig(
  governorate: string = 'الدقهلية',
  markaz: string = 'المنصورة'
): MessagingPrivacyConfig {
  return {
    enabled: true,
    privacyMode: 'public_all',
    allowedGovernorates: [governorate],
    allowedMarkazList: [markaz],
    hidePhoneNumberInMessages: false,
    allowWhatsAppForward: true,
    autoReplyText:
      'مرحباً بك! تم استلام رسالتك بنجاح في صندوق رسائل الأعضاء وسنقوم بالرد عليك في أقرب وقت.',
    updatedAt: new Date().toISOString().split('T')[0],
  };
}

export function getMessagingPrivacyModeLabel(mode: MessagingPrivacyMode): string {
  switch (mode) {
    case 'public_all':
      return 'عام لجميع الأعضاء والزوار (كافة المحافظات)';
    case 'members_only':
      return 'للأعضاء المشتركين فقط (حماية الخصوصية)';
    case 'same_governorate_only':
      return 'حسب الموقع الجغرافي (نفس المحافظة أو المحافظات المسموحة فقط)';
    case 'same_markaz_only':
      return 'حسب الموقع الدقيق (نفس المركز والمنطقة فقط)';
    case 'disabled':
      return 'إيقاف استقبال الرسائل نهائياً (مغلق للخصوصية)';
    default:
      return 'عام لجميع الأعضاء';
  }
}

export function evaluateMessagingPrivacyAndLocation(params: {
  config?: MessagingPrivacyConfig | null;
  recipientName: string;
  recipientGovernorate: string;
  recipientMarkaz?: string;
  senderRole: AuthRole | 'visitor' | 'subscriber' | 'admin';
  senderGovernorate: string;
  senderMarkaz?: string;
}): {
  allowed: boolean;
  reasonAr: string;
  statusBadge: string;
  modeLabel: string;
} {
  const {
    config,
    recipientName,
    recipientGovernorate,
    recipientMarkaz = '',
    senderRole,
    senderGovernorate,
    senderMarkaz = '',
  } = params;

  const activeConfig =
    config || getDefaultMessagingPrivacyConfig(recipientGovernorate, recipientMarkaz);
  const modeLabel = getMessagingPrivacyModeLabel(activeConfig.privacyMode);

  // Admin can always test or message, unless testing explicit block or disabled
  if (!activeConfig.enabled || activeConfig.privacyMode === 'disabled') {
    return {
      allowed: false,
      reasonAr: `قام (${recipientName}) بإيقاف استقبال الرسائل حالياً حسب إعدادات الخصوصية.`,
      statusBadge: 'استقبال الرسائل متوقف (خصوصية)',
      modeLabel,
    };
  }

  if (activeConfig.privacyMode === 'members_only') {
    const isGuest = senderRole === 'guest' || senderRole === 'visitor' || senderRole === 'customer';
    if (isGuest) {
      return {
        allowed: false,
        reasonAr: `صفحة رسائل (${recipientName}) مخصصة لاستقبال رسائل الأعضاء المشتركين المسجلين فقط حفاظاً على الخصوصية.`,
        statusBadge: 'للأعضاء المشتركين فقط',
        modeLabel,
      };
    }
  }

  if (activeConfig.privacyMode === 'same_governorate_only') {
    const cleanSenderGov = (senderGovernorate || '').trim();
    const cleanRecipGov = (recipientGovernorate || '').trim();
    const allowedGovs =
      activeConfig.allowedGovernorates && activeConfig.allowedGovernorates.length > 0
        ? activeConfig.allowedGovernorates.map((g) => g.trim())
        : [cleanRecipGov];

    const isGovAllowed =
      cleanSenderGov === cleanRecipGov || allowedGovs.includes(cleanSenderGov);

    if (!isGovAllowed) {
      return {
        allowed: false,
        reasonAr: `استقبال الرسائل لدى (${recipientName}) مفعّل حسب الموقع الجغرافي لأعضاء محافظة (${allowedGovs.join('، ')}) فقط، بينما موقع المرسل الحالي هو (${cleanSenderGov || 'غير محدد'}).`,
        statusBadge: `مقيد بالموقع: ${allowedGovs.join(' / ')}`,
        modeLabel,
      };
    }
  }

  if (activeConfig.privacyMode === 'same_markaz_only') {
    const cleanSenderGov = (senderGovernorate || '').trim();
    const cleanRecipGov = (recipientGovernorate || '').trim();
    const cleanSenderMarkaz = (senderMarkaz || '').trim();
    const cleanRecipMarkaz = (recipientMarkaz || '').trim();

    const matchesGov = cleanSenderGov === cleanRecipGov;
    const matchesMarkaz =
      !cleanRecipMarkaz ||
      cleanSenderMarkaz === cleanRecipMarkaz ||
      (activeConfig.allowedMarkazList || []).map((m) => m.trim()).includes(cleanSenderMarkaz);

    if (!matchesGov || !matchesMarkaz) {
      return {
        allowed: false,
        reasonAr: `استقبال الرسائل لدى (${recipientName}) مفعّل حسب النطاق المحلي الدقيق لأعضاء مركز (${cleanRecipMarkaz} - ${cleanRecipGov}) فقط.`,
        statusBadge: `مقيد بمركز: ${cleanRecipMarkaz || cleanRecipGov}`,
        modeLabel,
      };
    }
  }

  return {
    allowed: true,
    reasonAr: `استقبال الرسائل مفعّل ومتاح لـ (${recipientName}) وفق إعدادات الخصوصية والموقع.`,
    statusBadge: 'متاح استقبال الرسائل ✓',
    modeLabel,
  };
}

export function generateMemberDirectMessageWhatsAppUrl(
  targetPhone: string,
  msg: Pick<
    MemberDirectMessage,
    | 'recipientName'
    | 'senderName'
    | 'senderPhone'
    | 'senderGovernorate'
    | 'senderMarkaz'
    | 'subject'
    | 'content'
  >,
  hideSenderPhone: boolean = false
): string {
  const cleanTarget = cleanPhoneNumber(targetPhone);
  let text = `📩 *رسالة جديدة من أعضاء منصة MantiqatiX*\n`;
  text += `━━━━━━━━━━━━━━━━━━━━\n`;
  text += `👤 *إلى:* ${msg.recipientName}\n`;
  text += `✍️ *المرسل:* ${msg.senderName}\n`;
  if (!hideSenderPhone && msg.senderPhone) {
    text += `📱 *رقم المرسل:* ${msg.senderPhone}\n`;
  } else {
    text += `🔒 *رقم المرسل:* مخفي حسب إعدادات الخصوصية (الرد عبر صندوق رسائل المنصة)\n`;
  }
  text += `📍 *موقع المرسل:* ${msg.senderGovernorate}${msg.senderMarkaz ? ` - ${msg.senderMarkaz}` : ''}\n`;
  text += `📌 *الموضوع:* ${msg.subject}\n`;
  text += `━━━━━━━━━━━━━━━━━━━━\n`;
  text += `💬 *نص الرسالة:*\n${msg.content}\n`;

  return `https://wa.me/${cleanTarget}?text=${encodeURIComponent(text)}`;
}





