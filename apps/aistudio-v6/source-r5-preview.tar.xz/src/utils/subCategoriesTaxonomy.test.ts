import test from 'node:test';
import assert from 'node:assert/strict';
import {
  SECTOR_SUBCATEGORIES_MAP,
  getSubcategoriesForSector,
  getAllSubcategories,
  getSubcategoryById,
  matchSubcategories,
  filterBusinessesBySubcategory,
  countBusinessesInSubcategory,
} from './subCategoriesTaxonomy';
import { Business } from '../types';

test('SECTOR_SUBCATEGORIES_MAP contains all 15 sectors with valid subcategories', () => {
  const expectedSectors = [
    'dining',
    'retail',
    'services',
    'healthcare',
    'crafts_maintenance',
    'education_training',
    'real_estate',
    'tourism_hotels',
    'transport_logistics',
    'agriculture_livestock',
    'technology_software',
    'sports_fitness',
    'events_entertainment',
    'legal_financial',
    'industrial_manufacturing',
  ];

  for (const sector of expectedSectors) {
    const subcategories = SECTOR_SUBCATEGORIES_MAP[sector as keyof typeof SECTOR_SUBCATEGORIES_MAP];
    assert.ok(subcategories && subcategories.length >= 3, `Sector ${sector} must have at least 3 subcategories`);
    for (const sub of subcategories) {
      assert.ok(sub.id.startsWith('sub_'), `Subcategory id must start with sub_ but got ${sub.id}`);
      assert.ok(sub.name.length > 0, 'Subcategory must have a valid Arabic name');
      assert.ok(sub.keywords.length > 0, 'Subcategory must have search keywords');
      assert.equal(sub.sectorId, sector, `Subcategory ${sub.id} sectorId must match parent sector`);
    }
  }
});

test('getSubcategoriesForSector returns sector specific items or cross-sector list when all', () => {
  const diningSubs = getSubcategoriesForSector('dining');
  assert.ok(diningSubs.length >= 4, 'dining should have at least 4 subcategories');
  assert.ok(diningSubs.some((s) => s.id === 'sub_dining_restaurants'));

  const allSubs = getSubcategoriesForSector('all');
  assert.ok(allSubs.length >= 15, 'all should return representative items across sectors');
});

test('getSubcategoryById correctly finds subcategory by id or returns undefined', () => {
  const pharmacy = getSubcategoryById('sub_health_pharmacies');
  assert.ok(pharmacy);
  assert.equal(pharmacy?.sectorId, 'healthcare');
  assert.ok(pharmacy?.name.includes('صيدليات'));

  const notFound = getSubcategoryById('non_existent_id');
  assert.equal(notFound, undefined);
});

test('matchSubcategories matches user queries with Arabic normalization', () => {
  // Matching "تكييف" -> crafts_maintenance sub_crafts_ac_appliances
  const acMatches = matchSubcategories('تكييف');
  assert.ok(acMatches.length > 0, 'Should find subcategory matching "تكييف"');
  assert.ok(acMatches.some((m) => m.id === 'sub_crafts_ac_appliances'));

  // Matching "اسنان" or "أسنان" -> dental
  const dentalMatches = matchSubcategories('أسنان');
  assert.ok(dentalMatches.some((m) => m.id === 'sub_health_dental'));

  // Matching "عقارات" or "شقق"
  const realEstateMatches = matchSubcategories('شقق');
  assert.ok(realEstateMatches.some((m) => m.id === 'sub_realestate_brokerage'));
});

test('filterBusinessesBySubcategory correctly filters businesses', () => {
  const sampleBusinesses: Business[] = [
    {
      id: 'b1',
      name: 'صيدلية النور الكبرى',
      slug: 'alnoor',
      category: 'صيدليات ومستلزمات طبية',
      functionalGroupId: 'healthcare',
      bio: 'صيدلية تعمل على مدار 24 ساعة لتوفير الأدوية',
    } as unknown as Business,
    {
      id: 'b2',
      name: 'مقهى الأفق',
      slug: 'horizon',
      category: 'مطاعم ومقاهي',
      functionalGroupId: 'dining',
      bio: 'أجود أنواع البن المختص والإسبريسو',
    } as unknown as Business,
    {
      id: 'b3',
      name: 'مركز الشامل لصيانة التكييف',
      slug: 'shamel',
      category: 'صيانة أجهزة منزلية وتكييف',
      functionalGroupId: 'crafts_maintenance',
      bio: 'فنيون لصيانة وإصلاح التكييفات والغسالات',
    } as unknown as Business,
  ];

  const filteredPharmacies = filterBusinessesBySubcategory(sampleBusinesses, 'sub_health_pharmacies');
  assert.equal(filteredPharmacies.length, 1);
  assert.equal(filteredPharmacies[0].id, 'b1');

  const filteredCafes = filterBusinessesBySubcategory(sampleBusinesses, 'sub_dining_cafes');
  assert.equal(filteredCafes.length, 1);
  assert.equal(filteredCafes[0].id, 'b2');

  const count = countBusinessesInSubcategory(sampleBusinesses, 'sub_crafts_ac_appliances');
  assert.equal(count, 1);
});
