import test from 'node:test';
import assert from 'node:assert/strict';
import {
  resolveBusinessCoordinates,
  calculateGovernorateStats,
  EGYPT_GOVERNORATES_MAP,
  DEFAULT_EGYPT_CENTER,
} from './geoCoordinates';
import { Business } from '../types';

test('resolveBusinessCoordinates resolves Cairo business correctly', () => {
  const dummyBiz: Business = {
    id: 'test_biz_cairo',
    name: 'شركة القاهرة للاستشارات',
    slug: 'cairo-consulting',
    category: 'خدمات',
    functionalGroupId: 'services',
    logoUrl: '',
    coverUrl: '',
    bio: '',
    ownerWhatsApp: '0100000000',
    governorate: 'القاهرة',
    markaz: 'المعادي',
    isVerified: true,
  } as unknown as Business;

  const coords = resolveBusinessCoordinates(dummyBiz);
  assert.ok(coords.lat >= 29.8 && coords.lat <= 30.2, 'Cairo/Maadi lat should be around 29.9');
  assert.ok(coords.lng >= 31.1 && coords.lng <= 31.4, 'Cairo/Maadi lng should be around 31.25');
});

test('resolveBusinessCoordinates resolves Dakahlia / Mansoura business correctly', () => {
  const dummyBiz: Business = {
    id: 'test_biz_mansoura',
    name: 'محل المنصورة',
    slug: 'mansoura-shop',
    category: 'مطاعم',
    functionalGroupId: 'dining',
    logoUrl: '',
    coverUrl: '',
    bio: '',
    ownerWhatsApp: '0100000000',
    governorate: 'الدقهلية',
    markaz: 'المنصورة',
    isVerified: true,
  } as unknown as Business;

  const coords = resolveBusinessCoordinates(dummyBiz);
  assert.ok(coords.lat >= 30.9 && coords.lat <= 31.2, 'Mansoura lat should be near 31.04');
  assert.ok(coords.lng >= 31.2 && coords.lng <= 31.5, 'Mansoura lng should be near 31.37');
});

test('resolveBusinessCoordinates gives jitter for multiple businesses in same markaz', () => {
  const biz1: Business = {
    id: 'biz_alnoor_pharmacy_1',
    name: 'صيدلية 1',
    slug: 'p1',
    category: 'صحة',
    functionalGroupId: 'healthcare',
    logoUrl: '',
    coverUrl: '',
    bio: '',
    ownerWhatsApp: '',
    governorate: 'الدقهلية',
    markaz: 'المنصورة',
  } as unknown as Business;

  const biz2: Business = {
    id: 'biz_coffee_shop_2',
    name: 'مقهى 2',
    slug: 'p2',
    category: 'مطاعم',
    functionalGroupId: 'dining',
    logoUrl: '',
    coverUrl: '',
    bio: '',
    ownerWhatsApp: '',
    governorate: 'الدقهلية',
    markaz: 'المنصورة',
  } as unknown as Business;

  const c1 = resolveBusinessCoordinates(biz1);
  const c2 = resolveBusinessCoordinates(biz2);

  assert.notEqual(c1.lat, c2.lat, 'Coordinates should not be identical for different IDs');
});

test('calculateGovernorateStats groups and counts properly', () => {
  const businesses: Business[] = [
    { id: '1', governorate: 'القاهرة', isVerified: true } as unknown as Business,
    { id: '2', governorate: 'القاهرة', isVerified: false } as unknown as Business,
    { id: '3', governorate: 'الدقهلية', isVerified: true } as unknown as Business,
    { id: '4', governorate: 'الإسكندرية', isVerified: true } as unknown as Business,
  ];

  const stats = calculateGovernorateStats(businesses);
  assert.equal(stats[0].name, 'القاهرة');
  assert.equal(stats[0].count, 2);
  assert.equal(stats[0].verifiedCount, 1);
  assert.equal(stats.length, 3);
});
