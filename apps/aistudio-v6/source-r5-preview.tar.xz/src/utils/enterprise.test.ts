import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeArabicText, calculateHaversineDistance, executeEnterpriseSearch } from './searchEngine';
import { simulateEnterpriseLoadTest, getLiveTelemetryMetrics } from './loadTestingEngine';
import { Business } from '../types';

test('Arabic text normalization unifies Alef variants, Taa Marbuta, Yaa, and strips Tashkeel', () => {
  // Test Alef normalization: أ, إ, آ, ٱ -> ا
  assert.equal(normalizeArabicText('أحمد'), 'احمد');
  assert.equal(normalizeArabicText('إسلام'), 'اسلام');
  assert.equal(normalizeArabicText('آدم'), 'ادم');

  // Test Taa Marbuta: ة -> ه
  assert.equal(normalizeArabicText('صيدلية'), 'صيدليه');
  assert.equal(normalizeArabicText('عيادة'), 'عياده');

  // Test Yaa and Alef Maksura: ى -> ي
  assert.equal(normalizeArabicText('مستشفى'), 'مستشفي');

  // Test Tashkeel / Harakat stripping
  assert.equal(normalizeArabicText('مُسْتَشْفَى'), 'مستشفي');
  assert.equal(normalizeArabicText('طَبِيبٌ'), 'طبيب');

  // Test Tatweel / Kashida removal
  assert.equal(normalizeArabicText('دكـــتور'), 'دكتور');
});

test('Haversine distance calculates accurate geographic kilometers between Egyptian coordinates', () => {
  // Cairo (30.0444, 31.2357) to Mansoura (31.0409, 31.3785) is ~115 - 120 km
  const dist = calculateHaversineDistance(30.0444, 31.2357, 31.0409, 31.3785);
  assert.ok(dist >= 110 && dist <= 125, `Expected ~115km, got ${dist}km`);
});

test('Enterprise search prioritizes verified entities first and applies Arabic NLP', () => {
  const sampleBusinesses = [
    {
      id: 'biz_unverified',
      name: 'عيادة الشفاء',
      slug: 'al-shifaa-unverified',
      category: 'عيادات واستشارات طبية',
      functionalGroupId: 'healthcare' as const,
      logoUrl: '',
      coverUrl: '',
      bio: 'عيادة باطنة',
      ownerWhatsApp: '01000000001',
      address: 'شارع البحر',
      governorate: 'الدقهلية',
      markaz: 'المنصورة',
      village: 'حي الجامعة',
      workingHours: '9 ص - 9 م',
      isVerified: false,
      verificationStatus: 'unverified' as const,
      maxProductsLimit: 150,
      createdAt: '2026-01-01',
      registrationDate: '2026-01-01',
      paymentDueDay: 1,
      paymentDueDate: '2026-02-01',
      commissionPerOrder: 0.01,
      totalOrdersCount: 0,
      paymentStatus: 'paid' as const,
      overdueDaysCount: 0,
      isFrozen: false,
    },
    {
      id: 'biz_verified',
      name: 'عيادة الشفاء التخصصية',
      slug: 'al-shifaa-verified',
      category: 'عيادات واستشارات طبية',
      functionalGroupId: 'healthcare' as const,
      logoUrl: '',
      coverUrl: '',
      bio: 'عيادة استشارية معتمدة',
      ownerWhatsApp: '01000000002',
      address: 'شارع المشاية',
      governorate: 'الدقهلية',
      markaz: 'المنصورة',
      village: 'حي الجامعة',
      workingHours: '9 ص - 9 م',
      isVerified: true,
      verificationStatus: 'verified' as const,
      maxProductsLimit: 150,
      createdAt: '2026-01-01',
      registrationDate: '2026-01-01',
      paymentDueDay: 1,
      paymentDueDate: '2026-02-01',
      commissionPerOrder: 0.01,
      totalOrdersCount: 0,
      paymentStatus: 'paid' as const,
      overdueDaysCount: 0,
      isFrozen: false,
    },
  ] as Business[];

  // Search with diacritics and Alef variant: "عِيَادَةُ أَلْشِفَاء"
  const results = executeEnterpriseSearch(sampleBusinesses, { query: 'عِيَادَةُ أَلْشِفَاء' });
  assert.equal(results.length, 2);
  // Verified business must rank #1
  assert.equal(results[0].id, 'biz_verified');
  assert.equal(results[1].id, 'biz_unverified');
});

test('Load-test placeholder never fabricates capacity or live telemetry measurements', () => {
  const res1k = simulateEnterpriseLoadTest(1000);
  assert.equal(res1k.vus, 1000);
  assert.equal(res1k.rps, 0);
  assert.equal(res1k.requestsPerSecond, 0);
  assert.equal(res1k.degradationLevel, 'heavy');
  assert.equal(res1k.status, 'warning');
  assert.match(res1k.bottleneckReason ?? '', /لم يتم تشغيل اختبار حمل فعلي/);

  const res500k = simulateEnterpriseLoadTest(500000);
  assert.equal(res500k.vus, 500000);
  assert.equal(res500k.rps, 0);
  assert.equal(res500k.p95LatencyMs, 0);
  assert.ok(res500k.scalingRecommendation.length > 0);

  const metrics = getLiveTelemetryMetrics(1);
  assert.equal(metrics.dbConnectionPoolMax, 0);
  assert.equal(metrics.cacheHitRatio, 0);
  assert.equal(metrics.globalRPS, 0);
});
