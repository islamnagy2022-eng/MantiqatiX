import test from 'node:test';
import assert from 'node:assert/strict';
import { DIRECTORY_PAGE_SIZE, getNextDirectoryVisibleCount } from './directoryPagination.ts';

test('directory starts with a 20-item page size', () => {
  assert.equal(DIRECTORY_PAGE_SIZE, 20);
});

test('load more advances by one page', () => {
  assert.equal(getNextDirectoryVisibleCount(20, 65), 40);
});

test('last page is capped at the filtered result total', () => {
  assert.equal(getNextDirectoryVisibleCount(40, 45), 45);
});

test('visible count never exceeds the total', () => {
  assert.equal(getNextDirectoryVisibleCount(80, 45), 45);
});

test('negative and non-finite values are handled safely', () => {
  assert.equal(getNextDirectoryVisibleCount(-5, 30), 20);
  assert.equal(getNextDirectoryVisibleCount(Number.NaN, 30), 20);
  assert.equal(getNextDirectoryVisibleCount(5, Number.NaN), 0);
});
