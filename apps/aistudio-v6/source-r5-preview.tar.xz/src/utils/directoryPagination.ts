export const DIRECTORY_PAGE_SIZE = 20;

/** Return the next visible item count without exceeding the filtered result total. */
export function getNextDirectoryVisibleCount(visibleCount: number, totalCount: number): number {
  const safeVisibleCount = Number.isFinite(visibleCount) ? Math.max(0, Math.trunc(visibleCount)) : 0;
  const safeTotalCount = Number.isFinite(totalCount) ? Math.max(0, Math.trunc(totalCount)) : 0;

  return Math.min(safeVisibleCount + DIRECTORY_PAGE_SIZE, safeTotalCount);
}
