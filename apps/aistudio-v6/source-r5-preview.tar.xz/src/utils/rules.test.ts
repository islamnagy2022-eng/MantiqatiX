import test from 'node:test';
import assert from 'node:assert/strict';
import {
  canAddProduct,
  getRemainingProductsCount,
  cleanPhoneNumber,
  calculateCartTotals,
  generateWhatsAppOrderUrl,
  filterBusinessesByTaxonomy,
  authenticateSubscriber,
  canSubscriberAccessBusiness,
  formatDirectCredentialsText,
  generateStorePublicUrl,
  createBackupPayload,
  validateAndParseBackup,
  formatEgyptianLocation,
  calculateBusinessCommission,
  evaluatePaymentFreezeStatus,
  applyAdminPaymentConfirmation,
  advanceOverdueDay,
  formatPrice,
  calculatePaymobFee,
  MAX_PRODUCTS_PER_BUSINESS,
  DEFAULT_COMMISSION_PER_ORDER,
  OVERDUE_GRACE_PERIOD_DAYS,
  DEFAULT_CURRENCY,
  DEFAULT_BUSINESS_LOGO_URL,
  DEFAULT_BUSINESS_COVER_URL,
  ensureBusinessStaticImages,
  getSectorDefaultLogo,
  getSectorDefaultCover,
  mergeFunctionalGroups,
  getDefaultTierConfiguration,
  validateSubscriptionRequestInput,
  generateContactUsWhatsAppUrl,
  createInitialPlatformWallets,
  executeWalletLedgerOperation,
  generateBusinessMarketingCampaign,
  getPickedForYouBusinesses,
  getMostRequestedBusinesses,
  buildEnterpriseStateSummary,
  getAllSectorDevelopmentBlueprints,
  getSectorDevelopmentBlueprint,
  getUnlockedSectorToolsForBusiness,
  applySectorPackageUpgradeToBusiness,
  generateSectorToolWhatsAppActionUrl,
  isAdCompetingWithHostBusiness,
  getNonCompetingSponsoredAdsForContext,
  getDefaultMessagingPrivacyConfig,
  evaluateMessagingPrivacyAndLocation,
  generateMemberDirectMessageWhatsAppUrl,
} from './rules';
import { DEFAULT_FUNCTIONAL_GROUPS, INITIAL_BUSINESSES, INITIAL_PRODUCTS, INITIAL_AD_REQUESTS } from '../data/seedData';
import { Product, Subscriber, AuthSession, Business, PaymobConfig } from '../types';

test('150 products limit logic checks correctly', () => {
  assert.equal(MAX_PRODUCTS_PER_BUSINESS, 150);
  assert.equal(canAddProduct(0, 150), true);
  assert.equal(canAddProduct(149, 150), true);
  assert.equal(canAddProduct(150, 150), false);
  assert.equal(getRemainingProductsCount(10, 150), 140);
  assert.equal(getRemainingProductsCount(150, 150), 0);
});

test('cleanPhoneNumber sanitizes symbols and spaces', () => {
  assert.equal(cleanPhoneNumber('+20 10 1234 5678'), '201012345678');
  assert.equal(cleanPhoneNumber('010-9988-7766'), '01099887766');
});

test('calculateCartTotals calculates totals correctly', () => {
  const dummyProduct: Product = {
    id: 'p1',
    businessId: 'b1',
    name: 'قهوة كولومبية',
    category: 'قهوة',
    type: 'product',
    price: 45,
    comparePrice: 55,
    description: 'بن مختص',
    imageUrl: '',
    isAvailable: true,
  };

  const result = calculateCartTotals([{ product: dummyProduct, quantity: 2 }]);
  assert.equal(result.totalCount, 2);
  assert.equal(result.subtotal, 90);
  assert.equal(result.originalSubtotal, 110);
});

test('Egyptian Pound default currency formatPrice uses ج.م', () => {
  assert.equal(DEFAULT_CURRENCY, 'ج.م');
  const priceStr = formatPrice(150);
  assert.ok(priceStr.includes('ج.م'));
});

test('Tenant isolation: subscriber cannot access another business', () => {
  const subscriberSession: AuthSession = {
    role: 'subscriber',
    subscriberId: 'sub_1',
    businessId: 'biz_horizon_coffee',
    subscriberName: 'أحمد محمود',
  };

  const adminSession: AuthSession = {
    role: 'admin',
  };

  assert.equal(canSubscriberAccessBusiness(subscriberSession, 'biz_horizon_coffee'), true);
  assert.equal(canSubscriberAccessBusiness(subscriberSession, 'biz_dar_alanaqah'), false);
  assert.equal(canSubscriberAccessBusiness(adminSession, 'biz_horizon_coffee'), true);
});

test('authenticateSubscriber verifies credentials with email/username and password', () => {
  const mockSubscribers: Subscriber[] = [
    {
      id: 'sub_1',
      fullName: 'أحمد محمود',
      email: 'ahmed@horizon.com',
      username: 'ahmed_horizon',
      password: 'mypassword123',
      phone: '+201012345678',
      businessId: 'biz_horizon',
      status: 'active',
      authMethod: 'direct_password',
      inviteStatus: 'direct_created',
      joinedDate: '2026-01-01',
    },
  ];

  const res1 = authenticateSubscriber(mockSubscribers, 'ahmed@horizon.com', 'mypassword123');
  assert.ok(res1 !== null);
  assert.equal(res1?.id, 'sub_1');

  const res3 = authenticateSubscriber(mockSubscribers, 'ahmed@horizon.com', 'wrongpass');
  assert.equal(res3, null);
});

test('formatDirectCredentialsText contains MantiqatiX, subscriber details and password', () => {
  const text = formatDirectCredentialsText(
    'أحمد محمود',
    'مقهى ومحمصة الأفق',
    'ahmed@horizon.com',
    'pass9988',
    'https://mantiqatix.com'
  );
  assert.ok(text.includes('أحمد محمود'));
  assert.ok(text.includes('MantiqatiX'));
});

test('generateStorePublicUrl creates isolated storefront URL', () => {
  const url = generateStorePublicUrl('https://mantiqatix.com', 'horizon-coffee');
  assert.equal(url, 'https://mantiqatix.com/?store=horizon-coffee');
});

test('filterBusinessesByTaxonomy filters businesses correctly by Functional Group and Category', () => {
  const sampleBusinesses: Business[] = [
    {
      id: 'b1',
      name: 'مطعم ومقهى الأفق',
      slug: 'horizon',
      category: 'مطاعم ومقاهي',
      categoryId: 'cat_dining_1',
      functionalGroupId: 'dining',
      logoUrl: '',
      coverUrl: '',
      bio: 'قهوة ومأكولات',
      ownerWhatsApp: '01000000000',
      address: '',
      governorate: 'الدقهلية',
      markaz: 'المنصورة',
      village: 'حي الجامعة',
      workingHours: '',
      isVerified: true,
      maxProductsLimit: 150,
      createdAt: '2026-01-01',
      registrationDate: '2026-01-01',
      paymentDueDay: 1,
      paymentDueDate: '2026-02-01',
      commissionPerOrder: 0.01,
      totalOrdersCount: 10,
      paymentStatus: 'paid',
      overdueDaysCount: 0,
      isFrozen: false,
      paymentConfirmedByAdmin: true,
    },
  ];

  const diningOnly = filterBusinessesByTaxonomy(sampleBusinesses, 'dining');
  assert.equal(diningOnly.length, 1);
  assert.equal(diningOnly[0].id, 'b1');
});

test('Backup creation and validation parse correctly with MantiqatiX payload', () => {
  const dummyBiz = [{ id: 'b1', name: 'نشاط 1', functionalGroupId: 'dining' }] as any;
  const dummyProd = [{ id: 'p1', name: 'منتج 1' }] as any;
  const dummySub = [{ id: 's1', fullName: 'مشترك 1' }] as any;
  const dummySettings = { platformName: 'MantiqatiX', currency: 'ج.م' } as any;

  const jsonStr = createBackupPayload(dummyBiz, dummyProd, dummySub, dummySettings);
  const result = validateAndParseBackup(jsonStr);
  assert.equal(result.valid, true);
});

test('formatEgyptianLocation formats governorate, markaz, village and address properly', () => {
  const formatted = formatEgyptianLocation('الدقهلية', 'المنصورة', 'ميت علي', 'شارع الجيش');
  assert.ok(formatted.includes('محافظة الدقهلية'));
  assert.ok(formatted.includes('مركز المنصورة'));
});

test('calculateBusinessCommission calculates accurately with 0.01 EGP default rate', () => {
  assert.equal(DEFAULT_COMMISSION_PER_ORDER, 0.01);
  const res100 = calculateBusinessCommission(100, 0.01);
  assert.equal(res100.totalCommission, 1.0);
});

test('evaluatePaymentFreezeStatus and advanceOverdueDay work as expected', () => {
  assert.equal(OVERDUE_GRACE_PERIOD_DAYS, 5);
  const day6State = evaluatePaymentFreezeStatus('overdue', 6);
  assert.equal(day6State.isFrozen, true);

  let mockBiz: Business = {
    id: 'b1',
    name: 'نشاط تجريبي',
    slug: 'demo',
    category: 'عام',
    functionalGroupId: 'dining',
    logoUrl: '',
    coverUrl: '',
    bio: '',
    ownerWhatsApp: '01000000000',
    address: 'طنطا',
    governorate: 'الغربية',
    markaz: 'طنطا',
    village: 'سبرباي',
    workingHours: '9 ص - 5 م',
    isVerified: true,
    maxProductsLimit: 150,
    createdAt: '2026-01-01',
    registrationDate: '2026-01-01',
    paymentDueDay: 1,
    paymentDueDate: '2026-02-01',
    commissionPerOrder: 0.01,
    totalOrdersCount: 15,
    paymentStatus: 'pending',
    overdueDaysCount: 5,
    isFrozen: false,
    paymentConfirmedByAdmin: false,
  };

  mockBiz = advanceOverdueDay(mockBiz);
  assert.equal(mockBiz.isFrozen, true);
  const confirmed = applyAdminPaymentConfirmation(mockBiz, '2026-02-17');
  assert.equal(confirmed.isFrozen, false);
});

test('calculatePaymobFee handles percentage, fixed, and percentage_plus_fixed', () => {
  const standardEgyptConfig: PaymobConfig = {
    enabled: true,
    feeType: 'percentage_plus_fixed',
    feePercentage: 2.75,
    feeFixed: 3.0,
    acceptedChannels: ['card', 'wallet', 'kiosk'],
  };
  assert.equal(calculatePaymobFee(100, standardEgyptConfig).fee, 5.75);
});

test('generateWhatsAppOrderUrl includes Paymob fee when paid via Paymob', () => {
  const dummyProduct: Product = {
    id: 'p1',
    businessId: 'b1',
    name: 'ساندوتش برجر كلاسيك',
    category: 'وجبات',
    type: 'product',
    price: 120,
    description: '',
    imageUrl: '',
    isAvailable: true,
  };

  const url = generateWhatsAppOrderUrl(
    '+201012345678',
    'مطعم ومشاوي الهنا',
    [{ product: dummyProduct, quantity: 2 }],
    {
      customerName: 'كريم عادل',
      customerPhone: '01011112222',
      customerAddress: 'المنصورة، المشاية',
      paymentMethod: 'paymob',
      paymobChannel: 'card',
      paymobFee: 9.6,
      paymobTotalPaid: 249.6,
      paymobTransactionRef: 'PMB-EG-778899',
    },
    'ج.م'
  );

  const decodedUrl = decodeURIComponent(url);
  assert.ok(decodedUrl.includes('PMB-EG-778899'));
});

test('15 functional groups merge and have exact shortNames in parentheses', () => {
  assert.equal(DEFAULT_FUNCTIONAL_GROUPS.length, 15);
  const merged = mergeFunctionalGroups(DEFAULT_FUNCTIONAL_GROUPS.slice(0, 5), DEFAULT_FUNCTIONAL_GROUPS);
  assert.equal(merged.length, 15);

  const expectedShortNames = [
    'مطاعم ومأكولات',
    'تجارة وتجزئة',
    'خدمات وحجوزات',
    'صحة ورعاية',
    'ورش وصيانة',
    'تعليم وتدريب',
    'عقارات ومقاولات',
    'سياحة وفنادق',
    'نقل وشحن',
    'زراعة وإنتاج',
    'برمجيات وتكنولوجيا',
    'رياضة ولياقة',
    'حفلات ومناسبات',
    'قانوني ومالي',
    'صناعة ومصانع',
  ];
  assert.deepEqual(
    merged.map((g) => g.shortName),
    expectedShortNames
  );
});

test('ensureBusinessStaticImages assigns default static logo and cover when empty', () => {
  const fixed = ensureBusinessStaticImages('', '   ');
  assert.equal(fixed.logoUrl, getSectorDefaultLogo());
  assert.equal(fixed.coverUrl, getSectorDefaultCover());
  assert.notEqual(fixed.logoUrl, '');
  assert.notEqual(fixed.coverUrl, '');
});

test('validateSubscriptionRequestInput requires businessName, phoneOrWhatsApp, governorate, and markaz', () => {
  assert.equal(
    validateSubscriptionRequestInput({
      businessName: '',
      phoneOrWhatsApp: '01010171770',
      governorate: 'القاهرة',
      markaz: 'مدينة نصر',
    }).valid,
    false
  );

  assert.equal(
    validateSubscriptionRequestInput({
      businessName: 'شركة النور',
      phoneOrWhatsApp: '01010171770',
      governorate: 'القاهرة',
      markaz: '',
    }).valid,
    false
  );

  assert.equal(
    validateSubscriptionRequestInput({
      businessName: 'شركة النور',
      phoneOrWhatsApp: '01010171770',
      governorate: 'القاهرة',
      markaz: 'مدينة نصر',
    }).valid,
    true
  );
});

test('getDefaultTierConfiguration returns accurate permissions for free, regular, and advanced tiers', () => {
  const freeCfg = getDefaultTierConfiguration('free');
  assert.equal(freeCfg.monthlySubscriptionFee, 0);
  assert.equal(freeCfg.maxAllowedBusinesses, 1);

  const regularCfg = getDefaultTierConfiguration('regular');
  assert.equal(regularCfg.permissions.enableCustomLinks, true);
  assert.equal(regularCfg.maxAllowedBusinesses, 2);

  const advCfg = getDefaultTierConfiguration('advanced');
  assert.equal(advCfg.permissions.enableSponsoredAds, true);
  assert.equal(advCfg.maxAllowedBusinesses, 5);
});

test('generateContactUsWhatsAppUrl creates a formatted WhatsApp message URL', () => {
  const url = generateContactUsWhatsAppUrl('201010171770', {
    senderName: 'محمود علي',
    senderPhone: '01099887766',
    messageType: 'inquiry',
    subject: 'استفسار عن الباقة المتقدمة',
    content: 'أرغب في معرفة تفاصيل تفعيل 3 فروع لنشاطي',
  });
  const decoded = decodeURIComponent(url);
  assert.ok(decoded.includes('محمود علي'));
  assert.ok(decoded.includes('استفسار عن الباقة المتقدمة'));
});

test('createInitialPlatformWallets and executeWalletLedgerOperation handle deposits, withdrawals, and free admin sponsored ad grants (0 EGP)', () => {
  const wallets = createInitialPlatformWallets(INITIAL_BUSINESSES, []);
  assert.ok(wallets.length >= 2);

  const masterWallet = wallets.find((w) => w.ownerType === 'admin')!;
  assert.ok(masterWallet);
  const initialBalance = masterWallet.availableBalance;

  // Test deposit
  const depositRes = executeWalletLedgerOperation(masterWallet, {
    type: 'deposit',
    amount: 500,
    paymentMethod: 'instapay',
    description: 'إيداع تجريبي عبر إنستا باي',
  });
  assert.equal(depositRes.success, true);
  assert.equal(depositRes.updatedWallet.availableBalance, initialBalance + 500);

  // Test Admin Free Sponsored Ad Grant (Must be 0 EGP and not deduct balance)
  const freeAdGrantRes = executeWalletLedgerOperation(depositRes.updatedWallet, {
    type: 'admin_free_ad_grant',
    amount: 350,
    paymentMethod: 'admin_grant',
    description: 'منحة إعلان ممول مربع مجاني للإدارة',
    isFreeAdminGrant: true,
  });
  assert.equal(freeAdGrantRes.success, true);
  assert.equal(freeAdGrantRes.transaction?.amount, 0);
  assert.equal(freeAdGrantRes.updatedWallet.availableBalance, initialBalance + 500);
});

test('generateBusinessMarketingCampaign generates multi-channel content and free admin ad flag for any business', () => {
  const sampleBiz = INITIAL_BUSINESSES[0];
  const bizProducts = INITIAL_PRODUCTS.filter((p) => p.businessId === sampleBiz.id);

  const campaign = generateBusinessMarketingCampaign(sampleBiz, {
    goal: 'sales_boost',
    discountPercent: 25,
    isAdminMode: true,
    featuredProducts: bizProducts,
  });

  assert.equal(campaign.businessId, sampleBiz.id);
  assert.equal(campaign.isFreeForAdmin, true);
  assert.equal(campaign.adCostEgp, 0);
  assert.ok(campaign.promoCode.endsWith('25'));
  assert.ok(campaign.headline.includes(sampleBiz.name));
  assert.ok(campaign.facebookInstagramCopy.includes(sampleBiz.name));
  assert.ok(campaign.whatsappBroadcastCopy.includes(campaign.promoCode));
  assert.ok(campaign.reelsVideoScript.includes('المشهد 1'));
});

test('getPickedForYouBusinesses and getMostRequestedBusinesses return curated home lists and buildEnterpriseStateSummary computes v4.0 metrics', () => {
  const picked = getPickedForYouBusinesses(INITIAL_BUSINESSES, 6);
  const mostReq = getMostRequestedBusinesses(INITIAL_BUSINESSES, 6);

  assert.ok(picked.length > 0);
  assert.ok(mostReq.length > 0);

  const wallets = createInitialPlatformWallets(INITIAL_BUSINESSES, []);
  const summary = buildEnterpriseStateSummary({
    businesses: INITIAL_BUSINESSES,
    products: INITIAL_PRODUCTS,
    wallets,
    transactions: [],
    campaigns: [],
    adRequests: INITIAL_AD_REQUESTS,
  });
  assert.equal(summary.schemaVersion, '4.0.0-enterprise');
  assert.ok(summary.activeSponsoredAds >= 4);
});

test('15-Sector 3-Tier Package Engine provides 3 progressive tiers and 3 interactive tools for all 15 sectors', () => {
  const allBlueprints = getAllSectorDevelopmentBlueprints();
  assert.equal(allBlueprints.length, 15);

  for (const bp of allBlueprints) {
    assert.equal(bp.tiers.length, 3);
    assert.equal(bp.tiers[0].level, 1);
    assert.equal(bp.tiers[1].level, 2);
    assert.equal(bp.tiers[2].level, 3);

    // Progressive quotas and credit limits across the 3 tiers
    assert.ok(bp.tiers[1].maxProducts > bp.tiers[0].maxProducts);
    assert.ok(bp.tiers[2].maxProducts > bp.tiers[1].maxProducts);
    assert.ok(bp.tiers[2].creditLimitEgp > bp.tiers[1].creditLimitEgp);

    // 3 specialized interactive tools per sector (one per level)
    assert.equal(bp.interactiveTools.length, 3);
    assert.ok(bp.tiers[2].sectorExclusiveFeatures.length >= 4);
  }
});

test('applySectorPackageUpgradeToBusiness upgrades business to Level 3 VIP and unlocks all 3 sector tools', () => {
  const diningBiz = INITIAL_BUSINESSES.find((b) => b.functionalGroupId === 'dining') || INITIAL_BUSINESSES[0];
  const level1Biz = applySectorPackageUpgradeToBusiness(diningBiz, 1);
  const toolsL1 = getUnlockedSectorToolsForBusiness(level1Biz);
  assert.equal(toolsL1.activeLevel, 1);
  assert.equal(toolsL1.unlockedTools.length, 1);
  assert.equal(toolsL1.lockedTools.length, 2);

  const level3Biz = applySectorPackageUpgradeToBusiness(diningBiz, 3);
  const toolsL3 = getUnlockedSectorToolsForBusiness(level3Biz);
  assert.equal(toolsL3.activeLevel, 3);
  assert.equal(toolsL3.unlockedTools.length, 3);
  assert.equal(toolsL3.lockedTools.length, 0);
  assert.equal(level3Biz.subscriptionTier, 'advanced');
  assert.equal(level3Biz.isVerified, true);

  const waUrl = generateSectorToolWhatsAppActionUrl(
    level3Biz,
    toolsL3.unlockedTools[2],
    'طلب 50 وجبة يومية للشركة',
    'عميل تجريبي',
    '01012345678'
  );
  assert.ok(waUrl.startsWith('https://wa.me/'));
});

test('Non-Competing Sponsored Ads Engine strictly blocks competing restaurants on a restaurant page', () => {
  const hostRestaurant: Business = {
    ...(INITIAL_BUSINESSES.find((b) => b.functionalGroupId === 'dining') || INITIAL_BUSINESSES[0]),
    id: 'biz_host_restaurant_1',
    name: 'مطعم المشويات الملكية',
    functionalGroupId: 'dining',
    category: 'مطاعم ومقاهي',
  };

  const competingRestaurant: Business = {
    ...hostRestaurant,
    id: 'biz_competing_restaurant_2',
    name: 'مطعم الشرق المنافس',
    functionalGroupId: 'dining',
    category: 'مطاعم ومقاهي',
  };

  const nonCompetingPharmacy: Business = {
    ...hostRestaurant,
    id: 'biz_non_competing_pharmacy',
    name: 'صيدليات النور الكبرى',
    functionalGroupId: 'healthcare',
    category: 'صيدليات ومستلزمات طبية',
  };

  assert.equal(isAdCompetingWithHostBusiness(hostRestaurant, competingRestaurant), true);
  assert.equal(isAdCompetingWithHostBusiness(hostRestaurant, nonCompetingPharmacy), false);

  const contextResult = getNonCompetingSponsoredAdsForContext({
    adRequests: INITIAL_AD_REQUESTS,
    businesses: [hostRestaurant, competingRestaurant, ...INITIAL_BUSINESSES],
    hostBusiness: hostRestaurant,
    limit: 4,
  });

  assert.ok(contextResult.ads.length >= 4);
  for (const ad of contextResult.ads) {
    assert.notEqual(ad.businessId, competingRestaurant.id);
    if (ad.resolvedBusiness) {
      assert.notEqual(
        ad.resolvedBusiness.functionalGroupId,
        'dining',
        'Must never display a competing restaurant ad inside a restaurant storefront!'
      );
    }
  }
});

test('Member & Business Messaging Privacy & Location engine enforces privacy and geographic rules accurately', () => {
  const defaultCfg = getDefaultMessagingPrivacyConfig('الدقهلية', 'المنصورة');
  assert.equal(defaultCfg.enabled, true);
  assert.equal(defaultCfg.privacyMode, 'public_all');

  // 1. Public all allows any visitor from any governorate
  const pubRes = evaluateMessagingPrivacyAndLocation({
    config: defaultCfg,
    recipientName: 'صيدليات النور الكبرى',
    recipientGovernorate: 'الدقهلية',
    recipientMarkaz: 'المنصورة',
    senderRole: 'visitor',
    senderGovernorate: 'الإسكندرية',
    senderMarkaz: 'سموحة',
  });
  assert.equal(pubRes.allowed, true);

  // 2. Members only blocks guest/visitor but allows subscriber
  const membersOnlyCfg = { ...defaultCfg, privacyMode: 'members_only' as const };
  const guestBlocked = evaluateMessagingPrivacyAndLocation({
    config: membersOnlyCfg,
    recipientName: 'أحمد محمود (مشترك)',
    recipientGovernorate: 'الدقهلية',
    senderRole: 'visitor',
    senderGovernorate: 'الدقهلية',
  });
  assert.equal(guestBlocked.allowed, false);

  const subAllowed = evaluateMessagingPrivacyAndLocation({
    config: membersOnlyCfg,
    recipientName: 'أحمد محمود (مشترك)',
    recipientGovernorate: 'الدقهلية',
    senderRole: 'subscriber',
    senderGovernorate: 'الدقهلية',
  });
  assert.equal(subAllowed.allowed, true);

  // 3. Same governorate only blocks outside governorates and allows matching governorate
  const govOnlyCfg = {
    ...defaultCfg,
    privacyMode: 'same_governorate_only' as const,
    allowedGovernorates: ['الدقهلية', 'الغربية'],
  };
  const cairoBlocked = evaluateMessagingPrivacyAndLocation({
    config: govOnlyCfg,
    recipientName: 'مطعم الأفق',
    recipientGovernorate: 'الدقهلية',
    senderRole: 'subscriber',
    senderGovernorate: 'أسوان',
  });
  assert.equal(cairoBlocked.allowed, false);

  const dakahliaAllowed = evaluateMessagingPrivacyAndLocation({
    config: govOnlyCfg,
    recipientName: 'مطعم الأفق',
    recipientGovernorate: 'الدقهلية',
    senderRole: 'subscriber',
    senderGovernorate: 'الدقهلية',
  });
  assert.equal(dakahliaAllowed.allowed, true);

  // 4. Same markaz only enforces both governorate and markaz
  const markazOnlyCfg = {
    ...defaultCfg,
    privacyMode: 'same_markaz_only' as const,
    allowedMarkazList: ['المنصورة'],
  };
  const talkhaBlocked = evaluateMessagingPrivacyAndLocation({
    config: markazOnlyCfg,
    recipientName: 'مطعم الأفق',
    recipientGovernorate: 'الدقهلية',
    recipientMarkaz: 'المنصورة',
    senderRole: 'subscriber',
    senderGovernorate: 'الدقهلية',
    senderMarkaz: 'طلخا',
  });
  assert.equal(talkhaBlocked.allowed, false);

  const mansouraAllowed = evaluateMessagingPrivacyAndLocation({
    config: markazOnlyCfg,
    recipientName: 'مطعم الأفق',
    recipientGovernorate: 'الدقهلية',
    recipientMarkaz: 'المنصورة',
    senderRole: 'subscriber',
    senderGovernorate: 'الدقهلية',
    senderMarkaz: 'المنصورة',
  });
  assert.equal(mansouraAllowed.allowed, true);

  // 5. Disabled master toggle blocks all incoming messages
  const disabledCfg = { ...defaultCfg, enabled: false };
  const disabledRes = evaluateMessagingPrivacyAndLocation({
    config: disabledCfg,
    recipientName: 'نشاط خاص',
    recipientGovernorate: 'الدقهلية',
    senderRole: 'subscriber',
    senderGovernorate: 'الدقهلية',
  });
  assert.equal(disabledRes.allowed, false);

  // 6. WhatsApp formatter respects phone privacy flag
  const waHiddenPhone = generateMemberDirectMessageWhatsAppUrl(
    '201010171770',
    {
      recipientName: 'صيدليات النور',
      senderName: 'عضو مشترك',
      senderPhone: '01099998888',
      senderGovernorate: 'الدقهلية',
      senderMarkaz: 'المنصورة',
      subject: 'استفسار عن توافر دواء',
      content: 'هل يتوفر دواء الضغط؟',
    },
    true
  );
  assert.ok(waHiddenPhone.startsWith('https://wa.me/201010171770'));
  assert.ok(!decodeURIComponent(waHiddenPhone).includes('01099998888'));
});



