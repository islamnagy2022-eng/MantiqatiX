import { Business, FunctionalGroup, Product } from '../types';
import { MarqueeProductItem } from '../components/common/AnimatedProductsMarqueeStrip';
import { DEFAULT_BUSINESS_COVER_URL } from '../utils/rules';

interface SectorTemplate {
  name: string;
  price: number;
  comparePrice?: number;
  unit?: string;
  image: string;
  badge: string;
}

const SECTOR_DIVERSE_ITEMS: Record<string, SectorTemplate[]> = {
  dining: [
    {
      name: 'كيلو مشويات مشكلة على الفحم (كباب وكفتة)',
      price: 490,
      comparePrice: 580,
      unit: 'كيلو',
      image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=600&auto=format&fit=crop&q=80',
      badge: 'مشويات طازجة 🔥',
    },
    {
      name: 'بيتزا باربيكيو تشيكن سوبر رانش إيطالي',
      price: 195,
      comparePrice: 240,
      unit: 'قطعة كبيرة',
      image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&auto=format&fit=crop&q=80',
      badge: 'الأعلى طلباً 🍕',
    },
    {
      name: 'برجر دبل بيف بلاك أنجوس مع صوص شيدر',
      price: 165,
      comparePrice: 210,
      unit: 'ساندوتش كومبو',
      image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
      badge: 'كومبو مميز',
    },
    {
      name: 'بوكس حلويات شرقية فاخرة بالسمن البلدي',
      price: 280,
      comparePrice: 340,
      unit: 'كيلو مشكل',
      image: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?w=600&auto=format&fit=crop&q=80',
      badge: 'سمن بلدي 100%',
    },
    {
      name: 'قهوة مختصة كولومبية محمصة طازجة',
      price: 120,
      comparePrice: 150,
      unit: '250 جرام',
      image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80',
      badge: 'محمصة مختصة ☕',
    },
    {
      name: 'طاجن سي فود ملوكي بالكريمة والجمبري',
      price: 360,
      comparePrice: 420,
      unit: 'طاجن عائلي',
      image: 'https://images.unsplash.com/photo-1559847844-5315695dadae?w=600&auto=format&fit=crop&q=80',
      badge: 'سي فود طازج',
    },
    {
      name: 'وجبة شاورما عربي دجاج مع التومية والبطاطس',
      price: 135,
      comparePrice: 160,
      unit: 'وجبة دبل',
      image: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=600&auto=format&fit=crop&q=80',
      badge: 'شاورما سوري',
    },
  ],
  retail: [
    {
      name: 'بدلة رجالي تركي فورمال قماش صوف كلاسيك',
      price: 2650,
      comparePrice: 3200,
      unit: 'طقم كامل',
      image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600&auto=format&fit=crop&q=80',
      badge: 'تركي أصلي 👔',
    },
    {
      name: 'حذاء كلاسيك جلد طبيعي 100% نعل طبي مريح',
      price: 850,
      comparePrice: 1100,
      unit: 'زوج',
      image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=600&auto=format&fit=crop&q=80',
      badge: 'جلد طبيعي',
    },
    {
      name: 'عطر فرنسي نيش فاخر 100 مل ثبات 48 ساعة',
      price: 1450,
      comparePrice: 1800,
      unit: 'زجاجة 100 مل',
      image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?w=600&auto=format&fit=crop&q=80',
      badge: 'ثبات يدوم ✨',
    },
    {
      name: 'ساعة يد أوتوماتيك ستانلس ستيل مقاومة للماء',
      price: 1950,
      comparePrice: 2400,
      unit: 'قطعة',
      image: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=600&auto=format&fit=crop&q=80',
      badge: 'ضمان سنتين',
    },
    {
      name: 'عباية خليجي كريب كوري تطريز يدوي راقي',
      price: 1250,
      comparePrice: 1600,
      unit: 'قطعة',
      image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=600&auto=format&fit=crop&q=80',
      badge: 'تصميم راقي',
    },
    {
      name: 'نظارة شمسية بولارايزد إيطالي حماية UV400',
      price: 680,
      comparePrice: 900,
      unit: 'قطعة بالجراب',
      image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=600&auto=format&fit=crop&q=80',
      badge: 'عدسات UV400',
    },
    {
      name: 'شنطة يد نسائية جلد طبيعي بتصميم إيطالي عصري',
      price: 980,
      comparePrice: 1300,
      unit: 'قطعة',
      image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=600&auto=format&fit=crop&q=80',
      badge: 'ماركة أصلية',
    },
  ],
  healthcare: [
    {
      name: 'جهاز قياس ضغط الدم ديجيتال دقيق بضمان 3 سنوات',
      price: 790,
      comparePrice: 950,
      unit: 'جهاز بالجراب',
      image: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=600&auto=format&fit=crop&q=80',
      badge: 'معتمد طبياً 🩺',
    },
    {
      name: 'باقة مكملات غذائية وفيتامينات مستوردة لدعم المناعة',
      price: 450,
      comparePrice: 550,
      unit: 'باقة شهرية',
      image: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=600&auto=format&fit=crop&q=80',
      badge: 'مستورد أصلي',
    },
    {
      name: 'جلسة تنظيف وتبييض أسنان بالليزر هوليوود سمايل',
      price: 850,
      comparePrice: 1200,
      unit: 'جلسة كاملة',
      image: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=600&auto=format&fit=crop&q=80',
      badge: 'حجز فوري',
    },
    {
      name: 'باقة فحص وتحاليل شاملة (وظائف كبد وكلى وسكر وصورة دم)',
      price: 650,
      comparePrice: 900,
      unit: 'فحص معملي',
      image: 'https://images.unsplash.com/photo-1579154204601-01588f351e67?w=600&auto=format&fit=crop&q=80',
      badge: 'نتائج فورية',
    },
    {
      name: 'كشف واستشارة استشاري قلب وأوعية دموية وسونار',
      price: 350,
      comparePrice: 450,
      unit: 'كشف عيادة',
      image: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=600&auto=format&fit=crop&q=80',
      badge: 'استشاري معتمد',
    },
    {
      name: 'جهاز قياس نسبة السكر بالدم مع 50 شريط اختبار',
      price: 420,
      comparePrice: 520,
      unit: 'طقم كامل',
      image: 'https://images.unsplash.com/photo-1584515933487-779824d29309?w=600&auto=format&fit=crop&q=80',
      badge: 'أشرطة مجانية',
    },
    {
      name: 'جلسة ليزر كربوني لنضارة البشرة وتجديد الكولاجين',
      price: 550,
      comparePrice: 800,
      unit: 'جلسة عيادة',
      image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=600&auto=format&fit=crop&q=80',
      badge: 'عناية فائقة',
    },
  ],
  services: [
    {
      name: 'تصميم هوية بصرية كاملة وشعار احترافي للمشاريع',
      price: 1800,
      comparePrice: 2400,
      unit: 'مشروع كامل',
      image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
      badge: 'تسليم سريع ⚡',
    },
    {
      name: 'حملة إعلانية ممولة احترافية على منصات ميتا وجوجل',
      price: 1200,
      comparePrice: 1600,
      unit: 'إدارة شهرية',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&auto=format&fit=crop&q=80',
      badge: 'عائد مضمون',
    },
    {
      name: 'جلسة تصوير فوتوسيشن برودكت احترافي 25 صورة',
      price: 950,
      comparePrice: 1400,
      unit: 'جلسة تصوير',
      image: 'https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=600&auto=format&fit=crop&q=80',
      badge: 'استوديو مجهز',
    },
    {
      name: 'باقة تنظيف وغسيل عميق للصالونات والانتريه بالبخار',
      price: 450,
      comparePrice: 600,
      unit: 'طقم انتريه',
      image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600&auto=format&fit=crop&q=80',
      badge: 'خدمة منزلية',
    },
    {
      name: 'تطوير موقع متجر إلكتروني سريع مع الربط بالدفع',
      price: 3800,
      comparePrice: 4800,
      unit: 'متجر متكامل',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&auto=format&fit=crop&q=80',
      badge: 'ربط Paymob',
    },
    {
      name: 'كورس تدريبي مكثف في التسويق عبر وسائل التواصل',
      price: 750,
      comparePrice: 1100,
      unit: 'دورة 20 ساعة',
      image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&auto=format&fit=crop&q=80',
      badge: 'شهادة معتمدة',
    },
    {
      name: 'طباعة 1000 كارت شخصي فاخر كوشيه وسلوفان مط',
      price: 250,
      comparePrice: 320,
      unit: '1000 كارت',
      image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=600&auto=format&fit=crop&q=80',
      badge: 'طباعة فورية',
    },
  ],
  crafts_maintenance: [
    {
      name: 'صيانة وشحن فريون تكييف سبليت منزلي مع فحص التسريب',
      price: 380,
      comparePrice: 480,
      unit: 'جهاز تكييف',
      image: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600&auto=format&fit=crop&q=80',
      badge: 'فني معتمد 🔧',
    },
    {
      name: 'طقم غيار زيت محرك سيارة تخليقي بالكامل مع الفلتر',
      price: 1100,
      comparePrice: 1350,
      unit: '4 لتر + فلتر',
      image: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?w=600&auto=format&fit=crop&q=80',
      badge: 'زيوت أصلية',
    },
    {
      name: 'فحص كمبيوتر كامل وضبط أعطال كنترول السيارة',
      price: 250,
      comparePrice: 350,
      unit: 'فحص شامل',
      image: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?w=600&auto=format&fit=crop&q=80',
      badge: 'أحدث أجهزة OBD',
    },
    {
      name: 'صيانة غسالات أوتوماتيك وثلاجات منزلية بقطع غيار أصلية',
      price: 320,
      comparePrice: 420,
      unit: 'معاينة وإصلاح',
      image: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&auto=format&fit=crop&q=80',
      badge: 'ضمان 6 شهور',
    },
    {
      name: 'تأسيس وصيانة شبكات سباكة حديثة بتقنية اللحام الحراري',
      price: 500,
      comparePrice: 650,
      unit: 'يومية عمل',
      image: 'https://images.unsplash.com/photo-1504148455328-c376907d081c?w=600&auto=format&fit=crop&q=80',
      badge: 'ضمان ضد التسريب',
    },
    {
      name: 'تشطيب أعمال كهرباء وإضاءة ليد وسمارت هوم للشقق',
      price: 1200,
      comparePrice: 1500,
      unit: 'غرفة / صالة',
      image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80',
      badge: 'أنظمة سمارت',
    },
    {
      name: 'تصنيع وصيانة أبواب وشبابيك ألوميتال قطاع جامبو عازل',
      price: 1850,
      comparePrice: 2200,
      unit: 'متر مربع',
      image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=600&auto=format&fit=crop&q=80',
      badge: 'عازل للصوت',
    },
  ],
  education_training: [
    {
      name: 'كورس محادثة إنجليزية تفاعلي أونلاين مع مدرب أجنبي',
      price: 650,
      comparePrice: 900,
      unit: 'مستوى شهرين',
      image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600&auto=format&fit=crop&q=80',
      badge: 'تفاعلي لايف 🎓',
    },
    {
      name: 'برنامج تأسيس وبرمجة روبوت للأطفال واليافعين',
      price: 850,
      comparePrice: 1100,
      unit: 'شهر تدريبي',
      image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=600&auto=format&fit=crop&q=80',
      badge: 'روبوت وذكاء',
    },
    {
      name: 'دبلومة المحاسبة المالية المعتمدة وإعداد القوائم',
      price: 1200,
      comparePrice: 1600,
      unit: 'دبلومة كاملة',
      image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=600&auto=format&fit=crop&q=80',
      badge: 'إكسيل ودفاتر',
    },
    {
      name: 'دورة التصميم الجرافيكي الاحترافي فوتوشوب وإليستريتور',
      price: 950,
      comparePrice: 1300,
      unit: 'دورة 30 ساعة',
      image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600&auto=format&fit=crop&q=80',
      badge: 'مشاريع عملية',
    },
    {
      name: 'كورس تحفيظ القرآن الكريم وتجويده بالتجويد العملي',
      price: 250,
      comparePrice: 350,
      unit: 'اشتراك شهري',
      image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80',
      badge: 'شيوخ معتمدون',
    },
    {
      name: 'دورة احتراف التسويق الرقمي وإدارة الحملات الإعلانية',
      price: 1100,
      comparePrice: 1500,
      unit: 'كورس شامل',
      image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&auto=format&fit=crop&q=80',
      badge: 'تطبيق عملي',
    },
    {
      name: 'برنامج إعداد قادة الأعمال وإدارة المشروعات PMP',
      price: 1900,
      comparePrice: 2500,
      unit: 'دورة معتمدة',
      image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=600&auto=format&fit=crop&q=80',
      badge: 'معتمد دولياً',
    },
  ],
  real_estate: [
    {
      name: 'شقة فاخرة 160م تشطيب سوبر لوكس بحي الجامعة',
      price: 2200000,
      comparePrice: 2400000,
      unit: 'سعر كاش',
      image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=600&auto=format&fit=crop&q=80',
      badge: 'استلام فوري 🏢',
    },
    {
      name: 'مقر إداري ومكتب تجاري مرخص 90م ببرج تجاري رئيسي',
      price: 8500,
      comparePrice: 10000,
      unit: 'إيجار شهري',
      image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&auto=format&fit=crop&q=80',
      badge: 'موقع حيوي',
    },
    {
      name: 'محل تجاري واجهة 6 أمتار على شارع رئيسي للعلامات الكبرى',
      price: 16000,
      comparePrice: 19000,
      unit: 'إيجار شهري',
      image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&auto=format&fit=crop&q=80',
      badge: 'أعلى ترافيك',
    },
    {
      name: 'فيلا مستقلة 350م بحمام سباحة وحديقة خاصة',
      price: 5900000,
      comparePrice: 6500000,
      unit: 'شامل الحديقة',
      image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&auto=format&fit=crop&q=80',
      badge: 'فيلا VIP',
    },
    {
      name: 'شقة مفروشة راقية للإيجار الشهري مكيفة بالكامل',
      price: 7500,
      comparePrice: 9000,
      unit: 'إيجار شهري',
      image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=600&auto=format&fit=crop&q=80',
      badge: 'مفروشة بالكامل',
    },
    {
      name: 'قطعة أرض مباني 200م مسجلة شهر عقاري ترخيص سكني',
      price: 1400000,
      comparePrice: 1600000,
      unit: 'أرض مسجلة',
      image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&auto=format&fit=crop&q=80',
      badge: 'ترخيص جاهز',
    },
    {
      name: 'شاليه يرى البحر برأس البر تشطيب ألترا مودرن',
      price: 950000,
      comparePrice: 1100000,
      unit: 'شاليه مصيفي',
      image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&auto=format&fit=crop&q=80',
      badge: 'فيو بحر',
    },
  ],
  tourism_hotels: [
    {
      name: 'رحلة شرم الشيخ 4 أيام 3 ليالي إقامة شاملة سوفت أول إنكلوسيف',
      price: 3600,
      comparePrice: 4400,
      unit: 'للفرد بالغرفة',
      image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=600&auto=format&fit=crop&q=80',
      badge: 'فندق 5 نجوم 🧭',
    },
    {
      name: 'توصيل ليموزين خاص مطار القاهرة بأحدث سيارات السيدان',
      price: 900,
      comparePrice: 1100,
      unit: 'مشوار ذهاب',
      image: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=600&auto=format&fit=crop&q=80',
      badge: 'خدمة VIP 24h',
    },
    {
      name: 'رحلة عشاء نيلية بالقاهرة مع برنامج فني واستعراضي',
      price: 450,
      comparePrice: 600,
      unit: 'تذكرة للفرد',
      image: 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=600&auto=format&fit=crop&q=80',
      badge: 'بوفيه مفتوح',
    },
    {
      name: 'باقة الغردقة والجونة مع رحلة بحرية لجزيرة الجفتون',
      price: 4200,
      comparePrice: 5000,
      unit: 'شامل الانتقالات',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80',
      badge: 'يخت وغوص',
    },
    {
      name: 'تأشيرة سياحية إلكترونية سريعة وحجز طيران مخفض',
      price: 1500,
      comparePrice: 1900,
      unit: 'استخراج فوري',
      image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=600&auto=format&fit=crop&q=80',
      badge: 'إنجاز خلال 48h',
    },
    {
      name: 'عطلة مرسى علم واحات ومحمية صمداي للدلافين',
      price: 4800,
      comparePrice: 5800,
      unit: '4 أيام كاملة',
      image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=600&auto=format&fit=crop&q=80',
      badge: 'محميات طبيعية',
    },
    {
      name: 'إيجار سيارة هيونداي النترا حديثة بالسائق لرجال الأعمال',
      price: 850,
      comparePrice: 1050,
      unit: 'يومية 10 ساعات',
      image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=600&auto=format&fit=crop&q=80',
      badge: 'تأمين شامل',
    },
  ],
  transport_logistics: [
    {
      name: 'خدمة نقل أثاث منزلي بالونش الهيدروليكي مع التغليف الشامل',
      price: 1600,
      comparePrice: 2100,
      unit: 'نقلة ونش كاملة',
      image: 'https://images.unsplash.com/photo-1600518464441-9154a4dea21b?w=600&auto=format&fit=crop&q=80',
      badge: 'ونش هيدروليك 🚚',
    },
    {
      name: 'شحن طرود سريعة من الباب للباب لكافة محافظات مصر',
      price: 65,
      comparePrice: 90,
      unit: 'طرد حتى 5 كجم',
      image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&auto=format&fit=crop&q=80',
      badge: 'توصيل 24 ساعة',
    },
    {
      name: 'نقل بضائع بسيارات جامبو مغلقة ومؤمنة للمصانع والشركات',
      price: 1400,
      comparePrice: 1800,
      unit: 'مشوار حمولة',
      image: 'https://images.unsplash.com/photo-1519003722824-194d4455a60c?w=600&auto=format&fit=crop&q=80',
      badge: 'سيارات مجهزة',
    },
    {
      name: 'شحن طرود مبردة للمنتجات الغذائية والأدوية الطبية',
      price: 250,
      comparePrice: 320,
      unit: 'طرد مبرد',
      image: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?w=600&auto=format&fit=crop&q=80',
      badge: 'تبريد مراقب',
    },
    {
      name: 'تأجير تريلات وبرادات نقل ثقيل بين الموانئ والمحافظات',
      price: 4500,
      comparePrice: 5500,
      unit: 'نقلة ثقيلة',
      image: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=600&auto=format&fit=crop&q=80',
      badge: 'حمولة 30 طن',
    },
    {
      name: 'خدمة تخزين بضائع بمستودعات مؤمنة بكاميرات 24/7',
      price: 900,
      comparePrice: 1200,
      unit: 'متر مكعب / شهر',
      image: 'https://images.unsplash.com/photo-1586528116493-a029325540fa?w=600&auto=format&fit=crop&q=80',
      badge: 'مستودع مؤمن',
    },
    {
      name: 'توصيل أوردرات المتاجر والمطاعم بأسطول دليفري سريع',
      price: 25,
      comparePrice: 35,
      unit: 'توصيل أوردر',
      image: 'https://images.unsplash.com/photo-1526367790999-0150786686a2?w=600&auto=format&fit=crop&q=80',
      badge: 'دليفري سريع',
    },
  ],
  agriculture_livestock: [
    {
      name: 'شتلات نخيل برحي ومجدول نسيجي عالي الجودة',
      price: 320,
      comparePrice: 400,
      unit: 'شتلة معتمدة',
      image: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=600&auto=format&fit=crop&q=80',
      badge: 'إنتاجية عالية 🌱',
    },
    {
      name: 'شيكارة سماد نترات نشادر وبوتاسيوم عضوي 50 كجم',
      price: 580,
      comparePrice: 690,
      unit: 'شيكارة 50 كجم',
      image: 'https://images.unsplash.com/photo-1592417817098-8f3d6eb22659?w=600&auto=format&fit=crop&q=80',
      badge: 'عضوي معتمد',
    },
    {
      name: 'أعلاف مواشي ودواجن بروتين 21% عالية التحويل الغذائي',
      price: 750,
      comparePrice: 880,
      unit: 'شيكارة 50 كجم',
      image: 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?w=600&auto=format&fit=crop&q=80',
      badge: 'بروتين نقي',
    },
    {
      name: 'كشف بيطري وتحصينات مزارع المواشي والدواجن',
      price: 350,
      comparePrice: 450,
      unit: 'زيارة مزرعة',
      image: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=600&auto=format&fit=crop&q=80',
      badge: 'طبيب بيطري',
    },
    {
      name: 'عسل نحل سدر جبلي مصري طبيعي نقي ومفحوص معملياً',
      price: 240,
      comparePrice: 300,
      unit: 'برطمان كيلو',
      image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=600&auto=format&fit=crop&q=80',
      badge: 'طبيعي 100%',
    },
    {
      name: 'شبكات ري بالتنقيط ومواسير بولي إيثيلين للمزارع الحديثة',
      price: 1800,
      comparePrice: 2200,
      unit: 'لفة 400 متر',
      image: 'https://images.unsplash.com/photo-1563514227147-6d2ff665a6a0?w=600&auto=format&fit=crop&q=80',
      badge: 'توفير المياه',
    },
    {
      name: 'شتلات مانجو عويس وتومي وفص مطعومة أصناف ممتازة',
      price: 140,
      comparePrice: 180,
      unit: 'شتلة كيس',
      image: 'https://images.unsplash.com/photo-1553279768-865429fa0078?w=600&auto=format&fit=crop&q=80',
      badge: 'مطعومة جاهزة',
    },
  ],
  technology_software: [
    {
      name: 'تطوير تطبيق جوال متكامل أندرويد وiOS مع لوحة تحكم سحابية',
      price: 6800,
      comparePrice: 8500,
      unit: 'مشروع تسليم مفتاح',
      image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=600&auto=format&fit=crop&q=80',
      badge: 'كود نقي وسريع 💻',
    },
    {
      name: 'سيستم ونظام نقاط بيع وكاشير سحابي POS للمحلات والمطاعم',
      price: 2400,
      comparePrice: 3200,
      unit: 'ترخيص سنوي',
      image: 'https://images.unsplash.com/photo-1556742049-0a67e557224e?w=600&auto=format&fit=crop&q=80',
      badge: 'تقارير فورية',
    },
    {
      name: 'كاميرات مراقبة IP هيكفيجن بدقة 4K مع جهاز تسجيل NVR',
      price: 3400,
      comparePrice: 4200,
      unit: 'سيستم 4 كاميرات',
      image: 'https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=600&auto=format&fit=crop&q=80',
      badge: 'رؤية ليلية ملونة',
    },
    {
      name: 'سيرفر استضافة سحابية فائقة السرعة مع شهادة SSL مجانية',
      price: 950,
      comparePrice: 1300,
      unit: 'اشتراك سنوي',
      image: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=600&auto=format&fit=crop&q=80',
      badge: 'أمان وسرعة',
    },
    {
      name: 'تجهيز سنترال داخلي IP-PBX وشبكات إنترنت للمكاتب والشركات',
      price: 2900,
      comparePrice: 3600,
      unit: 'تجهيز مقر',
      image: 'https://images.unsplash.com/photo-1544197150-199123fa6d70?w=600&auto=format&fit=crop&q=80',
      badge: 'خطوط داخلية',
    },
    {
      name: 'باقة تدقيق أمني واختبار اختراق للمواقع والأنظمة',
      price: 3200,
      comparePrice: 4500,
      unit: 'تقرير أمني',
      image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600&auto=format&fit=crop&q=80',
      badge: 'حماية متقدمة',
    },
    {
      name: 'تصميم واجهة وتجربة مستخدم UI/UX متجاوبة للهواتف والويب',
      price: 2100,
      comparePrice: 2800,
      unit: '15 شاشة فوتوسيشن',
      image: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=600&auto=format&fit=crop&q=80',
      badge: 'Figma تفاعلي',
    },
  ],
  sports_fitness: [
    {
      name: 'اشتراك جيم سنوي VIP شامل الساونا والجاكوزي والمسبح',
      price: 2800,
      comparePrice: 3800,
      unit: 'اشتراك 12 شهر',
      image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&auto=format&fit=crop&q=80',
      badge: 'شامل كل الخدمات 🏋️',
    },
    {
      name: 'واي بروتين جولد ستاندرد أصلي 5 باوند مستورد',
      price: 2450,
      comparePrice: 2900,
      unit: 'عبوة 5 باوند',
      image: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=600&auto=format&fit=crop&q=80',
      badge: 'مستورد باركود',
    },
    {
      name: 'برنامج تدريب شخصي وتغذية رياضية أونلاين لمدة 3 أشهر',
      price: 1200,
      comparePrice: 1700,
      unit: 'متابعة أسبوعية',
      image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600&auto=format&fit=crop&q=80',
      badge: 'خطة مخصصة',
    },
    {
      name: 'حجز ساعة ملعب بادل بانوراما نجيل صناعي وكشافات ليد',
      price: 250,
      comparePrice: 320,
      unit: 'ساعة لعب',
      image: 'https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=600&auto=format&fit=crop&q=80',
      badge: 'ملعب بانوراما',
    },
    {
      name: 'حذاء جري وتمارين رياضية مريح ومرن ومقاوم للانزلاق',
      price: 780,
      comparePrice: 990,
      unit: 'زوج أحذية',
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=80',
      badge: 'نعل هوائي',
    },
    {
      name: 'كرياتين مونوهيدرات ميكرونايزد نقي لزيادة القوة العضلية',
      price: 680,
      comparePrice: 850,
      unit: 'عبوة 300 جرام',
      image: 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=600&auto=format&fit=crop&q=80',
      badge: 'زيادة التحمل',
    },
    {
      name: 'طقم ملابس رياضية جيم دراي فيت تهوية ممتازة',
      price: 490,
      comparePrice: 650,
      unit: 'طقم تيشرت وشورت',
      image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&auto=format&fit=crop&q=80',
      badge: 'قماش دراي فيت',
    },
  ],
  events_entertainment: [
    {
      name: 'باقة تصوير سيشن زفاف كامل فيديو فوتوسيشن ودرون جوي',
      price: 3900,
      comparePrice: 5200,
      unit: 'ألبوم وفيديو كامل',
      image: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600&auto=format&fit=crop&q=80',
      badge: 'درون وتصوير 4K 🎉',
    },
    {
      name: 'حجز قاعة أفراح VIP تسع 300 فرد مع البوفيه والديكور',
      price: 18500,
      comparePrice: 22000,
      unit: 'ليلة زفاف كاملة',
      image: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=600&auto=format&fit=crop&q=80',
      badge: 'قاعة فندقية',
    },
    {
      name: 'سيستم صوت وإضاءة دي جي احترافي وأجهزة ليزر للحفلات',
      price: 1800,
      comparePrice: 2400,
      unit: 'حفلة ليلية',
      image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80',
      badge: 'إضاءة ودخان',
    },
    {
      name: 'تجهيز كوشة زفاف ورد طبيعي أحدث صيحات الديكور المودرن',
      price: 3200,
      comparePrice: 4200,
      unit: 'كوشة وتجهيز',
      image: 'https://images.unsplash.com/photo-1520854221256-17451cc331bf?w=600&auto=format&fit=crop&q=80',
      badge: 'ورد طبيعي',
    },
    {
      name: 'بوفيه عشاء مفتوح للمناسبات والمؤتمرات 100 فرد مع السيرفيس',
      price: 8500,
      comparePrice: 10500,
      unit: '100 فرد',
      image: 'https://images.unsplash.com/photo-1555244162-803834f70033?w=600&auto=format&fit=crop&q=80',
      badge: 'شيفات متخصصون',
    },
    {
      name: 'ألعاب كيدز اريا ونطاطات هوائية عملاقة لأعياد الميلاد',
      price: 950,
      comparePrice: 1300,
      unit: 'يوم كامل',
      image: 'https://images.unsplash.com/photo-1566737236500-c8ac43014a67?w=600&auto=format&fit=crop&q=80',
      badge: 'أمان تام للأطفال',
    },
    {
      name: 'تنظيم وتنسيق مؤتمرات وندوات أعمال مع شاشات عرض LED',
      price: 5500,
      comparePrice: 7000,
      unit: 'يوم مؤتمر',
      image: 'https://images.unsplash.com/photo-1511578314322-379afb476865?w=600&auto=format&fit=crop&q=80',
      badge: 'تنظيم متكامل',
    },
  ],
  legal_financial: [
    {
      name: 'خدمة تأسيس شركة ذات مسؤولية محدودة والسجل والبطاقة الضريبية',
      price: 4500,
      comparePrice: 6000,
      unit: 'تأسيس كامل',
      image: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?w=600&auto=format&fit=crop&q=80',
      badge: 'تسليم السجل التجاري ⚖️',
    },
    {
      name: 'استشارة قانونية متخصصة في عقود الشركات وصياغة الاتفاقيات',
      price: 500,
      comparePrice: 700,
      unit: 'جلسة استشارة',
      image: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
      badge: 'محامٍ بالنقض',
    },
    {
      name: 'إعداد الإقرار الضريبي السنوي ودفاتر المحاسبة القانونية',
      price: 1500,
      comparePrice: 2000,
      unit: 'إقرار معتمد',
      image: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
      badge: 'محاسب قانوني',
    },
    {
      name: 'دراسة جدوى اقتصادية وتسويقية متكاملة للمشاريع الجديدة',
      price: 3200,
      comparePrice: 4200,
      unit: 'دراسة كاملة',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&auto=format&fit=crop&q=80',
      badge: 'معتمدة للبنوك',
    },
    {
      name: 'تسجيل العلامات التجارية وحماية الملكية الفكرية بمصر',
      price: 2400,
      comparePrice: 3000,
      unit: 'علامة تجارية',
      image: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?w=600&auto=format&fit=crop&q=80',
      badge: 'فحص وبحث رسمي',
    },
    {
      name: 'إدارة الرواتب والتأمينات الاجتماعية لعمال وموظفي الشركات',
      price: 800,
      comparePrice: 1100,
      unit: 'شهرياً للشركة',
      image: 'https://images.unsplash.com/photo-1554224154-26032ffc0d07?w=600&auto=format&fit=crop&q=80',
      badge: 'مطابقة قانون العمل',
    },
    {
      name: 'تسوية النزاعات والتحكيم التجاري للشركات والمنشآت',
      price: 3500,
      comparePrice: 5000,
      unit: 'جلسة تحكيم',
      image: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
      badge: 'محكم معتمد',
    },
  ],
  industrial_manufacturing: [
    {
      name: 'توريد كراتين شحن وتغليف 5 طبقات للمصانع والمتاجر',
      price: 18,
      comparePrice: 24,
      unit: 'كرتونة مقاس كبير',
      image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&auto=format&fit=crop&q=80',
      badge: 'تحمل عالي 🏭',
    },
    {
      name: 'ماكينة تعبئة وتغليف سوائل أوتوماتيكية استانلس 316',
      price: 48000,
      comparePrice: 55000,
      unit: 'خط تعبئة كامل',
      image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=600&auto=format&fit=crop&q=80',
      badge: 'ضمان سنة صيانة',
    },
    {
      name: 'ألواح صاج مجلفن واستانلس ستيل مقصوص بالليزر حسب الطلب',
      price: 920,
      comparePrice: 1150,
      unit: 'متر مربع قص ليزر',
      image: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?w=600&auto=format&fit=crop&q=80',
      badge: 'دقة CNC',
    },
    {
      name: 'توريد براميل بلاستيك سعة 220 لتر معتمدة للمواد الكيميائية',
      price: 450,
      comparePrice: 550,
      unit: 'برميل غطاء محكم',
      image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=600&auto=format&fit=crop&q=80',
      badge: 'مطابق للمواصفات',
    },
    {
      name: 'قوالب حقن بلاستيك واسطمبات فولاذية عالية الدقة للمصانع',
      price: 25000,
      comparePrice: 32000,
      unit: 'اسطمبة تصنيع',
      image: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=600&auto=format&fit=crop&q=80',
      badge: 'فولاذ معالج',
    },
    {
      name: 'مواتير سحب وتوربينات هواء وشفاطات صناعية للمصانع الكبرى',
      price: 6800,
      comparePrice: 8200,
      unit: 'موتور إيطالي 10 حصان',
      image: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&auto=format&fit=crop&q=80',
      badge: 'تشغيل شاق 24h',
    },
    {
      name: 'توريد رولات أكياس استرتش وفيلم تغليف بالات الشحن للمستودعات',
      price: 180,
      comparePrice: 220,
      unit: 'رول استرتش 3 كجم',
      image: 'https://images.unsplash.com/photo-1586528116493-a029325540fa?w=600&auto=format&fit=crop&q=80',
      badge: 'مرونة عالية',
    },
  ],
};

/**
 * Generates exactly 100 diverse activities & products spanning all 15 sectors
 * and matched with real registered businesses in the platform.
 */
export function generateCurated100Products(
  businesses: Business[],
  functionalGroups: FunctionalGroup[],
  existingProducts: Product[],
  type: 'most_requested' | 'picked_for_you'
): MarqueeProductItem[] {
  const result: MarqueeProductItem[] = [];

  // Group businesses by functionalGroupId
  const businessesBySector = new Map<string, Business[]>();
  for (const biz of businesses) {
    const arr = businessesBySector.get(biz.functionalGroupId) || [];
    arr.push(biz);
    businessesBySector.set(biz.functionalGroupId, arr);
  }

  // 15 Sector IDs in balanced order
  const sectorIds = Object.keys(SECTOR_DIVERSE_ITEMS);

  // Pool of items across all sectors
  const sectorPool: Array<{ sectorId: string; template: SectorTemplate }> = [];
  for (const sectorId of sectorIds) {
    const templates = SECTOR_DIVERSE_ITEMS[sectorId] || [];
    for (const t of templates) {
      sectorPool.push({ sectorId, template: t });
    }
  }

  // Pick or cycle until we reach exactly 100 items
  let itemCounter = 0;
  while (result.length < 100) {
    const poolIndex = (type === 'most_requested' ? itemCounter : itemCounter + 37) % sectorPool.length;
    const { sectorId, template } = sectorPool[poolIndex];

    // Find a matching real business in this sector, or fallback
    const sectorBizs = businessesBySector.get(sectorId) || businesses;
    const biz = sectorBizs[itemCounter % sectorBizs.length] || businesses[0];
    const group = functionalGroups.find((g) => g.id === sectorId) || functionalGroups[0];

    const rank = itemCounter + 1;
    const orderCountBase = type === 'most_requested'
      ? Math.max(85, Math.round(1450 - rank * 13 + (itemCounter % 7) * 9))
      : Math.max(50, Math.round(920 - rank * 7 + (itemCounter % 5) * 12));

    const itemPrice = type === 'picked_for_you' && template.comparePrice
      ? template.price
      : template.price;

    const discountPill = template.comparePrice
      ? `خصم ${Math.round(((template.comparePrice - template.price) / template.comparePrice) * 100)}%`
      : 'عرض حصري';

    const highlightBadge = type === 'most_requested'
      ? rank === 1
        ? 'الأكثر طلباً بالمنطقة 🔥'
        : rank <= 5
        ? `#${rank} الأعلى طلباً 🔥`
        : template.badge
      : rank <= 3
      ? 'ترشيح المنصة الموثق ⭐'
      : template.badge;

    const pseudoProduct: Product = {
      id: `curated_100_${type}_${rank}`,
      businessId: biz.id,
      name: template.name,
      category: biz.category || 'عام',
      type: 'product',
      description: '', // No descriptions on them ("ولا اريد شروحات عليهم")
      price: itemPrice,
      comparePrice: template.comparePrice,
      unit: template.unit,
      imageUrl: template.image,
      isAvailable: true,
    };

    result.push({
      product: pseudoProduct,
      business: biz,
      sectorShortName: group?.shortName || biz.category,
      rankIndex: rank,
      ordersCount: orderCountBase,
      highlightBadge,
    });

    itemCounter++;
  }

  return result.slice(0, 100);
}
