import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_MANTYGO_CHANNELS,
  evaluateProviderBiddingEligibility,
  getEligibleVerifiedProvidersForChannel,
  createCustomMantyGoChannel,
  generateAutomatedVerifiedBidsForRequest,
  applyCustomerCounterOfferToBid,
  submitVerifiedProviderBidOnRequest,
  acceptProviderBidForRequest,
  generateMantyGoAcceptedDealWhatsAppUrl,
  createInitialSeedMantyGoRequests,
} from './mantygoBiddingEngine';
import { INITIAL_BUSINESSES } from '../data/seedData';
import { Business } from '../types';

test('DEFAULT_MANTYGO_CHANNELS contains the 4 core required channels (MantyGo, Home Maintenance, Legal, Accounting)', () => {
  assert.equal(DEFAULT_MANTYGO_CHANNELS.length, 4);
  const ids = DEFAULT_MANTYGO_CHANNELS.map((c) => c.id);
  assert.deepEqual(ids, [
    'mantygo_rides',
    'home_maintenance',
    'legal_consultation',
    'accounting_consultation',
  ]);
});

test('evaluateProviderBiddingEligibility strictly requires verified non-frozen businesses in matching sector', () => {
  const ridesChannel = DEFAULT_MANTYGO_CHANNELS[0];
  const sampleBiz: Business = {
    ...INITIAL_BUSINESSES[0],
    id: 'biz_test_verified',
    name: 'كابتن مصر للنقل السريع',
    functionalGroupId: 'transport_logistics',
    isVerified: true,
    verificationStatus: 'verified',
    isFrozen: false,
    sectorPackageLevel: 3,
    subscriptionTier: 'advanced',
  };

  const eligibleRes = evaluateProviderBiddingEligibility(sampleBiz, ridesChannel);
  assert.equal(eligibleRes.isEligible, true);
  assert.equal(eligibleRes.packageLevel, 3);

  // Unverified business should be blocked from bidding
  const unverifiedBiz: Business = {
    ...sampleBiz,
    id: 'biz_test_unverified',
    isVerified: false,
    verificationStatus: 'unverified',
  };
  const unverifiedRes = evaluateProviderBiddingEligibility(unverifiedBiz, ridesChannel);
  assert.equal(unverifiedRes.isEligible, false);
  assert.ok(unverifiedRes.reasonAr.includes('للأنشطة الموثقة'));

  // Frozen business should be blocked
  const frozenBiz: Business = {
    ...sampleBiz,
    id: 'biz_test_frozen',
    isFrozen: true,
  };
  const frozenRes = evaluateProviderBiddingEligibility(frozenBiz, ridesChannel);
  assert.equal(frozenRes.isEligible, false);
});

test('createCustomMantyGoChannel validates input and creates a dynamic bidding hub', () => {
  const invalid = createCustomMantyGoChannel({
    name: 'أ',
    description: '',
    functionalGroupId: 'healthcare',
    subServicesText: '',
    suggestedMinPriceEgp: 100,
    suggestedMaxPriceEgp: 500,
  });
  assert.equal(invalid.valid, false);

  const valid = createCustomMantyGoChannel({
    name: 'خدمات التمريض والرعاية المنزلية',
    badgeTitle: 'تمريض منزلي فوري',
    description: 'طلب طاقم تمريض منزلي موثق بنظام التفاوض المباشر',
    functionalGroupId: 'healthcare',
    subServicesText: 'تركيب محاليل وحقن, رعاية مسنين بالمنزل, جلسات علاج طبيعي',
    suggestedMinPriceEgp: 150,
    suggestedMaxPriceEgp: 2500,
    unitLabel: 'للزيارة / الشفت',
    requiresPickupDropoff: false,
  });

  assert.equal(valid.valid, true);
  assert.ok(valid.channel);
  assert.equal(valid.channel?.name, 'خدمات التمريض والرعاية المنزلية');
  assert.equal(valid.channel?.subServices.length, 3);
  assert.equal(valid.channel?.isCustomChannel, true);
});

test('full negotiation flow: create request -> automated verified bids -> customer counter-offer -> provider manual bid -> accept bid', () => {
  const maintChannel = DEFAULT_MANTYGO_CHANNELS[1];
  const seedRequests = createInitialSeedMantyGoRequests(INITIAL_BUSINESSES);
  assert.equal(seedRequests.length, 4);

  const maintReq = seedRequests[1];
  assert.equal(maintReq.channelId, 'home_maintenance');
  assert.ok(maintReq.bids.length >= 2);

  const firstBid = maintReq.bids[0];
  // Customer submits a counter-offer
  const counteredReq = applyCustomerCounterOfferToBid(
    maintReq,
    firstBid.id,
    420,
    'مستعد للتنفيذ فوراً بسعر 420 ج.م'
  );
  assert.equal(counteredReq.status, 'negotiating');
  assert.equal(counteredReq.customerProposedPriceEgp, 420);
  const updatedBid = counteredReq.bids.find((b) => b.id === firstBid.id)!;
  assert.equal(updatedBid.status, 'countered_by_user');
  assert.equal(updatedBid.customerCounterPriceEgp, 420);
  assert.ok(updatedBid.negotiationHistory.length >= 4);

  // Verified provider submits a custom bid
  const verifiedMaintBiz: Business = {
    ...INITIAL_BUSINESSES[0],
    id: 'biz_custom_maint_verified',
    name: 'المركز الهندسي الموثق للصيانة',
    functionalGroupId: 'crafts_maintenance',
    isVerified: true,
    verificationStatus: 'verified',
    isFrozen: false,
    sectorPackageLevel: 3,
  };
  const manualBidRes = submitVerifiedProviderBidOnRequest({
    request: counteredReq,
    business: verifiedMaintBiz,
    channel: maintChannel,
    offeredPriceEgp: 410,
    estimatedArrivalOrDelivery: 'خلال 25 دقيقة',
    providerMessage: 'عرض خاص شاملة قطع الغيار والضمان',
  });
  assert.equal(manualBidRes.success, true);
  assert.ok(manualBidRes.updatedRequest);
  assert.equal(manualBidRes.updatedRequest?.bids[0].offeredPriceEgp, 410);

  // Accept the bid
  const winningBidId = manualBidRes.updatedRequest!.bids[0].id;
  const acceptedReq = acceptProviderBidForRequest(manualBidRes.updatedRequest!, winningBidId);
  assert.equal(acceptedReq.status, 'accepted');
  assert.equal(acceptedReq.acceptedBidId, winningBidId);
  assert.equal(acceptedReq.acceptedFinalPriceEgp, 410);

  const waUrl = generateMantyGoAcceptedDealWhatsAppUrl(acceptedReq, acceptedReq.bids[0]);
  assert.ok(waUrl.startsWith('https://wa.me/'));
});
