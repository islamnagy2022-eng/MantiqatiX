import test from 'node:test';
import assert from 'node:assert/strict';
import { canAccessProtectedView, resolveProtectedView } from './accessPolicy.ts';

const ALL_ROLES = [
  'guest', 'subscriber', 'admin', 'super_admin',
  'regional_manager', 'medical_staff', 'customer',
] as const;

const PUBLIC_VIEWS = [
  'directory', 'public_storefront', 'medical_directory',
  'contact_us',
] as const;

test('guest cannot open either dashboard route or member messages', () => {
  for (const route of ['super_admin', 'merchant_admin', 'member_messages'] as const) {
    assert.equal(resolveProtectedView(route, 'guest', 'business-1'), 'directory');
    assert.equal(canAccessProtectedView(route, 'guest', 'business-1'), false);
  }
});

test('subscriber can open only a merchant dashboard for a non-empty assigned business scope', () => {
  assert.equal(resolveProtectedView('merchant_admin', 'subscriber', 'biz-1'), 'merchant_admin');
  assert.equal(resolveProtectedView('merchant_admin', 'subscriber', '  '), 'directory');
  assert.equal(resolveProtectedView('merchant_admin', 'subscriber'), 'directory');
  assert.equal(resolveProtectedView('super_admin', 'subscriber', 'biz-1'), 'directory');
});

test('only platform admin roles can open the platform dashboard', () => {
  for (const role of ['admin', 'super_admin'] as const) {
    assert.equal(resolveProtectedView('super_admin', role), 'super_admin');
  }
  for (const role of ALL_ROLES.filter((role) => role !== 'admin' && role !== 'super_admin')) {
    assert.equal(resolveProtectedView('super_admin', role), 'directory');
  }
});

test('public routes remain available to all recognized roles', () => {
  for (const role of ALL_ROLES) {
    for (const route of PUBLIC_VIEWS) {
      assert.equal(resolveProtectedView(route, role), route);
    }
  }
});

test('member messaging is limited to supported authenticated roles', () => {
  for (const role of ['subscriber', 'admin', 'super_admin'] as const) {
    assert.equal(resolveProtectedView('member_messages', role), 'member_messages');
  }
  for (const role of ['guest', 'regional_manager', 'medical_staff', 'customer'] as const) {
    assert.equal(resolveProtectedView('member_messages', role), 'directory');
  }
});

test('obsolete login route and unknown routes fail closed', () => {
  for (const role of ALL_ROLES) {
    assert.equal(resolveProtectedView('login', role), 'directory');
    assert.equal(resolveProtectedView('unexpected_admin_route', role), 'directory');
  }
});
