import { Business } from '../types';

export interface LatLng {
  lat: number;
  lng: number;
}

export interface GovernorateMapData {
  id: string;
  name: string;
  center: LatLng;
  zoom: number;
}

// Canonical center coordinates for all Egyptian governorates
export const EGYPT_GOVERNORATES_MAP: Record<string, GovernorateMapData> = {
  'القاهرة': { id: 'cairo', name: 'القاهرة', center: { lat: 30.0444, lng: 31.2357 }, zoom: 11 },
  'الجيزة': { id: 'giza', name: 'الجيزة', center: { lat: 30.0131, lng: 31.2089 }, zoom: 11 },
  'الإسكندرية': { id: 'alexandria', name: 'الإسكندرية', center: { lat: 31.2001, lng: 29.9187 }, zoom: 11 },
  'الدقهلية': { id: 'dakahlia', name: 'الدقهلية', center: { lat: 31.0409, lng: 31.3785 }, zoom: 10 },
  'القليوبية': { id: 'qalyubia', name: 'القليوبية', center: { lat: 30.4660, lng: 31.1853 }, zoom: 11 },
  'الشرقية': { id: 'sharqia', name: 'الشرقية', center: { lat: 30.5877, lng: 31.5020 }, zoom: 10 },
  'الغربية': { id: 'gharbia', name: 'الغربية', center: { lat: 30.7865, lng: 31.0004 }, zoom: 11 },
  'المنوفية': { id: 'monufia', name: 'المنوفية', center: { lat: 30.5566, lng: 31.0118 }, zoom: 11 },
  'دمياط': { id: 'damietta', name: 'دمياط', center: { lat: 31.4175, lng: 31.8144 }, zoom: 11 },
  'كفر الشيخ': { id: 'kafr_el_sheikh', name: 'كفر الشيخ', center: { lat: 31.1107, lng: 30.9388 }, zoom: 10 },
  'البحيرة': { id: 'beheira', name: 'البحيرة', center: { lat: 31.0397, lng: 30.4703 }, zoom: 10 },
  'بورسعيد': { id: 'port_said', name: 'بورسعيد', center: { lat: 31.2653, lng: 32.3019 }, zoom: 12 },
  'الإسماعيلية': { id: 'ismailia', name: 'الإسماعيلية', center: { lat: 30.5965, lng: 32.2715 }, zoom: 11 },
  'السويس': { id: 'suez', name: 'السويس', center: { lat: 29.9668, lng: 32.5498 }, zoom: 11 },
  'الفيوم': { id: 'fayoum', name: 'الفيوم', center: { lat: 29.3084, lng: 30.8428 }, zoom: 11 },
  'بني سويف': { id: 'beni_suef', name: 'بني سويف', center: { lat: 29.0661, lng: 31.0994 }, zoom: 11 },
  'المنيا': { id: 'minya', name: 'المنيا', center: { lat: 28.0871, lng: 30.7618 }, zoom: 10 },
  'أسيوط': { id: 'asyut', name: 'أسيوط', center: { lat: 27.1809, lng: 31.1837 }, zoom: 11 },
  'سوهاج': { id: 'sohag', name: 'سوهاج', center: { lat: 26.5590, lng: 31.6957 }, zoom: 11 },
  'قنا': { id: 'qena', name: 'قنا', center: { lat: 26.1551, lng: 32.7160 }, zoom: 11 },
  'الأقصر': { id: 'luxor', name: 'الأقصر', center: { lat: 25.6872, lng: 32.6396 }, zoom: 12 },
  'أسوان': { id: 'aswan', name: 'أسوان', center: { lat: 24.0889, lng: 32.8998 }, zoom: 11 },
  'البحر الأحمر': { id: 'red_sea', name: 'البحر الأحمر', center: { lat: 27.2579, lng: 33.8116 }, zoom: 9 },
  'جنوب سيناء': { id: 'south_sinai', name: 'جنوب سيناء', center: { lat: 27.9158, lng: 34.3299 }, zoom: 9 },
  'شمال سيناء': { id: 'north_sinai', name: 'شمال سيناء', center: { lat: 31.1325, lng: 33.8033 }, zoom: 9 },
  'مطروح': { id: 'matrouh', name: 'مطروح', center: { lat: 31.3543, lng: 27.2373 }, zoom: 9 },
  'الوادي الجديد': { id: 'new_valley', name: 'الوادي الجديد', center: { lat: 25.4514, lng: 30.5464 }, zoom: 8 },
};

// Key centers and neighborhoods coordinates
export const EGYPT_MARKAZ_COORDINATES: Record<string, LatLng> = {
  // الدقهلية
  'المنصورة': { lat: 31.0409, lng: 31.3785 },
  'ميت غمر': { lat: 30.7188, lng: 31.2618 },
  'طلخا': { lat: 31.0542, lng: 31.3794 },
  'السنبلاوين': { lat: 30.8778, lng: 31.5217 },
  'دكرنس': { lat: 31.0850, lng: 31.5960 },
  'شربين': { lat: 31.1963, lng: 31.5204 },
  'بلقاس': { lat: 31.2338, lng: 31.3592 },

  // القاهرة
  'مدينة نصر': { lat: 30.0561, lng: 31.3301 },
  'المعادي': { lat: 29.9599, lng: 31.2584 },
  'التجمع الخامس': { lat: 30.0263, lng: 31.4967 },
  'القاهرة الجديدة': { lat: 30.0263, lng: 31.4967 },
  'مصر الجديدة': { lat: 30.0883, lng: 31.3285 },
  'وسط البلد': { lat: 30.0444, lng: 31.2357 },
  'المعادي ودجلة': { lat: 29.9599, lng: 31.2584 },
  'حلوان': { lat: 29.8498, lng: 31.3342 },
  'شبرا': { lat: 30.0760, lng: 31.2450 },
  'الشروق': { lat: 30.1444, lng: 31.6310 },
  'بدر': { lat: 30.1386, lng: 31.7410 },

  // الجيزة
  'الشيخ زايد': { lat: 30.0528, lng: 30.9708 },
  '6 أكتوبر': { lat: 29.9737, lng: 30.9328 },
  'الدقي': { lat: 30.0384, lng: 31.2124 },
  'المهندسين': { lat: 30.0567, lng: 31.2036 },
  'الهرم': { lat: 29.9974, lng: 31.1506 },
  'فيصل': { lat: 30.0050, lng: 31.1620 },
  'العجوزة': { lat: 30.0610, lng: 31.2160 },

  // الإسكندرية
  'سموحة': { lat: 31.2156, lng: 29.9553 },
  'سيدي جابر': { lat: 31.2201, lng: 29.9419 },
  'محطة الرمل': { lat: 31.2001, lng: 29.9000 },
  'لوران': { lat: 31.2483, lng: 29.9722 },
  'العجمي': { lat: 31.1070, lng: 29.7610 },
  'برج العرب': { lat: 30.9167, lng: 29.5333 },

  // الشرقية
  'الزقازيق': { lat: 30.5877, lng: 31.5020 },
  'العاشر من رمضان': { lat: 30.3013, lng: 31.7432 },
  'بلبيس': { lat: 30.4190, lng: 31.5620 },

  // القليوبية
  'بنها': { lat: 30.4660, lng: 31.1853 },
  'شبرا الخيمة': { lat: 30.1286, lng: 31.2422 },
  'العبور': { lat: 30.2290, lng: 31.4720 },

  // الغربية
  'طنطا': { lat: 30.7865, lng: 31.0004 },
  'المحلة الكبرى': { lat: 30.9706, lng: 31.1669 },

  // المنوفية
  'شبين الكوم': { lat: 30.5566, lng: 31.0118 },
  'قويسنا': { lat: 30.5516, lng: 31.1444 },
  'السادات': { lat: 30.3780, lng: 30.5280 },

  // دمياط
  'دمياط الجديدة': { lat: 31.4420, lng: 31.6700 },
  'رأس البر': { lat: 31.5152, lng: 31.8315 },

  // البحر الأحمر
  'الغردقة': { lat: 27.2579, lng: 33.8116 },
  'الجونة': { lat: 27.3949, lng: 33.6766 },
  'مرسى علم': { lat: 25.0754, lng: 34.8916 },

  // جنوب سيناء
  'شرم الشيخ': { lat: 27.9158, lng: 34.3299 },
  'دهب': { lat: 28.5094, lng: 34.5136 },
};

export const DEFAULT_EGYPT_CENTER: LatLng = { lat: 29.5, lng: 31.2 };
export const DEFAULT_EGYPT_ZOOM = 7;

/**
 * Deterministically compute a micro-offset for businesses located in the same city
 * so their pins do not sit exactly on top of each other.
 */
function getDeterministicOffset(id: string): { latOffset: number; lngOffset: number } {
  let hash = 0;
  for (let i = 0; i < id.length; i++) {
    hash = (hash << 5) - hash + id.charCodeAt(i);
    hash |= 0;
  }
  const factor = 0.007; // ~700 meters spread
  const angle = ((Math.abs(hash) % 360) * Math.PI) / 180;
  const radius = 0.4 + ((Math.abs(hash >> 3) % 100) / 100) * 0.6;
  return {
    latOffset: Math.sin(angle) * factor * radius,
    lngOffset: Math.cos(angle) * factor * radius,
  };
}

/**
 * Resolves the accurate GPS coordinates for any business registered on the platform.
 */
export function resolveBusinessCoordinates(business: Business): LatLng {
  // 1. Direct explicit coordinates on business
  if (
    business.coordinates &&
    typeof business.coordinates.lat === 'number' &&
    typeof business.coordinates.lng === 'number' &&
    business.coordinates.lat > 20 &&
    business.coordinates.lat < 33 &&
    business.coordinates.lng > 24 &&
    business.coordinates.lng < 37
  ) {
    return {
      lat: business.coordinates.lat,
      lng: business.coordinates.lng,
    };
  }

  // 2. Resolve via markaz / city
  const markaz = (business.markaz || '').trim();
  const governorate = (business.governorate || '').trim();
  const offset = getDeterministicOffset(business.id);

  let basePoint: LatLng | null = null;

  if (markaz && EGYPT_MARKAZ_COORDINATES[markaz]) {
    basePoint = EGYPT_MARKAZ_COORDINATES[markaz];
  } else {
    // Check if markaz matches part of a key
    const foundMarkazKey = Object.keys(EGYPT_MARKAZ_COORDINATES).find(
      (k) => markaz.includes(k) || k.includes(markaz)
    );
    if (foundMarkazKey) {
      basePoint = EGYPT_MARKAZ_COORDINATES[foundMarkazKey];
    }
  }

  // 3. Fallback to governorate center
  if (!basePoint) {
    if (governorate && EGYPT_GOVERNORATES_MAP[governorate]) {
      basePoint = EGYPT_GOVERNORATES_MAP[governorate].center;
    } else {
      const foundGovKey = Object.keys(EGYPT_GOVERNORATES_MAP).find(
        (g) => governorate.includes(g) || g.includes(governorate)
      );
      if (foundGovKey) {
        basePoint = EGYPT_GOVERNORATES_MAP[foundGovKey].center;
      }
    }
  }

  // 4. Default fallback to Greater Cairo / Egypt center
  if (!basePoint) {
    basePoint = DEFAULT_EGYPT_CENTER;
  }

  // Apply jitter
  return {
    lat: Number((basePoint.lat + offset.latOffset).toFixed(6)),
    lng: Number((basePoint.lng + offset.lngOffset).toFixed(6)),
  };
}

export interface GovernorateStat {
  name: string;
  count: number;
  verifiedCount: number;
  center: LatLng;
  zoom: number;
}

/**
 * Calculates statistics per governorate for businesses
 */
export function calculateGovernorateStats(businesses: Business[]): GovernorateStat[] {
  const map: Record<string, { count: number; verifiedCount: number }> = {};

  businesses.forEach((b) => {
    const gov = (b.governorate || 'القاهرة').trim();
    if (!map[gov]) {
      map[gov] = { count: 0, verifiedCount: 0 };
    }
    map[gov].count += 1;
    if (b.isVerified || b.verificationStatus === 'verified') {
      map[gov].verifiedCount += 1;
    }
  });

  return Object.entries(map)
    .map(([govName, stats]) => {
      const govInfo = EGYPT_GOVERNORATES_MAP[govName] || {
        center: DEFAULT_EGYPT_CENTER,
        zoom: 10,
      };
      return {
        name: govName,
        count: stats.count,
        verifiedCount: stats.verifiedCount,
        center: govInfo.center,
        zoom: govInfo.zoom,
      };
    })
    .sort((a, b) => b.count - a.count);
}
