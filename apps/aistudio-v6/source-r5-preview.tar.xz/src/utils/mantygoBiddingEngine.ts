import { Business, FunctionalGroupId, SectorPackageLevel } from '../types';
import { resolveBusinessSectorLevel } from './rules';

export type BuiltInMantyGoChannelId =
  | 'mantygo_rides'
  | 'home_maintenance'
  | 'legal_consultation'
  | 'accounting_consultation';

export type MantyGoChannelId = BuiltInMantyGoChannelId | string;

export interface MantyGoServiceChannel {
  id: MantyGoChannelId;
  name: string;
  badgeTitle: string;
  englishTag: string;
  description: string;
  iconName: 'car' | 'wrench' | 'scale' | 'calculator' | 'sparkles' | 'truck' | 'stethoscope' | 'code' | 'shield';
  accentColor: string;
  allowedFunctionalGroups: FunctionalGroupId[];
  subServices: string[];
  suggestedMinPriceEgp: number;
  suggestedMaxPriceEgp: number;
  priceStepEgp: number;
  unitLabel: string;
  requiresPickupDropoff?: boolean;
  requiresUrgencyLevel?: boolean;
  requiresConsultationMode?: boolean;
  isCustomChannel?: boolean;
  packageFeatureLabel: string;
}

export type NegotiationBidStatus =
  | 'offered'          // عرض مقدم من النشاط الموثق
  | 'countered_by_user'// تفاوض مضاد من العميل
  | 'accepted'         // تم قبول العرض والترسية
  | 'declined';        // مرفوض

export interface NegotiationHistoryStep {
  id: string;
  actor: 'customer' | 'provider';
  actorName: string;
  priceEgp: number;
  note: string;
  timestamp: string;
}

export interface MantyGoProviderBid {
  id: string;
  requestId: string;
  businessId: string;
  businessName: string;
  businessCategory: string;
  businessLogoUrl: string;
  businessPhone: string;
  governorate: string;
  markaz: string;
  packageLevel: SectorPackageLevel;
  packageBadge: string;
  isVerified: boolean;
  rating: number;
  completedJobsCount: number;
  offeredPriceEgp: number;
  originalCustomerPriceEgp: number;
  estimatedArrivalOrDelivery: string;
  providerMessage: string;
  perks: string[];
  status: NegotiationBidStatus;
  customerCounterPriceEgp?: number;
  customerCounterNote?: string;
  negotiationHistory: NegotiationHistoryStep[];
  createdAt: string;
}

export type MantyGoRequestStatus =
  | 'open_for_bids' // بانتظار عروض مقدمي الخدمة الموثقين
  | 'negotiating'   // جاري التفاوض الحي والتقارب السعري
  | 'accepted'      // تم الاتفاق وترسية الطلب
  | 'completed'     // تم التنفيذ والاكتمال وتقييم الأداء
  | 'cancelled';    // ملغي

export interface MantyGoServiceRequest {
  id: string;
  channelId: MantyGoChannelId;
  channelName: string;
  subService: string;
  customerName: string;
  customerPhone: string;
  governorate: string;
  markaz: string;
  pickupAddress: string;
  dropoffAddress?: string;
  vehicleOrServiceMode?: string;
  urgencyLevel: 'immediate' | 'today' | 'scheduled';
  details: string;
  customerProposedPriceEgp: number;
  recommendedFairPriceEgp: number;
  status: MantyGoRequestStatus;
  acceptedBidId?: string;
  acceptedBusinessId?: string;
  acceptedFinalPriceEgp?: number;
  routedEligibleProvidersCount: number;
  bids: MantyGoProviderBid[];
  createdAt: string;
  rating?: number; // 1 to 5 stars
  reviewText?: string;
  reviewedAt?: string;
}

export interface ProviderEligibilityResult {
  isEligible: boolean;
  businessId: string;
  businessName: string;
  packageLevel: SectorPackageLevel;
  packageBadge: string;
  isVerified: boolean;
  matchesSector: boolean;
  priorityWeight: number;
  reasonAr: string;
  unlockedPackageRightAr: string;
}

/**
 * The 4 core built-in direct negotiation service channels requested by the user:
 * 1. MANTYGO للمشاوير السريعة
 * 2. الصيانات المنزلية الفورية
 * 3. الاستشارات القانونية
 * 4. الاستشارات المحاسبية والضريبية
 */
export const DEFAULT_MANTYGO_CHANNELS: MantyGoServiceChannel[] = [
  {
    id: 'mantygo_rides',
    name: 'MANTYGO للمشاوير السريعة والتوصيل',
    badgeTitle: 'MANTYGO كابتن ومشاوير',
    englishTag: 'MantyGo Fast Rides & Delivery',
    description:
      'اطلب مشوارك السريع أو توصيل طلباتك وحدد السعر الذي يناسبك بنفسك، وتلقَّ عروضاً فورية من الكباتن وشركات النقل الموثقة في منطقتك.',
    iconName: 'car',
    accentColor: 'from-emerald-600 via-teal-600 to-cyan-700',
    allowedFunctionalGroups: ['transport_logistics', 'services', 'tourism_hotels'],
    subServices: [
      'مشوار سريع ملاكي مكيف (داخل المدينة)',
      'مشوار بين المراكز والمحافظات (سفر خاص)',
      'توصيل طلبات وأوردر سريع (طيار MantyGo)',
      'نقل خفيف وبضائع تجارية سريعة',
      'مشوار عائلي فان / 7 راكب',
      'توصيل طرود ومستندات عاجلة للشركات',
    ],
    suggestedMinPriceEgp: 35,
    suggestedMaxPriceEgp: 1200,
    priceStepEgp: 5,
    unitLabel: 'للمشوار / التوصيلة',
    requiresPickupDropoff: true,
    requiresUrgencyLevel: true,
    packageFeatureLabel: 'خاصية كابتن MantyGo والرد التفاوضي الفوري على المشاوير بالباقات الموثقة',
  },
  {
    id: 'home_maintenance',
    name: 'الصيانات المنزلية والفنية الفورية',
    badgeTitle: 'صيانات منزلية',
    englishTag: 'On-Demand Home Maintenance',
    description:
      'اطلب فني أو شركة صيانة معتمدة (سباكة، كهرباء، تكييف، نجارة، أجهزة منزلية) بالسعر المقترح منك وتفاوض مباشرة مع الأنشطة الموثقة.',
    iconName: 'wrench',
    accentColor: 'from-amber-600 via-orange-600 to-rose-600',
    allowedFunctionalGroups: ['crafts_maintenance', 'real_estate', 'industrial_manufacturing', 'services'],
    subServices: [
      'صيانة وإصلاح التكييف والتبريد وشحن فريون',
      'تأسيس وصيانة الكهرباء والأعطال الطارئة',
      'أعمال السباكة وكشف التسريبات وتغيير الخلاطات',
      'صيانة الأجهزة المنزلية (غسالات، ثلاجات، سخانات)',
      'أعمال النجارة والألوميتال والمطابخ',
      'دهانات وديكورات وتشطيبات سريعة',
      'تركيب وصيانة كاميرات المراقبة والإنتركم',
    ],
    suggestedMinPriceEgp: 100,
    suggestedMaxPriceEgp: 5000,
    priceStepEgp: 25,
    unitLabel: 'للمعاينة / الصيانة',
    requiresPickupDropoff: false,
    requiresUrgencyLevel: true,
    packageFeatureLabel: 'خاصية استقبال طلبات الصيانة المنزلية العاجلة وتقديم عروض الأسعار الموثقة',
  },
  {
    id: 'legal_consultation',
    name: 'الاستشارات القانونية والمحاماة',
    badgeTitle: 'استشارات قانونية',
    englishTag: 'Verified Legal Consultations',
    description:
      'احصل على استشارة قانونية متخصصة، صياغة ومراجعة العقود، أو تأسيس الشركات من مكاتب المحاماة والمستشارين الموثقين بنظام التفاوض المباشر على الأتعاب.',
    iconName: 'scale',
    accentColor: 'from-indigo-700 via-blue-700 to-slate-900',
    allowedFunctionalGroups: ['legal_financial', 'services', 'real_estate'],
    subServices: [
      'استشارة قانونية فورية (هاتفية / أونلاين / بالمكتب)',
      'صياغة ومراجعة عقود البيع والإيجار والشراكة',
      'تأسيس الشركات والسجل التجاري والعلامات التجارية',
      'إجراءات الشهر العقاري والتسجيل العقاري',
      'مذكرات دفاع واستشارات القضايا المدنية والتجارية',
      'استشارات قانون العمل وعقود الموظفين للشركات',
    ],
    suggestedMinPriceEgp: 150,
    suggestedMaxPriceEgp: 6000,
    priceStepEgp: 50,
    unitLabel: 'للاستشارة / الإجراء القانوني',
    requiresPickupDropoff: false,
    requiresConsultationMode: true,
    packageFeatureLabel: 'خاصية التعاقد القانوني الفوري واستقبال طلبات الاستشارات للمكاتب الموثقة',
  },
  {
    id: 'accounting_consultation',
    name: 'الاستشارات المحاسبية والضريبية',
    badgeTitle: 'استشارات محاسبية',
    englishTag: 'Accounting & Tax Advisory',
    description:
      'تواصل مع مكاتب المحاسبة القانونية وخبراء الضرائب الموثقين لإعداد الإقرارات الضريبية، الفاتورة الإلكترونية، ودراسات الجدوى بالسعر التفاوضي المناسب.',
    iconName: 'calculator',
    accentColor: 'from-purple-700 via-violet-700 to-indigo-800',
    allowedFunctionalGroups: ['legal_financial', 'services', 'technology_software', 'industrial_manufacturing'],
    subServices: [
      'إعداد وتقديم الإقرارات الضريبية (دخل / قيمة مضافة)',
      'التسجيل والربط بمنظومة الفاتورة الإلكترونية والإيصال',
      'مراجعة الميزانيات والقوائم المالية السنوية والربع سنوية',
      'فتح ملف ضريبي وتأمينات اجتماعية لنشاط جديد',
      'إعداد دراسة جدوى مالية واحتمالية للمشروعات',
      'تنظيم الدورة المستندية وحسابات التكاليف والمخازن',
    ],
    suggestedMinPriceEgp: 200,
    suggestedMaxPriceEgp: 8000,
    priceStepEgp: 50,
    unitLabel: 'للاستشارة / الملف المحاسبي',
    requiresPickupDropoff: false,
    requiresConsultationMode: true,
    packageFeatureLabel: 'خاصية استقبال طلبات المحاسبة والضرائب المباشرة للمكاتب المعتمدة بالباقات',
  },
];

/**
 * Evaluates whether a Business has the right to receive and bid on MantyGo requests.
 * Per user requirement:
 * "وتحول لمقدمي الخدمة للخاصية الموجودة بالباقات للموجودين بالانشطة الموثقة ولهم الحق بتقديم الخدمة"
 */
export function evaluateProviderBiddingEligibility(
  business: Business,
  channel: MantyGoServiceChannel
): ProviderEligibilityResult {
  const packageLevel = resolveBusinessSectorLevel(business);
  const packageBadge =
    packageLevel === 3
      ? 'باقة المستوى 3 (VIP الذهبية - أولوية قصوى)'
      : packageLevel === 2
      ? 'باقة المستوى 2 (الاحترافية الموثقة)'
      : 'باقة المستوى 1 (الأساسية)';

  const isVerified = Boolean(
    business.isVerified &&
      business.verificationStatus !== 'rejected' &&
      business.verificationStatus !== 'suspended' &&
      !business.isFrozen
  );

  const matchesSector = channel.allowedFunctionalGroups.includes(business.functionalGroupId);

  // Only verified businesses with active package (Level 2 or Level 3, or verified status with non-frozen account)
  // in the matching sector have the right to receive & bid on live customer requests.
  if (business.isFrozen) {
    return {
      isEligible: false,
      businessId: business.id,
      businessName: business.name,
      packageLevel,
      packageBadge,
      isVerified: false,
      matchesSector,
      priorityWeight: 0,
      reasonAr: 'النشاط مجمد مؤقتاً لعدم سداد المستحقات ولا يمكنه استقبال طلبات التفاوض.',
      unlockedPackageRightAr: 'موقوف مؤقتاً لحين تسوية الاشتراك',
    };
  }

  if (!isVerified) {
    return {
      isEligible: false,
      businessId: business.id,
      businessName: business.name,
      packageLevel,
      packageBadge,
      isVerified: false,
      matchesSector,
      priorityWeight: 0,
      reasonAr: 'خاصية استقبال طلبات التفاوض الفوري والتقارب السعري متاحة حصرياً للأنشطة الموثقة المشتركة بالباقات المعتمدة.',
      unlockedPackageRightAr: 'يتطلب توثيق النشاط وترقية الباقة للمستوى 2 أو 3',
    };
  }

  if (!matchesSector) {
    return {
      isEligible: false,
      businessId: business.id,
      businessName: business.name,
      packageLevel,
      packageBadge,
      isVerified: true,
      matchesSector: false,
      priorityWeight: 0,
      reasonAr: `هذا النشاط موثق ولكنه مسجل في قطاع مختلف عن (${channel.badgeTitle}).`,
      unlockedPackageRightAr: 'مفعل في قطاع النشاط الأساسي فقط',
    };
  }

  const priorityWeight =
    (packageLevel === 3 ? 300 : packageLevel === 2 ? 200 : 120) +
    (business.verificationBadgeLevel === 'gold' ? 50 : business.verificationBadgeLevel === 'silver' ? 25 : 10) +
    Math.min(100, (business.totalOrdersCount || 0) * 2);

  return {
    isEligible: true,
    businessId: business.id,
    businessName: business.name,
    packageLevel,
    packageBadge,
    isVerified: true,
    matchesSector: true,
    priorityWeight,
    reasonAr: `نشاط موثق ومؤهل بالكامل لاستقبال الطلبات وتقديم عروض الأسعار التفاوضية عبر (${packageBadge}).`,
    unlockedPackageRightAr: channel.packageFeatureLabel,
  };
}

/**
 * Returns all eligible verified businesses for a given service channel, ranked by package level and governorate affinity.
 */
export function getEligibleVerifiedProvidersForChannel(
  businesses: Business[],
  channel: MantyGoServiceChannel,
  preferredGovernorate?: string
): {
  eligibleProviders: { business: Business; eligibility: ProviderEligibilityResult }[];
  ineligibleUnverifiedCount: number;
} {
  let ineligibleUnverifiedCount = 0;
  const eligibleProviders: { business: Business; eligibility: ProviderEligibilityResult }[] = [];

  for (const biz of businesses) {
    const matchesSector = channel.allowedFunctionalGroups.includes(biz.functionalGroupId);
    if (matchesSector && (!biz.isVerified || biz.isFrozen)) {
      ineligibleUnverifiedCount++;
    }
    const eligibility = evaluateProviderBiddingEligibility(biz, channel);
    if (eligibility.isEligible) {
      eligibleProviders.push({ business: biz, eligibility });
    }
  }

  // Fallback: if a custom or specialized channel has fewer than 2 exact-sector verified businesses,
  // also include top Level-3 VIP verified service businesses so the user always sees live verified providers
  if (eligibleProviders.length < 2) {
    for (const biz of businesses) {
      if (biz.isVerified && !biz.isFrozen && !eligibleProviders.some((p) => p.business.id === biz.id)) {
        const level = resolveBusinessSectorLevel(biz);
        if (level >= 2) {
          eligibleProviders.push({
            business: biz,
            eligibility: {
              isEligible: true,
              businessId: biz.id,
              businessName: biz.name,
              packageLevel: level,
              packageBadge:
                level === 3
                  ? 'باقة المستوى 3 (VIP الذهبية - تغطية شاملة)'
                  : 'باقة المستوى 2 (الاحترافية الموثقة)',
              isVerified: true,
              matchesSector: true,
              priorityWeight: level === 3 ? 250 : 180,
              reasonAr: 'نشاط موثق معتمد بالباقات المتقدمة لتغطية خدمات المنصة.',
              unlockedPackageRightAr: channel.packageFeatureLabel,
            },
          });
        }
        if (eligibleProviders.length >= 5) break;
      }
    }
  }

  eligibleProviders.sort((a, b) => {
    const govBonusA = preferredGovernorate && a.business.governorate === preferredGovernorate ? 120 : 0;
    const govBonusB = preferredGovernorate && b.business.governorate === preferredGovernorate ? 120 : 0;
    return b.eligibility.priorityWeight + govBonusB - (a.eligibility.priorityWeight + govBonusA);
  });

  return {
    eligibleProviders,
    ineligibleUnverifiedCount,
  };
}

/**
 * Validates creating a new custom Service Activity Channel ("امكانية اضافة انشطة اخري بنفس النظام").
 */
export function createCustomMantyGoChannel(input: {
  name: string;
  badgeTitle?: string;
  description: string;
  functionalGroupId: FunctionalGroupId;
  subServicesText: string;
  suggestedMinPriceEgp: number;
  suggestedMaxPriceEgp: number;
  unitLabel?: string;
  requiresPickupDropoff?: boolean;
}): { valid: boolean; error?: string; channel?: MantyGoServiceChannel } {
  const cleanName = (input.name || '').trim();
  if (!cleanName || cleanName.length < 3) {
    return { valid: false, error: 'يرجى إدخال اسم النشاط أو الخدمة الجديدة (3 أحرف على الأقل).' };
  }

  const subServices = (input.subServicesText || '')
    .split(/[,،\n]/)
    .map((s) => s.trim())
    .filter(Boolean);

  const finalSubServices =
    subServices.length > 0
      ? subServices
      : [`طلب خدمة ${cleanName} فورية`, `معاينة وتنفيذ ${cleanName}`, `استشارة وتعاقد ${cleanName}`];

  const minPrice = Math.max(10, Number(input.suggestedMinPriceEgp) || 100);
  const maxPrice = Math.max(minPrice + 50, Number(input.suggestedMaxPriceEgp) || minPrice * 10);

  const channel: MantyGoServiceChannel = {
    id: `custom_channel_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    name: cleanName,
    badgeTitle: (input.badgeTitle || cleanName).trim(),
    englishTag: 'Custom On-Demand Bidding Hub',
    description:
      (input.description || '').trim() ||
      `نظام طلب وتفاوض مباشر لخدمات (${cleanName}) موجه للأنشطة الموثقة المشتركة في الباقات المعتمدة.`,
    iconName: 'sparkles',
    accentColor: 'from-teal-600 via-emerald-600 to-indigo-700',
    allowedFunctionalGroups: [input.functionalGroupId, 'services'],
    subServices: finalSubServices,
    suggestedMinPriceEgp: minPrice,
    suggestedMaxPriceEgp: maxPrice,
    priceStepEgp: minPrice < 100 ? 10 : 25,
    unitLabel: (input.unitLabel || 'للخدمة / الطلب').trim(),
    requiresPickupDropoff: Boolean(input.requiresPickupDropoff),
    requiresUrgencyLevel: true,
    isCustomChannel: true,
    packageFeatureLabel: `خاصية استقبال طلبات (${cleanName}) والتفاوض السعري للأنشطة الموثقة بالباقات`,
  };

  return { valid: true, channel };
}

/**
 * Generates realistic initial counter-offers / bids from verified businesses when a customer submits a request,
 * so the real-time negotiation loop works immediately and deterministically.
 */
export function generateAutomatedVerifiedBidsForRequest(
  request: Omit<MantyGoServiceRequest, 'bids' | 'routedEligibleProvidersCount'>,
  businesses: Business[],
  channel: MantyGoServiceChannel
): {
  bids: MantyGoProviderBid[];
  routedCount: number;
} {
  const { eligibleProviders } = getEligibleVerifiedProvidersForChannel(
    businesses,
    channel,
    request.governorate
  );

  const selectedProviders = eligibleProviders.slice(0, 4);
  const basePrice = Math.max(20, request.customerProposedPriceEgp);

  // Price multipliers: first provider accepts exact customer price, others propose slight counter-offers (+10%, +18%, -5%)
  const multipliers = [1.0, 1.12, 1.22, 0.95];
  const etas =
    channel.id === 'mantygo_rides'
      ? ['خلال 4 دقائق (قريب جداً منك)', 'خلال 7 دقائق', 'خلال 9 دقائق', 'خلال 12 دقيقة']
      : channel.id === 'home_maintenance'
      ? ['وصول الفني خلال 35 دقيقة', 'معاينة وتنفيذ خلال ساعة', 'متاح اليوم في الموعد المحدد', 'فريق طوارئ خلال 45 دقيقة']
      : ['رد واستشارة فورية الآن', 'موعد مكتبي أو أونلاين خلال 30 دقيقة', 'تجهيز العقود والمراجعة اليوم', 'استشارة تفصيلية شاملة'];

  const perksPool =
    channel.id === 'mantygo_rides'
      ? [
          ['سيارة مكيفة حديثة', 'كابتن موثق 5 نجوم', 'التزام كامل بالسعر'],
          ['سيارة فئة أولى مريحة', 'إمكانية انتظار إضافي', 'دفع كاش أو محفظة'],
          ['أسرع مسار عبر الخريطة', 'تأمين كامل على الرحلة والتوصيل'],
          ['خصم 5% لعملاء منطقتي X', 'توصيل لباب المنزل'],
        ]
      : channel.id === 'home_maintenance'
      ? [
          ['ضمان 6 أشهر على الصيانة', 'قطع غيار أصلية معتمدة', 'معاينة مجانية عند التنفيذ'],
          ['فنيون معتمدون وموثقون', 'التزام بالمواعيد', 'فاتورة ضمان رسمية'],
          ['شامل العدد والخامات الأساسية', 'خدمة طوارئ 24 ساعة'],
          ['خصم خاص لأعضاء المنصة', 'متابعة فنية بعد الإصلاح'],
        ]
      : [
          ['مكتب معتمد وموثق رسمياً', 'سرية تامة للبيانات والمستندات', 'متابعة شاملة للملف'],
          ['خبرة أكثر من 12 عاماً', 'صياغة قانونية/محاسبية دقيقة', 'استشارة متابعة مجانية'],
          ['إنجاز الإجراءات الحكومية بسرعة', 'مراجعة شاملة للعقود والضرائب'],
          ['سعر تفاوضي خاص لعملاء المنصة', 'تقرير مكتوب ومعتمد'],
        ];

  const bids: MantyGoProviderBid[] = selectedProviders.map(({ business, eligibility }, idx) => {
    const rawOffer = Math.round((basePrice * (multipliers[idx % multipliers.length] || 1)) / 5) * 5;
    const offeredPriceEgp = Math.max(channel.suggestedMinPriceEgp, rawOffer);
    const isExactMatch = offeredPriceEgp === basePrice;

    const noteText = isExactMatch
      ? `موافق على سعرك المقترح (${offeredPriceEgp} ج.م) وجاهز للتنفيذ الفوري بأعلى جودة.`
      : offeredPriceEgp > basePrice
      ? `عرضنا (${offeredPriceEgp} ج.م) شامل الخدمة الكاملة والضمان الموثق عبر ${business.name}. قابل للتفاوض.`
      : `عرض تنافسي خاص (${offeredPriceEgp} ج.م) من ${business.name} لخدمتك فوراً في ${request.governorate}.`;

    const nowTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

    return {
      id: `bid_${Date.now()}_${idx}_${business.id}`,
      requestId: request.id,
      businessId: business.id,
      businessName: business.name,
      businessCategory: business.category,
      businessLogoUrl: business.logoUrl,
      businessPhone: business.ownerWhatsApp || business.phone || '201010171770',
      governorate: business.governorate,
      markaz: business.markaz,
      packageLevel: eligibility.packageLevel,
      packageBadge: eligibility.packageBadge,
      isVerified: true,
      rating: Number((4.9 - (idx % 3) * 0.1).toFixed(1)),
      completedJobsCount: (business.totalOrdersCount || 45) + 30 - idx * 5,
      offeredPriceEgp,
      originalCustomerPriceEgp: basePrice,
      estimatedArrivalOrDelivery: etas[idx % etas.length],
      providerMessage: noteText,
      perks: perksPool[idx % perksPool.length],
      status: 'offered',
      negotiationHistory: [
        {
          id: `hist_init_${idx}`,
          actor: 'customer',
          actorName: request.customerName,
          priceEgp: basePrice,
          note: `السعر المبدئي المقترح من العميل لطلب (${request.subService})`,
          timestamp: nowTime,
        },
        {
          id: `hist_bid_${idx}`,
          actor: 'provider',
          actorName: business.name,
          priceEgp: offeredPriceEgp,
          note: noteText,
          timestamp: nowTime,
        },
      ],
      createdAt: nowTime,
    };
  });

  return {
    bids,
    routedCount: Math.max(eligibleProviders.length, selectedProviders.length),
  };
}

/**
 * Customer sends a counter-offer price to a specific provider bid (or updates request price),
 * and optionally triggers a smart provider response.
 */
export function applyCustomerCounterOfferToBid(
  request: MantyGoServiceRequest,
  bidId: string,
  counterPriceEgp: number,
  counterNote?: string
): MantyGoServiceRequest {
  const safePrice = Math.max(10, Math.round(counterPriceEgp));
  const nowTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

  const updatedBids = request.bids.map((bid) => {
    if (bid.id !== bidId) return bid;

    const custNote =
      (counterNote || '').trim() ||
      `عرض مضاد من العميل: أقترح مبلغ ${safePrice} ج.م لإتمام الاتفاق فوراً.`;

    // Smart negotiation convergence: if customer's counter-offer is within 15% of provider's offer,
    // provider meets halfway or agrees!
    const diffRatio = Math.abs(bid.offeredPriceEgp - safePrice) / Math.max(1, bid.offeredPriceEgp);
    const providerAgreedPrice =
      diffRatio <= 0.15
        ? safePrice
        : Math.round(((bid.offeredPriceEgp + safePrice) / 2) / 5) * 5;

    const providerReplyNote =
      providerAgreedPrice === safePrice
        ? `تمت الموافقة من (${bid.businessName}) على سعرك التفاوضي (${safePrice} ج.م)! يمكنك تأكيد القبول الآن.`
        : `رد تفاوضي من (${bid.businessName}): نقدر عرضك، ويمكننا النزول بالسعر إلى (${providerAgreedPrice} ج.م) شامل كافة المميزات.`;

    return {
      ...bid,
      status: 'countered_by_user' as NegotiationBidStatus,
      customerCounterPriceEgp: safePrice,
      customerCounterNote: custNote,
      offeredPriceEgp: providerAgreedPrice,
      providerMessage: providerReplyNote,
      negotiationHistory: [
        ...bid.negotiationHistory,
        {
          id: `hist_cust_${Date.now()}`,
          actor: 'customer' as const,
          actorName: request.customerName,
          priceEgp: safePrice,
          note: custNote,
          timestamp: nowTime,
        },
        {
          id: `hist_prov_${Date.now() + 1}`,
          actor: 'provider' as const,
          actorName: bid.businessName,
          priceEgp: providerAgreedPrice,
          note: providerReplyNote,
          timestamp: nowTime,
        },
      ],
    };
  });

  return {
    ...request,
    status: 'negotiating',
    customerProposedPriceEgp: safePrice,
    bids: updatedBids,
  };
}

/**
 * Allows a verified business (in Provider Mode) to submit a new live bid or update its existing bid on a customer request.
 */
export function submitVerifiedProviderBidOnRequest(params: {
  request: MantyGoServiceRequest;
  business: Business;
  channel: MantyGoServiceChannel;
  offeredPriceEgp: number;
  estimatedArrivalOrDelivery: string;
  providerMessage: string;
}): {
  success: boolean;
  error?: string;
  updatedRequest?: MantyGoServiceRequest;
} {
  const { request, business, channel, offeredPriceEgp, estimatedArrivalOrDelivery, providerMessage } = params;
  const eligibility = evaluateProviderBiddingEligibility(business, channel);

  if (!eligibility.isEligible) {
    return {
      success: false,
      error: eligibility.reasonAr,
    };
  }

  const safePrice = Math.max(10, Math.round(offeredPriceEgp));
  if (!safePrice || Number.isNaN(safePrice)) {
    return {
      success: false,
      error: 'يرجى إدخال قيمة عرض السعر بالجنيه المصري.',
    };
  }

  const nowTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  const cleanMsg =
    (providerMessage || '').trim() ||
    `عرض رسمي من ${business.name} (نشاط موثق) بقيمة ${safePrice} ج.م لتنفيذ الطلب بأعلى كفاءة.`;
  const cleanEta = (estimatedArrivalOrDelivery || '').trim() || 'جاهز للتنفيذ الفوري';

  const existingBidIndex = request.bids.findIndex((b) => b.businessId === business.id);
  let nextBids: MantyGoProviderBid[];

  if (existingBidIndex >= 0) {
    nextBids = request.bids.map((b, idx) =>
      idx === existingBidIndex
        ? {
            ...b,
            offeredPriceEgp: safePrice,
            estimatedArrivalOrDelivery: cleanEta,
            providerMessage: cleanMsg,
            status: 'offered',
            negotiationHistory: [
              ...b.negotiationHistory,
              {
                id: `hist_prov_manual_${Date.now()}`,
                actor: 'provider',
                actorName: business.name,
                priceEgp: safePrice,
                note: cleanMsg,
                timestamp: nowTime,
              },
            ],
          }
        : b
    );
  } else {
    const newBid: MantyGoProviderBid = {
      id: `bid_manual_${Date.now()}_${business.id}`,
      requestId: request.id,
      businessId: business.id,
      businessName: business.name,
      businessCategory: business.category,
      businessLogoUrl: business.logoUrl,
      businessPhone: business.ownerWhatsApp || business.phone || '201010171770',
      governorate: business.governorate,
      markaz: business.markaz,
      packageLevel: eligibility.packageLevel,
      packageBadge: eligibility.packageBadge,
      isVerified: true,
      rating: 4.9,
      completedJobsCount: (business.totalOrdersCount || 50) + 15,
      offeredPriceEgp: safePrice,
      originalCustomerPriceEgp: request.customerProposedPriceEgp,
      estimatedArrivalOrDelivery: cleanEta,
      providerMessage: cleanMsg,
      perks: ['نشاط موثق رسمياً', eligibility.packageBadge, 'ضمان جودة التنفيذ'],
      status: 'offered',
      negotiationHistory: [
        {
          id: `hist_init_manual_${Date.now()}`,
          actor: 'customer',
          actorName: request.customerName,
          priceEgp: request.customerProposedPriceEgp,
          note: `السعر المبدئي للعميل: ${request.customerProposedPriceEgp} ج.م`,
          timestamp: nowTime,
        },
        {
          id: `hist_prov_new_${Date.now() + 1}`,
          actor: 'provider',
          actorName: business.name,
          priceEgp: safePrice,
          note: cleanMsg,
          timestamp: nowTime,
        },
      ],
      createdAt: nowTime,
    };
    nextBids = [newBid, ...request.bids];
  }

  return {
    success: true,
    updatedRequest: {
      ...request,
      status: request.status === 'accepted' ? 'accepted' : 'negotiating',
      bids: nextBids,
    },
  };
}

/**
 * Customer accepts a bid -> locks the agreement and marks the request as accepted.
 */
export function acceptProviderBidForRequest(
  request: MantyGoServiceRequest,
  bidId: string
): MantyGoServiceRequest {
  const targetBid = request.bids.find((b) => b.id === bidId);
  if (!targetBid) return request;

  const nowTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

  return {
    ...request,
    status: 'accepted',
    acceptedBidId: targetBid.id,
    acceptedBusinessId: targetBid.businessId,
    acceptedFinalPriceEgp: targetBid.offeredPriceEgp,
    bids: request.bids.map((b) =>
      b.id === bidId
        ? {
            ...b,
            status: 'accepted',
            negotiationHistory: [
              ...b.negotiationHistory,
              {
                id: `hist_accept_${Date.now()}`,
                actor: 'customer',
                actorName: request.customerName,
                priceEgp: b.offeredPriceEgp,
                note: `تم قبول العرض والاتفاق النهائي على مبلغ ${b.offeredPriceEgp} ج.م!`,
                timestamp: nowTime,
              },
            ],
          }
        : {
            ...b,
            status: 'declined',
          }
    ),
  };
}

/**
 * Generates a direct WhatsApp dispatch URL once a negotiation bid is accepted.
 */
export function generateMantyGoAcceptedDealWhatsAppUrl(
  request: MantyGoServiceRequest,
  bid: MantyGoProviderBid
): string {
  const cleanPhone = (bid.businessPhone || '201010171770').replace(/[^0-9]/g, '');
  const formattedPhone = cleanPhone.startsWith('01') ? `2${cleanPhone}` : cleanPhone;

  let text = `🚀 *تأكيد اتفاق وتفاوض مباشر عبر MantyGo (منطقتي X)*\n`;
  text += `━━━━━━━━━━━━━━━━━━━━\n`;
  text += `🏷️ *القسم الخدمي:* ${request.channelName}\n`;
  text += `⚡ *الخدمة المطلوبة:* ${request.subService}\n`;
  text += `🏢 *مقدم الخدمة الموثق:* ${bid.businessName} (${bid.packageBadge})\n`;
  text += `💰 *السعر المتفق عليه بعد التفاوض:* ${bid.offeredPriceEgp} ج.م (بدلاً من المقترح المبدئي ${request.customerProposedPriceEgp} ج.م)\n`;
  text += `⏱️ *موعد الوصول / التنفيذ:* ${bid.estimatedArrivalOrDelivery}\n`;
  text += `━━━━━━━━━━━━━━━━━━━━\n`;
  text += `👤 *اسم العميل:* ${request.customerName}\n`;
  text += `📱 *هاتف العميل:* ${request.customerPhone}\n`;
  text += `📍 *الموقع / نقطة الانطلاق:* ${request.governorate} - ${request.markaz} (${request.pickupAddress})\n`;
  if (request.dropoffAddress) {
    text += `🏁 *نقطة الوصول (الوجهة):* ${request.dropoffAddress}\n`;
  }
  if (request.details) {
    text += `📝 *ملاحظات الطلب:* ${request.details}\n`;
  }
  text += `━━━━━━━━━━━━━━━━━━━━\n`;
  text += `✅ *حالة الطلب:* تم قبول العرض والترسية عبر نظام التفاوض الذكي MantiqatiX`;

  return `https://wa.me/${formattedPhone}?text=${encodeURIComponent(text)}`;
}

/**
 * Creates deterministic initial live requests across the 4 built-in channels so the user immediately sees
 * active requests, verified provider bids, and live negotiation histories on first paint.
 */
export function createInitialSeedMantyGoRequests(businesses: Business[]): MantyGoServiceRequest[] {
  const ridesChannel = DEFAULT_MANTYGO_CHANNELS[0];
  const maintChannel = DEFAULT_MANTYGO_CHANNELS[1];
  const legalChannel = DEFAULT_MANTYGO_CHANNELS[2];
  const accChannel = DEFAULT_MANTYGO_CHANNELS[3];

  const baseRequests: Omit<MantyGoServiceRequest, 'bids' | 'routedEligibleProvidersCount'>[] = [
    {
      id: 'mgo_req_1',
      channelId: 'mantygo_rides',
      channelName: ridesChannel.name,
      subService: 'مشوار سريع ملاكي مكيف (داخل المدينة)',
      customerName: 'أحمد محمود الشناوي',
      customerPhone: '01012349876',
      governorate: 'الدقهلية',
      markaz: 'المنصورة',
      pickupAddress: 'شارع الجمهورية أمام جامعة المنصورة',
      dropoffAddress: 'حي توريل الجديدة - شارع الإمام محمد عبده',
      vehicleOrServiceMode: 'ملاكي مكيف حديث (كابتن MantyGo)',
      urgencyLevel: 'immediate',
      details: 'مشوار فوري، معي حقيبة لابتوب فقط وأرغب في الوصول خلال 15 دقيقة.',
      customerProposedPriceEgp: 55,
      recommendedFairPriceEgp: 60,
      status: 'negotiating',
      createdAt: 'منذ 3 دقائق',
    },
    {
      id: 'mgo_req_2',
      channelId: 'home_maintenance',
      channelName: maintChannel.name,
      subService: 'صيانة وإصلاح التكييف والتبريد وشحن فريون',
      customerName: 'م. كريم عبد الرحمن',
      customerPhone: '01098765432',
      governorate: 'الدقهلية',
      markaz: 'المنصورة',
      pickupAddress: 'المشاية السفلية - برج النيل الدور السادس',
      vehicleOrServiceMode: 'زيارة فني معتمد بالمنزل + ضمان',
      urgencyLevel: 'today',
      details: 'جهاز تكييف اسبليت 2.25 حصان يحتاج غسيل كيميائي ومراجعة شحن الفريون بالكامل.',
      customerProposedPriceEgp: 450,
      recommendedFairPriceEgp: 500,
      status: 'negotiating',
      createdAt: 'منذ 12 دقيقة',
    },
    {
      id: 'mgo_req_3',
      channelId: 'legal_consultation',
      channelName: legalChannel.name,
      subService: 'صياغة ومراجعة عقود البيع والإيجار والشراكة',
      customerName: 'د. طارق الجندي',
      customerPhone: '01122334455',
      governorate: 'القاهرة',
      markaz: 'مدينة نصر',
      pickupAddress: 'مكرم عبيد - استشارة بمقر المكتب أو عبر Zoom',
      vehicleOrServiceMode: 'مراجعة وصياغة عقد شراكة تجارية موثق',
      urgencyLevel: 'today',
      details: 'مطلوب صياغة عقد شراكة لشركة تجارية ذات مسؤولية محدودة ومراجعة بنود التخارج والضمانات.',
      customerProposedPriceEgp: 1200,
      recommendedFairPriceEgp: 1400,
      status: 'negotiating',
      createdAt: 'منذ 25 دقيقة',
    },
    {
      id: 'mgo_req_4',
      channelId: 'accounting_consultation',
      channelName: accChannel.name,
      subService: 'التسجيل والربط بمنظومة الفاتورة الإلكترونية والإيصال',
      customerName: 'شركة النور للتجارة والتوريدات',
      customerPhone: '01234567890',
      governorate: 'الدقهلية',
      markaz: 'طلخا',
      pickupAddress: 'شارع صلاح سالم - مقر الشركة أو أونلاين',
      vehicleOrServiceMode: 'تأسيس ملف ضريبي وربط الفاتورة الإلكترونية',
      urgencyLevel: 'scheduled',
      details: 'مطلوب محاسب قانوني معتمد لإتمام ربط منظومة الفاتورة الإلكترونية ومراجعة إقرار القيمة المضافة.',
      customerProposedPriceEgp: 1500,
      recommendedFairPriceEgp: 1650,
      status: 'negotiating',
      createdAt: 'منذ 40 دقيقة',
    },
  ];

  const channelsMap: Record<string, MantyGoServiceChannel> = {
    mantygo_rides: ridesChannel,
    home_maintenance: maintChannel,
    legal_consultation: legalChannel,
    accounting_consultation: accChannel,
  };

  return baseRequests.map((req) => {
    const ch = channelsMap[req.channelId] || ridesChannel;
    const { bids, routedCount } = generateAutomatedVerifiedBidsForRequest(req, businesses, ch);
    return {
      ...req,
      routedEligibleProvidersCount: routedCount,
      bids,
    };
  });
}

/**
 * Customer submits a rating (1-5) and review upon service execution completion.
 * Results and reviews are restricted to management view (يظهر النتيجة للادارة فقط).
 */
export function submitRequestRatingAndReview(
  request: MantyGoServiceRequest,
  rating: number,
  reviewText: string
): MantyGoServiceRequest {
  const safeRating = Math.max(1, Math.min(5, Math.round(rating)));
  const nowTime = new Date().toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  return {
    ...request,
    status: 'completed',
    rating: safeRating,
    reviewText: (reviewText || '').trim() || 'تقييم ممتاز للخدمة وجودة الأداء.',
    reviewedAt: nowTime,
  };
}

