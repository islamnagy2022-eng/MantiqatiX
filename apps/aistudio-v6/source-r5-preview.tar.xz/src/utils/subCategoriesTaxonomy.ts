import { Business, FunctionalGroupId } from '../types';
import { normalizeArabicText } from './searchEngine';

export interface SubCategoryItem {
  id: string;
  name: string;
  sectorId: FunctionalGroupId;
  sectorName: string;
  iconName: string;
  keywords: string[];
  description: string;
}

export const SECTOR_SUBCATEGORIES_MAP: Record<FunctionalGroupId, SubCategoryItem[]> = {
  dining: [
    {
      id: 'sub_dining_restaurants',
      name: 'مطاعم ومأكولات شرقية وغربية',
      sectorId: 'dining',
      sectorName: 'قطاع الأغذية والمطاعم والمقاهي',
      iconName: 'UtensilsCrossed',
      keywords: ['مطعم', 'مشويات', 'كباب', 'كفتة', 'أسماك', 'سي فود', 'شاورما', 'طواجن', 'حواوشي'],
      description: 'أشهى المأكولات والمطاعم الشرقية، المشويات، والأسماك مع خدمة الصالة والتوصيل.',
    },
    {
      id: 'sub_dining_cafes',
      name: 'مقاهي وكافيهات ومحامص بن',
      sectorId: 'dining',
      sectorName: 'قطاع الأغذية والمطاعم والمقاهي',
      iconName: 'Coffee',
      keywords: ['كافيه', 'مقهى', 'قهوة', 'اسبريسو', 'محمصة', 'بن', 'مشروبات ساخنة', 'شاي'],
      description: 'أجود أنواع البن المختص المحموص طازجاً، مشروبات الإسبريسو، وجلسات هادئة.',
    },
    {
      id: 'sub_dining_fastfood',
      name: 'وجبات سريعة وبرجر وبيتزا',
      sectorId: 'dining',
      sectorName: 'قطاع الأغذية والمطاعم والمقاهي',
      iconName: 'Pizza',
      keywords: ['وجبات سريعة', 'برجر', 'بيتزا', 'كريب', 'سندوتشات', 'فرايد تشيكن', 'تيك اواي'],
      description: 'سندوتشات سريعة، بيتزا إيطالي وفطائر، برجر دجاج ولحم بأسرع وقت.',
    },
    {
      id: 'sub_dining_sweets',
      name: 'حلويات ومخابز ومعجنات',
      sectorId: 'dining',
      sectorName: 'قطاع الأغذية والمطاعم والمقاهي',
      iconName: 'Cake',
      keywords: ['حلويات', 'مخبز', 'تورتة', 'كيك', 'جاتوه', 'بسبوسة', 'كنافة', 'معجنات', 'عيش فينوه'],
      description: 'حلويات شرقية وغربية طازجة، تورتات مناسبات، ومخبوزات يومية.',
    },
    {
      id: 'sub_dining_juices',
      name: 'عصائر فريش وآيس كريم ووافل',
      sectorId: 'dining',
      sectorName: 'قطاع الأغذية والمطاعم والمقاهي',
      iconName: 'Citrus',
      keywords: ['عصير', 'فريش', 'ايس كريم', 'وافل', 'بان كيك', 'زبادو', 'سموزي', 'كوكتيل'],
      description: 'عصائر فواكه طبيعية مثلجة، آيس كريم إيطالي، ووافل بالشوكولاتة الفاخرة.',
    },
    {
      id: 'sub_dining_catering',
      name: 'تموين غذائي وحفلات كيترينج',
      sectorId: 'dining',
      sectorName: 'قطاع الأغذية والمطاعم والمقاهي',
      iconName: 'ChefHat',
      keywords: ['كيترينج', 'بوفيه', 'وجبات شركات', 'عزومات', 'تموين', 'طبخ ولائم'],
      description: 'توريد وجبات يومية للشركات، إعداد ولائم العائلات والمناسبات الكبرى.',
    },
  ],

  retail: [
    {
      id: 'sub_retail_fashion',
      name: 'أزياء وملابس وعبايات وأحذية',
      sectorId: 'retail',
      sectorName: 'قطاع التجزئة والسلع والمنتجات',
      iconName: 'Shirt',
      keywords: ['ملابس', 'ازياء', 'عبايات', 'فساتين', 'احذية', 'بدل رجالي', 'شنط', 'طرح'],
      description: 'أحدث صيحات الموضة والأزياء الرجالية والنسائية وفساتين السهرة والعبايات.',
    },
    {
      id: 'sub_retail_supermarket',
      name: 'سوبرماركت ومواد غذائية ولحوم',
      sectorId: 'retail',
      sectorName: 'قطاع التجزئة والسلع والمنتجات',
      iconName: 'ShoppingBag',
      keywords: ['سوبرماركت', 'بقالة', 'لحوم', 'خضار', 'فواكه', 'جبن', 'البان', 'مجمدات'],
      description: 'كافة احتياجات المنزل اليومية من ألبان، خضروات، لحوم، وسلع تموينية.',
    },
    {
      id: 'sub_retail_electronics',
      name: 'إلكترونيات وهواتف ذكية وأجهزة',
      sectorId: 'retail',
      sectorName: 'قطاع التجزئة والسلع والمنتجات',
      iconName: 'Smartphone',
      keywords: ['موبايل', 'هواتف', 'لابتوب', 'شاشات', 'اجهزة منزلية', 'سماعات', 'شواحن'],
      description: 'أحدث الهواتف الذكية، الشاشات، أجهزة اللابتوب، وإكسسوارات الأجهزة الأصلية.',
    },
    {
      id: 'sub_retail_cosmetics',
      name: 'عطور ومستحضرات تجميل وميك آب',
      sectorId: 'retail',
      sectorName: 'قطاع التجزئة والسلع والمنتجات',
      iconName: 'Sparkles',
      keywords: ['عطور', 'برفان', 'مكياج', 'ميك اب', 'عناية بالبشرة', 'كريمات', 'سيروم'],
      description: 'عطور أصلية فاخرة، مستحضرات تجميل عالمية، ومنتجات العناية بالبشرة والشعر.',
    },
    {
      id: 'sub_retail_furniture',
      name: 'أثاث وديكور ومفروشات منزلية',
      sectorId: 'retail',
      sectorName: 'قطاع التجزئة والسلع والمنتجات',
      iconName: 'Armchair',
      keywords: ['اثاث', 'مفروشات', 'سجاد', 'ستائر', 'صالون', 'انتريه', 'غرف نوم', 'ديكور'],
      description: 'مفروشات عصرية، أثاث راقي، سجاد وموكيت، وستائر بمقاسات وتصميمات متنوعة.',
    },
    {
      id: 'sub_retail_stationery',
      name: 'مكتبات وأدوات مدرسية وألعاب',
      sectorId: 'retail',
      sectorName: 'قطاع التجزئة والسلع والمنتجات',
      iconName: 'BookOpen',
      keywords: ['مكتبة', 'ادوات مدرسية', 'العاب اطفال', 'هدايا', 'روايات', 'كشاكيل'],
      description: 'مستلزمات مدرسية وجامعية، كتب وروايات، ألعاب ذكاء للأطفال، وهدايا مميزة.',
    },
  ],

  services: [
    {
      id: 'sub_service_digital',
      name: 'خدمات رقمية وبرمجة وتسويق',
      sectorId: 'services',
      sectorName: 'قطاع الخدمات والحجوزات والاستشارات',
      iconName: 'Monitor',
      keywords: ['تسويق الكتروني', 'تصميم', 'برمجة', 'سوشيال ميديا', 'فيديو', 'اعلانات ممولة'],
      description: 'تصميم الهويات التجارية، إدارة الحملات التسويقية، وإنشاء المواقع الإلكترونية.',
    },
    {
      id: 'sub_service_beauty',
      name: 'صالونات ومراكز تجميل وعناية',
      sectorId: 'services',
      sectorName: 'قطاع الخدمات والحجوزات والاستشارات',
      iconName: 'Scissors',
      keywords: ['صالون', 'حلاقة', 'كوافير', 'بيوتي سنتر', 'مكياج عرائس', 'تنظيف بشرة'],
      description: 'أفضل مراكز العناية الرجالية والنسائية، تجهيز العرائس، وخدمات السبا.',
    },
    {
      id: 'sub_service_photography',
      name: 'استوديوهات وتصوير فوتوغرافي',
      sectorId: 'services',
      sectorName: 'قطاع الخدمات والحجوزات والاستشارات',
      iconName: 'Camera',
      keywords: ['تصوير', 'استوديو', 'فوتوسيشن', 'فيديو', 'مونتاج', 'تغطية حفلات'],
      description: 'جلسات تصوير احترافية للمناسبات والأفراح، وتصوير منتجات الشركات.',
    },
    {
      id: 'sub_service_cleaning',
      name: 'خدمات تنظيف ومكافحة حشرات',
      sectorId: 'services',
      sectorName: 'قطاع الخدمات والحجوزات والاستشارات',
      iconName: 'Sparkle',
      keywords: ['تنظيف', 'غسيل سجاد', 'مكافحة حشرات', 'تعقيم', 'نظافة واجهات'],
      description: 'خدمات تنظيف المنازل والشركات، غسيل السجاد والأنتريهات بالبخار، وإبادة الحشرات.',
    },
    {
      id: 'sub_service_printing',
      name: 'مطابع ودعاية وإعلان وتجهيز معارض',
      sectorId: 'services',
      sectorName: 'قطاع الخدمات والحجوزات والاستشارات',
      iconName: 'Printer',
      keywords: ['طباعة', 'مطبعة', 'بنر', 'فلكس', 'كروت شخصية', 'بروشور', 'يفط محلات'],
      description: 'طباعة الدعاية الورقية والبنرات، لافتات المحلات المضيئة، وتجهيز أجنحة المعارض.',
    },
  ],

  healthcare: [
    {
      id: 'sub_health_pharmacies',
      name: 'صيدليات ومستلزمات وخدمة 24 ساعة',
      sectorId: 'healthcare',
      sectorName: 'قطاع الرعاية الصحية والطبية',
      iconName: 'ShieldAlert',
      keywords: ['صيدلية', 'صيدليات', 'ادوية', 'روشتة', 'فيتامينات', 'لبن اطفال', 'توصيل ادوية'],
      description: 'صيدليات تعمل 24 ساعة مع خدمة صرف الروشتات والتوصيل الفوري للمنازل.',
    },
    {
      id: 'sub_health_clinics',
      name: 'عيادات وأطباء استشاريين',
      sectorId: 'healthcare',
      sectorName: 'قطاع الرعاية الصحية والطبية',
      iconName: 'Stethoscope',
      keywords: ['عيادة', 'دكتور', 'طبيب', 'كشف', 'باطنة', 'اطفال', 'عظام', 'جراحة', 'نساء وتوليد'],
      description: 'نخبة من كبار الأطباء والاستشاريين في كافة التخصصات الطبية.',
    },
    {
      id: 'sub_health_dental',
      name: 'طب وجراحة وتجميل الأسنان',
      sectorId: 'healthcare',
      sectorName: 'قطاع الرعاية الصحية والطبية',
      iconName: 'Smile',
      keywords: ['اسنان', 'زراعة اسنان', 'تقويم', 'تبييض', 'فينير', 'حشو عصب'],
      description: 'زراعة الأسنان، التقويم الحديث، تبييض الأسنان بالليزر، وعلاج العصب الدقيق.',
    },
    {
      id: 'sub_health_labs',
      name: 'معامل تحاليل طبية وفحوصات',
      sectorId: 'healthcare',
      sectorName: 'قطاع الرعاية الصحية والطبية',
      iconName: 'FlaskConical',
      keywords: ['معمل', 'تحاليل', 'تحليل دم', 'سكر تراكمي', 'وظائف كبد', 'فيتامين د', 'فحص شامل'],
      description: 'معامل تحاليل معتمدة لجميع التحاليل الطبية والوراثية مع سحب عينات منزلي.',
    },
    {
      id: 'sub_health_radiology',
      name: 'مراكز أشعة وسونار ورنين',
      sectorId: 'healthcare',
      sectorName: 'قطاع الرعاية الصحية والطبية',
      iconName: 'Radio',
      keywords: ['اشعة', 'رنين مغناطيسي', 'سونار', 'اشعة مقطعية', 'ايكو', 'ماموجرام'],
      description: 'أحدث أجهزة الرنين المغناطيسي والأشعة المقطعية والموجات الصوتية الملونة.',
    },
    {
      id: 'sub_health_optics',
      name: 'بصريات ونظارات طبية وشمسية',
      sectorId: 'healthcare',
      sectorName: 'قطاع الرعاية الصحية والطبية',
      iconName: 'Eye',
      keywords: ['نظارات', 'بصريات', 'فحص نظر', 'عدسات لاصقة', 'نظارة شمس'],
      description: 'قياس دقيق للنظر بالكمبيوتر، نظارات طبية وشمسية عالمية وعدسات لاصقة.',
    },
  ],

  crafts_maintenance: [
    {
      id: 'sub_crafts_ac_appliances',
      name: 'صيانة تكييفات وأجهزة منزلية',
      sectorId: 'crafts_maintenance',
      sectorName: 'قطاع الورش والصيانة والحرف المنزلية',
      iconName: 'AirVent',
      keywords: ['تكييف', 'صيانة اجهزة', 'غسالة', 'ثلاجة', 'شحن فريون', 'سخان', 'ميكروويف'],
      description: 'فنيون متخصصون لصيانة التكييفات والغسالات والثلاجات منزلياً مع الضمان.',
    },
    {
      id: 'sub_crafts_auto',
      name: 'ميكانيكا وكهرباء وعفشة سيارات',
      sectorId: 'crafts_maintenance',
      sectorName: 'قطاع الورش والصيانة والحرف المنزلية',
      iconName: 'Car',
      keywords: ['ميكانيكا', 'سيارات', 'عفشة', 'ضبط زوايا', 'غيار زيت', 'كهرباء سيارات', 'خراطة طنابير'],
      description: 'ورش فحص وتشخيص أعطال السيارات بالكمبيوتر، ميكانيكا، كهرباء وعفشة.',
    },
    {
      id: 'sub_crafts_plumbing',
      name: 'سباكة وتأسيس وتركيبات صحية',
      sectorId: 'crafts_maintenance',
      sectorName: 'قطاع الورش والصيانة والحرف المنزلية',
      iconName: 'Pipette',
      keywords: ['سباكة', 'سباك', 'مواسير', 'تسريب مياه', 'خلاطات', 'مضخات مياه'],
      description: 'تأسيس وتشطيب شبكات السباكة وعلاج تسريبات المياه وتركيب أطقم الحمامات.',
    },
    {
      id: 'sub_crafts_electricity',
      name: 'كهرباء منازل وإنارة وليد',
      sectorId: 'crafts_maintenance',
      sectorName: 'قطاع الورش والصيانة والحرف المنزلية',
      iconName: 'Zap',
      keywords: ['كهربائي', 'كهرباء منازل', 'لوحة قواطع', 'ليد', 'سبوتات', 'انتركم'],
      description: 'تأسيس شبكات الكهرباء المنزلية والإنارة الحديثة وتركيب أنظمة الطوارئ.',
    },
    {
      id: 'sub_crafts_carpentry',
      name: 'نجارة وألوميتال وتفصيل مطابخ',
      sectorId: 'crafts_maintenance',
      sectorName: 'قطاع الورش والصيانة والحرف المنزلية',
      iconName: 'Hammer',
      keywords: ['نجار', 'الوميتال', 'مطابخ خشمونيوم', 'ابواب وشبابيك', 'صيانة خشب'],
      description: 'تفصيل وتصليح غرف النوم، أبواب وشبابيك ألوميتال ومطابخ خشمونيوم وأكريليك.',
    },
    {
      id: 'sub_crafts_finishing',
      name: 'نقاشة وديكور ودهانات حديثة',
      sectorId: 'crafts_maintenance',
      sectorName: 'قطاع الورش والصيانة والحرف المنزلية',
      iconName: 'Paintbrush',
      keywords: ['نقاش', 'دهانات', 'ديكورات', 'ورق حائط', 'بديل رخام', 'تشطيب'],
      description: 'تنفيذ أحدث دهانات الجدران، بدائل الرخام والخشب، والبانوهات الكلاسيكية.',
    },
  ],

  education_training: [
    {
      id: 'sub_edu_centers',
      name: 'سناتر ومراكز دروس تعليمية',
      sectorId: 'education_training',
      sectorName: 'قطاع التعليم والتدريب والسناتر التعليمية',
      iconName: 'GraduationCap',
      keywords: ['سنتر', 'دروس خصوصية', 'ثانوية عامة', 'مراجعات', 'مناهج دراسية'],
      description: 'سناتر تعليمية مجهزة بأفضل المعلمين لجميع المراحل الابتدائية والإعدادية والثانوية.',
    },
    {
      id: 'sub_edu_languages',
      name: 'أكاديميات لغات و IELTS وتوفل',
      sectorId: 'education_training',
      sectorName: 'قطاع التعليم والتدريب والسناتر التعليمية',
      iconName: 'Globe',
      keywords: ['كورسات لغات', 'انجليزي', 'الماني', 'فرنسي', 'IELTS', 'محادثة'],
      description: 'دورات لغات مكثفة مع مدربين معتمدين وتجهيز لاختبارات الآيلتس والتويفل.',
    },
    {
      id: 'sub_edu_tech_courses',
      name: 'دورات برمجة وتصميم وتكنولوجيا',
      sectorId: 'education_training',
      sectorName: 'قطاع التعليم والتدريب والسناتر التعليمية',
      iconName: 'Code',
      keywords: ['برمجة', 'كورسات كمبيوتر', 'تصميم جرافيك', 'تطوير ويب', 'ذكاء اصطناعي'],
      description: 'تأهيل الشباب لسوق العمل الحر والشركات العالمية في البرمجة والتصميم والبيانات.',
    },
    {
      id: 'sub_edu_nurseries',
      name: 'حضانات وتأسيس وتنمية مهارات',
      sectorId: 'education_training',
      sectorName: 'قطاع التعليم والتدريب والسناتر التعليمية',
      iconName: 'Baby',
      keywords: ['حضانة', 'تأسيس اطفال', 'منتسوري', 'تخاطب', 'تعديل سلوك'],
      description: 'رعاية نموذجية للأطفال، تعليم اللغات، تنمية المهارات وجلسات التخاطب.',
    },
    {
      id: 'sub_edu_business',
      name: 'تدريب مهني وإدارة أعمال PMP',
      sectorId: 'education_training',
      sectorName: 'قطاع التعليم والتدريب والسناتر التعليمية',
      iconName: 'Briefcase',
      keywords: ['ادارة اعمال', 'تسويق', 'محاسبة', 'PMP', 'تنمية بشرية'],
      description: 'شهادات مهنية معتمدة في إدارة المشروعات والموارد البشرية والتسويق.',
    },
  ],

  real_estate: [
    {
      id: 'sub_realestate_brokerage',
      name: 'تسويق عقاري وبيع وشراء شقق',
      sectorId: 'real_estate',
      sectorName: 'قطاع العقارات والمقاولات والتشطيبات',
      iconName: 'Building',
      keywords: ['عقارات', 'شقق للبيع', 'شقق للايجار', 'فلل', 'دوبلكس', 'سمسار'],
      description: 'أفضل الفرص العقارية السكنية والتجارية في أرقى الأحياء والمدن الجديدة.',
    },
    {
      id: 'sub_realestate_contracting',
      name: 'مقاولات عامة وبناء وإنشاءات',
      sectorId: 'real_estate',
      sectorName: 'قطاع العقارات والمقاولات والتشطيبات',
      iconName: 'HardHat',
      keywords: ['مقاولات', 'بناء', 'خرسانات', 'تشييد', 'اشراف هندسي'],
      description: 'تنفيذ أعمال البناء والخرسانات والإنشاءات الهندسية بأعلى معايير الجودة.',
    },
    {
      id: 'sub_realestate_interior',
      name: 'ديكور وتشطيبات معمارية متكاملة',
      sectorId: 'real_estate',
      sectorName: 'قطاع العقارات والمقاولات والتشطيبات',
      iconName: 'Layers',
      keywords: ['تشطيبات', 'ديكور داخلي', 'جبسوم بورد', 'سيراميك', 'تصميم 3D'],
      description: 'باقات تشطيب متكاملة من الطوب الأحمر للمفتاح مع تصميمات ثلاثية الأبعاد 3D.',
    },
    {
      id: 'sub_realestate_commercial',
      name: 'مقرات ومحلات تجارية وإدارية',
      sectorId: 'real_estate',
      sectorName: 'قطاع العقارات والمقاولات والتشطيبات',
      iconName: 'Store',
      keywords: ['محلات للبيع', 'محلات للايجار', 'مكاتب ادارية', 'عيادات', 'مقرات شركات'],
      description: 'مساحات تجارية وإدارية بمواقع حيوية لافتتاح الأنشطة والعيادات والمكاتب.',
    },
  ],

  tourism_hotels: [
    {
      id: 'sub_tourism_hotels',
      name: 'حجز فنادق ومنتجعات وشقق فندقية',
      sectorId: 'tourism_hotels',
      sectorName: 'قطاع السياحة والفنادق والشقق الفندقية',
      iconName: 'Compass',
      keywords: ['فنادق', 'حجز فندق', 'منتجع', 'شقق مصيفية', 'شاليهات'],
      description: 'أفضل الأسعار لحجز الفنادق والمنتجعات والشاليهات في جميع المحافظات السياحية.',
    },
    {
      id: 'sub_tourism_trips',
      name: 'رحلات سياحية داخلية وسفاري',
      sectorId: 'tourism_hotels',
      sectorName: 'قطاع السياحة والفنادق والشقق الفندقية',
      iconName: 'Map',
      keywords: ['رحلات داخلية', 'سفاري', 'داي يوز', 'شرم الشيخ', 'الغردقة', 'دهب', 'اسوان'],
      description: 'برامج رحلات سياحية ترفيهية متكاملة ورحلات سفاري وتخييم شيقة.',
    },
    {
      id: 'sub_tourism_flight_visa',
      name: 'حجز طيران وتأشيرات سفر',
      sectorId: 'tourism_hotels',
      sectorName: 'قطاع السياحة والفنادق والشقق الفندقية',
      iconName: 'Plane',
      keywords: ['طيران', 'تذاكر طيران', 'فيزا', 'تأشيرة', 'سياحة خارجية'],
      description: 'حجز تذاكر الطيران على جميع الخطوط الجوية واستخراج تأشيرات السفر الدولية.',
    },
    {
      id: 'sub_tourism_limousine',
      name: 'ليموزين وتأجير سيارات سياحية',
      sectorId: 'tourism_hotels',
      sectorName: 'قطاع السياحة والفنادق والشقق الفندقية',
      iconName: 'Car',
      keywords: ['ليموزين', 'توصيل مطار', 'تأجير سيارات', 'سيارة بسائق'],
      description: 'سيارات ليموزين فاخرة لاستقبال المطار والتنقلات السياحية وحفلات الزفاف.',
    },
    {
      id: 'sub_tourism_omrah',
      name: 'رحلات عمرة وحج سياحي',
      sectorId: 'tourism_hotels',
      sectorName: 'قطاع السياحة والفنادق والشقق الفندقية',
      iconName: 'Moon',
      keywords: ['عمرة', 'حج', 'رحلات عمرة', 'تأشيرة عمرة', 'مزارات مكة'],
      description: 'برامج عمرة منتظمة طيران وبري مع إقامة فندقية قريبة من الحرم الشريف.',
    },
  ],

  transport_logistics: [
    {
      id: 'sub_transport_express',
      name: 'شحن سريع وتوصيل طرود محافظات',
      sectorId: 'transport_logistics',
      sectorName: 'قطاع النقل والشحن والخدمات اللوجستية',
      iconName: 'Truck',
      keywords: ['شحن محافظات', 'توصيل طرود', 'شحن سريع', 'بوليصة شحن'],
      description: 'شحن بضائع وطرود لكافة المحافظات والمراكز المصرية مع ميزة التحصيل عند الاستلام.',
    },
    {
      id: 'sub_transport_furniture',
      name: 'نقل عفش وأثاث بالونش الهيدروليكي',
      sectorId: 'transport_logistics',
      sectorName: 'قطاع النقل والشحن والخدمات اللوجستية',
      iconName: 'Package',
      keywords: ['نقل عفش', 'ونش هيدروليك', 'تغليف اثاث', 'فك وتركيب موبيليا'],
      description: 'نقل الأثاث بأمان تام مع التغليف والفك والتركيب والرفع بالأوناش للأدوار العليا.',
    },
    {
      id: 'sub_transport_heavy',
      name: 'نقل بضائع وثقيل (جامبو وتريلات)',
      sectorId: 'transport_logistics',
      sectorName: 'قطاع النقل والشحن والخدمات اللوجستية',
      iconName: 'Container',
      keywords: ['نقل ثقيل', 'تريلا', 'جامبو', 'نقل مصانع', 'حاويات'],
      description: 'أسطول سيارات نقل ثقيل وتريلات لنقل الخامات والمنتجات والمعدات الضخمة.',
    },
    {
      id: 'sub_transport_city_courier',
      name: 'دليفري سريع وطلبات داخل المدن',
      sectorId: 'transport_logistics',
      sectorName: 'قطاع النقل والشحن والخدمات اللوجستية',
      iconName: 'Bike',
      keywords: ['دليفري', 'طيار', 'توصيل طلبات', 'مشاوير خاصة'],
      description: 'خدمة توصيل فورية للطلبات والمستندات داخل نطاق المدينة والقرى المجاورة.',
    },
    {
      id: 'sub_transport_warehousing',
      name: 'تخزين بضائع ومستودعات لوجستية',
      sectorId: 'transport_logistics',
      sectorName: 'قطاع النقل والشحن والخدمات اللوجستية',
      iconName: 'Warehouse',
      keywords: ['تخزين', 'مستودع', 'مخازن', 'لوجستيات'],
      description: 'مساحات تخزين مؤمنة ومجهزة بنظام إدارة المخزون للشركات والمتاجر الإلكترونية.',
    },
  ],

  agriculture_livestock: [
    {
      id: 'sub_agri_fertilizers',
      name: 'أسمدة ومبيدات وبذور معتمدة',
      sectorId: 'agriculture_livestock',
      sectorName: 'قطاع الزراعة والإنتاج الحيواني ومستلزماته',
      iconName: 'Sprout',
      keywords: ['اسمدة', 'مبيدات', 'بذور', 'تقاوي', 'مغذيات نبات', 'مخصبات'],
      description: 'أجود أنواع الأسمدة الكيميائية والعضوية، المبيدات المصرح بها، والتقاوي المعتمدة.',
    },
    {
      id: 'sub_agri_irrigation',
      name: 'شبكات ري حديث وتنقيط ومضخات',
      sectorId: 'agriculture_livestock',
      sectorName: 'قطاع الزراعة والإنتاج الحيواني ومستلزماته',
      iconName: 'Droplets',
      keywords: ['شبكات ري', 'ري بالتنقيط', 'خراطيم ري', 'طلمبات مياه', 'مضخات'],
      description: 'تصميم وتركيب شبكات الري بالتنقيط والرش وتوريد مواتير وخراطيم المياه للمزارع.',
    },
    {
      id: 'sub_agri_fodder',
      name: 'أعلاف دواجن وماشية ومكملات',
      sectorId: 'agriculture_livestock',
      sectorName: 'قطاع الزراعة والإنتاج الحيواني ومستلزماته',
      iconName: 'Wheat',
      keywords: ['اعلاف', 'علف دواجن', 'علف مواشي', 'ردة', 'دريس', 'كسب'],
      description: 'أعلاف متوازنة عالية البروتين للدواجن والماشية ومكملات غذائية للنمو.',
    },
    {
      id: 'sub_agri_veterinary',
      name: 'أدوية وعيادات واستشارات بيطرية',
      sectorId: 'agriculture_livestock',
      sectorName: 'قطاع الزراعة والإنتاج الحيواني ومستلزماته',
      iconName: 'Stethoscope',
      keywords: ['بيطري', 'ادوية بيطرية', 'تحصينات', 'علاج مواشي', 'اشراف مزارع'],
      description: 'أدوية ولقاحات بيطرية وإشراف طبي متكامل على مزارع الدواجن والتسمين.',
    },
    {
      id: 'sub_agri_farms',
      name: 'مزارع إنتاج حيواني وداجني وأسماك',
      sectorId: 'agriculture_livestock',
      sectorName: 'قطاع الزراعة والإنتاج الحيواني ومستلزماته',
      iconName: 'Fish',
      keywords: ['كتاكيت', 'مزارع اسماك', 'سلالات مواشي', 'عجول تسمين'],
      description: 'توريد كتاكيت تسمين وبياض، سلالات عجول، وزريعة أسماك عالية الإنتاجية.',
    },
  ],

  technology_software: [
    {
      id: 'sub_tech_software_apps',
      name: 'برمجة تطبيقات ومواقع ويب ومتاجر',
      sectorId: 'technology_software',
      sectorName: 'قطاع البرمجيات والتقنية والاتصالات',
      iconName: 'Cpu',
      keywords: ['تطبيقات موبايل', 'برمجة مواقع', 'متجر الكتروني', 'تطبيق اندرويد', 'ايفون'],
      description: 'تطوير تطبيقات الموبايل الاحترافية والمتاجر الإلكترونية المتوافقة مع بوابات الدفع.',
    },
    {
      id: 'sub_tech_pos_erp',
      name: 'أنظمة كاشير ونقاط بيع و ERP',
      sectorId: 'technology_software',
      sectorName: 'قطاع البرمجيات والتقنية والاتصالات',
      iconName: 'CreditCard',
      keywords: ['برنامج كاشير', 'نقاط بيع', 'ERP', 'برنامج حسابات', 'جرد مخازن'],
      description: 'أنظمة برمجية سحابية لإدارة الحسابات، المخازن، الفواتير الإلكترونية، والمطاعم.',
    },
    {
      id: 'sub_tech_security_cctv',
      name: 'كاميرات مراقبة وأنظمة أمنية وإنذار',
      sectorId: 'technology_software',
      sectorName: 'قطاع البرمجيات والتقنية والاتصالات',
      iconName: 'Shield',
      keywords: ['كاميرات مراقبة', 'كاميرات IP', 'DVR', 'جهاز بصمة', 'انذار سرقة'],
      description: 'توريد وتركيب كاميرات المراقبة فائقة الوضوح وأجهزة الحضور والانصراف بالبصمة.',
    },
    {
      id: 'sub_tech_it_hardware',
      name: 'صيانة كمبيوتر ولابتوب وسيرفرات',
      sectorId: 'technology_software',
      sectorName: 'قطاع البرمجيات والتقنية والاتصالات',
      iconName: 'Server',
      keywords: ['صيانة لابتوب', 'كمبيوتر', 'سيرفر', 'قطع غيار كمبيوتر', 'هارد SSD'],
      description: 'إصلاح وصيانة أجهزة الحاسب الآلي، اللابتوب، وتجهيز غرف السيرفرات والشبكات.',
    },
    {
      id: 'sub_tech_cloud_hosting',
      name: 'استضافة سحابية وإيميلات شركات',
      sectorId: 'technology_software',
      sectorName: 'قطاع البرمجيات والتقنية والاتصالات',
      iconName: 'Cloud',
      keywords: ['استضافة', 'دومين', 'ايميل رسمي', 'سيرفرات سحابية'],
      description: 'خدمات استضافة المواقع، حجز الدومينات، والإيميلات الرسمية للأعمال.',
    },
  ],

  sports_fitness: [
    {
      id: 'sub_sports_gym',
      name: 'صالات جيم ولياقة وبناء أجسام',
      sectorId: 'sports_fitness',
      sectorName: 'قطاع الأندية الرياضية والجيم ومستلزمات اللياقة',
      iconName: 'Dumbbell',
      keywords: ['جيم', 'لياقة بدنية', 'كمال اجسام', 'كروس فيت', 'اشتراك جيم'],
      description: 'أفضل صالات الجيم المجهزة بأحدث الأجهزة الرياضية والمدربين المعتمدين.',
    },
    {
      id: 'sub_sports_courts',
      name: 'حجز ملاعب بادل وكرة قدم وتنس',
      sectorId: 'sports_fitness',
      sectorName: 'قطاع الأندية الرياضية والجيم ومستلزمات اللياقة',
      iconName: 'Trophy',
      keywords: ['ملاعب', 'بادل', 'ملعب كرة قدم', 'حجز ملاعب', 'تنس'],
      description: 'حجز ساعات الملاعب المجهزة بالنجيل الصناعي والإضاءة الليلية الاحترافية.',
    },
    {
      id: 'sub_sports_supplements',
      name: 'مكملات غذائية وبروتينات وفيتامينات',
      sectorId: 'sports_fitness',
      sectorName: 'قطاع الأندية الرياضية والجيم ومستلزمات اللياقة',
      iconName: 'Flame',
      keywords: ['مكملات غذائية', 'واي بروتين', 'كرياتين', 'احماض امينية', 'فيتامينات رياضية'],
      description: 'مكملات غذائية وأغذية رياضية أصلية 100% مصرح بها لدعم الأداء العضلي.',
    },
    {
      id: 'sub_sports_academies',
      name: 'أكاديميات سباحة وفنون قتالية',
      sectorId: 'sports_fitness',
      sectorName: 'قطاع الأندية الرياضية والجيم ومستلزمات اللياقة',
      iconName: 'Award',
      keywords: ['سباحة', 'كاراتيه', 'كونغ فو', 'ملاكمة', 'جمباز اطفال'],
      description: 'تدريب الأطفال والشباب على السباحة والفنون القتالية والدفاع عن النفس.',
    },
    {
      id: 'sub_sports_spa',
      name: 'سبا وساونا وجاكوزي ومساج',
      sectorId: 'sports_fitness',
      sectorName: 'قطاع الأندية الرياضية والجيم ومستلزمات اللياقة',
      iconName: 'Sparkles',
      keywords: ['سبا', 'مساج', 'ساونا', 'جاكوزي', 'حمام تركي'],
      description: 'جلسات استرخاء ومساج علاجي وساونا لتجديد النشاط والراحة البدنية.',
    },
  ],

  events_entertainment: [
    {
      id: 'sub_events_halls',
      name: 'قاعات أفراح ومؤتمرات ومناسبات',
      sectorId: 'events_entertainment',
      sectorName: 'قطاع تنظيم الحفلات والمناسبات والترفيه',
      iconName: 'PartyPopper',
      keywords: ['قاعة افراح', 'حفلات', 'قاعات مؤتمرات', 'خطوبة', 'كتب كتاب'],
      description: 'قاعات أفراح راقية ومكيفة تسع أعداداً مختلفة ومجهزة بأحدث المؤثرات الصوتية.',
    },
    {
      id: 'sub_events_dj_lighting',
      name: 'دي جي وأنظمة صوت وإضاءة مسارح',
      sectorId: 'events_entertainment',
      sectorName: 'قطاع تنظيم الحفلات والمناسبات والترفيه',
      iconName: 'Music',
      keywords: ['دي جي', 'صوتيات', 'اضاءة حفلات', 'شاشات ليد', 'فاير ووركس'],
      description: 'أقوى أجهزة الدي جي والإضاءة المتحركة وشاشات العرض الكبيرة وشو الألعاب النارية.',
    },
    {
      id: 'sub_events_decor',
      name: 'كوشة وتنسيق زهور وبوالين',
      sectorId: 'events_entertainment',
      sectorName: 'قطاع تنظيم الحفلات والمناسبات والترفيه',
      iconName: 'Flower2',
      keywords: ['كوشة', 'تزيين سيارات', 'ورد طبيعي', 'بلالين', 'ديكور افراح'],
      description: 'تصميم وتنفيذ كوشات عرائس حديثة، بوكيهات ورد، وديكورات حفلات استثنائية.',
    },
    {
      id: 'sub_events_catering',
      name: 'بوفيهات مفتوحة وتورت مناسبات',
      sectorId: 'events_entertainment',
      sectorName: 'قطاع تنظيم الحفلات والمناسبات والترفيه',
      iconName: 'Cake',
      keywords: ['بوفيه مفتوح', 'تورتة زفاف', 'حلويات مناسبات', 'سيرفيس'],
      description: 'أرقى أصناف البوفيه المفتوح الحلو والحادق وتورتات الأفراح متعددة الأدوار.',
    },
    {
      id: 'sub_events_kids',
      name: 'ملاهي وألعاب أطفال وترفيه عائلي',
      sectorId: 'events_entertainment',
      sectorName: 'قطاع تنظيم الحفلات والمناسبات والترفيه',
      iconName: 'Smile',
      keywords: ['كيدز اريا', 'العاب اطفال', 'نطاطات', 'ملاهي', 'عرائس'],
      description: 'أماكن ترفيهية للأطفال، نطاطات هوائية، وعروض شخصيات كرتونية ومهرجين.',
    },
  ],

  legal_financial: [
    {
      id: 'sub_legal_lawyers',
      name: 'مكاتب محاماة وقضايا واستشارات',
      sectorId: 'legal_financial',
      sectorName: 'قطاع الاستشارات القانونية والمحاسبية والمالية',
      iconName: 'Scale',
      keywords: ['محامي', 'استشارات قانونية', 'قضايا مدنية', 'مجلس دولة', 'محامي شركات'],
      description: 'مرافعات قضائية وصياغة عقود وتمثيل قانوني أمام كافة المحاكم المصرية.',
    },
    {
      id: 'sub_legal_accounting',
      name: 'محاسبون قانونيون وضرائب وتأمينات',
      sectorId: 'legal_financial',
      sectorName: 'قطاع الاستشارات القانونية والمحاسبية والمالية',
      iconName: 'FileSpreadsheet',
      keywords: ['محاسب قانوني', 'ضرائب', 'فاتورة الكترونية', 'اقرار ضريبي', 'ميزانية'],
      description: 'إمساك الدفاتر المحاسبية، تقديم الإقرارات الضريبية، والربط بالفاتورة الإلكترونية.',
    },
    {
      id: 'sub_legal_incorporation',
      name: 'تأسيس شركات وسجل تجاري وبطاقات',
      sectorId: 'legal_financial',
      sectorName: 'قطاع الاستشارات القانونية والمحاسبية والمالية',
      iconName: 'Building2',
      keywords: ['تأسيس شركات', 'سجل تجاري', 'بطاقة ضريبية', 'تراخيص محلات', 'استثمار'],
      description: 'إنهاء إجراءات تأسيس الشركات وتراخيص المحلات التجارية واستخراج السجلات.',
    },
    {
      id: 'sub_legal_feasibility',
      name: 'دراسات جدوى واستشارات تمويل',
      sectorId: 'legal_financial',
      sectorName: 'قطاع الاستشارات القانونية والمحاسبية والمالية',
      iconName: 'Coins',
      keywords: ['دراسة جدوى', 'خطة عمل', 'تمويل بنكي', 'استشارات مالية'],
      description: 'إعداد دراسات الجدوى الاقتصادية الشاملة لطلب التمويل وإطلاق المشاريع.',
    },
    {
      id: 'sub_legal_contracts',
      name: 'توثيق عقود وترجمة معتمدة',
      sectorId: 'legal_financial',
      sectorName: 'قطاع الاستشارات القانونية والمحاسبية والمالية',
      iconName: 'FileCheck',
      keywords: ['ترجمة معتمدة', 'صياغة عقود', 'توثيق', 'ترجمة سفارات'],
      description: 'ترجمة معتمدة للشهادات والمستندات لكافة السفارات وصياغة العقود بدقة.',
    },
  ],

  industrial_manufacturing: [
    {
      id: 'sub_ind_raw_materials',
      name: 'توريد مواد خام ومستلزمات مصانع',
      sectorId: 'industrial_manufacturing',
      sectorName: 'قطاع المصانع والصناعات الثقيلة وخطوط الإنتاج',
      iconName: 'Factory',
      keywords: ['مواد خام', 'حديد ومعادن', 'كيماويات', 'بوليمرات', 'مستلزمات انتاج'],
      description: 'توريد المواد الخام الصناعية، الصاج، البلاستيك، والكيماويات للمصانع والورش.',
    },
    {
      id: 'sub_ind_production_lines',
      name: 'خطوط إنتاج وماكينات تعبئة وتغليف',
      sectorId: 'industrial_manufacturing',
      sectorName: 'قطاع المصانع والصناعات الثقيلة وخطوط الإنتاج',
      iconName: 'Cpu',
      keywords: ['خط انتاج', 'ماكينة تعبئة', 'سيور ناقلة', 'تغليف الي', 'معدات مصانع'],
      description: 'تصنيع وتوريد خطوط الإنتاج وماكينات التعبئة والتغليف الآلية لمختلف الصناعات.',
    },
    {
      id: 'sub_ind_metal_cnc',
      name: 'تشغيل معادن وخراطة CNC وإسطمبات',
      sectorId: 'industrial_manufacturing',
      sectorName: 'قطاع المصانع والصناعات الثقيلة وخطوط الإنتاج',
      iconName: 'Wrench',
      keywords: ['خراطة CNC', 'تقطيع ليزر', 'اسطمبات', 'تشكيل صاج', 'تشغيل معادن'],
      description: 'تشغيل المعادن بأحدث ماكينات الليزر والـ CNC وتصميم وتصنيع الإسطمبات الدقيقة.',
    },
    {
      id: 'sub_ind_packaging',
      name: 'صناعات كرتون وبلاستيك وتغليف',
      sectorId: 'industrial_manufacturing',
      sectorName: 'قطاع المصانع والصناعات الثقيلة وخطوط الإنتاج',
      iconName: 'Box',
      keywords: ['كرتون مضلع', 'عبوات بلاستيك', 'اكياس تغليف', 'طباعة علب'],
      description: 'تصنيع الكراتين المضلعة، علب المنتجات الدوائية والغذائية، وأكياس التعبئة.',
    },
    {
      id: 'sub_ind_maintenance_parts',
      name: 'قطع غيار ومولدات وصيانة صناعية',
      sectorId: 'industrial_manufacturing',
      sectorName: 'قطاع المصانع والصناعات الثقيلة وخطوط الإنتاج',
      iconName: 'Cog',
      keywords: ['قطع غيار مصانع', 'مولدات كهرباء', 'رولمان بلي', 'صيانة هيدروليك'],
      description: 'توريد مولدات الكهرباء الصناعية، قطع غيار المعدات، وخدمات العمرة والصيانة الميدانية.',
    },
  ],
};

/**
 * Returns subcategories for a given sector, or a curated list across all sectors if 'all'.
 */
export function getSubcategoriesForSector(
  sectorId: FunctionalGroupId | 'all'
): SubCategoryItem[] {
  if (sectorId !== 'all') {
    return SECTOR_SUBCATEGORIES_MAP[sectorId] || [];
  }

  // If 'all', return top curated representative subcategories from each major sector
  const allSubcategories: SubCategoryItem[] = [];
  const sectorKeys = Object.keys(SECTOR_SUBCATEGORIES_MAP) as FunctionalGroupId[];
  
  sectorKeys.forEach((secId) => {
    const list = SECTOR_SUBCATEGORIES_MAP[secId];
    if (list && list.length > 0) {
      // Pick first 2 items of each sector for a rich cross-sector preview
      allSubcategories.push(list[0]);
      if (list[1]) allSubcategories.push(list[1]);
    }
  });

  return allSubcategories;
}

/**
 * Returns all subcategories across all 15 sectors
 */
export function getAllSubcategories(): SubCategoryItem[] {
  const allList: SubCategoryItem[] = [];
  Object.values(SECTOR_SUBCATEGORIES_MAP).forEach((items) => {
    allList.push(...items);
  });
  return allList;
}

/**
 * Finds a subcategory item by its ID
 */
export function getSubcategoryById(id: string): SubCategoryItem | undefined {
  for (const items of Object.values(SECTOR_SUBCATEGORIES_MAP)) {
    const found = items.find((item) => item.id === id);
    if (found) return found;
  }
  return undefined;
}

/**
 * Matches subcategories based on a user search query (with Arabic normalization)
 */
export function matchSubcategories(
  query: string,
  sectorId?: FunctionalGroupId | 'all'
): SubCategoryItem[] {
  const normalized = normalizeArabicText(query);
  if (!normalized) return [];

  const candidatePool = sectorId && sectorId !== 'all'
    ? SECTOR_SUBCATEGORIES_MAP[sectorId] || []
    : getAllSubcategories();

  const queryTokens = normalized.split(/\s+/).filter(Boolean);

  return candidatePool.filter((item) => {
    const normalizedName = normalizeArabicText(item.name);
    const normalizedDesc = normalizeArabicText(item.description);
    const normalizedSector = normalizeArabicText(item.sectorName);
    const normalizedKeywords = item.keywords.map(normalizeArabicText).join(' ');

    const corpus = `${normalizedName} ${normalizedDesc} ${normalizedSector} ${normalizedKeywords}`;

    return queryTokens.some((token) => corpus.includes(token));
  });
}

/**
 * Filters businesses matching a given subcategory
 */
export function filterBusinessesBySubcategory(
  businesses: Business[],
  subcategoryId: string,
  sectorId?: FunctionalGroupId | 'all'
): Business[] {
  const subcategory = getSubcategoryById(subcategoryId);
  if (!subcategory) return businesses;

  const targetSector = subcategory.sectorId;
  const keywords = subcategory.keywords.map(normalizeArabicText);
  const normalizedSubName = normalizeArabicText(subcategory.name);

  return businesses.filter((b) => {
    // 1. If business matches sector (or general)
    const matchesSector = !sectorId || sectorId === 'all' || b.functionalGroupId === targetSector;
    if (!matchesSector) return false;

    // 2. Direct category or categoryId match
    if (b.categoryId === subcategoryId) return true;

    // 3. Normalized corpus matching against keywords or category name
    const bName = normalizeArabicText(b.name);
    const bCat = normalizeArabicText(b.category);
    const bBio = normalizeArabicText(b.bio);
    const corpus = `${bName} ${bCat} ${bBio}`;

    if (corpus.includes(normalizedSubName)) return true;

    // Check if any keyword appears in the business category or name
    const hasKeywordMatch = keywords.some((kw) => corpus.includes(kw));
    return hasKeywordMatch;
  });
}

/**
 * Counts how many businesses match a subcategory in a provided business list
 */
export function countBusinessesInSubcategory(
  businesses: Business[],
  subcategoryId: string
): number {
  return filterBusinessesBySubcategory(businesses, subcategoryId).length;
}
