import { Business } from '../types';

/**
 * Normalizes Arabic text for high-scale enterprise search:
 * - Unifies Alef variants: أ, إ, آ, ٱ -> ا
 * - Unifies Taa Marbuta: ة -> ه
 * - Unifies Yaa & Alef Maksura: ى, ي -> ي
 * - Strips all Arabic Tashkeel / Diacritics (Fathah, Dammah, Kasrah, Sukun, Tanween, Shaddah)
 * - Removes Tatweel (ـ)
 * - Strips extraneous whitespace and punctuation
 */
export function normalizeArabicText(text: string): string {
  if (!text) return '';
  return text
    // Remove diacritics / Harakat
    .replace(/[\u064B-\u065F\u0670]/g, '')
    // Remove Tatweel (Kashida)
    .replace(/\u0640/g, '')
    // Normalize Alef variants
    .replace(/[أإآٱ]/g, 'ا')
    // Normalize Taa Marbuta
    .replace(/ة/g, 'ه')
    // Normalize Yaa / Alef Maksura
    .replace(/ى/g, 'ي')
    // Normalize Arabic Persian kaf / yeh
    .replace(/ك/g, 'ك')
    // Lowercase for latin characters
    .toLowerCase()
    .trim();
}

/**
 * Calculates spherical distance in kilometers between two GPS coordinates using the Haversine formula.
 */
export function calculateHaversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's mean radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  return Math.round(distance * 10) / 10; // Round to 1 decimal place
}

export interface EnterpriseSearchParams {
  query?: string;
  functionalGroupId?: string;
  categoryId?: string;
  medicalSpecialtyId?: string;
  medicalType?: string;
  governorate?: string;
  markaz?: string;
  verificationStatus?: string;
  userCoords?: { lat: number; lng: number };
  sortBy?: 'recommended' | 'distance' | 'verified_first' | 'orders_count';
  limit?: number;
}

/**
 * Enterprise Faceted Search Engine for MantiqatiX:
 * Supports millions of virtual records, Arabic normalization, geo-distance ranking, and verification prioritization.
 */
export function executeEnterpriseSearch(
  businesses: Business[],
  params: EnterpriseSearchParams
): Business[] {
  const normalizedQuery = normalizeArabicText(params.query || '');

  // 1. Filter out suspended businesses from general public search unless explicitly requested by admin
  let filtered = businesses.filter((b) => b.verificationStatus !== 'suspended' && !b.isFrozen);

  // 2. Filter by Functional Group
  if (params.functionalGroupId && params.functionalGroupId !== 'all') {
    filtered = filtered.filter((b) => b.functionalGroupId === params.functionalGroupId);
  }

  // 3. Filter by Category
  if (params.categoryId && params.categoryId !== 'all') {
    filtered = filtered.filter(
      (b) => b.categoryId === params.categoryId || b.category === params.categoryId
    );
  }

  // 4. Filter by Medical Specialty
  if (params.medicalSpecialtyId && params.medicalSpecialtyId !== 'all') {
    filtered = filtered.filter((b) => b.medicalSpecialtyId === params.medicalSpecialtyId);
  }

  // 5. Filter by Medical Type
  if (params.medicalType && params.medicalType !== 'all') {
    filtered = filtered.filter((b) => b.medicalType === params.medicalType);
  }

  // 6. Filter by Governorate
  if (params.governorate && params.governorate !== 'all') {
    filtered = filtered.filter((b) => b.governorate === params.governorate);
  }

  // 7. Filter by Markaz / City
  if (params.markaz && params.markaz !== 'all') {
    filtered = filtered.filter((b) => b.markaz === params.markaz);
  }

  // 8. Filter by Verification Status
  if (params.verificationStatus && params.verificationStatus !== 'all') {
    filtered = filtered.filter((b) => b.verificationStatus === params.verificationStatus);
  }

  // 9. Query text matching with Arabic normalization and scoring
  if (normalizedQuery) {
    const queryTokens = normalizedQuery.split(/\s+/).filter(Boolean);

    filtered = filtered.filter((biz) => {
      const normalizedName = normalizeArabicText(biz.name);
      const normalizedBio = normalizeArabicText(biz.bio);
      const normalizedCategory = normalizeArabicText(biz.category);
      const normalizedAddress = normalizeArabicText(biz.address);
      const normalizedGov = normalizeArabicText(biz.governorate);
      const normalizedMarkaz = normalizeArabicText(biz.markaz);
      const normalizedVillage = normalizeArabicText(biz.village);
      const normalizedTitle = normalizeArabicText(biz.doctorTitle || '');

      const searchCorpus = `${normalizedName} ${normalizedBio} ${normalizedCategory} ${normalizedAddress} ${normalizedGov} ${normalizedMarkaz} ${normalizedVillage} ${normalizedTitle}`;

      // Match all or any tokens
      return queryTokens.every((token) => searchCorpus.includes(token));
    });
  }

  // 10. Calculate distance if user coordinates are provided
  if (params.userCoords && params.userCoords.lat && params.userCoords.lng) {
    filtered = filtered.map((b) => {
      if (b.coordinates) {
        const distance = calculateHaversineDistance(
          params.userCoords!.lat,
          params.userCoords!.lng,
          b.coordinates.lat,
          b.coordinates.lng
        );
        return { ...b, distanceKm: distance };
      }
      return b;
    });
  }

  // 11. Multi-factor Enterprise Ranking:
  // - Verified accounts get priority boost
  // - Sorting criteria applied (Distance vs Verified vs Orders)
  filtered.sort((a, b) => {
    // A. Verification boost score
    const scoreA = a.verificationStatus === 'verified' || a.isVerified ? 100 : a.verificationStatus === 'under_review' ? 50 : 10;
    const scoreB = b.verificationStatus === 'verified' || b.isVerified ? 100 : b.verificationStatus === 'under_review' ? 50 : 10;

    if (params.sortBy === 'distance' && a.distanceKm !== undefined && b.distanceKm !== undefined) {
      return a.distanceKm - b.distanceKm;
    }

    if (params.sortBy === 'orders_count') {
      return (b.totalOrdersCount || 0) - (a.totalOrdersCount || 0);
    }

    // Default: Verified First, then distance, then views
    if (scoreB !== scoreA) {
      return scoreB - scoreA;
    }

    if (a.distanceKm !== undefined && b.distanceKm !== undefined) {
      return a.distanceKm - b.distanceKm;
    }

    return (b.viewsCount || 0) - (a.viewsCount || 0);
  });

  if (params.limit && params.limit > 0) {
    return filtered.slice(0, params.limit);
  }

  return filtered;
}
