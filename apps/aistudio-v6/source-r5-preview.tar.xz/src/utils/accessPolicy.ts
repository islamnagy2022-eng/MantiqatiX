export type AccessRole =
  | 'guest'
  | 'subscriber'
  | 'admin'
  | 'super_admin'
  | 'regional_manager'
  | 'medical_staff'
  | 'customer';

const PUBLIC_VIEWS = new Set([
  'public_storefront',
  'directory',
  'medical_directory',
  'contact_us',
]);

const ADMIN_ROLES = new Set<AccessRole>(['admin', 'super_admin']);
const MERCHANT_ROLES = new Set<AccessRole>(['subscriber']);
const MESSAGING_ROLES = new Set<AccessRole>(['subscriber', 'admin', 'super_admin']);

/**
 * Resolve a requested UI route against the current session.
 * This is a navigation defense only. Every private read/write must still be
 * authorized by Supabase Auth, an active membership, and server-side scope checks.
 * Unknown routes fail closed to the public directory.
 */
export function resolveProtectedView<T extends string>(
  requestedView: T,
  role: AccessRole,
  businessId?: string,
): T | 'directory' {
  if (PUBLIC_VIEWS.has(requestedView)) return requestedView;

  if (requestedView === 'super_admin') {
    return ADMIN_ROLES.has(role) ? requestedView : 'directory';
  }

  if (requestedView === 'merchant_admin') {
    return MERCHANT_ROLES.has(role) && Boolean(businessId?.trim())
      ? requestedView
      : 'directory';
  }

  if (requestedView === 'member_messages') {
    return MESSAGING_ROLES.has(role) ? requestedView : 'directory';
  }

  // Includes the obsolete local-login route and any future route that has not
  // been explicitly classified and covered by a policy test.
  return 'directory';
}

export function canAccessProtectedView(
  requestedView: string,
  role: AccessRole,
  businessId?: string,
): boolean {
  return resolveProtectedView(requestedView, role, businessId) === requestedView;
}
