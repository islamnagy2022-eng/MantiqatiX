import React, { useMemo, useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { DEFAULT_MEDICAL_SPECIALTIES } from '../../data/seedData';
import { executeEnterpriseSearch } from '../../utils/searchEngine';
import { resolveBusinessLogo } from '../../data/imageAssets';
import { CheckCircle2, MapPin, MessageCircle, Phone, Search, Stethoscope, ChevronLeft } from 'lucide-react';
import { DIRECTORY_PAGE_SIZE, getNextDirectoryVisibleCount } from '../../utils/directoryPagination';

export const MedicalDirectoryView: React.FC = () => {
  const { directoryBusinesses, setSelectedBusinessId, setCurrentView } = useApp();
  const [query, setQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [governorate, setGovernorate] = useState('all');
  const [visibleCount, setVisibleCount] = useState(DIRECTORY_PAGE_SIZE);

  useEffect(() => setVisibleCount(DIRECTORY_PAGE_SIZE), [query, selectedSpecialty, selectedType, governorate]);

  const medicalBusinesses = useMemo(() => directoryBusinesses.filter((business) =>
    business.isMedical || business.functionalGroupId === 'healthcare' || /طب|صيدل|مركز طبي|عياد/i.test(business.category)
  ), [directoryBusinesses]);

  const governorates = useMemo(() => Array.from(new Set(medicalBusinesses.map((item) => item.governorate).filter(Boolean))), [medicalBusinesses]);

  const results = useMemo(() => executeEnterpriseSearch(medicalBusinesses, {
    query,
    medicalSpecialtyId: selectedSpecialty,
    medicalType: selectedType,
    governorate,
    sortBy: 'verified_first',
  }), [medicalBusinesses, query, selectedSpecialty, selectedType, governorate]);

  const openBusiness = (id: string) => {
    setSelectedBusinessId(id);
    setCurrentView('public_storefront');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-16" dir="rtl">
      <section className="bg-gradient-to-br from-emerald-950 via-teal-900 to-slate-900 px-4 py-10 text-white sm:py-12">
        <div className="mx-auto max-w-7xl space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-200/30 bg-emerald-200/10 px-3 py-1 text-xs font-bold text-emerald-100"><Stethoscope className="h-4 w-4" /> الدليل الطبي</div>
          <h1 className="text-3xl font-black sm:text-4xl">الأطباء والعيادات والصيدليات</h1>
          <p className="max-w-2xl text-sm leading-7 text-slate-200">ابحث عن مقدم الخدمة الطبية حسب التخصص والمحافظة، وتواصل مباشرة مع النشاط المنشور.</p>
          <div className="grid gap-3 rounded-2xl bg-white p-3 shadow-xl sm:grid-cols-[1fr_220px]">
            <label className="relative block"><Search className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-emerald-700" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="اسم الطبيب أو العيادة أو الصيدلية..." className="min-h-12 w-full rounded-xl border border-slate-200 bg-slate-50 pr-11 pl-3 text-sm font-semibold text-slate-900 outline-none focus:border-emerald-500" /></label>
            <select value={governorate} onChange={(event) => setGovernorate(event.target.value)} className="min-h-12 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm font-bold text-slate-800"><option value="all">كل المحافظات</option>{governorates.map((name) => <option key={name} value={name}>{name}</option>)}</select>
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-7xl space-y-6 px-4 py-8">
        <section className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4">
          <h2 className="text-sm font-black text-slate-900">التخصصات الطبية</h2>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => setSelectedSpecialty('all')} className={`rounded-full px-3 py-2 text-xs font-bold ${selectedSpecialty === 'all' ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>كل التخصصات</button>
            {DEFAULT_MEDICAL_SPECIALTIES.map((specialty) => <button key={specialty.id} type="button" onClick={() => setSelectedSpecialty(specialty.id)} className={`rounded-full px-3 py-2 text-xs font-bold ${selectedSpecialty === specialty.id ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>{specialty.name}</button>)}
          </div>
          <div className="flex flex-wrap gap-2 border-t border-slate-100 pt-3">
            {['all', 'doctor', 'clinic', 'pharmacy', 'hospital', 'lab', 'radiology'].map((type) => <button key={type} type="button" onClick={() => setSelectedType(type)} className={`rounded-lg px-3 py-2 text-xs font-bold ${selectedType === type ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700'}`}>{({ all: 'الكل', doctor: 'أطباء', clinic: 'عيادات', pharmacy: 'صيدليات', lab: 'معامل', hospital: 'مستشفيات', radiology: 'أشعة' } as Record<string, string>)[type]}</button>)}
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-end justify-between gap-3"><div><h2 className="text-xl font-black text-slate-900">نتائج الدليل الطبي</h2><p className="mt-1 text-sm text-slate-500">{results.length} نتيجة</p></div></div>
          {results.length === 0 ? <p className="rounded-xl bg-white p-6 text-center text-sm text-slate-500">لا توجد نتائج مطابقة للفلاتر الحالية.</p> : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {results.slice(0, visibleCount).map((business) => {
                const verified = business.isVerified && (!business.verificationStatus || business.verificationStatus === 'verified');
                const phone = business.ownerWhatsApp || business.phone || '';
                const digits = phone.replace(/\D/g, '');
                const waDigits = digits.startsWith('0') ? `20${digits.slice(1)}` : digits;
                return <article key={business.id} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                  <button type="button" onClick={() => openBusiness(business.id)} className="flex w-full items-center gap-3 text-right">
                    <img src={resolveBusinessLogo(business)} alt="" className="h-14 w-14 rounded-xl border border-slate-100 object-cover" loading="lazy" />
                    <span className="min-w-0 flex-1"><span className="flex flex-wrap items-center gap-1.5"><span className="truncate text-sm font-black text-slate-900">{business.name}</span>{verified && <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-bold text-emerald-800"><CheckCircle2 className="h-3 w-3" /> موثق</span>}{!verified && <span className="rounded-full bg-amber-50 px-2 py-1 text-[10px] font-bold text-amber-800">غير موثق</span>}</span><span className="mt-1 block truncate text-xs text-slate-500">{business.category}</span></span>
                  </button>
                  <div className="mt-4 space-y-2 text-xs text-slate-600"><p className="flex items-center gap-2"><MapPin className="h-4 w-4 shrink-0 text-slate-400" /><span>{[business.governorate, business.markaz, business.village].filter(Boolean).join(' • ') || business.address}</span></p>{phone && <p className="flex items-center gap-2"><Phone className="h-4 w-4 shrink-0 text-slate-400" /><span dir="ltr">{phone}</span></p>}</div>
                  <div className="mt-4 grid grid-cols-2 gap-2">{waDigits && <a href={`https://wa.me/${waDigits}`} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-10 items-center justify-center gap-1 rounded-lg bg-emerald-600 px-2 text-xs font-bold text-white"><MessageCircle className="h-4 w-4" /> واتساب</a>}<button type="button" onClick={() => openBusiness(business.id)} className="inline-flex min-h-10 items-center justify-center gap-1 rounded-lg bg-slate-100 px-2 text-xs font-bold text-slate-800">عرض النشاط <ChevronLeft className="h-4 w-4" /></button></div>
                </article>;
              })}
            </div>
          )}
          {visibleCount < results.length && <div className="flex justify-center"><button type="button" onClick={() => setVisibleCount((current) => getNextDirectoryVisibleCount(current, results.length))} className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-emerald-200 bg-white px-5 py-2.5 text-sm font-black text-emerald-800 hover:bg-emerald-50">رؤية المزيد <ChevronLeft className="h-4 w-4" /></button></div>}
        </section>
      </main>
    </div>
  );
};
