import React, { useEffect, useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { FunctionalGroupId } from '../types';
import {
  DEFAULT_MANTYGO_CHANNELS,
  MantyGoChannelId,
  MantyGoServiceChannel,
  MantyGoServiceRequest,
  acceptProviderBidForRequest,
  applyCustomerCounterOfferToBid,
  createCustomMantyGoChannel,
  createInitialSeedMantyGoRequests,
  evaluateProviderBiddingEligibility,
  generateAutomatedVerifiedBidsForRequest,
  generateMantyGoAcceptedDealWhatsAppUrl,
  getEligibleVerifiedProvidersForChannel,
  submitVerifiedProviderBidOnRequest,
  submitRequestRatingAndReview,
} from '../utils/mantygoBiddingEngine';
import {
  Car,
  Wrench,
  Scale,
  Calculator,
  Sparkles,
  ShieldCheck,
  Plus,
  MapPin,
  Clock,
  CheckCircle2,
  ArrowLeftRight,
  MessageCircle,
  Star,
  Lock,
  Crown,
  Send,
  TrendingUp,
  Users,
  AlertCircle,
  Check,
  Navigation,
  Briefcase,
  Building2,
  LayoutDashboard,
  Filter,
  BarChart3,
} from 'lucide-react';

const STORAGE_KEY_CUSTOM_CHANNELS = 'mantiqatix_mantygo_custom_channels_v1';
const STORAGE_KEY_REQUESTS = 'mantiqatix_mantygo_requests_v1';

export const MantyGoBiddingView: React.FC = () => {
  const {
    businesses,
    functionalGroups,
    selectedBusinessId,
    setSelectedBusinessId,
    setCurrentView,
    openSectorDevelopmentStudio,
  } = useApp();

  // 1. Channels State (4 Built-in + Custom Dynamic Channels)
  const [customChannels, setCustomChannels] = useState<MantyGoServiceChannel[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CUSTOM_CHANNELS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore storage errors
    }
    return [];
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CUSTOM_CHANNELS, JSON.stringify(customChannels));
    } catch {
      // ignore
    }
  }, [customChannels]);

  const allChannels = useMemo(
    () => [...DEFAULT_MANTYGO_CHANNELS, ...customChannels],
    [customChannels]
  );

  const [activeChannelId, setActiveChannelId] = useState<MantyGoChannelId>('mantygo_rides');
  const activeChannel = useMemo(
    () => allChannels.find((c) => c.id === activeChannelId) || DEFAULT_MANTYGO_CHANNELS[0],
    [allChannels, activeChannelId]
  );

  // 2. Requests & Live Bids State
  const [requests, setRequests] = useState<MantyGoServiceRequest[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_REQUESTS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return createInitialSeedMantyGoRequests(businesses);
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_REQUESTS, JSON.stringify(requests));
    } catch {
      // ignore
    }
  }, [requests]);

  // Active workspace mode: 'customer' (اطلب وتفاوض كعميل) | 'provider' (مقدم خدمة موثق بالباقات)
  const [workspaceRole, setWorkspaceRole] = useState<'customer' | 'provider'>('customer');

  // MantyGo Workspace View Mode: 'room' (Live Negotiation Room) | 'dashboard' (Orders Dashboard)
  const [mantyGoViewMode, setMantyGoViewMode] = useState<'room' | 'dashboard'>('room');

  // Dashboard Filters State
  const [dashRoleFilter, setDashRoleFilter] = useState<'all' | 'customer' | 'provider'>('all');
  const [dashStatusFilter, setDashStatusFilter] = useState<'all' | 'active' | 'completed'>('all');
  const [dashChannelFilter, setDashChannelFilter] = useState<string>('all');

  // Toast Notifications State & Helper
  const [toast, setToast] = useState<{
    id: number;
    message: string;
    type: 'success' | 'info' | 'bid' | 'alert';
  } | null>(null);

  const triggerToast = (message: string, type: 'success' | 'info' | 'bid' | 'alert' = 'info') => {
    const id = Date.now();
    setToast({ id, message, type });
    setTimeout(() => {
      setToast((current) => (current?.id === id ? null : current));
    }, 4500);
  };

  const handleMarkRequestCompleted = (reqId: string) => {
    setRequests((prev) =>
      prev.map((r) => (r.id === reqId ? { ...r, status: 'completed' } : r))
    );
    triggerToast('تم تحديث حالة الطلب إلى مكتمل بنجاح! يمكنك الآن تسجيل التقييم.', 'success');
  };


  // Selected request for live negotiation room
  const channelRequests = useMemo(
    () => requests.filter((r) => r.channelId === activeChannel.id),
    [requests, activeChannel.id]
  );

  const [selectedRequestId, setSelectedRequestId] = useState<string>(() => {
    const first = requests.find((r) => r.channelId === 'mantygo_rides');
    return first ? first.id : requests[0]?.id || '';
  });

  useEffect(() => {
    if (!channelRequests.some((r) => r.id === selectedRequestId)) {
      setSelectedRequestId(channelRequests[0]?.id || '');
    }
  }, [activeChannel.id, channelRequests, selectedRequestId]);

  const activeRequest = useMemo(
    () => requests.find((r) => r.id === selectedRequestId) || channelRequests[0] || null,
    [requests, selectedRequestId, channelRequests]
  );

  // 5. Provider Bidding Console State
  const [providerBusinessId, setProviderBusinessId] = useState<string>(
    selectedBusinessId || businesses[0]?.id || ''
  );
  const selectedProviderBusiness = useMemo(
    () => businesses.find((b) => b.id === providerBusinessId) || businesses[0],
    [businesses, providerBusinessId]
  );

  const filteredDashboardRequests = useMemo(() => {
    return requests.filter((req) => {
      // 1. Activity Channel / Sector Filter
      if (dashChannelFilter !== 'all' && req.channelId !== dashChannelFilter) {
        return false;
      }

      // 2. Role Filter
      if (dashRoleFilter === 'customer' && workspaceRole === 'customer') {
        // Customer perspective
      } else if (dashRoleFilter === 'provider' && workspaceRole === 'provider') {
        if (selectedProviderBusiness) {
          const hasBid = req.bids.some((b) => b.businessId === selectedProviderBusiness.id);
          const isAccepted = req.acceptedBusinessId === selectedProviderBusiness.id;
          if (!hasBid && !isAccepted) return false;
        }
      }

      // 3. Status Filter (active vs completed)
      if (dashStatusFilter === 'active') {
        if (req.status === 'completed' || req.status === 'cancelled') return false;
      } else if (dashStatusFilter === 'completed') {
        if (req.status !== 'completed') return false;
      }

      return true;
    });
  }, [requests, dashChannelFilter, dashRoleFilter, dashStatusFilter, workspaceRole, selectedProviderBusiness]);

  // 3. New Request Form State (Customer Request Builder)
  const [subService, setSubService] = useState<string>(activeChannel.subServices[0] || '');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [governorate, setGovernorate] = useState<string>('الدقهلية');
  const [markaz, setMarkaz] = useState<string>('المنصورة');
  const [pickupAddress, setPickupAddress] = useState<string>('');
  const [dropoffAddress, setDropoffAddress] = useState<string>('');
  const [urgencyLevel, setUrgencyLevel] = useState<'immediate' | 'today' | 'scheduled'>('immediate');
  const [details, setDetails] = useState<string>('');
  const [proposedPriceEgp, setProposedPriceEgp] = useState<number>(
    Math.round((activeChannel.suggestedMinPriceEgp + activeChannel.suggestedMaxPriceEgp) / 4)
  );
  const [formFeedback, setFormFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );

  // Sync default sub-service & price when switching channel
  useEffect(() => {
    setSubService(activeChannel.subServices[0] || '');
    const defaultPrice =
      activeChannel.id === 'mantygo_rides'
        ? 65
        : activeChannel.id === 'home_maintenance'
        ? 350
        : activeChannel.id === 'legal_consultation'
        ? 800
        : activeChannel.id === 'accounting_consultation'
        ? 950
        : Math.max(activeChannel.suggestedMinPriceEgp, 200);
    setProposedPriceEgp(defaultPrice);
    setFormFeedback(null);
  }, [activeChannel]);

  // 4. Customer Counter-Offer State per Bid
  const [activeCounterBidId, setActiveCounterBidId] = useState<string | null>(null);
  const [counterOfferInputPrice, setCounterOfferInputPrice] = useState<number>(0);
  const [counterOfferInputNote, setCounterOfferInputNote] = useState<string>('');

  const providerEligibility = useMemo(
    () =>
      selectedProviderBusiness
        ? evaluateProviderBiddingEligibility(selectedProviderBusiness, activeChannel)
        : null,
    [selectedProviderBusiness, activeChannel]
  );

  const [providerBidPrice, setProviderBidPrice] = useState<number>(150);
  const [providerBidEta, setProviderBidEta] = useState<string>('خلال 15 دقيقة');
  const [providerBidMessage, setProviderBidMessage] = useState<string>('');
  const [providerBidFeedback, setProviderBidFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  useEffect(() => {
    if (activeRequest) {
      setProviderBidPrice(activeRequest.customerProposedPriceEgp);
    }
  }, [activeRequest]);

  // 6. Add Custom Activity Channel Modal State
  const [isAddChannelModalOpen, setIsAddChannelModalOpen] = useState<boolean>(false);
  const [newChannelName, setNewChannelName] = useState<string>('');
  const [newChannelBadge, setNewChannelBadge] = useState<string>('');
  const [newChannelDesc, setNewChannelDesc] = useState<string>('');
  const [newChannelGroup, setNewChannelGroup] = useState<FunctionalGroupId>('healthcare');
  const [newChannelSubServices, setNewChannelSubServices] = useState<string>(
    'تمريض منزلي ورعاية مركزة, جلسات علاج طبيعي بالمنزل, سحب عينات تحاليل بالمنزل'
  );
  const [newChannelMinPrice, setNewChannelMinPrice] = useState<number>(150);
  const [newChannelMaxPrice, setNewChannelMaxPrice] = useState<number>(3000);
  const [newChannelRequiresRoute, setNewChannelRequiresRoute] = useState<boolean>(false);
  const [newChannelError, setNewChannelError] = useState<string | null>(null);

  // 7. Rating & Review Modal State (Management only visibility)
  const [isRatingModalOpen, setIsRatingModalOpen] = useState<boolean>(false);
  const [targetRatingRequestId, setTargetRatingRequestId] = useState<string | null>(null);
  const [ratingScore, setRatingScore] = useState<number>(5);
  const [reviewComment, setReviewComment] = useState<string>('');
  const [isManagementDashboardOpen, setIsManagementDashboardOpen] = useState<boolean>(false);

  const handleOpenRatingModal = (reqId: string) => {
    setTargetRatingRequestId(reqId);
    setRatingScore(5);
    setReviewComment('');
    setIsRatingModalOpen(true);
  };

  const handleConfirmRatingAndReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetRatingRequestId) return;
    const targetReq = requests.find((r) => r.id === targetRatingRequestId);
    if (!targetReq) return;

    const updated = submitRequestRatingAndReview(targetReq, ratingScore, reviewComment);
    setRequests((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
    setIsRatingModalOpen(false);
    setTargetRatingRequestId(null);
    triggerToast('تم تسجيل تقييم الخدمة ومراجعة الجودة بنجاح! النتيجة متاحة لصالحة إدارة المنصة فقط.', 'success');
  };

  // Eligible providers for the currently active channel
  const { eligibleProviders, ineligibleUnverifiedCount } = useMemo(
    () => getEligibleVerifiedProvidersForChannel(businesses, activeChannel, governorate),
    [businesses, activeChannel, governorate]
  );

  const renderChannelIcon = (iconName: MantyGoServiceChannel['iconName'], className = 'w-5 h-5') => {
    switch (iconName) {
      case 'car':
        return <Car className={className} />;
      case 'wrench':
        return <Wrench className={className} />;
      case 'scale':
        return <Scale className={className} />;
      case 'calculator':
        return <Calculator className={className} />;
      default:
        return <Sparkles className={className} />;
    }
  };

  // Handler: Submit new Customer Request
  const handleCreateCustomerRequest = (e: React.FormEvent) => {
    e.preventDefault();
    setFormFeedback(null);

    if (!customerName.trim() || customerName.trim().length < 2) {
      setFormFeedback({ type: 'error', text: 'يرجى إدخال اسم العميل بالكامل لتوجيه الطلب.' });
      return;
    }
    if (!customerPhone.trim() || customerPhone.replace(/[^0-9]/g, '').length < 8) {
      setFormFeedback({ type: 'error', text: 'يرجى إدخال رقم هاتف أو واتساب صحيح للتواصل.' });
      return;
    }
    if (!pickupAddress.trim()) {
      setFormFeedback({
        type: 'error',
        text: activeChannel.requiresPickupDropoff
          ? 'يرجى إدخال نقطة الانطلاق (عنوان التحرك).'
          : 'يرجى إدخال العنوان التفصيلي أو مقر الخدمة.',
      });
      return;
    }
    if (activeChannel.requiresPickupDropoff && !dropoffAddress.trim()) {
      setFormFeedback({ type: 'error', text: 'يرجى تحديد وجهة الوصول للمشوار أو التوصيل.' });
      return;
    }

    const recommendedFairPriceEgp = Math.round(proposedPriceEgp * 1.1);
    const newReqBase: Omit<MantyGoServiceRequest, 'bids' | 'routedEligibleProvidersCount'> = {
      id: `mgo_req_${Date.now()}`,
      channelId: activeChannel.id,
      channelName: activeChannel.name,
      subService: subService || activeChannel.subServices[0],
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      governorate,
      markaz: markaz.trim() || 'المركز الرئيسي',
      pickupAddress: pickupAddress.trim(),
      dropoffAddress: activeChannel.requiresPickupDropoff ? dropoffAddress.trim() : undefined,
      vehicleOrServiceMode: subService,
      urgencyLevel,
      details: details.trim() || `طلب ${subService} بسعر مقترح ${proposedPriceEgp} ج.م`,
      customerProposedPriceEgp: proposedPriceEgp,
      recommendedFairPriceEgp,
      status: 'negotiating',
      createdAt: 'الآن (مباشر)',
    };

    const { bids, routedCount } = generateAutomatedVerifiedBidsForRequest(
      newReqBase,
      businesses,
      activeChannel
    );

    const createdRequest: MantyGoServiceRequest = {
      ...newReqBase,
      routedEligibleProvidersCount: routedCount,
      bids,
    };

    setRequests((prev) => [createdRequest, ...prev]);
    setSelectedRequestId(createdRequest.id);
    triggerToast(`تم إرسال الطلب بنجاح! وتلقي (${bids.length}) عروض سعر من الأنشطة الموثقة.`, 'bid');
    setFormFeedback({
      type: 'success',
      text: `تم إرسال طلبك بنجاح وتوجيهه إلى (${routedCount}) من مقدمي الخدمة الموثقين بالباقات! وصلتك (${bids.length}) عروض تفاوضية فورية.`,
    });
    setPickupAddress('');
    setDropoffAddress('');
    setDetails('');
  };

  // Handler: Customer sends counter-offer on a specific provider bid
  const handleSendCustomerCounterOffer = (bidId: string) => {
    if (!activeRequest) return;
    if (!counterOfferInputPrice || counterOfferInputPrice < 10) return;

    const updated = applyCustomerCounterOfferToBid(
      activeRequest,
      bidId,
      counterOfferInputPrice,
      counterOfferInputNote
    );

    setRequests((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
    setActiveCounterBidId(null);
    setCounterOfferInputNote('');
    triggerToast('تم إرسال عرض السعر المضاد بنجاح في جلسة التفاوض الحي!', 'info');
  };

  // Handler: Customer accepts a provider bid
  const handleAcceptBid = (bidId: string) => {
    if (!activeRequest) return;
    const updated = acceptProviderBidForRequest(activeRequest, bidId);
    setRequests((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
    triggerToast('تم قبول عرض مقدم الخدمة بنجاح وتوثيق اتفاق السعر النهائي!', 'success');
  };

  // Handler: Provider submits a live bid
  const handleProviderSubmitBid = (e: React.FormEvent) => {
    e.preventDefault();
    setProviderBidFeedback(null);
    if (!activeRequest || !selectedProviderBusiness) return;

    const res = submitVerifiedProviderBidOnRequest({
      request: activeRequest,
      business: selectedProviderBusiness,
      channel: activeChannel,
      offeredPriceEgp: providerBidPrice,
      estimatedArrivalOrDelivery: providerBidEta,
      providerMessage: providerBidMessage,
    });

    if (!res.success || !res.updatedRequest) {
      setProviderBidFeedback({
        type: 'error',
        text: res.error || 'تعذر تقديم العرض.',
      });
      return;
    }

    setRequests((prev) =>
      prev.map((r) => (r.id === res.updatedRequest!.id ? res.updatedRequest! : r))
    );
    setProviderBidFeedback({
      type: 'success',
      text: `تم إرسال عرض السعر التفاوضي (${providerBidPrice} ج.م) باسم (${selectedProviderBusiness.name}) إلى العميل بنجاح!`,
    });
    setProviderBidMessage('');
    triggerToast(`تم استلام عرض سعر جديد (${providerBidPrice} ج.م) من مقدم الخدمة الموثق (${selectedProviderBusiness.name})!`, 'bid');
  };

  // Handler: Create a new custom Service Activity Channel
  const handleCreateCustomChannel = (e: React.FormEvent) => {
    e.preventDefault();
    setNewChannelError(null);

    const res = createCustomMantyGoChannel({
      name: newChannelName,
      badgeTitle: newChannelBadge || newChannelName,
      description: newChannelDesc,
      functionalGroupId: newChannelGroup,
      subServicesText: newChannelSubServices,
      suggestedMinPriceEgp: newChannelMinPrice,
      suggestedMaxPriceEgp: newChannelMaxPrice,
      requiresPickupDropoff: newChannelRequiresRoute,
    });

    if (!res.valid || !res.channel) {
      setNewChannelError(res.error || 'يرجى التحقق من البيانات المدخلة.');
      return;
    }

    const createdChannel = res.channel;
    setCustomChannels((prev) => [...prev, createdChannel]);

    // Also seed 1 initial live request for the newly added channel so it is immediately interactive
    const demoReqBase: Omit<MantyGoServiceRequest, 'bids' | 'routedEligibleProvidersCount'> = {
      id: `mgo_req_custom_${Date.now()}`,
      channelId: createdChannel.id,
      channelName: createdChannel.name,
      subService: createdChannel.subServices[0],
      customerName: 'عميل منطقتي X',
      customerPhone: '01065432198',
      governorate: 'الدقهلية',
      markaz: 'المنصورة',
      pickupAddress: 'شارع الجيش - بجوار المحافظة',
      vehicleOrServiceMode: createdChannel.subServices[0],
      urgencyLevel: 'immediate',
      details: `طلب خدمة فورية في قسم (${createdChannel.name}) بنظام التفاوض المباشر مع الأنشطة الموثقة.`,
      customerProposedPriceEgp: createdChannel.suggestedMinPriceEgp + 50,
      recommendedFairPriceEgp: createdChannel.suggestedMinPriceEgp + 75,
      status: 'negotiating',
      createdAt: 'الآن',
    };

    const { bids, routedCount } = generateAutomatedVerifiedBidsForRequest(
      demoReqBase,
      businesses,
      createdChannel
    );

    const seededCustomReq: MantyGoServiceRequest = {
      ...demoReqBase,
      routedEligibleProvidersCount: routedCount,
      bids,
    };

    setRequests((prev) => [seededCustomReq, ...prev]);
    setActiveChannelId(createdChannel.id);
    setSelectedRequestId(seededCustomReq.id);
    setIsAddChannelModalOpen(false);
    setNewChannelName('');
    setNewChannelBadge('');
    setNewChannelDesc('');
    triggerToast(`تم إضافة نشاط (${createdChannel.name}) وتفعيل نظام التفاوض المباشر بنجاح!`, 'success');
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-16" dir="rtl">
      {/* Floating Toast Notification Banner */}
      {toast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 max-w-lg w-full px-4 animate-bounce-short">
          <div
            className={`p-4 rounded-2xl shadow-2xl border text-xs sm:text-sm font-black flex items-center justify-between gap-3 ${
              toast.type === 'success'
                ? 'bg-emerald-900 text-emerald-100 border-emerald-500'
                : toast.type === 'bid'
                ? 'bg-amber-950 text-amber-100 border-amber-400'
                : 'bg-slate-900 text-slate-100 border-indigo-500'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {toast.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              ) : toast.type === 'bid' ? (
                <Sparkles className="w-5 h-5 text-amber-400 flex-shrink-0" />
              ) : (
                <ArrowLeftRight className="w-5 h-5 text-indigo-400 flex-shrink-0" />
              )}
              <span>{toast.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="text-slate-400 hover:text-white text-xs font-bold px-2 py-1 rounded-lg bg-black/30 cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Hero Header Banner — Clean & Minimalist */}
      <section className="bg-gradient-to-r from-slate-950 via-indigo-950 to-emerald-950 text-white border-b border-slate-800 relative overflow-hidden">
        <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 py-6 relative z-10">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <div className="inline-flex items-center gap-2 bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 px-3 py-1 rounded-full text-xs font-black">
                <ArrowLeftRight className="w-3.5 h-3.5 text-emerald-400" />
                <span>MANTYGO & مركز التفاوض الحي المباشر</span>
              </div>
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-white">
                منصة التفاوض الفوري للخدمات والأنشطة الموثقة
              </h1>
              <p className="text-slate-300 text-xs leading-relaxed">
                اطلب خدمتك أو مشوارك بالسعر الذي تختاره، وتلقَّ عروضاً لحظية وتفاوضاً مباشراً مع الأنشطة الموثقة في منطقتك.
              </p>
            </div>

            {/* Mode Switcher & Role Switcher Bar */}
            <div className="flex flex-wrap items-center gap-2 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-700/80 shadow-xl">
              {/* View Mode Tabs */}
              <button
                type="button"
                onClick={() => setMantyGoViewMode('room')}
                className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                  mantyGoViewMode === 'room'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                <span>غرفة التفاوض الحي</span>
              </button>

              <button
                type="button"
                onClick={() => setMantyGoViewMode('dashboard')}
                className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                  mantyGoViewMode === 'dashboard'
                    ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-md'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5 text-amber-300" />
                <span>شاشة حالة الطلبات (Dashboard)</span>
                <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                  {requests.filter((r) => r.status !== 'cancelled').length}
                </span>
              </button>

              <div className="h-4 w-px bg-slate-700 mx-1 hidden sm:block" />

              {/* Role Toggle */}
              <button
                type="button"
                onClick={() => setWorkspaceRole('customer')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  workspaceRole === 'customer'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>العميل</span>
              </button>

              <button
                type="button"
                onClick={() => setWorkspaceRole('provider')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  workspaceRole === 'provider'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>مقدم الخدمة</span>
              </button>

              <button
                type="button"
                onClick={() => setIsManagementDashboardOpen(true)}
                className="px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 text-amber-300 hover:bg-slate-800 cursor-pointer"
                title="لوحة التقييمات والمراجعات (للإدارة حصرياً)"
              >
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>الإدارة</span>
              </button>
            </div>
          </div>

          {/* Service Channels Bar */}
          <div className="mt-5 pt-4 border-t border-slate-800/80">
            <div className="flex items-center justify-between gap-2 mb-2.5 flex-wrap">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>اختر القطاع الخدمي (أو أضف نشاطاً جديداً):</span>
              </span>
              <button
                type="button"
                onClick={() => setIsAddChannelModalOpen(true)}
                className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white px-3.5 py-1.5 rounded-xl text-xs font-black shadow-md border border-indigo-400/30 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة نشاط تفاوضي جديد</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {allChannels.map((channel) => {
                const isSelected = channel.id === activeChannel.id;
                const countReqs = requests.filter((r) => r.channelId === channel.id).length;
                return (
                  <button
                    key={channel.id}
                    type="button"
                    onClick={() => setActiveChannelId(channel.id)}
                    className={`text-right p-3 rounded-2xl border transition-all cursor-pointer flex items-center gap-3 ${
                      isSelected
                        ? 'bg-white text-slate-900 border-emerald-400 shadow-md ring-2 ring-emerald-400/40'
                        : 'bg-slate-900/70 text-slate-200 border-slate-800 hover:bg-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-xl bg-gradient-to-br ${channel.accentColor} text-white flex items-center justify-center flex-shrink-0 shadow-sm`}
                    >
                      {renderChannelIcon(channel.iconName, 'w-4 h-4')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[10px] font-black truncate text-emerald-400">
                          {channel.badgeTitle}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                            isSelected ? 'bg-slate-100 text-slate-700' : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {countReqs} نشط
                        </span>
                      </div>
                      <h2
                        className={`font-black text-xs mt-0.5 truncate ${
                          isSelected ? 'text-slate-900' : 'text-white'
                        }`}
                      >
                        {channel.name}
                      </h2>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Container: Live Negotiation Room */}
      {mantyGoViewMode === 'room' && (
        <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 mt-5 space-y-5">
        {/* Compact Package & Verification Eligibility Bar */}
        <div className="bg-white rounded-2xl border border-slate-200/90 px-4 py-3 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span className="font-bold text-slate-800">
              {eligibleProviders.length} نشاط موثق مؤهل لاستقبال طلبات ({activeChannel.badgeTitle})
            </span>
            {ineligibleUnverifiedCount > 0 && (
              <span className="text-slate-400">({ineligibleUnverifiedCount} غير موثق محجوب)</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() =>
                openSectorDevelopmentStudio(activeChannel.allowedFunctionalGroups[0] || 'services')
              }
              className="text-indigo-600 hover:text-indigo-800 font-bold underline cursor-pointer"
            >
              استعراض الباقات الموثقة
            </button>
          </div>
        </div>

        {/* Main 12-Column Grid: Left (4 cols) Request Builder / Provider Console, Right (8 cols) Live Real-time Negotiation Room */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* RIGHT/FIRST COLUMN (5 cols on lg): Customer Request Form OR Provider Dispatch Form */}
          <div className="lg:col-span-5 space-y-6">
            {workspaceRole === 'customer' ? (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div
                  className={`bg-gradient-to-r ${activeChannel.accentColor} p-4 text-white flex items-center justify-between`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-white/15 backdrop-blur-xs flex items-center justify-center">
                      {renderChannelIcon(activeChannel.iconName, 'w-5 h-5')}
                    </div>
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-wider bg-black/25 px-2 py-0.5 rounded">
                        نموذج طلب العميل (التفاوض المباشر)
                      </span>
                      <h2 className="font-black text-base mt-0.5">اطلب {activeChannel.badgeTitle} وحدد سعرك</h2>
                    </div>
                  </div>
                </div>

                <form onSubmit={handleCreateCustomerRequest} className="p-5 space-y-4">
                  {formFeedback && (
                    <div
                      className={`p-3.5 rounded-xl text-xs font-bold flex items-start gap-2 border ${
                        formFeedback.type === 'success'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-rose-50 text-rose-800 border-rose-200'
                      }`}
                    >
                      {formFeedback.type === 'success' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                      )}
                      <span>{formFeedback.text}</span>
                    </div>
                  )}

                  {/* Sub-service Selection */}
                  <div>
                    <label
                      htmlFor="mantygo-subservice"
                      className="block text-xs font-black text-slate-800 mb-1.5"
                    >
                      نوع الخدمة المطلوبة داخل ({activeChannel.badgeTitle})
                    </label>
                    <select
                      id="mantygo-subservice"
                      value={subService}
                      onChange={(e) => setSubService(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                    >
                      {activeChannel.subServices.map((sub) => (
                        <option key={sub} value={sub}>
                          {sub}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Customer Name & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label
                        htmlFor="mantygo-cust-name"
                        className="block text-xs font-black text-slate-800 mb-1"
                      >
                        اسم العميل
                      </label>
                      <input
                        id="mantygo-cust-name"
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="مثال: م. محمد عادل"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="mantygo-cust-phone"
                        className="block text-xs font-black text-slate-800 mb-1"
                      >
                        رقم الموبايل / واتساب
                      </label>
                      <input
                        id="mantygo-cust-phone"
                        type="tel"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="010xxxxxxxx"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  {/* Governorate & Markaz */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label
                        htmlFor="mantygo-gov"
                        className="block text-xs font-black text-slate-800 mb-1"
                      >
                        المحافظة
                      </label>
                      <select
                        id="mantygo-gov"
                        value={governorate}
                        onChange={(e) => setGovernorate(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                      >
                        <option value="الدقهلية">الدقهلية</option>
                        <option value="القاهرة">القاهرة</option>
                        <option value="الجيزة">الجيزة</option>
                        <option value="الإسكندرية">الإسكندرية</option>
                        <option value="الغربية">الغربية</option>
                        <option value="الشرقية">الشرقية</option>
                        <option value="دمياط">دمياط</option>
                      </select>
                    </div>
                    <div>
                      <label
                        htmlFor="mantygo-markaz"
                        className="block text-xs font-black text-slate-800 mb-1"
                      >
                        المركز / الحي
                      </label>
                      <input
                        id="mantygo-markaz"
                        type="text"
                        value={markaz}
                        onChange={(e) => setMarkaz(e.target.value)}
                        placeholder="المنصورة / مدينة نصر..."
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  {/* Pickup / Location & Dropoff (if MantyGo Rides) */}
                  <div>
                    <label
                      htmlFor="mantygo-pickup"
                      className="block text-xs font-black text-slate-800 mb-1"
                    >
                      {activeChannel.requiresPickupDropoff
                        ? 'نقطة الانطلاق (من أين يبدأ المشوار / الاستلام؟)'
                        : 'العنوان التفصيلي أو طريقة الاستشارة (مكتب / منزل / أونلاين)'}
                    </label>
                    <input
                      id="mantygo-pickup"
                      type="text"
                      value={pickupAddress}
                      onChange={(e) => setPickupAddress(e.target.value)}
                      placeholder={
                        activeChannel.requiresPickupDropoff
                          ? 'مثال: شارع المشاية السفلية أمام نادي جزيرة الورد'
                          : 'مثال: حي الجامعة - شارع جيهان - عمارة 14'
                      }
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  {activeChannel.requiresPickupDropoff && (
                    <div>
                      <label
                        htmlFor="mantygo-dropoff"
                        className="block text-xs font-black text-slate-800 mb-1"
                      >
                        نقطة الوصول (إلى أين تتجه في مشوار MANTYGO؟)
                      </label>
                      <input
                        id="mantygo-dropoff"
                        type="text"
                        value={dropoffAddress}
                        onChange={(e) => setDropoffAddress(e.target.value)}
                        placeholder="مثال: موقف المنصورة الجديد / محطة القطار / تقسيم سامية الجمل"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                      />
                    </div>
                  )}

                  {/* Urgency Level */}
                  <div>
                    <span className="block text-xs font-black text-slate-800 mb-1.5">
                      توقيت التنفيذ المطلوب
                    </span>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'immediate', label: 'فوري الآن ⚡' },
                        { id: 'today', label: 'اليوم 📅' },
                        { id: 'scheduled', label: 'موعد مجدول 🕒' },
                      ].map((u) => (
                        <button
                          key={u.id}
                          type="button"
                          onClick={() =>
                            setUrgencyLevel(u.id as 'immediate' | 'today' | 'scheduled')
                          }
                          className={`py-2 px-2 rounded-xl text-xs font-black border transition-all cursor-pointer ${
                            urgencyLevel === u.id
                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {u.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Interactive Price Proposer Widget */}
                  <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-emerald-400 flex items-center gap-1.5">
                        <TrendingUp className="w-4 h-4" />
                        <span>حدد سعرك المقترح (نظام التفاوض الحر)</span>
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {activeChannel.unitLabel}
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={() =>
                          setProposedPriceEgp((p) =>
                            Math.max(activeChannel.suggestedMinPriceEgp, p - activeChannel.priceStepEgp)
                          )
                        }
                        className="w-11 h-11 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-black text-lg flex items-center justify-center border border-slate-700 cursor-pointer"
                        aria-label="تقليل السعر المقترح"
                      >
                        -
                      </button>

                      <div className="flex-1 text-center">
                        <div className="flex items-baseline justify-center gap-1">
                          <input
                            type="number"
                            aria-label="السعر المقترح بالجنيه"
                            value={proposedPriceEgp}
                            onChange={(e) =>
                              setProposedPriceEgp(Math.max(10, Number(e.target.value) || 0))
                            }
                            className="w-28 bg-transparent text-center text-2xl sm:text-3xl font-black text-emerald-400 focus:outline-hidden border-b border-emerald-500/40"
                          />
                          <span className="text-xs font-bold text-slate-300">ج.م</span>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1">
                          النطاق الاسترشادي: {activeChannel.suggestedMinPriceEgp} ج.م إلى{' '}
                          {activeChannel.suggestedMaxPriceEgp} ج.م
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          setProposedPriceEgp((p) =>
                            Math.min(
                              activeChannel.suggestedMaxPriceEgp * 2,
                              p + activeChannel.priceStepEgp
                            )
                          )
                        }
                        className="w-11 h-11 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-lg flex items-center justify-center shadow-md cursor-pointer"
                        aria-label="زيادة السعر المقترح"
                      >
                        +
                      </button>
                    </div>

                    <input
                      type="range"
                      aria-label="شريط تحديد السعر المقترح"
                      min={activeChannel.suggestedMinPriceEgp}
                      max={activeChannel.suggestedMaxPriceEgp}
                      step={activeChannel.priceStepEgp}
                      value={Math.min(
                        activeChannel.suggestedMaxPriceEgp,
                        Math.max(activeChannel.suggestedMinPriceEgp, proposedPriceEgp)
                      )}
                      onChange={(e) => setProposedPriceEgp(Number(e.target.value))}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>

                  {/* Additional Notes */}
                  <div>
                    <label
                      htmlFor="mantygo-details"
                      className="block text-xs font-black text-slate-800 mb-1"
                    >
                      تفاصيل إضافية لمقدمي الخدمة الموثقين (اختياري)
                    </label>
                    <textarea
                      id="mantygo-details"
                      rows={2}
                      value={details}
                      onChange={(e) => setDetails(e.target.value)}
                      placeholder="اكتب أي تفاصيل إضافية حول المشوار، العطل الفني، أو موضوع الاستشارة..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black py-3.5 px-4 rounded-xl shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 text-sm transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>إرسال الطلب وتلقي عروض الأنشطة الموثقة فوراً</span>
                  </button>
                </form>
              </div>
            ) : (
              /* PROVIDER CONSOLE (وضع مقدم الخدمة الموثق بالباقات) */
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-4 text-white">
                  <span className="text-[10px] font-black uppercase bg-amber-400 text-slate-950 px-2 py-0.5 rounded">
                    لوحة مقدم الخدمة الموثق • صلاحيات الباقات
                  </span>
                  <h2 className="font-black text-base mt-1 flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    <span>رادار استقبال طلبات العملاء وتقديم العروض</span>
                  </h2>
                  <p className="text-xs text-slate-300 mt-0.5">
                    اختر النشاط التجاري لمعاينة صلاحيته بالباقة وتقديم عرض سعر تفاوضي على الطلب المحدد.
                  </p>
                </div>

                <div className="p-5 space-y-4">
                  <div>
                    <label
                      htmlFor="provider-biz-select"
                      className="block text-xs font-black text-slate-800 mb-1.5"
                    >
                      اختر النشاط المسجل بالمنصة (لاختبار صلاحية الباقة والتوثيق):
                    </label>
                    <select
                      id="provider-biz-select"
                      value={providerBusinessId}
                      onChange={(e) => setProviderBusinessId(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-black text-slate-900"
                    >
                      {businesses.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.name} — ({b.isVerified ? 'موثق ✓' : 'غير موثق ✗'} • {b.category})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Eligibility Diagnostic Card */}
                  {providerEligibility && (
                    <div
                      className={`p-4 rounded-2xl border ${
                        providerEligibility.isEligible
                          ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                          : 'bg-rose-50/70 border-rose-200 text-rose-950'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 flex-wrap mb-1.5">
                        <span className="font-black text-xs flex items-center gap-1.5">
                          {providerEligibility.isEligible ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Lock className="w-4 h-4 text-rose-600" />
                          )}
                          <span>{providerEligibility.businessName}</span>
                        </span>
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            providerEligibility.isEligible
                              ? 'bg-emerald-600 text-white'
                              : 'bg-rose-600 text-white'
                          }`}
                        >
                          {providerEligibility.packageBadge}
                        </span>
                      </div>
                      <p className="text-xs leading-relaxed font-medium">
                        {providerEligibility.reasonAr}
                      </p>

                      {!providerEligibility.isEligible && selectedProviderBusiness && (
                        <div className="mt-3 pt-3 border-t border-rose-200/80 flex items-center justify-between gap-2 flex-wrap">
                          <span className="text-[11px] font-bold text-rose-800">
                            لتفعيل استقبال طلبات التفاوض لهذا النشاط:
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              openSectorDevelopmentStudio(selectedProviderBusiness.functionalGroupId, selectedProviderBusiness)
                            }
                            className="bg-slate-900 hover:bg-slate-800 text-amber-300 px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer"
                          >
                            <Crown className="w-3.5 h-3.5" />
                            <span>ترقية الباقة وتوثيق النشاط الآن</span>
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Provider Bid Submission Form */}
                  {activeRequest ? (
                    <form onSubmit={handleProviderSubmitBid} className="space-y-3 pt-2">
                      <div className="bg-slate-100 p-3 rounded-xl border border-slate-200 text-xs">
                        <span className="font-black text-slate-900 block">
                          تقديم عرض على طلب العميل: {activeRequest.customerName}
                        </span>
                        <span className="text-slate-600 block mt-0.5">
                          الخدمة: {activeRequest.subService} • السعر المقترح من العميل:{' '}
                          <strong className="text-emerald-700">
                            {activeRequest.customerProposedPriceEgp} ج.م
                          </strong>
                        </span>
                      </div>

                      {providerBidFeedback && (
                        <div
                          className={`p-3 rounded-xl text-xs font-bold border ${
                            providerBidFeedback.type === 'success'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : 'bg-rose-50 text-rose-800 border-rose-200'
                          }`}
                        >
                          {providerBidFeedback.text}
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label
                            htmlFor="prov-bid-price"
                            className="block text-xs font-black text-slate-800 mb-1"
                          >
                            عرض السعر المقدم منك (ج.م)
                          </label>
                          <input
                            id="prov-bid-price"
                            type="number"
                            value={providerBidPrice}
                            onChange={(e) => setProviderBidPrice(Number(e.target.value) || 0)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-900"
                          />
                        </div>
                        <div>
                          <label
                            htmlFor="prov-bid-eta"
                            className="block text-xs font-black text-slate-800 mb-1"
                          >
                            مدة الوصول / التنفيذ
                          </label>
                          <input
                            id="prov-bid-eta"
                            type="text"
                            value={providerBidEta}
                            onChange={(e) => setProviderBidEta(e.target.value)}
                            placeholder="مثال: خلال 10 دقائق"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900"
                          />
                        </div>
                      </div>

                      <div>
                        <label
                          htmlFor="prov-bid-msg"
                          className="block text-xs font-black text-slate-800 mb-1"
                        >
                          رسالة العرض والمميزات للعميل
                        </label>
                        <input
                          id="prov-bid-msg"
                          type="text"
                          value={providerBidMessage}
                          onChange={(e) => setProviderBidMessage(e.target.value)}
                          placeholder="مثال: شامل الضمان وقطع الغيار الأصلية / سيارة مكيفة حديثة..."
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={!providerEligibility?.isEligible}
                        className={`w-full py-3 px-4 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition-all ${
                          providerEligibility?.isEligible
                            ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md cursor-pointer'
                            : 'bg-slate-200 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        <Send className="w-4 h-4" />
                        <span>
                          {providerEligibility?.isEligible
                            ? 'إرسال عرض السعر التفاوضي للعميل الآن'
                            : 'يتطلب نشاطاً موثقاً ومؤهلاً بالباقة لتقديم العرض'}
                        </span>
                      </button>
                    </form>
                  ) : null}
                </div>
              </div>
            )}
          </div>

          {/* LEFT/SECOND COLUMN (7 cols on lg): Active Requests List + Live Real-time Negotiation & Bidding Room */}
          <div className="lg:col-span-7 space-y-5">
            {/* Active Requests Selector Strip for the Current Channel */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
              <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
                <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-600" />
                  <span>الطلبات النشطة وجلسات التفاوض الحية في ({activeChannel.badgeTitle})</span>
                </h3>
                <span className="text-xs font-bold text-slate-500">
                  إجمالي الطلبات بالقسم: {channelRequests.length}
                </span>
              </div>

              <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
                {channelRequests.map((req) => {
                  const isActive = activeRequest?.id === req.id;
                  return (
                    <button
                      key={req.id}
                      type="button"
                      onClick={() => setSelectedRequestId(req.id)}
                      className={`text-right px-3.5 py-2.5 rounded-xl border transition-all flex-shrink-0 min-w-[230px] max-w-[280px] cursor-pointer ${
                        isActive
                          ? 'bg-slate-900 text-white border-slate-900 shadow-md'
                          : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] font-black truncate">{req.customerName}</span>
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            req.status === 'accepted'
                              ? 'bg-emerald-500 text-slate-950'
                              : 'bg-amber-400 text-slate-950'
                          }`}
                        >
                          {req.status === 'accepted'
                            ? `تم الاتفاق (${req.acceptedFinalPriceEgp} ج.م)`
                            : `مقترح ${req.customerProposedPriceEgp} ج.م`}
                        </span>
                      </div>
                      <p
                        className={`text-[11px] truncate mt-1 font-medium ${
                          isActive ? 'text-slate-300' : 'text-slate-600'
                        }`}
                      >
                        {req.subService}
                      </p>
                      <div
                        className={`flex items-center justify-between text-[10px] mt-1.5 ${
                          isActive ? 'text-emerald-300' : 'text-slate-500'
                        }`}
                      >
                        <span>
                          {req.governorate} - {req.markaz}
                        </span>
                        <span>{req.bids.length} عروض موثقة</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Active Request Live Negotiation Room */}
            {activeRequest && (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                {/* Request Summary Header */}
                <div className="bg-slate-900 text-white p-5 border-b border-slate-800">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-black px-2.5 py-0.5 rounded-full">
                          {activeRequest.channelName}
                        </span>
                        <span className="text-xs text-slate-400">• {activeRequest.createdAt}</span>
                        <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-[11px] font-bold px-2.5 py-0.5 rounded-full">
                          تم التوجيه إلى {activeRequest.routedEligibleProvidersCount} نشاط موثق بالباقات
                        </span>
                      </div>
                      <h3 className="text-lg font-black text-white mt-1.5">
                        {activeRequest.subService}
                      </h3>
                      <div className="flex items-center gap-3 text-xs text-slate-300 mt-1 flex-wrap">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                          <span>
                            {activeRequest.governorate} ({activeRequest.markaz}):{' '}
                            {activeRequest.pickupAddress}
                          </span>
                        </span>
                        {activeRequest.dropoffAddress && (
                          <span className="flex items-center gap-1 text-amber-300 font-bold">
                            <span>⬅ الوجهة: {activeRequest.dropoffAddress}</span>
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="bg-slate-800/90 border border-slate-700 px-4 py-3 rounded-2xl text-center flex-shrink-0">
                      <span className="text-[10px] text-slate-400 block font-bold">
                        {activeRequest.status === 'accepted'
                          ? 'السعر النهائي المتفق عليه'
                          : 'سعر العميل المقترح حالياً'}
                      </span>
                      <span className="text-2xl font-black text-emerald-400">
                        {activeRequest.status === 'accepted'
                          ? activeRequest.acceptedFinalPriceEgp
                          : activeRequest.customerProposedPriceEgp}{' '}
                        <small className="text-xs">ج.م</small>
                      </span>
                    </div>
                  </div>

                  {activeRequest.details && (
                    <p className="mt-3 text-xs text-slate-300 bg-slate-800/60 px-3.5 py-2 rounded-xl border border-slate-700/70">
                      ملاحظات الطلب: {activeRequest.details}
                    </p>
                  )}
                </div>

                {/* Live Provider Bids & Counter-Offer Cards */}
                <div className="p-5 space-y-4">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <h4 className="font-black text-sm text-slate-900 flex items-center gap-2">
                      <ArrowLeftRight className="w-4 h-4 text-indigo-600" />
                      <span>
                        العروض التفاوضية المباشرة من مقدمي الخدمة الموثقين ({activeRequest.bids.length})
                      </span>
                    </h4>
                    <span className="text-[11px] font-bold text-slate-500">
                      يمكنك قبول العرض فوراً أو إرسال عرض سعر مضاد للتفاوض اللحظي
                    </span>
                  </div>

                  <div className="space-y-4">
                    {activeRequest.bids.map((bid) => {
                      const isAccepted = bid.status === 'accepted';
                      const isDeclined = bid.status === 'declined';
                      const isCountering = activeCounterBidId === bid.id;
                      const priceDiff = bid.offeredPriceEgp - activeRequest.customerProposedPriceEgp;

                      return (
                        <div
                          key={bid.id}
                          className={`rounded-2xl border p-4 transition-all ${
                            isAccepted
                              ? 'bg-emerald-50/70 border-emerald-400 ring-2 ring-emerald-400/40 shadow-md'
                              : isDeclined
                              ? 'bg-slate-50 border-slate-200 opacity-60'
                              : 'bg-white border-slate-200 hover:border-indigo-300 shadow-xs'
                          }`}
                        >
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                            {/* Provider Identity & Package Badge */}
                            <div className="flex items-start gap-3">
                              <img
                                src={bid.businessLogoUrl}
                                alt={bid.businessName}
                                className="w-12 h-12 rounded-xl object-cover border border-slate-200 flex-shrink-0"
                              />
                              <div>
                                <div className="flex items-center gap-2 flex-wrap">
                                  <h5 className="font-black text-sm text-slate-900">
                                    {bid.businessName}
                                  </h5>
                                  <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full">
                                    <ShieldCheck className="w-3 h-3 text-emerald-600" />
                                    <span>موثق رسمياً</span>
                                  </span>
                                  <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2 py-0.5 rounded-full">
                                    {bid.packageBadge}
                                  </span>
                                </div>

                                <div className="flex items-center gap-3 text-xs text-slate-500 mt-1 flex-wrap">
                                  <span className="flex items-center gap-1 text-amber-600 font-black">
                                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                                    <span>{bid.rating}</span>
                                  </span>
                                  <span>•</span>
                                  <span>{bid.completedJobsCount} خدمة مكتملة</span>
                                  <span>•</span>
                                  <span className="flex items-center gap-1 text-indigo-700 font-bold">
                                    <Clock className="w-3.5 h-3.5" />
                                    <span>{bid.estimatedArrivalOrDelivery}</span>
                                  </span>
                                </div>

                                <p className="text-xs text-slate-700 font-medium mt-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
                                  {bid.providerMessage}
                                </p>

                                {/* Perks Chips */}
                                <div className="flex items-center gap-1.5 flex-wrap mt-2">
                                  {bid.perks.map((perk) => (
                                    <span
                                      key={perk}
                                      className="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md border border-slate-200"
                                    >
                                      ✓ {perk}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>

                            {/* Price & Action Controls */}
                            <div className="flex flex-col sm:items-end justify-between gap-2 flex-shrink-0 min-w-[175px]">
                              <div className="sm:text-left bg-slate-900 text-white px-3.5 py-2 rounded-xl w-full sm:w-auto">
                                <span className="text-[10px] text-slate-400 block">
                                  عرض مقدم الخدمة الموثق
                                </span>
                                <div className="flex items-baseline gap-1.5">
                                  <span className="text-xl font-black text-emerald-400">
                                    {bid.offeredPriceEgp} ج.م
                                  </span>
                                  {priceDiff === 0 ? (
                                    <span className="text-[10px] font-black text-emerald-300">
                                      (مطابق لسعرك!)
                                    </span>
                                  ) : priceDiff > 0 ? (
                                    <span className="text-[10px] font-bold text-amber-300">
                                      (+{priceDiff} ج.م)
                                    </span>
                                  ) : (
                                    <span className="text-[10px] font-black text-emerald-300">
                                      (أوفر بـ {Math.abs(priceDiff)} ج.م)
                                    </span>
                                  )}
                                </div>
                              </div>

                              {/* Action Buttons */}
                              {isAccepted ? (
                                <div className="w-full space-y-1.5">
                                  <div className="bg-emerald-600 text-white text-xs font-black px-3 py-2 rounded-xl flex items-center justify-center gap-1.5">
                                    <Check className="w-4 h-4" />
                                    <span>تم قبول العرض والاتفاق</span>
                                  </div>
                                  <a
                                    href={generateMantyGoAcceptedDealWhatsAppUrl(activeRequest, bid)}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="w-full bg-slate-900 hover:bg-slate-800 text-emerald-400 text-xs font-black px-3 py-2 rounded-xl flex items-center justify-center gap-1.5 border border-slate-700"
                                  >
                                    <MessageCircle className="w-3.5 h-3.5" />
                                    <span>تأكيد التنفيذ عبر واتساب</span>
                                  </a>
                                </div>
                              ) : activeRequest.status !== 'accepted' ? (
                                <div className="flex sm:flex-col gap-1.5 w-full">
                                  <button
                                    type="button"
                                    onClick={() => handleAcceptBid(bid.id)}
                                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black px-3 py-2 rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                                  >
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                    <span>قبول العرض ({bid.offeredPriceEgp} ج.م)</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setActiveCounterBidId(isCountering ? null : bid.id);
                                      setCounterOfferInputPrice(
                                        Math.max(
                                          10,
                                          Math.round(
                                            (bid.offeredPriceEgp +
                                              activeRequest.customerProposedPriceEgp) /
                                              2
                                          )
                                        )
                                      );
                                    }}
                                    className="flex-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-black px-3 py-1.5 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                                  >
                                    <ArrowLeftRight className="w-3.5 h-3.5" />
                                    <span>تفاوض مضاد (عدّل السعر)</span>
                                  </button>
                                </div>
                              ) : null}
                            </div>
                          </div>

                          {/* Interactive Counter-Offer Box (when customer clicks "تفاوض مضاد") */}
                          {isCountering && (
                            <div className="mt-3 pt-3 border-t border-slate-200 bg-amber-50/60 p-3.5 rounded-xl space-y-2.5">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-black text-slate-900">
                                  إرسال عرض سعر مضاد إلى ({bid.businessName}):
                                </span>
                                <span className="text-[11px] font-bold text-slate-600">
                                  عرضهم الحالي: {bid.offeredPriceEgp} ج.م
                                </span>
                              </div>
                              <div className="flex flex-col sm:flex-row gap-2">
                                <input
                                  type="number"
                                  aria-label="سعر التفاوض المضاد"
                                  value={counterOfferInputPrice}
                                  onChange={(e) =>
                                    setCounterOfferInputPrice(Number(e.target.value) || 0)
                                  }
                                  className="sm:w-36 bg-white border border-amber-300 rounded-xl px-3 py-2 text-xs font-black text-slate-900"
                                  placeholder="السعر المقترح"
                                />
                                <input
                                  type="text"
                                  value={counterOfferInputNote}
                                  onChange={(e) => setCounterOfferInputNote(e.target.value)}
                                  className="flex-1 bg-white border border-amber-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900"
                                  placeholder="رسالة تفاوضية (مثال: جاهز للتنفيذ الفوري بهذا السعر)..."
                                />
                                <button
                                  type="button"
                                  onClick={() => handleSendCustomerCounterOffer(bid.id)}
                                  className="bg-slate-900 hover:bg-slate-800 text-amber-300 font-black text-xs px-4 py-2 rounded-xl cursor-pointer"
                                >
                                  إرسال التفاوض
                                </button>
                              </div>
                            </div>
                          )}

                          {/* Negotiation History Timeline */}
                          {bid.negotiationHistory.length > 0 && (
                            <div className="mt-3 pt-2.5 border-t border-slate-100">
                              <details className="group">
                                <summary className="text-[11px] font-bold text-slate-500 hover:text-slate-800 cursor-pointer list-none flex items-center gap-1">
                                  <span>
                                    سجل التفاوض اللحظي ({bid.negotiationHistory.length} حركات)
                                  </span>
                                  <span className="text-[10px] text-indigo-600 font-black">
                                    (اضغط للعرض)
                                  </span>
                                </summary>
                                <div className="mt-2 space-y-1.5 pl-2 border-r-2 border-indigo-200 pr-3">
                                  {bid.negotiationHistory.map((step) => (
                                    <div
                                      key={step.id}
                                      className="text-[11px] flex items-center justify-between gap-2 bg-slate-50 px-2.5 py-1.5 rounded-lg"
                                    >
                                      <div>
                                        <span
                                          className={`font-black ${
                                            step.actor === 'customer'
                                              ? 'text-indigo-700'
                                              : 'text-emerald-700'
                                          }`}
                                        >
                                          {step.actor === 'customer' ? 'العميل' : step.actorName}:
                                        </span>{' '}
                                        <span className="text-slate-700">{step.note}</span>
                                      </div>
                                      <span className="font-black text-slate-900 whitespace-nowrap">
                                        {step.priceEgp} ج.م
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </details>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      )}

      {/* MantyGo Orders Status Dashboard Screen (شاشة متابعة وحالة الطلبات قيد التنفيذ والمكتملة مع تصفية الأنشطة) */}
      {mantyGoViewMode === 'dashboard' && (
        <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 mt-5 space-y-6 animate-in fade-in duration-200">
          {/* Dashboard Header & Summary KPI Grid */}
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-3xl border border-indigo-500/30 shadow-xl space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 px-3 py-0.5 rounded-full text-xs font-black">
                  <LayoutDashboard className="w-3.5 h-3.5 text-amber-300" />
                  <span>شاشة عرض ومتابعة الطلبات • MantyGo Dashboard</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  شاشة متابعة حالة الطلبات (قيد التنفيذ والمكتملة)
                </h2>
                <p className="text-xs text-slate-300 leading-relaxed">
                  متابعة فورية وشاملة لكافة طلبات التفاوض والتسليمات للعميل ومقدم الخدمة الموثق مع إمكانية التصفية المباشرة حسب نوع النشاط والقطاع.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setMantyGoViewMode('room')}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs px-5 py-2.5 rounded-2xl shadow-md flex items-center gap-2 cursor-pointer shrink-0 self-start md:self-auto"
              >
                <ArrowLeftRight className="w-4 h-4" />
                <span>العودة لغرفة التفاوض المباشرة</span>
              </button>
            </div>

            {/* KPI Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5 pt-1">
              <div className="bg-white/10 border border-white/15 p-4 rounded-2xl">
                <span className="text-[11px] font-bold text-slate-300 block">إجمالي الطلبات المسجلة</span>
                <span className="text-2xl font-black text-white mt-1 block font-mono">
                  {requests.length}
                </span>
              </div>

              <div className="bg-amber-500/10 border border-amber-400/30 p-4 rounded-2xl">
                <span className="text-[11px] font-black text-amber-300 block">قيد التنفيذ والتفاوض ⏳</span>
                <span className="text-2xl font-black text-amber-300 mt-1 block font-mono">
                  {requests.filter((r) => r.status === 'negotiating' || r.status === 'open_for_bids' || r.status === 'accepted').length}
                </span>
              </div>

              <div className="bg-emerald-500/10 border border-emerald-400/30 p-4 rounded-2xl">
                <span className="text-[11px] font-black text-emerald-300 block">الطلبات المكتملة ✅</span>
                <span className="text-2xl font-black text-emerald-300 mt-1 block font-mono">
                  {requests.filter((r) => r.status === 'completed').length}
                </span>
              </div>

              <div className="bg-indigo-500/10 border border-indigo-400/30 p-4 rounded-2xl">
                <span className="text-[11px] font-black text-indigo-300 block">إجمالي قيم الصفقات (ج.م)</span>
                <span className="text-2xl font-black text-amber-300 mt-1 block font-mono">
                  {requests
                    .reduce((acc, r) => acc + (r.acceptedFinalPriceEgp || r.customerProposedPriceEgp || 0), 0)
                    .toLocaleString()}{' '}
                  ج.م
                </span>
              </div>
            </div>
          </div>

          {/* Filter Toolbar: Activity Type / Sector Filter + Status Filter + Role Perspective Filter */}
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col lg:flex-row items-center justify-between gap-4">
            {/* 1. Activity Sector Filter (تصفية حسب نوع النشاط) */}
            <div className="flex items-center gap-2.5 w-full lg:w-auto">
              <div className="flex items-center gap-1.5 text-xs font-black text-slate-800 whitespace-nowrap">
                <Filter className="w-4 h-4 text-emerald-600" />
                <span>نوع النشاط / القطاع:</span>
              </div>
              <select
                value={dashChannelFilter}
                onChange={(e) => setDashChannelFilter(e.target.value)}
                className="bg-slate-50 border border-slate-300 rounded-2xl px-4 py-2.5 text-xs sm:text-sm font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none w-full lg:w-72 cursor-pointer"
              >
                <option value="all">كافة الأنشطة والقطاعات الخدمية</option>
                {allChannels.map((ch) => (
                  <option key={ch.id} value={ch.id}>
                    {ch.name} ({ch.badgeTitle})
                  </option>
                ))}
              </select>
            </div>

            {/* 2. Status Filter Tabs (قيد التنفيذ والتفاوض vs المكتملة) */}
            <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 text-xs font-bold w-full lg:w-auto justify-center">
              <button
                type="button"
                onClick={() => setDashStatusFilter('all')}
                className={`px-3.5 py-2 rounded-xl cursor-pointer transition-all ${
                  dashStatusFilter === 'all'
                    ? 'bg-white text-slate-900 shadow-2xs font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                كافة الحالات
              </button>

              <button
                type="button"
                onClick={() => setDashStatusFilter('active')}
                className={`px-3.5 py-2 rounded-xl cursor-pointer transition-all flex items-center gap-1.5 ${
                  dashStatusFilter === 'active'
                    ? 'bg-amber-500 text-slate-950 shadow-2xs font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>قيد التنفيذ والتفاوض ({requests.filter((r) => r.status !== 'completed' && r.status !== 'cancelled').length})</span>
              </button>

              <button
                type="button"
                onClick={() => setDashStatusFilter('completed')}
                className={`px-3.5 py-2 rounded-xl cursor-pointer transition-all flex items-center gap-1.5 ${
                  dashStatusFilter === 'completed'
                    ? 'bg-emerald-600 text-white shadow-2xs font-black'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>الطلبات المكتملة ({requests.filter((r) => r.status === 'completed').length})</span>
              </button>
            </div>

            {/* 3. Role Filter Switcher */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500 hidden sm:inline">من منظور:</span>
              <button
                type="button"
                onClick={() => setDashRoleFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  dashRoleFilter === 'all'
                    ? 'bg-slate-900 text-white font-black'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                الجميع
              </button>
              <button
                type="button"
                onClick={() => setDashRoleFilter('customer')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  dashRoleFilter === 'customer'
                    ? 'bg-emerald-600 text-white font-black'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                طلبات العميل
              </button>
              <button
                type="button"
                onClick={() => setDashRoleFilter('provider')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  dashRoleFilter === 'provider'
                    ? 'bg-amber-500 text-slate-950 font-black'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                عروض مقدم الخدمة
              </button>
            </div>
          </div>

          {/* Orders Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredDashboardRequests.length === 0 ? (
              <div className="col-span-full py-16 bg-white rounded-3xl border border-slate-200 text-center space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-slate-100 border border-slate-200 text-slate-400 flex items-center justify-center mx-auto text-2xl">
                  📋
                </div>
                <h3 className="font-black text-sm text-slate-800">
                  لا توجد طلبات مطابقة للتصفية الحالية
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                  قم بتغيير فلتر النشاط أو الحالة لعرض باقي الطلبات، أو انتقل لغرفة التفاوض لإنشاء طلب جديد.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setDashChannelFilter('all');
                    setDashStatusFilter('all');
                    setDashRoleFilter('all');
                  }}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs px-5 py-2.5 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  إعادة تعيين الفلاتر وعرض كافة الطلبات
                </button>
              </div>
            ) : (
              filteredDashboardRequests.map((req) => {
                const ch = allChannels.find((c) => c.id === req.channelId);
                const acceptedBid = req.bids.find((b) => b.id === req.acceptedBidId || b.status === 'accepted') || req.bids[0];
                const isCompleted = req.status === 'completed';
                const isAccepted = req.status === 'accepted';

                return (
                  <div
                    key={req.id}
                    className={`bg-white rounded-3xl border shadow-xs overflow-hidden flex flex-col justify-between hover:shadow-xl transition-all ${
                      isCompleted
                        ? 'border-emerald-300 bg-emerald-50/10'
                        : isAccepted
                        ? 'border-indigo-300 bg-indigo-50/10'
                        : 'border-slate-200'
                    }`}
                  >
                    {/* Card Header */}
                    <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2">
                        <span className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center text-xs font-black shrink-0">
                          {ch ? renderChannelIcon(ch.iconName, 'w-4 h-4') : <Sparkles className="w-4 h-4" />}
                        </span>
                        <div>
                          <span className="text-[10px] font-black text-slate-500 block">
                            {req.channelName}
                          </span>
                          <h4 className="font-black text-xs text-slate-900 truncate">
                            {req.subService}
                          </h4>
                        </div>
                      </div>

                      {/* Status Badge */}
                      {isCompleted ? (
                        <span className="bg-emerald-600 text-white font-black text-[10px] px-2.5 py-1 rounded-full flex items-center gap-1 shadow-2xs">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>مكتملة بنجاح ✅</span>
                        </span>
                      ) : isAccepted ? (
                        <span className="bg-indigo-600 text-white font-black text-[10px] px-2.5 py-1 rounded-full flex items-center gap-1 shadow-2xs">
                          <Clock className="w-3 h-3" />
                          <span>جاري التنفيذ 🚀</span>
                        </span>
                      ) : (
                        <span className="bg-amber-500 text-slate-950 font-black text-[10px] px-2.5 py-1 rounded-full flex items-center gap-1 shadow-2xs">
                          <Sparkles className="w-3 h-3" />
                          <span>قيد التفاوض ⏳</span>
                        </span>
                      )}
                    </div>

                    {/* Card Body */}
                    <div className="p-4 space-y-3 flex-1 text-xs">
                      {/* Client Info & Location */}
                      <div className="space-y-1.5 bg-slate-50/80 p-3 rounded-2xl border border-slate-100">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-black text-slate-900">
                            العميل: {req.customerName}
                          </span>
                          <span className="text-[10px] text-slate-500 font-bold">
                            {req.governorate} • {req.markaz}
                          </span>
                        </div>

                        {req.pickupAddress && (
                          <div className="text-[11px] text-slate-600 flex items-start gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                            <span className="line-clamp-2">{req.pickupAddress}</span>
                          </div>
                        )}

                        {req.details && (
                          <p className="text-[11px] text-slate-500 italic line-clamp-2 pt-1 border-t border-slate-200/60">
                            "{req.details}"
                          </p>
                        )}
                      </div>

                      {/* Pricing Info */}
                      <div className="bg-slate-900 text-white p-3 rounded-2xl space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-300">سعر مقترح العميل:</span>
                          <span className="font-black text-amber-300 font-mono">
                            {req.customerProposedPriceEgp} ج.م
                          </span>
                        </div>

                        {acceptedBid && (
                          <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/10">
                            <span className="text-emerald-300 font-bold truncate max-w-[140px]">
                              مقدم الخدمة: {acceptedBid.businessName}
                            </span>
                            <span className="font-black text-emerald-400 font-mono">
                              الاتفاق: {req.acceptedFinalPriceEgp || acceptedBid.offeredPriceEgp} ج.م
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Bids Counter */}
                      <div className="flex items-center justify-between text-[11px] text-slate-500 font-bold px-1">
                        <span>العروض المتاحة: {req.bids.length} عرض موثق</span>
                        <span className="text-[10px] text-slate-400">{req.createdAt}</span>
                      </div>
                    </div>

                    {/* Card Actions Footer */}
                    <div className="p-4 pt-0 space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setActiveChannelId(req.channelId);
                            setSelectedRequestId(req.id);
                            setMantyGoViewMode('room');
                          }}
                          className="bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <ArrowLeftRight className="w-3.5 h-3.5" />
                          <span>غرفة التفاوض</span>
                        </button>

                        {!isCompleted ? (
                          <button
                            type="button"
                            onClick={() => handleMarkRequestCompleted(req.id)}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>علامة مكتمل ✅</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleOpenRatingModal(req.id)}
                            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                          >
                            <Star className="w-3.5 h-3.5" />
                            <span>تقييم الخدمة ⭐</span>
                          </button>
                        )}
                      </div>

                      {acceptedBid && (
                        <a
                          href={generateMantyGoAcceptedDealWhatsAppUrl(req, acceptedBid)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-black text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                        >
                          <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                          <span>تواصل واتساب مباشر مع الاتفاق</span>
                        </a>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Modal: Add Custom Service Activity Channel ("امكانية اضافة انشطة اخري بنفس النظام") */}
      {isAddChannelModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          dir="rtl"
          role="dialog"
          aria-modal="true"
          aria-label="إضافة نشاط أو قطاع خدمي جديد بنظام التفاوض"
        >
          <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden my-8">
            <div className="bg-gradient-to-r from-indigo-900 to-slate-900 p-5 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-500/30 border border-indigo-400/40 flex items-center justify-center">
                  <Briefcase className="w-5 h-5 text-amber-300" />
                </div>
                <div>
                  <h3 className="font-black text-base">
                    إضافة نشاط أو خدمة جديدة بنظام التفاوض الحي
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    سيتم ربط النشاط الجديد تلقائياً بالأنشطة الموثقة المشتركة في الباقات المعتمدة
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddChannelModalOpen(false)}
                className="text-slate-300 hover:text-white text-xs font-black bg-slate-800 px-3 py-1.5 rounded-xl cursor-pointer"
              >
                إغلاق
              </button>
            </div>

            <form onSubmit={handleCreateCustomChannel} className="p-5 space-y-4">
              {newChannelError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold">
                  {newChannelError}
                </div>
              )}

              <div>
                <label
                  htmlFor="custom-ch-name"
                  className="block text-xs font-black text-slate-800 mb-1"
                >
                  اسم الخدمة أو النشاط التفاوضي الجديد
                </label>
                <input
                  id="custom-ch-name"
                  type="text"
                  value={newChannelName}
                  onChange={(e) => setNewChannelName(e.target.value)}
                  placeholder="مثال: خدمات التمريض والرعاية المنزلية / نقل الأثاث..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-bold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="custom-ch-badge"
                    className="block text-xs font-black text-slate-800 mb-1"
                  >
                    الاسم المختصر للبطاقة
                  </label>
                  <input
                    id="custom-ch-badge"
                    type="text"
                    value={newChannelBadge}
                    onChange={(e) => setNewChannelBadge(e.target.value)}
                    placeholder="مثال: تمريض منزلي"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label
                    htmlFor="custom-ch-sector"
                    className="block text-xs font-black text-slate-800 mb-1"
                  >
                    القطاع الاقتصادي المرتبط بالباقات الموثقة
                  </label>
                  <select
                    id="custom-ch-sector"
                    value={newChannelGroup}
                    onChange={(e) => setNewChannelGroup(e.target.value as FunctionalGroupId)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900"
                  >
                    {functionalGroups.map((fg) => (
                      <option key={fg.id} value={fg.id}>
                        {fg.name} ({fg.shortName})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="custom-ch-subs"
                  className="block text-xs font-black text-slate-800 mb-1"
                >
                  التخصصات أو الخدمات الفرعية داخل هذا النشاط (افصل بينها بفاصلة)
                </label>
                <textarea
                  id="custom-ch-subs"
                  rows={2}
                  value={newChannelSubServices}
                  onChange={(e) => setNewChannelSubServices(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="custom-ch-min"
                    className="block text-xs font-black text-slate-800 mb-1"
                  >
                    الحد الأدنى الاسترشادي للسعر (ج.م)
                  </label>
                  <input
                    id="custom-ch-min"
                    type="number"
                    value={newChannelMinPrice}
                    onChange={(e) => setNewChannelMinPrice(Number(e.target.value) || 50)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-900"
                  />
                </div>
                <div>
                  <label
                    htmlFor="custom-ch-max"
                    className="block text-xs font-black text-slate-800 mb-1"
                  >
                    الحد الأقصى الاسترشادي للسعر (ج.م)
                  </label>
                  <input
                    id="custom-ch-max"
                    type="number"
                    value={newChannelMaxPrice}
                    onChange={(e) => setNewChannelMaxPrice(Number(e.target.value) || 1000)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-slate-900"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  id="custom-ch-route"
                  type="checkbox"
                  checked={newChannelRequiresRoute}
                  onChange={(e) => setNewChannelRequiresRoute(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600"
                />
                <label htmlFor="custom-ch-route" className="text-xs font-bold text-slate-700">
                  يتطلب تحديد نقطة انطلاق ووجهة وصول (مثل خدمات المشاوير والنقل والتوصيل)
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddChannelModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs px-5 py-2.5 rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>تفعيل النشاط بنظام التفاوض الآن</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Customer Rating & Review Submission ("تقييم ومراجعة جودة الأداء بعد اكتمال الخدمة") */}
      {isRatingModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          dir="rtl"
          role="dialog"
          aria-modal="true"
          aria-label="تقييم الخدمة المكتملة"
        >
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden my-8">
            <div className="bg-gradient-to-r from-emerald-900 to-slate-900 p-5 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/30 border border-emerald-400/40 flex items-center justify-center">
                  <Star className="w-5 h-5 fill-amber-300 text-amber-300" />
                </div>
                <div>
                  <h3 className="font-black text-base">تقييم الخدمة المكتملة وجودة الأداء</h3>
                  <p className="text-[11px] text-emerald-200">النتائج والمراجعات تظهر للإدارة فقط لضمان جودة الأنشطة</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsRatingModalOpen(false)}
                className="text-slate-300 hover:text-white text-xs font-black bg-slate-800 px-3 py-1.5 rounded-xl cursor-pointer"
              >
                إغلاق
              </button>
            </div>

            <form onSubmit={handleConfirmRatingAndReview} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-black text-slate-800 mb-2">
                  اختر تقييم النجوم (من 1 إلى 5 نجوم)
                </label>
                <div className="flex items-center justify-center gap-3 py-2 bg-slate-50 rounded-2xl border">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRatingScore(star)}
                      className="p-1 cursor-pointer transition-transform hover:scale-125"
                    >
                      <Star
                        className={`w-8 h-8 ${
                          star <= ratingScore
                            ? 'fill-amber-400 text-amber-500'
                            : 'text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <div className="text-center mt-1 text-xs font-black text-amber-600">
                  {ratingScore === 5 ? '⭐ ممتاز للغاية (5/5)' : ratingScore === 4 ? '⭐ جيد جداً (4/5)' : ratingScore === 3 ? '⭐ مقبول (3/5)' : '⭐ يحتاج تحسين'}
                </div>
              </div>

              <div>
                <label htmlFor="review-comment" className="block text-xs font-black text-slate-800 mb-1">
                  ملاحظات ومراجعة جودة الأداء (خاص للإدارة)
                </label>
                <textarea
                  id="review-comment"
                  rows={3}
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  placeholder="اكتب انطباعك حول سرعة الاستجابة، جودة التنفيذ، والتزام مقدم الخدمة الموثق..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900"
                />
              </div>

              <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl text-[11px] text-amber-900 leading-relaxed font-bold">
                🔒 ملاحظة سرية: تقييمك هذا ومراجعتك يتم حفظهما في سجلات النظام لتظهر حصرياً في لوحة الإدارة لمراقبة جودة الأنشطة الموثقة.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsRatingModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs px-6 py-2.5 rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>تأكيد الاعتماد والتقييم</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Management Dashboard Rating Inspection ("يظهر النتيجة للادارة فقط") */}
      {isManagementDashboardOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          dir="rtl"
          role="dialog"
          aria-modal="true"
          aria-label="لوحة إدارة التقييمات والمراجعات"
        >
          <div className="bg-white rounded-3xl max-w-3xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8">
            <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-amber-950 p-5 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center">
                  <Crown className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase bg-amber-400 text-slate-950 px-2 py-0.5 rounded">
                    إدارة المنصة • صلاحيات الإدارة حصرياً
                  </span>
                  <h3 className="font-black text-base mt-0.5">لوحة تقييمات ومراجعات الأنشطة الموثقة</h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsManagementDashboardOpen(false)}
                className="text-slate-300 hover:text-white text-xs font-black bg-slate-800 px-3.5 py-1.5 rounded-xl cursor-pointer"
              >
                إغلاق اللوحة
              </button>
            </div>

            <div className="p-6 space-y-5">
              <div className="bg-amber-50 border border-amber-300 p-4 rounded-2xl flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
                <div className="text-xs text-amber-900 leading-relaxed">
                  <strong className="block font-black mb-0.5">تقرير جودة الأداء والتقييمات (يظهر للادارة فقط):</strong>
                  هذه اللوحة تتيح لإدارة المنصة رصد تقييمات العملاء ومراجعاتهم بعد اكتمال تنفيذ الخدمات عبر نظام التفاوض المباشر، لتقييم كفاءة مقدمي الخدمة الموثقين وضمان أعلى معايير الجودة والالتزام.
                </div>
              </div>

              {/* Summary Metrics */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-slate-900 text-white p-4 rounded-2xl text-center">
                  <span className="text-[10px] text-slate-400 block font-bold">إجمالي الطلبات المكتملة والمقيمة</span>
                  <span className="text-2xl font-black text-emerald-400 mt-1 block">
                    {requests.filter((r) => r.status === 'completed' || r.rating).length}
                  </span>
                </div>
                <div className="bg-slate-900 text-white p-4 rounded-2xl text-center">
                  <span className="text-[10px] text-slate-400 block font-bold">متوسط تقييم المنصة العام</span>
                  <div className="flex items-center justify-center gap-1 mt-1">
                    <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                    <span className="text-2xl font-black text-amber-300">4.9 / 5</span>
                  </div>
                </div>
                <div className="bg-slate-900 text-white p-4 rounded-2xl text-center">
                  <span className="text-[10px] text-slate-400 block font-bold">نسبة رضا العملاء الموثقة</span>
                  <span className="text-2xl font-black text-teal-400 mt-1 block">99.4%</span>
                </div>
              </div>

              {/* List of Rated / Completed Requests */}
              <div className="space-y-3">
                <h4 className="font-black text-sm text-slate-900">سجل التقييمات والمراجعات التفصيلية (خاص بالإدارة):</h4>
                <div className="space-y-3 max-h-[380px] overflow-y-auto pl-1">
                  {requests.filter((r) => r.status === 'completed' || r.rating).length === 0 ? (
                    <div className="text-center py-8 bg-slate-50 rounded-2xl border border-slate-200 text-slate-500 text-xs">
                      لم يتم تسجيل أي تقييمات بعد. يمكنك تجربة قبول طلب وإنهائه وتقييمه من وضع العميل لتظهر هنا في لوحة الإدارة.
                    </div>
                  ) : (
                    requests
                      .filter((r) => r.status === 'completed' || r.rating)
                      .map((req) => {
                        const acceptedBid = req.bids.find((b) => b.id === req.acceptedBidId || b.status === 'accepted') || req.bids[0];
                        return (
                          <div key={req.id} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                            <div className="flex items-center justify-between gap-2 flex-wrap">
                              <span className="bg-indigo-100 text-indigo-900 font-black text-[11px] px-2.5 py-0.5 rounded-full">
                                {req.channelName}
                              </span>
                              <span className="text-[11px] font-bold text-slate-500">
                                تاريخ التقييم: {req.reviewedAt || 'الآن'}
                              </span>
                            </div>

                            <div className="flex items-start justify-between gap-4 flex-wrap">
                              <div>
                                <h5 className="font-black text-xs text-slate-900">الخدمة: {req.subService}</h5>
                                <p className="text-[11px] text-slate-600 mt-0.5">
                                  العميل: <strong className="text-slate-900">{req.customerName}</strong> ({req.governorate} - {req.markaz})
                                </p>
                                {acceptedBid && (
                                  <p className="text-[11px] text-emerald-800 font-bold mt-0.5">
                                    مقدم الخدمة الموثق: {acceptedBid.businessName} (السعر النهائي: {req.acceptedFinalPriceEgp || acceptedBid.offeredPriceEgp} ج.م)
                                  </p>
                                )}
                              </div>

                              <div className="bg-amber-50 border border-amber-300 px-3 py-2 rounded-xl text-center">
                                <div className="flex items-center gap-1 text-amber-600 font-black text-sm justify-center">
                                  <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                                  <span>{req.rating || 5} / 5</span>
                                </div>
                                <span className="text-[9px] text-slate-500 block">تقييم النجوم</span>
                              </div>
                            </div>

                            {req.reviewText && (
                              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 font-medium italic">
                                "{req.reviewText}"
                              </div>
                            )}
                          </div>
                        );
                      })
                  )}
                </div>
              </div>

              <div className="flex items-center justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setIsManagementDashboardOpen(false)}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-black text-xs px-6 py-2.5 rounded-xl cursor-pointer"
                >
                  إغلاق اللوحة
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

