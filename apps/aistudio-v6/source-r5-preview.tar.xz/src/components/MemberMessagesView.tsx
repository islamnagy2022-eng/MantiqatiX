import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { MessagingPrivacyConfig, MessagingPrivacyMode } from '../types';
import {
  DEFAULT_BUSINESS_LOGO_URL,
  evaluateMessagingPrivacyAndLocation,
  generateMemberDirectMessageWhatsAppUrl,
  getDefaultMessagingPrivacyConfig,
  getMessagingPrivacyModeLabel,
} from '../utils/rules';
import { NonCompetingSponsoredAdsStrip } from './common/NonCompetingSponsoredAdsStrip';
import {
  Mail,
  ShieldCheck,
  MapPin,
  Lock,
  Unlock,
  Send,
  User,
  Store,
  CheckCircle2,
  AlertCircle,
  MessageCircle,
  Trash2,
  Reply,
  ArrowRight,
  Sparkles,
  Globe,
  EyeOff,
  Filter,
} from 'lucide-react';

const EGYPT_GOVERNORATES = [
  'الدقهلية',
  'القاهرة',
  'الجيزة',
  'الإسكندرية',
  'الغربية',
  'الشرقية',
  'المنوفية',
  'دمياط',
  'كفر الشيخ',
  'بورسعيد',
  'الإسماعيلية',
  'السويس',
  'القليوبية',
  'البحيرة',
  'الفيوم',
  'بني سويف',
  'المنيا',
  'أسيوط',
  'سوهاج',
  'قنا',
  'الأقصر',
  'أسوان',
];

export const MemberMessagesView: React.FC = () => {
  const {
    businesses,
    subscribers,
    authSession,
    messagingTargetType,
    messagingTargetId,
    openMemberMessagingForTarget,
    updateRecipientMessagingPrivacy,
    memberDirectMessages,
    sendMemberDirectMessage,
    replyToMemberDirectMessage,
    markMemberDirectMessageRead,
    deleteMemberDirectMessage,
    setCurrentView,
    setSelectedBusinessId,
  } = useApp();

  const [targetType, setTargetType] = useState<'business' | 'subscriber'>(messagingTargetType);
  const [selectedId, setSelectedId] = useState<string>(
    messagingTargetId || businesses[0]?.id || ''
  );

  useEffect(() => {
    setTargetType(messagingTargetType);
    if (messagingTargetId) {
      setSelectedId(messagingTargetId);
    }
  }, [messagingTargetType, messagingTargetId]);

  const isPlatformAdmin = authSession.role === 'admin' || authSession.role === 'super_admin';
  const activeBusiness = useMemo(
    () => (targetType === 'business'
      ? businesses.find((b) => b.id === selectedId && (isPlatformAdmin || b.id === authSession.businessId))
      : undefined),
    [targetType, selectedId, businesses, isPlatformAdmin, authSession.businessId]
  );

  const activeSubscriber = useMemo(
    () => (targetType === 'subscriber'
      ? subscribers.find((s) => s.id === selectedId && (isPlatformAdmin || s.id === authSession.subscriberId))
      : undefined),
    [targetType, selectedId, subscribers, isPlatformAdmin, authSession.subscriberId]
  );

  const recipientName = activeBusiness
    ? activeBusiness.name
    : activeSubscriber?.fullName || 'المستلم المعتمد';
  const recipientGov = activeBusiness
    ? activeBusiness.governorate
    : activeSubscriber?.governorate || ''; 
  const recipientMarkaz = activeBusiness
    ? activeBusiness.markaz
    : activeSubscriber?.markaz || ''; 
  const recipientPhone = activeBusiness
    ? activeBusiness.ownerWhatsApp || activeBusiness.phone || ''
    : activeSubscriber?.phone || '';

  const currentPrivacyConfig: MessagingPrivacyConfig = useMemo(() => {
    if (activeBusiness) {
      return (
        activeBusiness.messagingPrivacy ||
        getDefaultMessagingPrivacyConfig(activeBusiness.governorate, activeBusiness.markaz)
      );
    }
    if (activeSubscriber) {
      return (
        activeSubscriber.messagingPrivacy ||
        getDefaultMessagingPrivacyConfig(
          activeSubscriber.governorate || 'الدقهلية',
          activeSubscriber.markaz || 'المنصورة'
        )
      );
    }
    return getDefaultMessagingPrivacyConfig('الدقهلية', 'المنصورة');
  }, [activeBusiness, activeSubscriber]);

  // Sender form state
  const [senderName, setSenderName] = useState(authSession.subscriberName || '');
  const [senderPhone, setSenderPhone] = useState(authSession.userPhone || '');
  const [senderRoleChoice, setSenderRoleChoice] = useState<'subscriber' | 'visitor'>(
    authSession.role === 'guest' ? 'subscriber' : 'subscriber'
  );
  const [senderGovernorate, setSenderGovernorate] = useState(recipientGov || 'الدقهلية');
  const [senderMarkaz, setSenderMarkaz] = useState(recipientMarkaz || 'المنصورة');
  const [category, setCategory] = useState<
    'order_inquiry' | 'partnership' | 'member_message' | 'consultation' | 'support'
  >('member_message');
  const [subject, setSubject] = useState('');
  const [content, setContent] = useState('');
  const [formNotice, setFormNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );
  const [lastSentWhatsAppUrl, setLastSentWhatsAppUrl] = useState<string | null>(null);

  // Inbox filter & reply state
  const [inboxFilter, setInboxFilter] = useState<'all' | 'unread'>('all');
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [privacySavedNotice, setPrivacySavedNotice] = useState<string | null>(null);

  // Sync default sender location when recipient changes so the user can test both matching & non-matching easily
  useEffect(() => {
    setSenderGovernorate(recipientGov || 'الدقهلية');
    setSenderMarkaz(recipientMarkaz || 'المنصورة');
    setFormNotice(null);
    setLastSentWhatsAppUrl(null);
  }, [selectedId, targetType, recipientGov, recipientMarkaz]);

  const liveEligibility = useMemo(
    () =>
      evaluateMessagingPrivacyAndLocation({
        config: currentPrivacyConfig,
        recipientName,
        recipientGovernorate: recipientGov,
        recipientMarkaz,
        senderRole: senderRoleChoice,
        senderGovernorate,
        senderMarkaz,
      }),
    [
      currentPrivacyConfig,
      recipientName,
      recipientGov,
      recipientMarkaz,
      senderRoleChoice,
      senderGovernorate,
      senderMarkaz,
    ]
  );

  const recipientMessages = useMemo(() => {
    const actualId = activeBusiness ? activeBusiness.id : activeSubscriber?.id || '';
    const list = memberDirectMessages.filter(
      (m) => m.recipientType === targetType && m.recipientId === actualId
    );
    if (inboxFilter === 'unread') {
      return list.filter((m) => !m.isRead);
    }
    return list;
  }, [memberDirectMessages, targetType, activeBusiness, activeSubscriber, inboxFilter]);

  const unreadRecipientCount = useMemo(() => {
    const actualId = activeBusiness ? activeBusiness.id : activeSubscriber?.id || '';
    return memberDirectMessages.filter(
      (m) => m.recipientType === targetType && m.recipientId === actualId && !m.isRead
    ).length;
  }, [memberDirectMessages, targetType, activeBusiness, activeSubscriber]);

  const canAccessMessages = ['subscriber', 'admin', 'super_admin'].includes(authSession.role);
  if (!canAccessMessages) {
    return (
      <section className="max-w-xl mx-auto my-12 p-6 rounded-2xl border border-amber-200 bg-amber-50 text-right" dir="rtl" role="alert">
        <h1 className="font-black text-slate-900">صفحة رسائل الأعضاء غير متاحة لهذا الدور</h1>
        <p className="mt-2 text-sm leading-6 text-slate-700">يلزم حساب صاحب نشاط بعضوية فعالة أو صلاحية إدارة منصة معتمدة. لا يكفي تسجيل الدخول وحده لعرض صناديق الرسائل.</p>
      </section>
    );
  }

  const handleUpdatePrivacy = (patch: Partial<MessagingPrivacyConfig>) => {
    const actualId = activeBusiness ? activeBusiness.id : activeSubscriber?.id || '';
    if (!actualId) return;
    const nextConfig: MessagingPrivacyConfig = {
      ...currentPrivacyConfig,
      ...patch,
    };
    updateRecipientMessagingPrivacy(targetType, actualId, nextConfig);
    setPrivacySavedNotice('تم تحديث إعدادات الخصوصية والموقع لاستقبال الرسائل بنجاح!');
    setTimeout(() => setPrivacySavedNotice(null), 3000);
  };

  const handleToggleAllowedGov = (gov: string) => {
    const currentList = currentPrivacyConfig.allowedGovernorates || [recipientGov];
    const exists = currentList.includes(gov);
    const nextList = exists
      ? currentList.filter((g) => g !== gov)
      : [...currentList, gov];
    handleUpdatePrivacy({
      allowedGovernorates: nextList.length > 0 ? nextList : [recipientGov],
    });
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    setFormNotice(null);
    setLastSentWhatsAppUrl(null);

    if (!senderName.trim() || !subject.trim() || !content.trim()) {
      setFormNotice({
        type: 'error',
        text: 'يرجى إدخال اسم المرسل، عنوان الرسالة، ونص الرسالة.',
      });
      return;
    }

    const actualId = activeBusiness ? activeBusiness.id : activeSubscriber?.id || '';
    const res = sendMemberDirectMessage({
      recipientType: targetType,
      recipientId: actualId,
      senderName: senderName.trim(),
      senderPhone: senderPhone.trim() || '01000000000',
      senderGovernorate,
      senderMarkaz,
      senderRole: senderRoleChoice,
      subject: subject.trim(),
      content: content.trim(),
      category,
    });

    if (!res.success || !res.message) {
      setFormNotice({
        type: 'error',
        text: res.error || 'تعذر إرسال الرسالة بسبب إعدادات الخصوصية أو الموقع.',
      });
      return;
    }

    setFormNotice({
      type: 'success',
      text: 'لم يتم إرسال الرسالة. ربط صندوق الرسائل الخادمي غير مكتمل، ولن نحفظ الرسالة محلياً على هذا الجهاز.',
    });
    if (recipientPhone && currentPrivacyConfig.allowWhatsAppForward) {
      const waUrl = generateMemberDirectMessageWhatsAppUrl(
        recipientPhone,
        res.message,
        currentPrivacyConfig.hidePhoneNumberInMessages
      );
      setLastSentWhatsAppUrl(waUrl);
    }
    setSubject('');
    setContent('');
  };

  return (
    <div className="pb-16" dir="rtl">
      {/* 1. FULL-WIDTH TOP COVER AREA (مساحة الـ Cover أعلى الصفحة) */}
      <div className="w-full bg-gradient-to-r from-slate-900 via-indigo-950 to-emerald-950 text-white py-8 px-4 sm:px-8 shadow-xl border-b border-emerald-500/30 relative overflow-hidden">
        <div className="max-w-[1720px] mx-auto flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2.5 max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-black px-3.5 py-1 rounded-full">
              <Mail className="w-4 h-4 text-emerald-400" />
              <span>صفحة استقبال رسائل الأعضاء للمشتركين والأنشطة • تحكم كامل بالخصوصية والموقع</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight leading-snug">
              بوابة رسائل الأعضاء وصندوق الاستقبال لـ ({recipientName})
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              لكل شخص مشترك أو نشاط تجاري صفحة خاصة لاستقبال رسائل الأعضاء، مع إمكانية تفعيل أو إيقاف استقبال الرسائل في أي وقت حسب الخصوصية (للأعضاء فقط / عام / إخفاء الرقم) أو حسب الموقع الجغرافي (نفس المحافظة أو المركز).
            </p>
          </div>

          {/* Clean Organized Header Buttons (Strictly Button Name Only) */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {isPlatformAdmin && <button
              type="button"
              onClick={() => openMemberMessagingForTarget('business', activeBusiness?.id || businesses[0]?.id)}
              className={`px-4 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer ${
                targetType === 'business'
                  ? 'bg-emerald-500 text-slate-950 shadow-lg'
                  : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
              }`}
            >
              <Store className="w-4 h-4" />
              <span>رسائل الأنشطة</span>
            </button>}

            {isPlatformAdmin && <button
              type="button"
              onClick={() => openMemberMessagingForTarget('subscriber', activeSubscriber?.id || subscribers[0]?.id)}
              className={`px-4 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer ${
                targetType === 'subscriber'
                  ? 'bg-amber-400 text-slate-950 shadow-lg'
                  : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
              }`}
            >
              <User className="w-4 h-4" />
              <span>رسائل المشتركين</span>
            </button>}

            <button
              type="button"
              onClick={() => setCurrentView('directory')}
              className="bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-xs px-4 py-2.5 rounded-2xl flex items-center gap-2 cursor-pointer"
            >
              <ArrowRight className="w-4 h-4" />
              <span>الرئيسية</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. BELOW COVER AREA: Main Content on Right + Full-Height Sponsored Ads Column on Left (بالشمال من تحت مساحة الـ Cover) */}
      <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 pt-8">
        <div className="flex flex-col lg:flex-row gap-6 items-stretch">
          {/* RIGHT SIDE: Main Member & Business Messaging Workspace */}
          <div className="flex-1 min-w-0 space-y-6">
            {(activeBusiness || activeSubscriber) ? (
              <>
            {/* Target Switcher Bar (Select Any Business or Any Subscriber) */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                <div className="flex items-center gap-3">
                  {activeBusiness ? (
                    <img
                      src={activeBusiness.logoUrl || DEFAULT_BUSINESS_LOGO_URL}
                      alt={activeBusiness.name}
                      className="w-14 h-14 rounded-2xl object-cover border border-slate-200 bg-slate-100 shrink-0"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-emerald-600 text-white font-black text-xl flex items-center justify-center shrink-0 shadow-md">
                      {recipientName.charAt(0)}
                    </div>
                  )}
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="bg-indigo-50 text-indigo-800 border border-indigo-200 text-[11px] font-black px-2.5 py-0.5 rounded-full">
                        {targetType === 'business' ? 'صفحة رسائل نشاط تجاري' : 'صفحة رسائل شخص مشترك'}
                      </span>
                      <span
                        className={`text-[11px] font-black px-2.5 py-0.5 rounded-full flex items-center gap-1 ${
                          currentPrivacyConfig.enabled && currentPrivacyConfig.privacyMode !== 'disabled'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {currentPrivacyConfig.enabled && currentPrivacyConfig.privacyMode !== 'disabled' ? (
                          <>
                            <Unlock className="w-3 h-3" />
                            <span>استقبال الرسائل مفعّل</span>
                          </>
                        ) : (
                          <>
                            <Lock className="w-3 h-3" />
                            <span>استقبال الرسائل متوقف</span>
                          </>
                        )}
                      </span>
                    </div>
                    <h2 className="font-black text-lg text-slate-900 mt-1">{recipientName}</h2>
                    <p className="text-xs font-bold text-slate-500 flex items-center gap-1.5 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                      <span>
                        النطاق الجغرافي: محافظة {recipientGov} • مركز {recipientMarkaz}
                      </span>
                    </p>
                  </div>
                </div>

                {/* Selector to switch between Businesses or Subscribers */}
                {isPlatformAdmin && <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  {targetType === 'business' ? (
                    <select
                      aria-label="اختر النشاط لعرض صفحة رسائله"
                      value={activeBusiness?.id || ''}
                      onChange={(e) => setSelectedId(e.target.value)}
                      className="bg-slate-50 border border-slate-200 rounded-2xl px-3.5 py-2.5 text-xs font-black text-slate-900 cursor-pointer"
                    >
                      {businesses.map((b) => (
                        <option key={b.id} value={b.id}>
                          نشاط: {b.name} ({b.governorate})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <select
                      aria-label="اختر المشترك لعرض صفحة رسائله"
                      value={activeSubscriber?.id || ''}
                      onChange={(e) => setSelectedId(e.target.value)}
                      className="bg-slate-50 border border-slate-200 rounded-2xl px-3.5 py-2.5 text-xs font-black text-slate-900 cursor-pointer"
                    >
                      {subscribers.map((s) => (
                        <option key={s.id} value={s.id}>
                          مشترك: {s.fullName} ({s.governorate || 'الدقهلية'})
                        </option>
                      ))}
                    </select>
                  )}

                  {activeBusiness && (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedBusinessId(activeBusiness.id);
                        setCurrentView('public_storefront');
                      }}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-4 py-2.5 rounded-2xl cursor-pointer whitespace-nowrap"
                    >
                      صفحة النشاط
                    </button>
                  )}
                </div>}
              </div>

              {/* PRIVACY & LOCATION MESSAGING CONTROL PANEL */}
              <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-emerald-400" />
                      <h3 className="font-black text-sm sm:text-base">
                        إعدادات تفعيل أو إيقاف استقبال الرسائل (حسب الخصوصية أو الموقع)
                      </h3>
                    </div>
                    <p className="text-xs text-slate-300">
                      تحكم فوري لصاحب الحساب أو النشاط في من يمكنه مراسلته حسب درجة الخصوصية أو المحافظة والمركز
                    </p>
                  </div>

                  {/* Master Enable / Disable Button */}
                  <button
                    type="button"
                    onClick={() =>
                      handleUpdatePrivacy({
                        enabled: !currentPrivacyConfig.enabled,
                        privacyMode:
                          !currentPrivacyConfig.enabled && currentPrivacyConfig.privacyMode === 'disabled'
                            ? 'public_all'
                            : currentPrivacyConfig.privacyMode,
                      })
                    }
                    className={`px-4 py-2.5 rounded-xl font-black text-xs flex items-center gap-2 cursor-pointer transition-all shrink-0 shadow-md ${
                      currentPrivacyConfig.enabled && currentPrivacyConfig.privacyMode !== 'disabled'
                        ? 'bg-rose-600 hover:bg-rose-500 text-white'
                        : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                    }`}
                  >
                    {currentPrivacyConfig.enabled && currentPrivacyConfig.privacyMode !== 'disabled' ? (
                      <>
                        <Lock className="w-4 h-4" />
                        <span>إيقاف استقبال الرسائل</span>
                      </>
                    ) : (
                      <>
                        <Unlock className="w-4 h-4" />
                        <span>تفعيل استقبال الرسائل</span>
                      </>
                    )}
                  </button>
                </div>

                {privacySavedNotice && (
                  <div className="bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{privacySavedNotice}</span>
                  </div>
                )}

                {/* 5 Privacy & Location Modes */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
                  {(
                    [
                      {
                        mode: 'public_all',
                        title: 'تفعيل للجميع (عام)',
                        desc: 'كافة الأعضاء والزوار بكل المحافظات',
                        icon: <Globe className="w-4 h-4 text-emerald-400" />,
                      },
                      {
                        mode: 'members_only',
                        title: 'للأعضاء المشتركين فقط',
                        desc: 'حماية الخصوصية ومنع غير المسجلين',
                        icon: <ShieldCheck className="w-4 h-4 text-amber-400" />,
                      },
                      {
                        mode: 'same_governorate_only',
                        title: 'حسب المحافظة (الموقع)',
                        desc: `أعضاء محافظة (${recipientGov}) فقط`,
                        icon: <MapPin className="w-4 h-4 text-cyan-400" />,
                      },
                      {
                        mode: 'same_markaz_only',
                        title: 'حسب المركز فقط',
                        desc: `أعضاء مركز (${recipientMarkaz}) فقط`,
                        icon: <Filter className="w-4 h-4 text-purple-400" />,
                      },
                      {
                        mode: 'disabled',
                        title: 'إيقاف الرسائل نهائياً',
                        desc: 'إغلاق صندوق الرسائل للخصوصية',
                        icon: <Lock className="w-4 h-4 text-rose-400" />,
                      },
                    ] as {
                      mode: MessagingPrivacyMode;
                      title: string;
                      desc: string;
                      icon: React.ReactNode;
                    }[]
                  ).map((item) => {
                    const isActive =
                      currentPrivacyConfig.privacyMode === item.mode &&
                      (item.mode === 'disabled' ? true : currentPrivacyConfig.enabled);
                    return (
                      <button
                        key={item.mode}
                        type="button"
                        onClick={() =>
                          handleUpdatePrivacy({
                            enabled: item.mode !== 'disabled',
                            privacyMode: item.mode,
                            allowedGovernorates:
                              currentPrivacyConfig.allowedGovernorates?.length > 0
                                ? currentPrivacyConfig.allowedGovernorates
                                : [recipientGov],
                          })
                        }
                        className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                          isActive
                            ? 'bg-emerald-600/30 border-emerald-400 text-white shadow-md'
                            : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          {item.icon}
                          {isActive && (
                            <span className="text-[10px] font-black bg-emerald-400 text-slate-950 px-2 py-0.5 rounded-full">
                              نشط ✓
                            </span>
                          )}
                        </div>
                        <div>
                          <div className="font-black text-xs">{item.title}</div>
                          <div className="text-[10px] text-slate-400 mt-0.5 leading-snug">
                            {item.desc}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Location Governorate Multi-Selector when 'same_governorate_only' is active */}
                {currentPrivacyConfig.enabled &&
                  currentPrivacyConfig.privacyMode === 'same_governorate_only' && (
                    <div className="bg-white/5 border border-white/15 rounded-2xl p-3.5 space-y-2.5">
                      <div className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                        <MapPin className="w-4 h-4" />
                        <span>تحديد المحافظات المسموح لها بمراسلة هذا الحساب/النشاط:</span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {EGYPT_GOVERNORATES.slice(0, 10).map((gov) => {
                          const isAllowed = (
                            currentPrivacyConfig.allowedGovernorates || [recipientGov]
                          ).includes(gov);
                          return (
                            <button
                              key={gov}
                              type="button"
                              onClick={() => handleToggleAllowedGov(gov)}
                              className={`px-3 py-1 rounded-xl text-[11px] font-black cursor-pointer transition-all ${
                                isAllowed
                                  ? 'bg-amber-400 text-slate-950 shadow-xs'
                                  : 'bg-white/10 text-slate-300 hover:bg-white/20'
                              }`}
                            >
                              {gov} {isAllowed ? '✓' : '+'}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                {/* Phone Privacy Toggle */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/10 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-200">
                    <input
                      type="checkbox"
                      checked={currentPrivacyConfig.hidePhoneNumberInMessages}
                      onChange={(e) =>
                        handleUpdatePrivacy({ hidePhoneNumberInMessages: e.target.checked })
                      }
                      className="rounded text-emerald-500 focus:ring-0"
                    />
                    <EyeOff className="w-4 h-4 text-amber-400" />
                    <span>إخفاء رقم الهاتف الشخصي والاكتفاء بصندوق الرسائل الداخلي للخصوصية</span>
                  </label>

                  <span className="text-[11px] font-black text-emerald-300">
                    الوضع الحالي: {getMessagingPrivacyModeLabel(currentPrivacyConfig.privacyMode)}
                  </span>
                </div>
              </div>
            </div>

            {/* SEND MESSAGE FORM + LIVE PRIVACY/LOCATION SHIELD CHECK */}
            <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <h3 className="font-black text-base sm:text-lg text-slate-900 flex items-center gap-2">
                    <Send className="w-5 h-5 text-emerald-600" />
                    <span>إرسال رسالة عضو إلى ({recipientName})</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    يتم فحص صلاحية الإرسال تلقائياً بناءً على إعدادات الخصوصية والموقع الجغرافي للمستلم
                  </p>
                </div>

                {/* Live Status Pill */}
                <span
                  className={`text-xs font-black px-3.5 py-1.5 rounded-full flex items-center gap-1.5 ${
                    liveEligibility.allowed
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-100 text-rose-800 border border-rose-200'
                  }`}
                >
                  {liveEligibility.allowed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Lock className="w-4 h-4 text-rose-600" />
                  )}
                  <span>{liveEligibility.statusBadge}</span>
                </span>
              </div>

              {/* Live Privacy / Location Explanation Banner */}
              <div
                className={`p-4 rounded-2xl border text-xs font-bold flex items-start gap-2.5 ${
                  liveEligibility.allowed
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                    : 'bg-rose-50 border-rose-200 text-rose-900'
                }`}
              >
                {liveEligibility.allowed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                )}
                <div className="space-y-1">
                  <div>{liveEligibility.reasonAr}</div>
                  {!liveEligibility.allowed && (
                    <div className="text-[11px] text-rose-700">
                      يمكنك تعديل موقع المرسل بالأسفل أو تغيير وضع الخصوصية بالأعلى لتفعيل استقبال الرسائل.
                    </div>
                  )}
                </div>
              </div>

              {formNotice && (
                <div
                  className={`p-4 rounded-2xl border text-xs font-black flex items-center justify-between gap-3 ${
                    formNotice.type === 'success'
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                      : 'bg-rose-50 border-rose-300 text-rose-900'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {formNotice.type === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    )}
                    <span>{formNotice.text}</span>
                  </div>

                  {lastSentWhatsAppUrl && (
                    <a
                      href={lastSentWhatsAppUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black px-3.5 py-2 rounded-xl flex items-center gap-1.5 shrink-0"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>إرسال نسخة واتساب</span>
                    </a>
                  )}
                </div>
              )}

              <form onSubmit={handleSendMessage} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">
                      اسم العضو المرسل *
                    </label>
                    <input
                      type="text"
                      value={senderName}
                      onChange={(e) => setSenderName(e.target.value)}
                      placeholder="مثال: م. خالد عبد العزيز"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">
                      صفة المرسل (الخصوصية)
                    </label>
                    <select
                      value={senderRoleChoice}
                      onChange={(e) =>
                        setSenderRoleChoice(e.target.value as 'subscriber' | 'visitor')
                      }
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 cursor-pointer"
                    >
                      <option value="subscriber">عضو مشترك مسجل بالمنصة</option>
                      <option value="visitor">زائر غير مشترك</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">
                      محافظة المرسل (الموقع) *
                    </label>
                    <select
                      value={senderGovernorate}
                      onChange={(e) => setSenderGovernorate(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 cursor-pointer"
                    >
                      {EGYPT_GOVERNORATES.map((gov) => (
                        <option key={gov} value={gov}>
                          محافظة {gov}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">
                      مركز / مدينة المرسل
                    </label>
                    <input
                      type="text"
                      value={senderMarkaz}
                      onChange={(e) => setSenderMarkaz(e.target.value)}
                      placeholder="مثال: المنصورة"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">
                      رقم التواصل (اختياري مع الخصوصية)
                    </label>
                    <input
                      type="text"
                      dir="ltr"
                      value={senderPhone}
                      onChange={(e) => setSenderPhone(e.target.value)}
                      placeholder="01012345678"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">
                      تصنيف الرسالة
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900 cursor-pointer"
                    >
                      <option value="member_message">رسالة مباشرة من عضو</option>
                      <option value="order_inquiry">استفسار عن منتج أو خدمة</option>
                      <option value="partnership">طلب شراكة أو تعامل تجاري</option>
                      <option value="consultation">طلب استشارة أو حجز</option>
                      <option value="support">ملاحظة أو دعم فني</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">
                      عنوان الرسالة *
                    </label>
                    <input
                      type="text"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="مثال: استفسار عن عروض الأعضاء"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">
                    نص الرسالة *
                  </label>
                  <textarea
                    rows={3}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="اكتب رسالتك هنا ليتم تسليمها فوراً في صندوق رسائل النشاط أو المشترك..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs font-bold text-slate-900"
                  />
                </div>

                <div className="flex items-center justify-end">
                  <button
                    type="submit"
                    disabled={!liveEligibility.allowed}
                    className={`px-6 py-3 rounded-2xl font-black text-xs flex items-center gap-2 transition-all shadow-md ${
                      liveEligibility.allowed
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer'
                        : 'bg-slate-200 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    <Send className="w-4 h-4" />
                    <span>إرسال الرسالة</span>
                  </button>
                </div>
              </form>
            </div>

            {/* RECEIVED MEMBER MESSAGES INBOX FOR THIS RECIPIENT */}
            <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-black">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-black text-base sm:text-lg text-slate-900">
                        صندوق رسائل الأعضاء الواردة لـ ({recipientName})
                      </h3>
                      <span className="bg-rose-100 text-rose-800 text-[11px] font-black px-2.5 py-0.5 rounded-full">
                        غير مقروء: {unreadRecipientCount}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500">
                      جميع الرسائل المستلمة من الأعضاء وفق قواعد الخصوصية والموقع الجغرافي
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
                  <button
                    type="button"
                    onClick={() => setInboxFilter('all')}
                    className={`px-3 py-1.5 rounded-lg cursor-pointer ${
                      inboxFilter === 'all' ? 'bg-white text-slate-900 font-black shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    الكل ({recipientMessages.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setInboxFilter('unread')}
                    className={`px-3 py-1.5 rounded-lg cursor-pointer ${
                      inboxFilter === 'unread'
                        ? 'bg-rose-600 text-white font-black shadow-2xs'
                        : 'text-slate-600'
                    }`}
                  >
                    غير مقروء ({unreadRecipientCount})
                  </button>
                </div>
              </div>

              {recipientMessages.length === 0 ? (
                <div className="py-10 text-center text-slate-500 space-y-2">
                  <Mail className="w-10 h-10 mx-auto text-slate-300" />
                  <div className="font-black text-sm text-slate-700">
                    لا توجد رسائل واردة في هذا الصندوق حالياً
                  </div>
                  <p className="text-xs text-slate-400">
                    يمكنك إرسال رسالة مباشرة من النموذج أعلاه للتواصل الفوري مع النشاط أو المشترك.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {recipientMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`p-4 sm:p-5 rounded-2xl border transition-all space-y-3 ${
                        msg.isRead
                          ? 'bg-slate-50/70 border-slate-200'
                          : 'bg-emerald-50/40 border-emerald-300 shadow-xs'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-black text-sm text-slate-900">{msg.senderName}</span>
                          <span className="bg-indigo-100 text-indigo-800 text-[10px] font-black px-2.5 py-0.5 rounded-full">
                            {msg.senderRole === 'subscriber' ? 'عضو مشترك' : 'زائر'}
                          </span>
                          <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-0.5 rounded-full flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            <span>
                              {msg.senderGovernorate}
                              {msg.senderMarkaz ? ` - ${msg.senderMarkaz}` : ''}
                            </span>
                          </span>
                          {!currentPrivacyConfig.hidePhoneNumberInMessages && msg.senderPhone && (
                            <span className="text-[11px] font-mono font-bold text-slate-600 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                              {msg.senderPhone}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-[11px] text-slate-400">
                          <span>{msg.createdAt}</span>
                          <button
                            type="button"
                            onClick={() => markMemberDirectMessageRead(msg.id, !msg.isRead)}
                            className="text-xs font-black text-indigo-700 hover:underline cursor-pointer"
                          >
                            {msg.isRead ? 'تحديد كغير مقروء' : 'تحديد كمقروء'}
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteMemberDirectMessage(msg.id)}
                            className="text-rose-600 hover:text-rose-700 p-1 cursor-pointer"
                            title="حذف الرسالة"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-black text-xs sm:text-sm text-slate-900">
                          {msg.subject}
                        </h4>
                        <p className="text-xs text-slate-700 mt-1 leading-relaxed">{msg.content}</p>
                      </div>

                      {msg.replyText && (
                        <div className="bg-white p-3 rounded-xl border border-emerald-200 space-y-1">
                          <div className="text-[11px] font-black text-emerald-700 flex items-center gap-1">
                            <Reply className="w-3.5 h-3.5" />
                            <span>الرد المسجل ({msg.repliedAt}):</span>
                          </div>
                          <p className="text-xs text-slate-700">{msg.replyText}</p>
                        </div>
                      )}

                      {/* Direct Reply Input */}
                      <div className="flex items-center gap-2 pt-1">
                        <input
                          type="text"
                          value={replyDrafts[msg.id] || ''}
                          onChange={(e) =>
                            setReplyDrafts((prev) => ({ ...prev, [msg.id]: e.target.value }))
                          }
                          placeholder="اكتب رداً مباشراً على عضو المنصة..."
                          className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const draft = replyDrafts[msg.id];
                            if (!draft || !draft.trim()) return;
                            replyToMemberDirectMessage(msg.id, draft);
                            setReplyDrafts((prev) => ({ ...prev, [msg.id]: '' }));
                          }}
                          className="bg-slate-900 hover:bg-emerald-600 text-white font-black text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                        >
                          <Reply className="w-3.5 h-3.5" />
                          <span>إرسال الرد</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
              </>
            ) : (
              <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-950" role="status">
                لا توجد عضوية نشطة مرتبطة بهذه الصفحة.
              </div>
            )}
          </div>

          {/* LEFT SIDE: Full-Height Vertical Column of Non-Competing Sponsored Ads (بالشمال من تحت مساحة الـ Cover) */}
          <NonCompetingSponsoredAdsStrip
            hostBusiness={activeBusiness || null}
            pageLabel={`صفحة رسائل الأعضاء — ${recipientName}`}
            limit={5}
          />
        </div>
      </div>
    </div>
  );
};
