import React from 'react';
import { useApp } from '../context/AppContext';
import { LogIn, LogOut, MessageCircle, Store, HeartPulse } from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    authSession,
    logout,
    setIsLoginModalOpen,
  } = useApp();

  const navItems = [
    { id: 'directory' as const, label: 'دليل الأنشطة', icon: Store },
    { id: 'medical_directory' as const, label: 'الدليل الطبي', icon: HeartPulse },
    { id: 'contact_us' as const, label: 'تواصل معنا', icon: MessageCircle },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 shadow-sm backdrop-blur-md" dir="rtl">
      <div className="bg-slate-950 px-4 py-2 text-white">
        <div className="mx-auto flex max-w-[1720px] flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setCurrentView('directory')}
            className="flex items-center gap-2 rounded-lg text-right focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
            aria-label="العودة إلى دليل MantiqatiX"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 text-sm font-black text-white">MX</span>
            <span>
              <span className="block text-sm font-black">منطقتي X</span>
              <span className="block text-[10px] text-slate-300">دليل الأنشطة والكتالوجات</span>
            </span>
          </button>

          <div className="flex items-center gap-2 text-xs">
            {authSession.role === 'guest' ? (
              <button
                type="button"
                onClick={() => setIsLoginModalOpen(true)}
                className="inline-flex min-h-9 items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2 font-bold text-white transition-colors hover:bg-emerald-500"
              >
                <LogIn className="h-4 w-4" />
                <span>دخول الحساب</span>
              </button>
            ) : (
              <>
                <span className="max-w-[45vw] truncate text-slate-200" title={authSession.userEmail || undefined}>
                  حساب موثق: {authSession.userEmail || 'مستخدم'}
                </span>
                <button
                  type="button"
                  onClick={logout}
                  className="inline-flex min-h-9 items-center gap-1 rounded-xl border border-slate-700 px-3 py-2 font-bold text-slate-200 hover:bg-slate-800"
                  title="تسجيل الخروج"
                >
                  <LogOut className="h-4 w-4" />
                  <span>خروج</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      <nav aria-label="التنقل الرئيسي" className="mx-auto flex max-w-[1720px] items-center gap-1 overflow-x-auto px-3 py-2 sm:px-6">
        {navItems.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            type="button"
            onClick={() => setCurrentView(id)}
            aria-current={currentView === id ? 'page' : undefined}
            className={`inline-flex min-h-10 shrink-0 items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold transition-colors sm:px-4 ${
              currentView === id
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Icon className="h-4 w-4" aria-hidden="true" />
            <span>{label}</span>
          </button>
        ))}
      </nav>
    </header>
  );
};
