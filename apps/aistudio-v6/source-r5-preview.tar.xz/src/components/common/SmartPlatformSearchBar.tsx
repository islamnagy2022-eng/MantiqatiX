import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Search,
  Store,
  Package,
  Wrench,
  MapPin,
  CheckCircle2,
  ExternalLink,
  X,
  Sparkles,
  TrendingUp,
  Tag,
  ArrowRight,
  SlidersHorizontal,
  UtensilsCrossed,
  Coffee,
  Pizza,
  Cake,
  ChefHat,
  Shirt,
  ShoppingBag,
  Smartphone,
  Armchair,
  BookOpen,
  Monitor,
  Scissors,
  Camera,
  Sparkle,
  Printer,
  ShieldAlert,
  Stethoscope,
  Smile,
  FlaskConical,
  Radio,
  Eye,
  AirVent,
  Car,
  Pipette,
  Zap,
  Hammer,
  Paintbrush,
  GraduationCap,
  Globe,
  Code,
  Baby,
  Briefcase,
  Building,
  HardHat,
  Compass,
  Map as MapIcon,
  Plane,
  Moon,
  Truck,
  Bike,
  Warehouse,
  Sprout,
  Droplets,
  Wheat,
  Fish,
  Cpu,
  CreditCard,
  Shield,
  Server,
  Cloud,
  Dumbbell,
  Trophy,
  Flame,
  Award,
  PartyPopper,
  Music,
  Scale,
  FileSpreadsheet,
  Building2,
  Coins,
  FileCheck,
  Factory,
  Box,
  Cog,
  Citrus,
  Layers,
} from 'lucide-react';
import { Business, Product, FunctionalGroup, FunctionalGroupId } from '../../types';
import {
  getSubcategoriesForSector,
  getSubcategoryById,
  matchSubcategories,
  filterBusinessesBySubcategory,
  countBusinessesInSubcategory,
} from '../../utils/subCategoriesTaxonomy';

interface SmartPlatformSearchBarProps {
  businesses: Business[];
  products: Product[];
  functionalGroups: FunctionalGroup[];
  onSelectBusiness: (businessId: string) => void;
  onSearchChange?: (query: string) => void;
  initialQuery?: string;
  selectedGov?: string;
  onGovChange?: (gov: string) => void;
  uniqueGovernorships?: string[];
  selectedSector?: FunctionalGroupId | 'all';
  onSectorChange?: (sectorId: FunctionalGroupId | 'all') => void;
  selectedSubCategoryId?: string | null;
  onSubCategoryChange?: (subCategoryId: string | null) => void;
}

type SearchTabFilter = 'all' | 'businesses' | 'products' | 'services';

const renderSubCategoryIcon = (iconName: string, className = 'w-4 h-4') => {
  switch (iconName) {
    case 'UtensilsCrossed': return <UtensilsCrossed className={className} />;
    case 'Coffee': return <Coffee className={className} />;
    case 'Pizza': return <Pizza className={className} />;
    case 'Cake': return <Cake className={className} />;
    case 'ChefHat': return <ChefHat className={className} />;
    case 'Citrus': return <Citrus className={className} />;
    case 'Shirt': return <Shirt className={className} />;
    case 'ShoppingBag': return <ShoppingBag className={className} />;
    case 'Smartphone': return <Smartphone className={className} />;
    case 'Sparkles': return <Sparkles className={className} />;
    case 'Armchair': return <Armchair className={className} />;
    case 'BookOpen': return <BookOpen className={className} />;
    case 'Monitor': return <Monitor className={className} />;
    case 'Scissors': return <Scissors className={className} />;
    case 'Camera': return <Camera className={className} />;
    case 'Sparkle': return <Sparkle className={className} />;
    case 'Printer': return <Printer className={className} />;
    case 'ShieldAlert': return <ShieldAlert className={className} />;
    case 'Stethoscope': return <Stethoscope className={className} />;
    case 'Smile': return <Smile className={className} />;
    case 'FlaskConical': return <FlaskConical className={className} />;
    case 'Radio': return <Radio className={className} />;
    case 'Eye': return <Eye className={className} />;
    case 'AirVent': return <AirVent className={className} />;
    case 'Car': return <Car className={className} />;
    case 'Pipette': return <Pipette className={className} />;
    case 'Zap': return <Zap className={className} />;
    case 'Hammer': return <Hammer className={className} />;
    case 'Paintbrush': return <Paintbrush className={className} />;
    case 'GraduationCap': return <GraduationCap className={className} />;
    case 'Globe': return <Globe className={className} />;
    case 'Code': return <Code className={className} />;
    case 'Baby': return <Baby className={className} />;
    case 'Briefcase': return <Briefcase className={className} />;
    case 'Building': return <Building className={className} />;
    case 'HardHat': return <HardHat className={className} />;
    case 'Layers': return <Layers className={className} />;
    case 'Store': return <Store className={className} />;
    case 'Compass': return <Compass className={className} />;
    case 'Map': return <MapIcon className={className} />;
    case 'Plane': return <Plane className={className} />;
    case 'Moon': return <Moon className={className} />;
    case 'Truck': return <Truck className={className} />;
    case 'Package': return <Package className={className} />;
    case 'Bike': return <Bike className={className} />;
    case 'Warehouse': return <Warehouse className={className} />;
    case 'Sprout': return <Sprout className={className} />;
    case 'Droplets': return <Droplets className={className} />;
    case 'Wheat': return <Wheat className={className} />;
    case 'Fish': return <Fish className={className} />;
    case 'Cpu': return <Cpu className={className} />;
    case 'CreditCard': return <CreditCard className={className} />;
    case 'Shield': return <Shield className={className} />;
    case 'Server': return <Server className={className} />;
    case 'Cloud': return <Cloud className={className} />;
    case 'Dumbbell': return <Dumbbell className={className} />;
    case 'Trophy': return <Trophy className={className} />;
    case 'Flame': return <Flame className={className} />;
    case 'Award': return <Award className={className} />;
    case 'PartyPopper': return <PartyPopper className={className} />;
    case 'Music': return <Music className={className} />;
    case 'Scale': return <Scale className={className} />;
    case 'FileSpreadsheet': return <FileSpreadsheet className={className} />;
    case 'Building2': return <Building2 className={className} />;
    case 'Coins': return <Coins className={className} />;
    case 'FileCheck': return <FileCheck className={className} />;
    case 'Factory': return <Factory className={className} />;
    case 'Box': return <Box className={className} />;
    case 'Cog': return <Cog className={className} />;
    default: return <Tag className={className} />;
  }
};

export const SmartPlatformSearchBar: React.FC<SmartPlatformSearchBarProps> = ({
  businesses,
  products,
  functionalGroups,
  onSelectBusiness,
  onSearchChange,
  initialQuery = '',
  selectedGov = 'all',
  onGovChange,
  uniqueGovernorships = [],
  selectedSector = 'all',
  onSectorChange,
  selectedSubCategoryId = null,
  onSubCategoryChange,
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [activeTab, setActiveTab] = useState<SearchTabFilter>('all');
  const [isOpen, setIsOpen] = useState(false);
  const [internalSector, setInternalSector] = useState<FunctionalGroupId | 'all'>(selectedSector);
  const [internalSubCategory, setInternalSubCategory] = useState<string | null>(selectedSubCategoryId);

  const searchContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setQuery(initialQuery);
  }, [initialQuery]);

  useEffect(() => {
    setInternalSector(selectedSector);
  }, [selectedSector]);

  useEffect(() => {
    setInternalSubCategory(selectedSubCategoryId);
  }, [selectedSubCategoryId]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const POPULAR_SEARCH_TAGS = [
    { label: 'صيدليات', query: 'صيدلية', type: 'businesses' as const },
    { label: 'مطاعم', query: 'مطعم', type: 'products' as const },
    { label: 'صيانة تكييف', query: 'تكييف', type: 'services' as const },
    { label: 'عقارات', query: 'شقة', type: 'products' as const },
    { label: 'أطباء وعيادات', query: 'طبيب', type: 'businesses' as const },
  ];

  const businessMap = useMemo(() => {
    const map = new Map<string, Business>();
    businesses.forEach((b) => map.set(b.id, b));
    return map;
  }, [businesses]);

  const currentSubcategories = useMemo(() => {
    return getSubcategoriesForSector(internalSector);
  }, [internalSector]);

  const matchingSubcategories = useMemo(() => {
    if (!query.trim()) return [];
    return matchSubcategories(query, internalSector).slice(0, 4);
  }, [query, internalSector]);

  const activeSubCategoryItem = useMemo(() => {
    if (!internalSubCategory) return null;
    return getSubcategoryById(internalSubCategory) || null;
  }, [internalSubCategory]);

  const searchResults = useMemo(() => {
    const cleanQuery = query.trim().toLowerCase();

    let candidateBusinesses = businesses;
    if (internalSector !== 'all') {
      candidateBusinesses = candidateBusinesses.filter((b) => b.functionalGroupId === internalSector);
    }
    if (internalSubCategory) {
      candidateBusinesses = filterBusinessesBySubcategory(
        candidateBusinesses,
        internalSubCategory,
        internalSector
      );
    }

    const matchedBusinesses = candidateBusinesses.filter((b) => {
      const matchesGov = selectedGov === 'all' || b.governorate === selectedGov;
      if (!matchesGov) return false;
      if (!cleanQuery) return Boolean(internalSubCategory);

      const nameMatch = b.name.toLowerCase().includes(cleanQuery);
      const catMatch = b.category.toLowerCase().includes(cleanQuery);
      const bioMatch = b.bio.toLowerCase().includes(cleanQuery);
      const addressMatch = (b.address || '').toLowerCase().includes(cleanQuery);
      const markazMatch = (b.markaz || '').toLowerCase().includes(cleanQuery);
      const govMatch = (b.governorate || '').toLowerCase().includes(cleanQuery);

      return nameMatch || catMatch || bioMatch || addressMatch || markazMatch || govMatch;
    });

    const matchedProducts = products.filter((p) => {
      if (p.type !== 'product') return false;
      const ownerBiz = businessMap.get(p.businessId);
      if (selectedGov !== 'all' && ownerBiz?.governorate !== selectedGov) return false;
      if (internalSector !== 'all' && ownerBiz?.functionalGroupId !== internalSector) return false;
      if (internalSubCategory && ownerBiz) {
        const matchesSub = filterBusinessesBySubcategory([ownerBiz], internalSubCategory, internalSector).length > 0;
        if (!matchesSub) return false;
      }

      if (!cleanQuery) return Boolean(internalSubCategory);

      const nameMatch = p.name.toLowerCase().includes(cleanQuery);
      const descMatch = (p.description || '').toLowerCase().includes(cleanQuery);
      const catMatch = (p.category || '').toLowerCase().includes(cleanQuery);
      const bizNameMatch = ownerBiz ? ownerBiz.name.toLowerCase().includes(cleanQuery) : false;

      return nameMatch || descMatch || catMatch || bizNameMatch;
    });

    const matchedServices = products.filter((p) => {
      if (p.type !== 'service') return false;
      const ownerBiz = businessMap.get(p.businessId);
      if (selectedGov !== 'all' && ownerBiz?.governorate !== selectedGov) return false;
      if (internalSector !== 'all' && ownerBiz?.functionalGroupId !== internalSector) return false;
      if (internalSubCategory && ownerBiz) {
        const matchesSub = filterBusinessesBySubcategory([ownerBiz], internalSubCategory, internalSector).length > 0;
        if (!matchesSub) return false;
      }

      if (!cleanQuery) return Boolean(internalSubCategory);

      const nameMatch = p.name.toLowerCase().includes(cleanQuery);
      const descMatch = (p.description || '').toLowerCase().includes(cleanQuery);
      const catMatch = (p.category || '').toLowerCase().includes(cleanQuery);
      const bizNameMatch = ownerBiz ? ownerBiz.name.toLowerCase().includes(cleanQuery) : false;

      return nameMatch || descMatch || catMatch || bizNameMatch;
    });

    const totalCount =
      activeTab === 'all'
        ? matchedBusinesses.length + matchedProducts.length + matchedServices.length
        : activeTab === 'businesses'
        ? matchedBusinesses.length
        : activeTab === 'products'
        ? matchedProducts.length
        : matchedServices.length;

    return {
      businesses: matchedBusinesses,
      products: matchedProducts,
      services: matchedServices,
      totalCount,
    };
  }, [
    query,
    selectedGov,
    businesses,
    products,
    businessMap,
    activeTab,
    internalSector,
    internalSubCategory,
  ]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setQuery(val);
    setIsOpen(true);
    if (onSearchChange) {
      onSearchChange(val);
    }
  };

  const handleClear = () => {
    setQuery('');
    if (onSearchChange) {
      onSearchChange('');
    }
    inputRef.current?.focus();
  };

  const handleTagClick = (tagQuery: string, tagType: SearchTabFilter) => {
    setQuery(tagQuery);
    setActiveTab(tagType);
    setIsOpen(true);
    if (onSearchChange) {
      onSearchChange(tagQuery);
    }
  };

  const handleSectorClick = (sectorId: FunctionalGroupId | 'all') => {
    setInternalSector(sectorId);
    setInternalSubCategory(null);
    if (onSectorChange) {
      onSectorChange(sectorId);
    }
    if (onSubCategoryChange) {
      onSubCategoryChange(null);
    }
  };

  const handleSubCategoryToggle = (subCategoryId: string) => {
    if (internalSubCategory === subCategoryId) {
      setInternalSubCategory(null);
      if (onSubCategoryChange) {
        onSubCategoryChange(null);
      }
    } else {
      setInternalSubCategory(subCategoryId);
      const subItem = getSubcategoryById(subCategoryId);
      if (subItem && internalSector === 'all') {
        setInternalSector(subItem.sectorId);
        if (onSectorChange) onSectorChange(subItem.sectorId);
      }
      if (onSubCategoryChange) {
        onSubCategoryChange(subCategoryId);
      }
      setIsOpen(true);
    }
  };

  const handleClearSubCategory = () => {
    setInternalSubCategory(null);
    if (onSubCategoryChange) {
      onSubCategoryChange(null);
    }
  };

  const handleSelectBusinessItem = (businessId: string) => {
    setIsOpen(false);
    onSelectBusiness(businessId);
  };

  const hasQuery = query.trim().length > 0;
  const isFilterActive = hasQuery || internalSubCategory !== null || internalSector !== 'all';

  return (
    <div ref={searchContainerRef} className="relative z-30 w-full" dir="rtl">
      {/* Sleek, Modern Simple Search Card */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 shadow-lg border border-slate-200 space-y-3">
        {/* Main Search Input & Actions */}
        <div className="flex flex-col md:flex-row items-stretch gap-2">
          {/* Main Input Box */}
          <div className="relative flex-1 flex items-center bg-slate-50 rounded-2xl border border-slate-300 focus-within:border-emerald-600 focus-within:bg-white focus-within:ring-2 focus-within:ring-emerald-500/20 transition-all overflow-hidden">
            <div className="pr-4 text-slate-400">
              <Search className="w-5 h-5 text-emerald-600" />
            </div>

            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={handleInputChange}
              onFocus={() => setIsOpen(true)}
              placeholder="ابحث عن اسم نشاط، صيدلية، عيادة، مطعم، منتج، أو خدمة..."
              className="w-full py-3.5 px-3 text-xs sm:text-sm font-black text-slate-900 placeholder:text-slate-400 placeholder:font-normal focus:outline-none bg-transparent"
              aria-label="شريط البحث الذكي"
            />

            {hasQuery && (
              <button
                type="button"
                onClick={handleClear}
                className="p-2 text-slate-400 hover:text-rose-600 rounded-full hover:bg-slate-200/60 transition-colors cursor-pointer shrink-0 ml-1"
                title="مسح البحث"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick Governorate Filter Dropdown */}
          {uniqueGovernorships.length > 0 && onGovChange && (
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-300 px-3.5 py-2.5 rounded-2xl shrink-0">
              <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
              <select
                value={selectedGov}
                onChange={(e) => onGovChange(e.target.value)}
                className="bg-transparent text-xs font-black text-slate-800 focus:outline-none cursor-pointer"
                aria-label="المحافظة"
              >
                <option value="all">كافة المحافظات</option>
                {uniqueGovernorships.map((gov) => (
                  <option key={gov} value={gov}>
                    محافظة {gov}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Search Button */}
          <button
            type="button"
            onClick={() => {
              setIsOpen(true);
              inputRef.current?.focus();
            }}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm px-6 py-3.5 rounded-2xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
          >
            <span>بحث</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Categories Bar & Quick Filters */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs pt-1 border-t border-slate-100">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            {/* Filter Tabs */}
            <button
              type="button"
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              الكل
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('businesses')}
              className={`px-3 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                activeTab === 'businesses'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Store className="w-3.5 h-3.5" />
              <span>الأنشطة</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('products')}
              className={`px-3 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                activeTab === 'products'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>المنتجات</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('services')}
              className={`px-3 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                activeTab === 'services'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Wrench className="w-3.5 h-3.5" />
              <span>الخدمات</span>
            </button>
          </div>

          {/* Active Subcategory Pill if selected */}
          {activeSubCategoryItem && (
            <div className="flex items-center gap-1.5 bg-amber-100 text-amber-900 font-black px-3 py-1 rounded-xl border border-amber-300 text-xs">
              {renderSubCategoryIcon(activeSubCategoryItem.iconName, 'w-3.5 h-3.5 text-amber-700')}
              <span>القسم: {activeSubCategoryItem.name}</span>
              <button
                type="button"
                onClick={handleClearSubCategory}
                className="hover:bg-amber-200 rounded-full p-0.5 ml-0.5 cursor-pointer text-amber-900"
                title="إلغاء تصفية القسم"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}

          {/* Popular quick tags */}
          <div className="hidden lg:flex items-center gap-1 text-[11px] font-bold text-slate-500 overflow-x-auto">
            <span className="text-slate-400">شائع:</span>
            {POPULAR_SEARCH_TAGS.map((tag, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleTagClick(tag.query, tag.type)}
                className={`px-2 py-0.5 rounded-lg border cursor-pointer hover:bg-emerald-50 transition-colors ${
                  query === tag.query
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300 font-black'
                    : 'bg-slate-50 text-slate-600 border-slate-200'
                }`}
              >
                {tag.label}
              </button>
            ))}
          </div>
        </div>

        {/* Subcategories Carousel Pills (Compact) */}
        {currentSubcategories.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1">
            <span className="text-[11px] font-bold text-slate-400 shrink-0 ml-1">الأقسام:</span>
            {currentSubcategories.map((sub) => {
              const isSelected = internalSubCategory === sub.id;
              return (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => handleSubCategoryToggle(sub.id)}
                  className={`text-[11px] font-bold px-2.5 py-1 rounded-xl border transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 shrink-0 ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 border-amber-400 font-black shadow-2xs'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  {renderSubCategoryIcon(sub.iconName, 'w-3 h-3')}
                  <span>{sub.name}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Auto-Suggest Live Results Dropdown */}
      {isOpen && (hasQuery || internalSubCategory !== null) && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden text-slate-900 z-50 animate-in fade-in duration-150">
          <div className="bg-slate-50 border-b border-slate-200 px-5 py-3 flex items-center justify-between text-xs">
            <span className="font-black text-slate-800">
              {hasQuery ? (
                <>نتائج البحث عن: <span className="text-emerald-700">"{query}"</span></>
              ) : (
                <>قسم: <span className="text-emerald-700">{activeSubCategoryItem?.name}</span></>
              )}
            </span>
            <div className="flex items-center gap-3">
              <span className="font-bold text-slate-500">النتائج: {searchResults.totalCount}</span>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="max-h-[450px] overflow-y-auto p-4 space-y-5">
            {matchingSubcategories.length > 0 && (
              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-2xl space-y-2">
                <div className="text-xs font-black text-emerald-800">أقسام فرعية مطابقة:</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {matchingSubcategories.map((sub) => (
                    <button
                      key={sub.id}
                      type="button"
                      onClick={() => handleSubCategoryToggle(sub.id)}
                      className="p-2 rounded-xl bg-white hover:bg-emerald-100/60 border border-emerald-200 flex items-center justify-between text-right cursor-pointer text-xs font-bold text-slate-900"
                    >
                      <div className="flex items-center gap-2">
                        {renderSubCategoryIcon(sub.iconName, 'w-3.5 h-3.5 text-emerald-600')}
                        <span>{sub.name}</span>
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {searchResults.totalCount === 0 && (
              <div className="py-8 text-center text-xs font-bold text-slate-500">
                لا توجد نتائج مطابقة لـ "{query || (activeSubCategoryItem?.name ?? '')}"
              </div>
            )}

            {(activeTab === 'all' || activeTab === 'businesses') && searchResults.businesses.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs font-black text-slate-800 pb-1 border-b border-slate-100 flex items-center gap-1.5">
                  <Store className="w-3.5 h-3.5 text-emerald-600" />
                  <span>الأنشطة التجاريه ({searchResults.businesses.length})</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {searchResults.businesses.slice(0, 6).map((biz) => (
                    <div
                      key={biz.id}
                      onClick={() => handleSelectBusinessItem(biz.id)}
                      className="p-2.5 rounded-2xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/30 transition-all cursor-pointer flex items-center gap-3 text-right group"
                    >
                      <img
                        src={biz.logoUrl}
                        alt={biz.name}
                        className="w-10 h-10 rounded-xl object-cover bg-slate-100 shrink-0 border border-slate-200"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-black text-xs text-slate-900 group-hover:text-emerald-700 truncate">
                          {biz.name}
                        </h4>
                        <p className="text-[10px] text-slate-500 truncate">{biz.governorate} • {biz.category}</p>
                      </div>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-600 shrink-0" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {(activeTab === 'all' || activeTab === 'products') && searchResults.products.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs font-black text-slate-800 pb-1 border-b border-slate-100 flex items-center gap-1.5">
                  <Package className="w-3.5 h-3.5 text-emerald-600" />
                  <span>المنتجات ({searchResults.products.length})</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {searchResults.products.slice(0, 6).map((prod) => (
                    <div
                      key={prod.id}
                      onClick={() => handleSelectBusinessItem(prod.businessId)}
                      className="p-2 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-slate-50 transition-all cursor-pointer flex gap-2.5 text-right group"
                    >
                      <img
                        src={prod.imageUrl}
                        alt={prod.name}
                        className="w-12 h-12 rounded-lg object-cover bg-slate-100 shrink-0 border border-slate-200"
                      />
                      <div className="flex-1 min-w-0 flex flex-col justify-between">
                        <h4 className="font-black text-xs text-slate-900 group-hover:text-emerald-700 truncate">
                          {prod.name}
                        </h4>
                        <span className="font-bold text-xs text-emerald-700 font-mono">
                          {prod.price.toLocaleString()} ج.م
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {(activeTab === 'all' || activeTab === 'services') && searchResults.services.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs font-black text-slate-800 pb-1 border-b border-slate-100 flex items-center gap-1.5">
                  <Wrench className="w-3.5 h-3.5 text-emerald-600" />
                  <span>الخدمات ({searchResults.services.length})</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {searchResults.services.slice(0, 6).map((serv) => (
                    <div
                      key={serv.id}
                      onClick={() => handleSelectBusinessItem(serv.businessId)}
                      className="p-2 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-slate-50 transition-all cursor-pointer flex gap-2.5 text-right group"
                    >
                      <img
                        src={serv.imageUrl}
                        alt={serv.name}
                        className="w-12 h-12 rounded-lg object-cover bg-slate-100 shrink-0 border border-slate-200"
                      />
                      <div className="flex-1 min-w-0 flex flex-col justify-between">
                        <h4 className="font-black text-xs text-slate-900 group-hover:text-emerald-700 truncate">
                          {serv.name}
                        </h4>
                        <span className="font-bold text-xs text-indigo-800 font-mono">
                          {serv.price > 0 ? `${serv.price.toLocaleString()} ج.م` : 'استشارة / حجز'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
