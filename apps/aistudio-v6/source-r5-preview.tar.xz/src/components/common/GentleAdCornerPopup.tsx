import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getNonCompetingSponsoredAdsForContext } from '../../utils/rules';
import { Megaphone, X, ExternalLink, Sparkles, ChevronUp, ShieldCheck } from 'lucide-react';

export const GentleAdCornerPopup: React.FC = () => {
  const {
    adRequests,
    businesses,
    currentView,
    currentBusiness,
    setSelectedBusinessId,
    setCurrentView,
    setAdModalType,
  } = useApp();
  const [isDismissed, setIsDismissed] = useState(false);
  const [isMinimized, setIsMinimized] = useState(true);

  const nonCompetingContext = React.useMemo(
    () =>
      getNonCompetingSponsoredAdsForContext({
        adRequests,
        businesses,
        hostBusiness: currentView === 'public_storefront' ? currentBusiness : null,
        limit: 1,
      }),
    [adRequests, businesses, currentView, currentBusiness]
  );

  if (nonCompetingContext.ads.length === 0 || isDismissed) return null;

  const featuredAd = nonCompetingContext.ads[0];
  const targetBiz = featuredAd.resolvedBusiness;

  if (isMinimized) {
    return (
      <div className="fixed bottom-4 right-4 z-30" dir="rtl">
        <button
          type="button"
          onClick={() => setIsMinimized(false)}
          className="bg-slate-900/95 hover:bg-slate-900 text-white border border-amber-400/40 px-3.5 py-2 rounded-2xl shadow-lg flex items-center gap-2 text-xs font-black cursor-pointer backdrop-blur-xs"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>عرض مميز</span>
          <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
        </button>
      </div>
    );
  }

  return (
    <div
      className="fixed bottom-4 right-4 z-30 w-[265px] bg-white/95 backdrop-blur-md rounded-3xl border border-amber-300 shadow-2xl p-3 text-right transition-all"
      dir="rtl"
    >
      <div className="flex items-center justify-between gap-2 pb-2">
        <span className="inline-flex items-center gap-1 text-[10px] font-black bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded-full">
          <ShieldCheck className="w-3 h-3 text-emerald-600" />
          <span>{currentView === 'public_storefront' ? 'إعلان تكميلي غير منافس' : 'بنر إعلان ممول مربع 1:1'}</span>
        </span>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setIsMinimized(true)}
            className="text-[10px] font-bold text-slate-400 hover:text-slate-700 px-1.5 py-0.5 rounded cursor-pointer"
            title="تصغير النافذة"
          >
            تصغير
          </button>
          <button
            type="button"
            onClick={() => setIsDismissed(true)}
            className="w-5 h-5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer"
            title="إغلاق"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Square Banner Frame (1:1 aspect-square) */}
      <div className="aspect-square w-full rounded-2xl overflow-hidden relative bg-slate-900 border border-slate-200 flex flex-col justify-between p-3.5 text-white">
        {featuredAd.imageUrl && (
          <img
            src={featuredAd.imageUrl}
            alt={featuredAd.title}
            className="absolute inset-0 w-full h-full object-cover opacity-55"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />

        <div className="relative z-10 flex items-center justify-between gap-1">
          <span className="bg-emerald-500/90 text-slate-950 text-[9px] font-black px-2 py-0.5 rounded-md truncate max-w-[130px]">
            {featuredAd.businessName}
          </span>
          {featuredAd.promoCode && (
            <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-2 py-0.5 rounded-md font-mono">
              {featuredAd.promoCode}
            </span>
          )}
        </div>

        <div className="relative z-10 space-y-1.5">
          <div className="font-black text-xs text-white line-clamp-2 leading-snug">
            {featuredAd.title}
          </div>
          <p className="text-[10px] text-slate-200 line-clamp-2 leading-relaxed">
            {featuredAd.description}
          </p>
          <div className="pt-1 flex items-center justify-between gap-1.5">
            {targetBiz ? (
              <button
                type="button"
                onClick={() => {
                  setSelectedBusinessId(targetBiz.id);
                  setCurrentView('public_storefront');
                }}
                className="w-full bg-amber-400 hover:bg-amber-300 text-slate-950 text-[10px] font-black py-1.5 px-2.5 rounded-xl flex items-center justify-center gap-1 cursor-pointer shadow-md"
              >
                <span>{featuredAd.ctaText || 'زيارة النشاط الآن'}</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setAdModalType('sponsored_ad')}
                className="w-full bg-amber-400 hover:bg-amber-300 text-slate-950 text-[10px] font-black py-1.5 px-2.5 rounded-xl cursor-pointer"
              >
                أعلن معنا ببنر مربع
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
