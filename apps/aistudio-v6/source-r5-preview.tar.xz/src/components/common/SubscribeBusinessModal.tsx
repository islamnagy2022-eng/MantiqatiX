import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { FunctionalGroupId } from '../../types';
import {
  validateSubscriptionRequestInput,
  cleanPhoneNumber,
  getSectorDefaultLogo,
  getSectorDefaultCover,
  SECTOR_DEFAULT_IMAGES,
} from '../../utils/rules';
import {
  FileText,
  X,
  Store,
  MapPin,
  Phone,
  CheckCircle2,
  MessageCircle,
  ExternalLink,
  AlertCircle,
  Sparkles,
  Image as ImageIcon,
} from 'lucide-react';

export const SubscribeBusinessModal: React.FC = () => {
  const {
    isSubscribeModalOpen,
    setIsSubscribeModalOpen,
    functionalGroups,
    submitSubscriptionRequest,
    adminSettings,
    setSelectedBusinessId,
    setCurrentView,
  } = useApp();

  const [businessName, setBusinessName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phoneOrWhatsApp, setPhoneOrWhatsApp] = useState('');
  const [governorate, setGovernorate] = useState('');
  const [markaz, setMarkaz] = useState('');
  const [detailedAddress, setDetailedAddress] = useState('');
  const [functionalGroupId, setFunctionalGroupId] = useState<FunctionalGroupId>('dining');
  const [category, setCategory] = useState('');
  const [notes, setNotes] = useState('');
  const [isFreeDirectoryOnly, setIsFreeDirectoryOnly] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [submittedInfo, setSubmittedInfo] = useState<{
    businessId: string;
    whatsappUrl: string;
  } | null>(null);

  if (!isSubscribeModalOpen) return null;

  const handleClose = () => {
    setIsSubscribeModalOpen(false);
    setSubmittedInfo(null);
    setErrorMsg('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const validation = validateSubscriptionRequestInput({
      businessName,
      phoneOrWhatsApp,
      governorate,
      markaz,
    });

    if (!validation.valid) {
      setErrorMsg(validation.error || 'يرجى التأكد من ملء كافة الحقول الإلزامية.');
      return;
    }

    const selectedGroup = functionalGroups.find((g) => g.id === functionalGroupId);
    const resolvedCategory = category.trim() || selectedGroup?.shortName || 'عام';

    const result = submitSubscriptionRequest({
      businessName,
      ownerName,
      phoneOrWhatsApp,
      governorate,
      markaz,
      detailedAddress,
      functionalGroupId,
      category: resolvedCategory,
      notes,
      isFreeDirectoryOnly,
    });

    const cleanAdmin = cleanPhoneNumber(adminSettings.adminWhatsApp);
    let msg = `🏢 *طلب اشتراك وتسجيل نشاط جديد على منصة MantiqatiX*\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `▫️ *اسم النشاط:* ${businessName.trim()}\n`;
    if (ownerName.trim()) msg += `▫️ *اسم المسؤول:* ${ownerName.trim()}\n`;
    msg += `▫️ *رقم الهاتف / الواتساب:* ${phoneOrWhatsApp.trim()}\n`;
    msg += `▫️ *المحافظة والمركز:* ${governorate.trim()} - ${markaz.trim()}\n`;
    if (detailedAddress.trim()) msg += `▫️ *العنوان التفصيلي:* ${detailedAddress.trim()}\n`;
    msg += `▫️ *القطاع:* ${selectedGroup?.shortName || functionalGroupId}\n`;
    msg += `▫️ *نوع التسجيل المطلوب:* ${
      isFreeDirectoryOnly
        ? 'إدراج مجاني في الدليل (الاسم والموقع والرقم لحين التوثيق)'
        : 'طلب اشتراك وتفعيل كتالوج وصلاحيات من الإدارة'
    }\n`;
    if (notes.trim()) msg += `▫️ *ملاحظات:* ${notes.trim()}\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `يرجى مراجعة الطلب وتحديد نظام الاشتراك (مجاني / عادي / متقدم) والصلاحيات والعمولات.`;

    setSubmittedInfo({
      businessId: result.businessId,
      whatsappUrl: `https://wa.me/${cleanAdmin}?text=${encodeURIComponent(msg)}`,
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      dir="rtl"
    >
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-6 text-right max-h-[92vh] overflow-y-auto relative">
        <button
          type="button"
          onClick={handleClose}
          className="absolute top-5 left-5 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 pb-4 border-b border-slate-100">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 flex items-center justify-center shadow-md font-black">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-black text-lg text-slate-900">
              أرغب في اشتراك نشاطي / إضافة نشاط بالدليل
            </h2>
            <p className="text-xs text-slate-500">
              سجل بيانات نشاطك الأساسية ليتم مراجعته من الإدارة وتحديد باقتك وصلاحياتك (مع صورة وغلاف ثابتين تلقائياً لحين تغييرهما).
            </p>
          </div>
        </div>

        {submittedInfo ? (
          <div className="bg-emerald-50 border-2 border-emerald-300 rounded-3xl p-6 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-lg">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div className="space-y-1.5">
              <h3 className="font-black text-lg text-emerald-950">
                تم تقديم طلب اشتراك نشاطك بنجاح للمراجعة مع الإدارة!
              </h3>
              <p className="text-xs text-emerald-800 max-w-lg mx-auto leading-relaxed">
                تم إنشاء سجل لنشاطك بصورة شعار وغلاف ثابتين افتراضيين وإرسال طلبك إلى لوحة تحكم الإدارة لتتواصل معك وتحدد نظام اشتراكك (مجاني / عادي / متقدم)، عمولاتك، وعدد الأنشطة المتاحة لك.
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <a
                href={submittedInfo.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-5 py-3 rounded-2xl shadow-md flex items-center gap-2 cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>تأكيد الطلب عبر واتساب الإدارة</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <button
                type="button"
                onClick={() => {
                  setSelectedBusinessId(submittedInfo.businessId);
                  setCurrentView('directory');
                  handleClose();
                }}
                className="bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 font-bold text-xs px-4 py-3 rounded-2xl cursor-pointer"
              >
                مشاهدة النشاط في الدليل
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {errorMsg && (
              <div className="bg-rose-50 border border-rose-200 text-rose-800 px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Preview of Sector-Specific Default Static Logo & Cover */}
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 shrink-0">
                  <img
                    src={getSectorDefaultLogo(functionalGroupId)}
                    alt="Default Sector Logo"
                    className="w-12 h-12 rounded-xl object-cover border-2 border-emerald-500 shadow-2xs"
                    title="الشعار الافتراضي الثابت للمجال"
                  />
                  <img
                    src={getSectorDefaultCover(functionalGroupId)}
                    alt="Default Sector Cover"
                    className="w-20 h-12 rounded-xl object-cover border border-slate-300 shadow-2xs"
                    title="الغلاف (Cover) الافتراضي الثابت للمجال"
                  />
                </div>
                <div>
                  <div className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                    <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                    <span>
                      شعار وغلاف (Cover) وصور منتجات افتراضية ثابتة لمجال (
                      {SECTOR_DEFAULT_IMAGES[functionalGroupId]?.sectorName || 'النشاط'})
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    حتى لو لم ترفع صورة، يظهر نشاطك ومنتجاتك تلقائياً بصور افتراضية مخصصة لمجالك مع إمكانية الاختيار من المكتبة في أي وقت.
                  </p>
                </div>
              </div>
            </div>

            {/* Listing Mode */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setIsFreeDirectoryOnly(false)}
                className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                  !isFreeDirectoryOnly
                    ? 'border-2 border-amber-500 bg-amber-50 text-amber-950'
                    : 'border-slate-200 bg-slate-50 text-slate-600'
                }`}
              >
                <div className="font-black text-xs flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>طلب اشتراك كامل (مجاني / عادي / متقدم)</span>
                </div>
                <div className="text-[10px] mt-1 opacity-80">
                  تراجع الإدارة الطلب وتحدد نظام الاشتراك والعمولات والصلاحيات وعدد الأنشطة المتاحة.
                </div>
              </button>

              <button
                type="button"
                onClick={() => setIsFreeDirectoryOnly(true)}
                className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                  isFreeDirectoryOnly
                    ? 'border-2 border-emerald-600 bg-emerald-50 text-emerald-950'
                    : 'border-slate-200 bg-slate-50 text-slate-600'
                }`}
              >
                <div className="font-black text-xs flex items-center gap-1.5">
                  <Store className="w-4 h-4 text-emerald-600" />
                  <span>إدراج في الدليل المجاني (غير موثق لحين التوثيق)</span>
                </div>
                <div className="text-[10px] mt-1 opacity-80">
                  يقتصر على الاسم والموقع والرقم لخدمة الزوار في القطاع لحين التوثيق الرسمي.
                </div>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  اسم النشاط التجاري أو الخدمي <span className="text-rose-500">* (إلزامي)</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: مطعم ومشويات السلطان / صيدلية الشفاء..."
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  رقم الهاتف أو الواتساب <span className="text-rose-500">* (إلزامي)</span>
                </label>
                <input
                  type="text"
                  required
                  dir="ltr"
                  placeholder="01012345678"
                  value={phoneOrWhatsApp}
                  onChange={(e) => setPhoneOrWhatsApp(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold text-right"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  المحافظة <span className="text-rose-500">* (إلزامي)</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: الدقهلية / القاهرة"
                  value={governorate}
                  onChange={(e) => setGovernorate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  المركز / المدينة <span className="text-rose-500">* (إلزامي)</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: المنصورة / طنطا"
                  value={markaz}
                  onChange={(e) => setMarkaz(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  العنوان التفصيلي / القرية
                </label>
                <input
                  type="text"
                  placeholder="الشارع أو الحي..."
                  value={detailedAddress}
                  onChange={(e) => setDetailedAddress(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  المجال / القطاع الرئيسي (من الـ 15 قطاعاً)
                </label>
                <select
                  value={functionalGroupId}
                  onChange={(e) => setFunctionalGroupId(e.target.value as FunctionalGroupId)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold cursor-pointer"
                >
                  {functionalGroups.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.shortName} ({g.name})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  اسم المالك أو المسؤول <span className="text-slate-400 font-normal">(اختياري)</span>
                </label>
                <input
                  type="text"
                  placeholder="اسم صاحب النشاط للتواصل..."
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">
                نبذة عن النشاط أو ملاحظات للإدارة <span className="text-slate-400 font-normal">(اختياري)</span>
              </label>
              <textarea
                rows={2}
                placeholder="اذكر أي تفاصيل عن منتجاتك أو عدد الأنشطة والفروع التي ترغب في إدارتها..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={handleClose}
                className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs shadow-lg cursor-pointer flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>تقديم الطلب للمراجعة مع الإدارة</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
