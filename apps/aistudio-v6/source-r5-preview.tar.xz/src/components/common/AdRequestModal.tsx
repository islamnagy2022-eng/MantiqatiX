import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Megaphone,
  Sparkles,
  X,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Phone,
  Image as ImageIcon,
} from 'lucide-react';

export const AdRequestModal: React.FC = () => {
  const {
    adModalType,
    setAdModalType,
    businesses,
    currentBusiness,
    authSession,
    addAdRequest,
  } = useApp();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [businessName, setBusinessName] = useState(currentBusiness?.name || '');
  const [contactPhone, setContactPhone] = useState(currentBusiness?.ownerWhatsApp || '');
  const [durationDays, setDurationDays] = useState(7);
  const [imageUrl, setImageUrl] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!adModalType) return null;

  const isBillboard = adModalType === 'billboard_banner';
  const estimatedBudget = isBillboard ? durationDays * 20 : durationDays * 15;

  const handleClose = () => {
    setAdModalType(null);
    setIsSubmitted(false);
    setErrorMsg('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!title.trim() || !businessName.trim() || !contactPhone.trim()) {
      setErrorMsg('يرجى إدخال عنوان الإعلان، اسم النشاط أو الجهة المعلنة، ورقم الهاتف للتواصل.');
      return;
    }

    const matchedBiz = businesses.find((b) => b.name === businessName.trim());

    addAdRequest({
      type: adModalType,
      title: title.trim(),
      description:
        description.trim() ||
        (isBillboard
          ? `يافطة إعلانية مميزة لـ ${businessName.trim()} عبر منصة MantiqatiX`
          : `إعلان ممول داخلي لـ ${businessName.trim()} عبر منصة MantiqatiX`),
      businessId: matchedBiz?.id || (authSession.role === 'subscriber' ? authSession.businessId : undefined),
      businessName: businessName.trim(),
      contactPhone: contactPhone.trim(),
      durationDays,
      budgetOrPrice: estimatedBudget,
      imageUrl:
        imageUrl.trim() ||
        'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=1200&auto=format&fit=crop&q=80',
    });

    setIsSubmitted(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      dir="rtl"
    >
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl space-y-6 text-right relative max-h-[92vh] overflow-y-auto">
        <button
          type="button"
          onClick={handleClose}
          className="absolute top-5 left-5 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 pb-4 border-b border-slate-100">
          <div
            className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-md font-black ${
              isBillboard ? 'bg-purple-600' : 'bg-amber-500 text-slate-950'
            }`}
          >
            {isBillboard ? <Sparkles className="w-6 h-6" /> : <Megaphone className="w-6 h-6" />}
          </div>
          <div>
            <h2 className="font-black text-lg text-slate-900">
              {isBillboard ? 'طلب حجز يافطة إعلانية بالموقع' : 'تقديم طلب إعلان ممول داخل الموقع'}
            </h2>
            <p className="text-xs text-slate-500">
              متاح للعملاء وأصحاب الأنشطة • يتم النشر داخل الموقع فور موافقة الإدارة أو تعديلها للطلب.
            </p>
          </div>
        </div>

        {isSubmitted ? (
          <div className="bg-emerald-50 border-2 border-emerald-300 rounded-3xl p-6 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-lg">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div className="space-y-1.5">
              <h3 className="font-black text-lg text-emerald-950">
                تم إرسال طلبك الإعلاني إلى الإدارة بنجاح!
              </h3>
              <p className="text-xs text-emerald-800 leading-relaxed">
                سيظهر طلبك الآن في لوحة تحكم الإدارة للمراجعة، ويمكن للإدارة الموافقة عليه لنشره فوراً في النوافذ والمساحات الإعلانية المنسقة داخل الموقع أو تعديله قبل النشر.
              </p>
            </div>
            <button
              type="button"
              onClick={handleClose}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-6 py-3 rounded-2xl cursor-pointer shadow-md"
            >
              حسناً، العودة للمنصة
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {errorMsg && (
              <div className="bg-rose-50 border border-rose-200 text-rose-800 px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Switch between Sponsored Ad and Billboard Banner */}
            <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1.5 rounded-2xl text-xs font-black">
              <button
                type="button"
                onClick={() => setAdModalType('sponsored_ad')}
                className={`py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  !isBillboard ? 'bg-white text-amber-700 shadow-xs' : 'text-slate-600'
                }`}
              >
                <Megaphone className="w-4 h-4" />
                <span>إعلان ممول داخلي</span>
              </button>
              <button
                type="button"
                onClick={() => setAdModalType('billboard_banner')}
                className={`py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  isBillboard ? 'bg-white text-purple-700 shadow-xs' : 'text-slate-600'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>حجز يافطة إعلانية</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  اسم النشاط أو المعلن <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  list="ad-businesses-list"
                  placeholder="اسم نشاطك أو شركتك..."
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                />
                <datalist id="ad-businesses-list">
                  {businesses.map((b) => (
                    <option key={b.id} value={b.name} />
                  ))}
                </datalist>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  رقم الهاتف / الواتساب للتواصل <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  dir="ltr"
                  placeholder="01012345678"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold text-right"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">
                عنوان الإعلان أو اليافطة البارز <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="مثال: خصم 30% بمناسبة الافتتاح لدى..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">
                تفاصيل العرض الإعلاني
              </label>
              <textarea
                rows={2}
                placeholder="اكتب وصفاً مختصراً وجذاباً يظهر للزوار والمشتركين بدون إزعاج..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  مدة عرض الإعلان المطلوبة
                </label>
                <select
                  value={durationDays}
                  onChange={(e) => setDurationDays(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold cursor-pointer"
                >
                  <option value={7}>7 أيام (أسبوع إعلاني)</option>
                  <option value={15}>15 يوماً (نصف شهر)</option>
                  <option value={30}>30 يوماً (شهر كامل)</option>
                  <option value={60}>60 يوماً (شهران)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  رابط صورة الإعلان <span className="text-slate-400 font-normal">(اختياري)</span>
                </label>
                <input
                  type="text"
                  dir="ltr"
                  placeholder="https://..."
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold text-right"
                />
              </div>
            </div>

            <div className="p-3.5 bg-indigo-50 border border-indigo-200 rounded-2xl text-xs flex items-center justify-between">
              <span className="font-bold text-indigo-950">
                التكلفة التقديرية ({durationDays} يوم):
              </span>
              <span className="font-black text-indigo-700 text-sm">
                {estimatedBudget} ج.م (تعتمد عند موافقة الإدارة)
              </span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={handleClose}
                className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className={`px-6 py-3 rounded-xl text-white font-black text-xs shadow-lg cursor-pointer flex items-center gap-2 ${
                  isBillboard
                    ? 'bg-purple-600 hover:bg-purple-700'
                    : 'bg-amber-500 hover:bg-amber-600 text-slate-950'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>إرسال الطلب لموافقة الإدارة</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
