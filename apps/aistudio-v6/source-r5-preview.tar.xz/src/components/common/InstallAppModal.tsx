import React, { useState, useEffect } from 'react';
import { Smartphone, Download, CheckCircle2, Bell, X, Shield, Apple, Share, PlusSquare } from 'lucide-react';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [notificationsList, setNotificationsList] = useState<any[]>([]);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Fetch initial notifications
    fetch('/api/notifications')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setNotificationsList(data);
      })
      .catch(() => {});

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      alert('لتثبيت التطبيق على أجهزة الأندرويد أو الكمبيوتر، افتح إعدادات المتصفح واختر "تثبيت التطبيق" أو "Add to Home Screen".');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 text-right shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-black text-lg text-slate-900">تثبيت تطبيق MantiqatiX Enterprise</h2>
            <p className="text-xs text-slate-500">ثبت التطبيق على هاتفك (أندرويد أو آيفون) لتجربة سريعة واستقبال الإشعارات.</p>
          </div>
        </div>

        {/* Installation Options for Android & iOS */}
        <div className="space-y-4">
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-2">
            <h3 className="font-black text-xs text-emerald-950 flex items-center gap-2">
              <Download className="w-4 h-4 text-emerald-600" />
              <span>تثبيت سريع (أندرويد / متصفح كروم)</span>
            </h3>
            <p className="text-xs text-emerald-900">
              {isInstalled ? 'تم تثبيت التطبيق بنجاح على جهازك!' : 'انقر على الزر أدناه لتثبيت التطبيق على شاشتك الرئيسية.'}
            </p>
            {!isInstalled && (
              <button
                onClick={handleInstallClick}
                className="w-full mt-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs py-3 rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>تثبيت التطبيق الآن</span>
              </button>
            )}
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <h3 className="font-black text-xs text-slate-900 flex items-center gap-2">
              <Apple className="w-4 h-4 text-slate-800" />
              <span>تثبيت على أجهزة آيفون (iOS Safari)</span>
            </h3>
            <ol className="text-xs text-slate-600 space-y-1.5 list-decimal list-inside font-bold">
              <li>اضغط على زر المشاركة <Share className="w-3.5 h-3.5 inline mx-1 text-blue-600" /> في متصفح Safari.</li>
              <li>انقر على خيار <span className="text-emerald-700">"إضافة إلى الشاشة الرئيسية" (Add to Home Screen)</span> <PlusSquare className="w-3.5 h-3.5 inline mx-1" />.</li>
              <li>اضغط "إضافة" لتجد الأيقونة جاهزة على شاشتك.</li>
            </ol>
          </div>

          {/* Notifications Subscription Section */}
          <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-indigo-600 animate-bounce" />
                <span className="font-black text-xs text-indigo-950">استقبال الإشعارات الفورية والتنبيهات</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationsEnabled}
                  onChange={(e) => setNotificationsEnabled(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>
            <p className="text-[11px] text-indigo-900">
              سيتم إرسال إشعارات العروض والأنشطة مباشرة لهاتفك عند قيام الإدارة ببث التنبيهات.
            </p>
          </div>

          {/* Recent Notifications Inbox */}
          <div className="space-y-2">
            <h4 className="font-black text-xs text-slate-900">آخر الإشعارات المرسلة من الإدارة:</h4>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {notificationsList.map((n) => (
                <div key={n.id} className="p-3 bg-white rounded-xl border border-slate-200 text-xs shadow-xs space-y-1">
                  <div className="font-black text-slate-900 flex items-center justify-between">
                    <span>{n.title}</span>
                    <span className="text-[10px] text-slate-400 font-normal">
                      {new Date(n.timestamp).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-slate-600 text-[11px]">{n.body}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
