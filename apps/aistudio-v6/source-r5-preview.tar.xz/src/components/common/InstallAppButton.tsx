import React, { useState } from 'react';
import { Smartphone, Download } from 'lucide-react';
import { InstallAppModal } from './InstallAppModal';

interface InstallAppButtonProps {
  className?: string;
  variant?: 'navbar' | 'dashboard' | 'floating';
}

export const InstallAppButton: React.FC<InstallAppButtonProps> = ({ className = '', variant = 'navbar' }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setIsModalOpen(true)}
        className={
          className ||
          (variant === 'dashboard'
            ? 'bg-slate-800 hover:bg-slate-700 text-emerald-300 font-bold text-xs px-3 py-2 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer border border-emerald-500/30 shadow-xs'
            : 'text-emerald-400 hover:text-emerald-300 font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer bg-emerald-950/40 px-2.5 py-1 rounded-md border border-emerald-500/30')
        }
        title="تثبيت التطبيق على الموبايل أو الآيفون واستقبال الإشعارات"
      >
        <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
        <span>تثبيت البرنامج</span>
      </button>

      <InstallAppModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
};
