import React, { useState } from 'react';
import { Sparkles, X, Image as ImageIcon, Check, Loader2 } from 'lucide-react';

interface GeminiImageModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectImage: (imageUrl: string) => void;
  defaultPrompt?: string;
}

export const GeminiImageModal: React.FC<GeminiImageModalProps> = ({
  isOpen,
  onClose,
  onSelectImage,
  defaultPrompt = '',
}) => {
  const [prompt, setPrompt] = useState(defaultPrompt || 'صيدلية حديثة مضيئة وأنيقة مع أرفف أدوية منظمة');
  const [isLoading, setIsLoading] = useState(false);
  const [generatedUrl, setGeneratedUrl] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    setIsLoading(true);
    setErrorMsg('');

    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      if (data.success && data.imageUrl) {
        setGeneratedUrl(data.imageUrl);
      } else {
        setErrorMsg(data.error || 'فشل توليد الصورة بالذكاء الاصطناعي.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'حدث خطأ أثناء الاتصال بخدمة الذكاء الاصطناعي.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 text-right shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-emerald-500/25">
            <Sparkles className="w-6 h-6 text-amber-300 animate-pulse" />
          </div>
          <div>
            <h2 className="font-black text-lg text-slate-900">توليد الصور بالذكاء الاصطناعي (Gemini AI)</h2>
            <p className="text-xs text-slate-500">ارتباط تلقائي مع نموذج Gemini لإنشاء صور احترافية للأنشطة والمنتجات.</p>
          </div>
        </div>

        <form onSubmit={handleGenerate} className="space-y-4">
          <div>
            <label className="block text-xs font-black text-slate-700 mb-1.5">اكتب وصف الصورة المطلوبة (Prompt):</label>
            <div className="flex gap-2">
              <input
                type="text"
                required
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="مثال: واجهة مطعم شرقي فخم مع أطباق شهية وإضاءة دافئة..."
                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold text-slate-900 focus:outline-hidden"
              />
              <button
                type="submit"
                disabled={isLoading}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs px-5 py-3 rounded-xl shadow-md cursor-pointer flex items-center gap-2 flex-shrink-0 disabled:opacity-50"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4 text-amber-300" />}
                <span>{isLoading ? 'جاري التوليد...' : 'توليد بالذكاء الاصطناعي'}</span>
              </button>
            </div>
          </div>
        </form>

        {errorMsg && (
          <div className="p-3 bg-rose-50 text-rose-700 rounded-xl text-xs font-bold border border-rose-200">
            {errorMsg}
          </div>
        )}

        {generatedUrl && (
          <div className="space-y-3 pt-3 border-t border-slate-100">
            <div className="font-black text-xs text-slate-900">الصورة الناتجة من Gemini AI:</div>
            <div className="relative h-64 rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 shadow-sm">
              <img src={generatedUrl} alt="Generated AI" className="w-full h-full object-cover" />
              <div className="absolute top-3 right-3 bg-emerald-600 text-white text-[10px] font-black px-3 py-1 rounded-full shadow-md flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>جاهزة ومولدة تلقائياً</span>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  onSelectImage(generatedUrl);
                  onClose();
                }}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs py-3 rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>اعتماد واستخدام هذه الصورة في النظام</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
