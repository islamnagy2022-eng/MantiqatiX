import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { AdRequestType, GeneratedMarketingCampaign, MarketingCampaignGoal } from '../../types';
import { DEFAULT_BUSINESS_COVER_URL } from '../../utils/rules';
import {
  Sparkles,
  Megaphone,
  X,
  Copy,
  Check,
  Send,
  Tag,
  Video,
  Share2,
  CheckCircle2,
  LayoutGrid,
} from 'lucide-react';

export const SmartMarketingModal: React.FC = () => {
  const {
    businesses,
    smartMarketingTargetBiz,
    setSmartMarketingTargetBiz,
    generatedCampaigns,
    generateMarketingForBusiness,
    publishCampaignAsFreeAdminAd,
  } = useApp();

  const [selectedBizId, setSelectedBizId] = useState<string>('');
  const [goal, setGoal] = useState<MarketingCampaignGoal>('sales_boost');
  const [discountPercent, setDiscountPercent] = useState<number>(30);
  const [customOfferText, setCustomOfferText] = useState<string>('');
  const [activeCampaign, setActiveCampaign] = useState<GeneratedMarketingCampaign | null>(null);
  const [copiedChannel, setCopiedChannel] = useState<string | null>(null);
  const [publishSuccessMsg, setPublishSuccessMsg] = useState<string | null>(null);
  const [durationDays, setDurationDays] = useState<number>(14);

  useEffect(() => {
    if (smartMarketingTargetBiz) {
      setSelectedBizId(smartMarketingTargetBiz.id);
      const existing = generatedCampaigns.find((c) => c.businessId === smartMarketingTargetBiz.id);
      if (existing) {
        setActiveCampaign(existing);
      } else {
        const fresh = generateMarketingForBusiness(smartMarketingTargetBiz.id, {
          goal: 'sales_boost',
          discountPercent: 30,
        });
        setActiveCampaign(fresh);
      }
      setPublishSuccessMsg(null);
    }
  }, [smartMarketingTargetBiz]);

  if (!smartMarketingTargetBiz) return null;

  const currentBiz = businesses.find((b) => b.id === selectedBizId) || smartMarketingTargetBiz;

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    const campaign = generateMarketingForBusiness(currentBiz.id, {
      goal,
      discountPercent,
      customOfferText,
    });
    if (campaign) {
      setActiveCampaign(campaign);
      setPublishSuccessMsg(null);
    }
  };

  const handlePublishFreeSponsoredAd = (adType: AdRequestType) => {
    if (!activeCampaign) return;
    const res = publishCampaignAsFreeAdminAd(activeCampaign.id, adType, durationDays);
    if (res.success) {
      setPublishSuccessMsg(
        `تم نشر الإعلان الممول الداخلي (بنر مربع) لنشاط "${currentBiz.name}" مجاناً للإدارة (0 ج.م) لمدة ${durationDays} يوماً!`
      );
    }
  };

  const copyText = (key: string, text: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedChannel(key);
      setTimeout(() => setCopiedChannel(null), 2000);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      dir="rtl"
    >
      <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-950 via-purple-900 to-slate-900 text-white p-5 sm:p-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-lg">
              <Megaphone className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-black text-base sm:text-lg text-white">
                  منظومة التسويق الذكي وتوليد محتوى الإعلانات الممولة لكل نشاط
                </h2>
                <span className="bg-emerald-500 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full">
                  مجاني 100% للإدارة (0 ج.م)
                </span>
              </div>
              <p className="text-xs text-purple-200 mt-0.5">
                توليد فوري لمحتوى الإعلانات الممولة المربعة، فيسبوك، واتساب، وريلز مع نشر مباشر مجاني للإدارة
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setSmartMarketingTargetBiz(null)}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer"
            aria-label="إغلاق نافذة التسويق الذكي"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6 max-h-[78vh] overflow-y-auto">
          {/* Generator Controls Form */}
          <form onSubmit={handleGenerate} className="bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">اختر النشاط المستهدف للتسويق</label>
                <select
                  value={currentBiz.id}
                  onChange={(e) => {
                    const found = businesses.find((b) => b.id === e.target.value);
                    if (found) {
                      setSelectedBizId(found.id);
                      const fresh = generateMarketingForBusiness(found.id, { goal, discountPercent, customOfferText });
                      setActiveCampaign(fresh);
                    }
                  }}
                  className="w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs font-black text-slate-900 cursor-pointer"
                >
                  {businesses.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.category} - {b.governorate})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">هدف الحملة التسويقية</label>
                <select
                  value={goal}
                  onChange={(e) => setGoal(e.target.value as MarketingCampaignGoal)}
                  className="w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs font-black text-slate-900 cursor-pointer"
                >
                  <option value="sales_boost">مضاعفة المبيعات والطلبات الفورية</option>
                  <option value="grand_opening">إعلان افتتاح وعروض ترحيبية</option>
                  <option value="seasonal_offer">مهرجان خصومات وعروض موسمية</option>
                  <option value="brand_awareness">تعزيز الهوية والانتشار بالمحافظة</option>
                  <option value="service_booking">تشجيع الحجز المسبق للخدمات</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">نسبة الخصم الترويجي المقترحة (%)</label>
                <input
                  type="number"
                  min={5}
                  max={80}
                  value={discountPercent}
                  onChange={(e) => setDiscountPercent(Number(e.target.value))}
                  className="w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs font-black text-slate-900"
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <input
                type="text"
                value={customOfferText}
                onChange={(e) => setCustomOfferText(e.target.value)}
                placeholder="ميزة إضافية للحملة (مثال: توصيل مجاني لأول 50 عميل في المنصورة)..."
                className="flex-1 w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900"
              />
              <button
                type="submit"
                className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs px-5 py-2.5 rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>توليد محتوى تسويقي شامل للنشاط</span>
              </button>
            </div>
          </form>

          {publishSuccessMsg && (
            <div className="bg-emerald-50 border border-emerald-300 text-emerald-950 p-4 rounded-2xl text-xs font-black flex items-center gap-2 shadow-xs">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>{publishSuccessMsg}</span>
            </div>
          )}

          {activeCampaign && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
              {/* Left Column: Square Sponsored Banner Live Preview (1:1 Aspect Square) */}
              <div className="lg:col-span-5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                    <LayoutGrid className="w-4 h-4 text-amber-600" />
                    <span>معاينة البنر الإعلاني المربع (1:1)</span>
                  </span>
                  <span className="text-[10px] font-black bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full">
                    كود الخصم: {activeCampaign.promoCode}
                  </span>
                </div>

                <div className="aspect-square w-full rounded-3xl overflow-hidden relative shadow-xl border-2 border-amber-400/80 bg-slate-900 flex flex-col justify-between p-5 text-white">
                  <img
                    src={currentBiz.coverUrl || DEFAULT_BUSINESS_COVER_URL}
                    alt={currentBiz.name}
                    className="absolute inset-0 w-full h-full object-cover opacity-45"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-slate-950/30" />

                  <div className="relative z-10 flex items-center justify-between gap-2">
                    <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2.5 py-1 rounded-full shadow-xs">
                      إعلان ممول • خصم {activeCampaign.discountPercent}%
                    </span>
                    <span className="bg-white/15 backdrop-blur-xs text-white text-[10px] font-black px-2.5 py-1 rounded-full border border-white/20">
                      كود: {activeCampaign.promoCode}
                    </span>
                  </div>

                  <div className="relative z-10 space-y-2 my-auto py-3">
                    <div className="text-xs font-black text-amber-300">{currentBiz.name}</div>
                    <h4 className="font-black text-base sm:text-lg leading-snug text-white">
                      {activeCampaign.headline}
                    </h4>
                    <p className="text-xs text-slate-200 line-clamp-3 leading-relaxed">
                      {activeCampaign.sponsoredAdCopy}
                    </p>
                  </div>

                  <div className="relative z-10 pt-2 border-t border-white/15 flex items-center justify-between gap-2">
                    <span className="text-[10px] text-emerald-300 font-bold truncate">
                      {currentBiz.governorate} • {currentBiz.markaz}
                    </span>
                    <span className="bg-emerald-500 text-slate-950 text-[11px] font-black px-3 py-1.5 rounded-xl">
                      {activeCampaign.ctaText}
                    </span>
                  </div>
                </div>

                {/* One-Click Free Admin Publishing Controls */}
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs font-black text-amber-950">
                    <span>نشر الإعلان الممول مجاناً للإدارة:</span>
                    <select
                      value={durationDays}
                      onChange={(e) => setDurationDays(Number(e.target.value))}
                      className="bg-white border border-amber-300 rounded-lg px-2 py-1 text-xs font-black cursor-pointer"
                    >
                      <option value={7}>7 أيام (مجاني 0 ج.م)</option>
                      <option value={14}>14 يوماً (مجاني 0 ج.م)</option>
                      <option value={30}>30 يوماً (مجاني 0 ج.م)</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-1 gap-2">
                    <button
                      type="button"
                      onClick={() => handlePublishFreeSponsoredAd('sponsored_ad')}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs py-3 rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                    >
                      <Send className="w-4 h-4" />
                      <span>نشر فوراً كبنر إعلان ممول مربع مجاني للإدارة (0 ج.م)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePublishFreeSponsoredAd('billboard_banner')}
                      className="w-full bg-slate-900 hover:bg-slate-800 text-amber-300 font-black text-xs py-2.5 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>نشر كيافطة إعلانية معتمدة مجاناً للإدارة (0 ج.م)</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column: Generated Multi-Channel Marketing Copies */}
              <div className="lg:col-span-7 space-y-4">
                {/* 1. Sponsored Ad Copy */}
                <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-2 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-indigo-900 flex items-center gap-1.5">
                      <Megaphone className="w-4 h-4 text-indigo-600" />
                      <span>1. نص الإعلان الممول الداخلي بالمنصة</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => copyText('sponsored', activeCampaign.sponsoredAdCopy)}
                      className="text-[11px] font-black bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      {copiedChannel === 'sponsored' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedChannel === 'sponsored' ? 'تم النسخ' : 'نسخ النص'}</span>
                    </button>
                  </div>
                  <p className="text-xs text-slate-700 bg-slate-50 p-3 rounded-xl leading-relaxed font-medium">
                    {activeCampaign.sponsoredAdCopy}
                  </p>
                </div>

                {/* 2. Facebook & Instagram Ad Copy */}
                <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-2 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-blue-900 flex items-center gap-1.5">
                      <Share2 className="w-4 h-4 text-blue-600" />
                      <span>2. منشور إعلان ممول (فيسبوك وإنستجرام) جاهز للنشر</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => copyText('fb', activeCampaign.facebookInstagramCopy)}
                      className="text-[11px] font-black bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      {copiedChannel === 'fb' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedChannel === 'fb' ? 'تم النسخ' : 'نسخ المنشور'}</span>
                    </button>
                  </div>
                  <pre className="text-xs text-slate-700 bg-slate-50 p-3 rounded-xl leading-relaxed whitespace-pre-wrap font-sans">
                    {activeCampaign.facebookInstagramCopy}
                  </pre>
                </div>

                {/* 3. WhatsApp Broadcast Copy */}
                <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-2 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-emerald-900 flex items-center gap-1.5">
                      <Send className="w-4 h-4 text-emerald-600" />
                      <span>3. رسالة حملة الواتساب الترويجية للعملاء</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => copyText('wa', activeCampaign.whatsappBroadcastCopy)}
                      className="text-[11px] font-black bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      {copiedChannel === 'wa' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedChannel === 'wa' ? 'تم النسخ' : 'نسخ الرسالة'}</span>
                    </button>
                  </div>
                  <pre className="text-xs text-slate-700 bg-emerald-50/50 p-3 rounded-xl leading-relaxed whitespace-pre-wrap font-sans">
                    {activeCampaign.whatsappBroadcastCopy}
                  </pre>
                </div>

                {/* 4. Reels / TikTok Script */}
                <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-2 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-rose-900 flex items-center gap-1.5">
                      <Video className="w-4 h-4 text-rose-600" />
                      <span>4. سكريبت فيديو ريلز وتيك توك ترويجي</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => copyText('reels', activeCampaign.reelsVideoScript)}
                      className="text-[11px] font-black bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      {copiedChannel === 'reels' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedChannel === 'reels' ? 'تم النسخ' : 'نسخ السكريبت'}</span>
                    </button>
                  </div>
                  <pre className="text-xs text-slate-700 bg-rose-50/40 p-3 rounded-xl leading-relaxed whitespace-pre-wrap font-sans">
                    {activeCampaign.reelsVideoScript}
                  </pre>
                </div>

                {/* Target Audience & SEO Tags */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[11px] font-black text-slate-600 flex items-center gap-1">
                    <Tag className="w-3.5 h-3.5 text-indigo-600" />
                    <span>الجمهور المستهدف:</span>
                  </span>
                  {activeCampaign.targetAudience.map((aud, i) => (
                    <span
                      key={i}
                      className="text-[10px] font-bold bg-indigo-50 text-indigo-800 px-2.5 py-1 rounded-full border border-indigo-200"
                    >
                      {aud}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
