import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  getAllSectorDevelopmentBlueprints,
  getSectorDevelopmentBlueprint,
  resolveBusinessSectorLevel,
  generateSectorToolWhatsAppActionUrl,
} from '../../utils/rules';
import { FunctionalGroupId, SectorInteractiveTool, SectorPackageLevel } from '../../types';
import {
  X,
  Layers,
  CheckCircle2,
  Sparkles,
  Rocket,
  Crown,
  ShieldCheck,
  TrendingUp,
  MessageCircle,
  Wallet,
  Zap,
  Lock,
  ExternalLink,
  Store,
} from 'lucide-react';

export const SectorDevelopmentModal: React.FC = () => {
  const {
    sectorDevelopmentTargetGroup,
    setSectorDevelopmentTargetGroup,
    sectorDevelopmentTargetBiz,
    setSectorDevelopmentTargetBiz,
    businesses,
    upgradeBusinessSectorPackage,
    authSession,
    setSelectedBusinessId,
    setCurrentView,
  } = useApp();

  const [selectedBizId, setSelectedBizId] = useState<string>('');
  const [paymentMode, setPaymentMode] = useState<'admin_free' | 'wallet'>('admin_free');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Interactive Tool Runner state
  const [activeTool, setActiveTool] = useState<SectorInteractiveTool | null>(null);
  const [toolCustomInput, setToolCustomInput] = useState<string>('');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');

  const allBlueprints = React.useMemo(() => getAllSectorDevelopmentBlueprints(), []);

  useEffect(() => {
    if (!sectorDevelopmentTargetGroup) return;
    setFeedbackMsg(null);
    const sectorBizList = businesses.filter((b) => b.functionalGroupId === sectorDevelopmentTargetGroup);
    if (sectorDevelopmentTargetBiz && sectorDevelopmentTargetBiz.functionalGroupId === sectorDevelopmentTargetGroup) {
      setSelectedBizId(sectorDevelopmentTargetBiz.id);
    } else if (sectorBizList.length > 0) {
      setSelectedBizId(sectorBizList[0].id);
    } else if (businesses.length > 0) {
      setSelectedBizId(businesses[0].id);
    }
    const bp = getSectorDevelopmentBlueprint(sectorDevelopmentTargetGroup);
    setActiveTool(bp.interactiveTools[0] || null);
    setToolCustomInput('');
  }, [sectorDevelopmentTargetGroup, sectorDevelopmentTargetBiz, businesses]);

  if (!sectorDevelopmentTargetGroup) return null;

  const blueprint = getSectorDevelopmentBlueprint(sectorDevelopmentTargetGroup);
  const sectorBusinesses = businesses.filter((b) => b.functionalGroupId === sectorDevelopmentTargetGroup);
  const activeBusiness =
    businesses.find((b) => b.id === selectedBizId) || sectorBusinesses[0] || businesses[0];
  const currentBizLevel: SectorPackageLevel = activeBusiness
    ? resolveBusinessSectorLevel(activeBusiness)
    : 1;
  const isAdmin = authSession.role === 'admin' || authSession.role === 'super_admin';

  const handleClose = () => {
    setSectorDevelopmentTargetGroup(null);
    setSectorDevelopmentTargetBiz(null);
    setFeedbackMsg(null);
  };

  const handleUpgradeTier = (level: SectorPackageLevel) => {
    if (!activeBusiness) return;
    const res = upgradeBusinessSectorPackage(activeBusiness.id, level, paymentMode);
    setFeedbackMsg({
      type: res.success ? 'success' : 'error',
      text: res.message,
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
      dir="rtl"
    >
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[94vh] overflow-y-auto shadow-2xl border border-slate-200 flex flex-col">
        {/* Top Sticky Header */}
        <div className="sticky top-0 z-30 bg-gradient-to-l from-slate-900 via-emerald-950 to-slate-900 text-white p-4 sm:p-6 border-b border-emerald-500/30 flex items-start justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[11px] font-black px-3 py-0.5 rounded-full">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>تطوير القطاعات الـ 15 • منظومة الباقات الثلاثية المتخصصة (3 مستويات)</span>
            </div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="text-2xl sm:text-3xl">{blueprint.emoji}</span>
              <h2 className="text-lg sm:text-2xl font-black text-white">
                {blueprint.shortName} — {blueprint.fullName}
              </h2>
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-black px-2.5 py-0.5 rounded-lg">
                {sectorBusinesses.length} نشاط مسجل بالقطاع
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              {blueprint.valueProposition}
            </p>
          </div>

          <button
            type="button"
            onClick={handleClose}
            className="w-9 h-9 rounded-2xl bg-white/10 hover:bg-rose-600 text-white flex items-center justify-center transition-colors shrink-0 cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* All 15 Sectors Quick Switcher Strip */}
        <div className="bg-slate-100 px-4 py-3 border-b border-slate-200">
          <div className="text-[11px] font-black text-slate-500 mb-2 flex items-center justify-between">
            <span>تنقل بين الـ 15 قطاعاً لاستعراض التطوير الخاص والـ 3 باقات لكل مجال:</span>
            <span className="text-emerald-700 font-bold">اختر القطاع</span>
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {allBlueprints.map((bp) => {
              const count = businesses.filter((b) => b.functionalGroupId === bp.functionalGroupId).length;
              const isCurrent = bp.functionalGroupId === sectorDevelopmentTargetGroup;
              return (
                <button
                  key={bp.functionalGroupId}
                  type="button"
                  onClick={() => setSectorDevelopmentTargetGroup(bp.functionalGroupId as FunctionalGroupId)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black whitespace-nowrap flex items-center gap-1.5 transition-all cursor-pointer shrink-0 border ${
                    isCurrent
                      ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-400'
                  }`}
                >
                  <span>{bp.emoji}</span>
                  <span>{bp.shortName}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-md ${
                      isCurrent ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Content Body */}
        <div className="p-4 sm:p-6 space-y-6 bg-slate-50/60">
          {/* Top KPI & Base Capabilities Summary */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 bg-white p-4 rounded-2xl border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-black text-slate-900">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>الأساس الموحد المتوفر في المنصة (بالإضافة لخصائص القطاع أدناه):</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {blueprint.basePlatformCapabilities.map((cap, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-1.5 text-[11px] font-bold text-slate-600 bg-slate-50 p-2 rounded-xl border border-slate-100"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{cap}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-emerald-900 to-slate-900 text-white p-4 rounded-2xl border border-emerald-500/30 flex flex-col justify-between space-y-3">
              <div className="flex items-center gap-2 text-xs font-black text-emerald-300">
                <TrendingUp className="w-4 h-4" />
                <span>مؤشرات النمو المتوقعة لقطاع {blueprint.shortName}</span>
              </div>
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between bg-white/10 px-3 py-1.5 rounded-xl">
                  <span className="text-slate-300">نمو المبيعات والحجوزات:</span>
                  <span className="font-black text-amber-300">{blueprint.growthMetrics.avgSalesBoost}</span>
                </div>
                <div className="flex items-center justify-between bg-white/10 px-3 py-1.5 rounded-xl">
                  <span className="text-slate-300">الكفاءة التشغيلية:</span>
                  <span className="font-black text-emerald-300">{blueprint.growthMetrics.operationalSaving}</span>
                </div>
                <div className="flex items-center justify-between bg-white/10 px-3 py-1.5 rounded-xl">
                  <span className="text-slate-300">ولاء وتكرار العملاء:</span>
                  <span className="font-black text-sky-300">{blueprint.growthMetrics.retentionRate}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Target Business Selector Bar for Applying / Testing Sector Packages */}
          <div className="bg-white p-4 rounded-2xl border border-indigo-200 shadow-2xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-black">
                <Store className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-black text-slate-900">
                  اختر النشاط لتطبيق أو ترقية باقة القطاع (3 مستويات) وتجربة أدواته:
                </div>
                <div className="text-[11px] font-bold text-slate-500">
                  يمكنك ترقية أي نشاط فوراً لفتح خدمات المستوى الثاني أو الثالث (VIP)
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
              <select
                value={activeBusiness?.id || ''}
                onChange={(e) => setSelectedBizId(e.target.value)}
                className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-black text-slate-900 min-w-[220px]"
              >
                {sectorBusinesses.length > 0 ? (
                  sectorBusinesses.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.governorate}) — المستوى الحالي: {resolveBusinessSectorLevel(b)}
                    </option>
                  ))
                ) : (
                  businesses.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.category}) — المستوى الحالي: {resolveBusinessSectorLevel(b)}
                    </option>
                  ))
                )}
              </select>

              <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-[11px] font-black">
                <button
                  type="button"
                  onClick={() => setPaymentMode('admin_free')}
                  className={`px-2.5 py-1.5 rounded-lg cursor-pointer transition-all ${
                    paymentMode === 'admin_free'
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'text-slate-600'
                  }`}
                >
                  {isAdmin ? 'منحة الإدارة مجاناً (0 ج.م)' : 'تفعيل تجريبي فوري (0 ج.م)'}
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMode('wallet')}
                  className={`px-2.5 py-1.5 rounded-lg cursor-pointer transition-all flex items-center gap-1 ${
                    paymentMode === 'wallet'
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'text-slate-600'
                  }`}
                >
                  <Wallet className="w-3 h-3" />
                  <span>خصم من المحفظة</span>
                </button>
              </div>

              {activeBusiness && (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedBusinessId(activeBusiness.id);
                    setCurrentView('public_storefront');
                    handleClose();
                  }}
                  className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-black px-3 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  <span>فتح صفحة النشاط</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {feedbackMsg && (
            <div
              className={`p-3.5 rounded-2xl border text-xs font-black flex items-center justify-between ${
                feedbackMsg.type === 'success'
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                  : 'bg-rose-50 border-rose-300 text-rose-900'
              }`}
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{feedbackMsg.text}</span>
              </div>
              <button
                type="button"
                onClick={() => setFeedbackMsg(null)}
                className="text-slate-500 hover:text-slate-800 px-2 cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}

          {/* =========================================================================
              THE 3-TIER PACKAGE COMPARISON CARDS FOR THIS SECTOR (باقات 3 مستويات)
             ========================================================================= */}
          <div className="space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-700" />
                <h3 className="font-black text-base sm:text-lg text-slate-900">
                  باقات التطوير الثلاثية لقطاع ({blueprint.shortName}) — 3 مستويات لخدمات أعلى وأقوى
                </h3>
              </div>
              <span className="text-xs font-bold text-slate-500">
                كل مستوى يفتح أدوات تشغيلية وتسويقية وتمويلية أقوى لنشاطك
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              {blueprint.tiers.map((tier) => {
                const isCurrentTier = currentBizLevel === tier.level;
                const isLevel3 = tier.level === 3;
                const isLevel2 = tier.level === 2;

                return (
                  <div
                    key={tier.level}
                    className={`rounded-3xl border p-5 flex flex-col justify-between transition-all relative ${
                      isLevel3
                        ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-indigo-950 text-white border-amber-400/60 shadow-xl'
                        : isLevel2
                        ? 'bg-white text-slate-900 border-emerald-500 shadow-lg ring-2 ring-emerald-500/20'
                        : 'bg-white text-slate-900 border-slate-200 shadow-xs'
                    }`}
                  >
                    <div className="space-y-4">
                      {/* Header & Badge */}
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className={`text-[11px] font-black px-3 py-1 rounded-full flex items-center gap-1 ${
                            isLevel3
                              ? 'bg-amber-400 text-slate-950'
                              : isLevel2
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {isLevel3 ? (
                            <Crown className="w-3.5 h-3.5" />
                          ) : isLevel2 ? (
                            <Rocket className="w-3.5 h-3.5" />
                          ) : (
                            <Zap className="w-3.5 h-3.5" />
                          )}
                          <span>{tier.badgeText}</span>
                        </span>

                        {isCurrentTier && (
                          <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-400/40 text-[10px] font-black px-2.5 py-0.5 rounded-lg">
                            الباقة المفعلة حالياً ✓
                          </span>
                        )}
                      </div>

                      <div>
                        <h4
                          className={`font-black text-base sm:text-lg leading-snug ${
                            isLevel3 ? 'text-white' : 'text-slate-900'
                          }`}
                        >
                          {tier.name}
                        </h4>
                        <p
                          className={`text-xs mt-1 leading-relaxed ${
                            isLevel3 ? 'text-slate-300' : 'text-slate-500'
                          }`}
                        >
                          {tier.operationalPowerSummary}
                        </p>
                      </div>

                      {/* Price & Core Quotas */}
                      <div
                        className={`p-3.5 rounded-2xl border space-y-2 ${
                          isLevel3
                            ? 'bg-white/5 border-white/10'
                            : 'bg-slate-50 border-slate-200/80'
                        }`}
                      >
                        <div className="flex items-baseline justify-between">
                          <div>
                            <span
                              className={`text-2xl font-black ${
                                isLevel3 ? 'text-amber-300' : 'text-emerald-700'
                              }`}
                            >
                              {tier.monthlyFeeEgp === 0 ? 'مجاناً (0 ج.م)' : `${tier.monthlyFeeEgp} ج.م`}
                            </span>
                            {tier.monthlyFeeEgp > 0 && (
                              <span
                                className={`text-[11px] font-bold mr-1 ${
                                  isLevel3 ? 'text-slate-400' : 'text-slate-500'
                                }`}
                              >
                                / شهرياً
                              </span>
                            )}
                          </div>
                          <span
                            className={`text-[11px] font-black px-2 py-0.5 rounded-md ${
                              isLevel3
                                ? 'bg-amber-400/20 text-amber-300'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            عمولة {tier.commissionPercentage}% + {tier.commissionFixedEgp} ج.م
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-1.5 pt-2 border-t border-slate-200/20 text-[11px] font-bold">
                          <div>• حتى {tier.maxProducts} منتج/خدمة</div>
                          <div>• حتى {tier.maxBranches} فروع للنشاط</div>
                          <div>• ائتمان محفظة: {tier.creditLimitEgp.toLocaleString('ar-EG')} ج.م</div>
                          <div>• {tier.freeSponsoredAdsPerMonth} إعلانات مربعة/شهر</div>
                        </div>
                      </div>

                      {/* Sector Exclusive Features */}
                      <div className="space-y-2">
                        <div
                          className={`text-xs font-black ${
                            isLevel3 ? 'text-amber-300' : 'text-slate-800'
                          }`}
                        >
                          الخدمات الإضافية المتخصصة لقطاع ({blueprint.shortName}):
                        </div>
                        <ul className="space-y-2">
                          {tier.sectorExclusiveFeatures.map((feat, fIdx) => (
                            <li key={fIdx} className="flex items-start gap-2 text-xs leading-relaxed">
                              <CheckCircle2
                                className={`w-4 h-4 shrink-0 mt-0.5 ${
                                  isLevel3
                                    ? 'text-amber-400'
                                    : isLevel2
                                    ? 'text-emerald-600'
                                    : 'text-slate-600'
                                }`}
                              />
                              <span className={isLevel3 ? 'text-slate-200 font-semibold' : 'text-slate-700 font-semibold'}>
                                {feat}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Action Button */}
                    <div className="pt-5 mt-4 border-t border-slate-200/20">
                      <button
                        type="button"
                        onClick={() => handleUpgradeTier(tier.level)}
                        className={`w-full py-3 px-4 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                          isCurrentTier
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                            : isLevel3
                            ? 'bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 text-slate-950'
                            : isLevel2
                            ? 'bg-slate-900 hover:bg-emerald-700 text-white'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-900'
                        }`}
                      >
                        <Sparkles className="w-4 h-4" />
                        <span>
                          {isCurrentTier
                            ? `مفعّل حالياً لـ (${activeBusiness?.name || 'النشاط'}) — إعادة تأكيد`
                            : `ترقية وتفعيل المستوى ${tier.level} الآن`}
                        </span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* =========================================================================
              INTERACTIVE SECTOR OPERATIONAL TOOLS SIMULATOR & WHATSAPP LAUNCHER
             ========================================================================= */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-500" />
                <h3 className="font-black text-base text-slate-900">
                  مشغل الأدوات التفاعلية المتخصصة لقطاع ({blueprint.shortName})
                </h3>
              </div>
              <span className="text-xs font-bold text-slate-500">
                جرب الأدوات العملية التي تفتح للنشاط والعملاء حسب مستوى الباقة (1 أو 2 أو 3)
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {blueprint.interactiveTools.map((tool) => {
                const isUnlocked = currentBizLevel >= tool.requiredLevel;
                const isSelectedTool = activeTool?.id === tool.id;

                return (
                  <button
                    key={tool.id}
                    type="button"
                    onClick={() => setActiveTool(tool)}
                    className={`p-4 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                      isSelectedTool
                        ? 'bg-slate-900 text-white border-slate-900 shadow-md'
                        : isUnlocked
                        ? 'bg-emerald-50/40 border-emerald-200 text-slate-800 hover:border-emerald-400'
                        : 'bg-slate-50 border-slate-200 text-slate-500 hover:border-amber-400'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 w-full">
                      <span
                        className={`text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 ${
                          isUnlocked
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-amber-500/20 text-amber-600 border border-amber-400/30'
                        }`}
                      >
                        {isUnlocked ? (
                          <>
                            <CheckCircle2 className="w-3 h-3" />
                            <span>متاح (المستوى {tool.requiredLevel})</span>
                          </>
                        ) : (
                          <>
                            <Lock className="w-3 h-3" />
                            <span>يتطلب المستوى {tool.requiredLevel}</span>
                          </>
                        )}
                      </span>
                      <span className="text-[10px] font-black text-amber-500">{tool.kpiImpact}</span>
                    </div>

                    <div>
                      <div className="font-black text-xs sm:text-sm">{tool.title}</div>
                      <p
                        className={`text-[11px] mt-1 leading-relaxed ${
                          isSelectedTool ? 'text-slate-300' : 'text-slate-500'
                        }`}
                      >
                        {tool.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            {activeTool && activeBusiness && (
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="text-xs font-black text-slate-900">
                    تنفيذ مباشر لأداة: <span className="text-emerald-700">{activeTool.title}</span> — لنشاط ({activeBusiness.name})
                  </div>
                  {currentBizLevel < activeTool.requiredLevel && (
                    <button
                      type="button"
                      onClick={() => handleUpgradeTier(activeTool.requiredLevel)}
                      className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-[11px] font-black px-3 py-1 rounded-xl cursor-pointer"
                    >
                      فعل المستوى {activeTool.requiredLevel} لفتح هذه الأداة مجاناً
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="اسم العميل أو مقدم الطلب (اختياري)..."
                    className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold"
                  />
                  <input
                    type="text"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="رقم الهاتف أو الواتساب للتواصل..."
                    className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold"
                  />
                </div>

                <textarea
                  rows={2}
                  value={toolCustomInput}
                  onChange={(e) => setToolCustomInput(e.target.value)}
                  placeholder={activeTool.placeholderHint}
                  className="w-full bg-white border border-slate-200 rounded-xl p-3 text-xs font-semibold"
                />

                <div className="flex items-center justify-end gap-2">
                  <a
                    href={generateSectorToolWhatsAppActionUrl(
                      activeBusiness,
                      activeTool,
                      toolCustomInput,
                      customerName,
                      customerPhone
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-5 py-2.5 rounded-xl shadow-md flex items-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{activeTool.actionLabel} عبر واتساب النشاط</span>
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
