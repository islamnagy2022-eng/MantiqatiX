import React, { useState, useEffect } from 'react';
import {
  CANONICAL_IMAGE_LIBRARY,
  SECTOR_DEFAULT_IMAGES,
  getSectorDefaultLogo,
  getSectorDefaultCover,
  getSectorDefaultProductImage,
} from '../../data/imageAssets';
import { FunctionalGroupId } from '../../types';
import { X, Image as ImageIcon, CheckCircle2, Sparkles, Layers } from 'lucide-react';

export const ImageLibraryModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onSelectImage: (url: string) => void;
  defaultCategory?: string;
  defaultSectorId?: FunctionalGroupId | 'all';
  defaultAssetType?: 'logo' | 'cover' | 'product' | 'all';
}> = ({
  isOpen,
  onClose,
  onSelectImage,
  defaultCategory = 'covers',
  defaultSectorId = 'all',
  defaultAssetType,
}) => {
  const resolveInitialType = (): 'all' | 'logo' | 'cover' | 'product' => {
    if (defaultAssetType) return defaultAssetType;
    if (defaultCategory === 'logos') return 'logo';
    if (defaultCategory === 'covers') return 'cover';
    if (defaultCategory && defaultCategory !== 'all') return 'product';
    return 'all';
  };

  const resolveInitialSector = (): FunctionalGroupId | 'all' => {
    if (defaultSectorId && defaultSectorId !== 'all') return defaultSectorId;
    if (defaultCategory && defaultCategory in SECTOR_DEFAULT_IMAGES) {
      return defaultCategory as FunctionalGroupId;
    }
    return 'all';
  };

  const [selectedAssetType, setSelectedAssetType] = useState<'all' | 'logo' | 'cover' | 'product'>(
    resolveInitialType
  );
  const [selectedSector, setSelectedSector] = useState<FunctionalGroupId | 'all'>(
    resolveInitialSector
  );

  useEffect(() => {
    if (isOpen) {
      setSelectedAssetType(resolveInitialType());
      setSelectedSector(resolveInitialSector());
    }
  }, [isOpen, defaultCategory, defaultSectorId, defaultAssetType]);

  if (!isOpen) return null;

  const filteredImages = CANONICAL_IMAGE_LIBRARY.filter((img) => {
    const matchesType = selectedAssetType === 'all' || img.assetType === selectedAssetType;
    const matchesSector = selectedSector === 'all' || img.sectorId === selectedSector;
    return matchesType && matchesSector;
  });

  const activeSectorPack =
    selectedSector !== 'all' ? SECTOR_DEFAULT_IMAGES[selectedSector] : null;

  const handleQuickApplySectorDefault = () => {
    const targetSector = selectedSector !== 'all' ? selectedSector : defaultSectorId !== 'all' ? defaultSectorId : 'services';
    if (selectedAssetType === 'logo') {
      onSelectImage(getSectorDefaultLogo(targetSector));
    } else if (selectedAssetType === 'cover') {
      onSelectImage(getSectorDefaultCover(targetSector));
    } else {
      onSelectImage(getSectorDefaultProductImage(targetSector));
    }
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4"
      dir="rtl"
    >
      <div className="bg-white rounded-3xl max-w-4xl w-full p-5 sm:p-7 space-y-4 text-right shadow-2xl max-h-[92vh] flex flex-col border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-sm">
              <ImageIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base sm:text-lg text-slate-900">
                مكتبة الصور الافتراضية المعتمدة للأنشطة والمنتجات
              </h3>
              <p className="text-xs text-slate-500 font-bold">
                اختر شعاراً (Logo) أو غلافاً (Cover) أو صورة منتج جاهزة حسب تخصص نشاطك من بين الـ 15 قطاعاً
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 hover:bg-slate-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Active Sector Default Quick Strip */}
        {activeSectorPack && (
          <div className="bg-gradient-to-l from-emerald-950 via-slate-900 to-slate-900 text-white p-3.5 rounded-2xl flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">{activeSectorPack.emoji}</span>
              <div>
                <div className="text-xs font-black text-amber-300 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>الصور الافتراضية الثابتة لقطاع: {activeSectorPack.sectorName}</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  تظهر تلقائياً للنشاط والمنتجات حتى في حال عدم رفع صورة خاصة من صاحب النشاط
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={handleQuickApplySectorDefault}
                className="bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black px-3.5 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs transition-all"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>
                  {selectedAssetType === 'logo'
                    ? 'اعتماد الشعار الافتراضي للمجال'
                    : selectedAssetType === 'cover'
                    ? 'اعتماد الغلاف الافتراضي للمجال'
                    : 'اعتماد الصورة الافتراضية للمجال'}
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Asset Type Filter Tabs */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 pb-3">
          {[
            { id: 'all', label: 'كافة الصور الافتراضية' },
            { id: 'cover', label: '🖼️ أغلفة الأنشطة (Covers)' },
            { id: 'logo', label: '🏷️ شعارات الأنشطة (Logos)' },
            { id: 'product', label: '📦 صور المنتجات والخدمات' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSelectedAssetType(tab.id as 'all' | 'logo' | 'cover' | 'product')}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                selectedAssetType === tab.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* 15 Sectors Filter Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 text-xs font-bold">
          <button
            type="button"
            onClick={() => setSelectedSector('all')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap cursor-pointer transition-all flex items-center gap-1 ${
              selectedSector === 'all'
                ? 'bg-slate-900 text-white font-black'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>كافة الـ 15 مجالاً</span>
          </button>
          {Object.values(SECTOR_DEFAULT_IMAGES).map((pack) => (
            <button
              key={pack.sectorId}
              type="button"
              onClick={() => setSelectedSector(pack.sectorId)}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap cursor-pointer transition-all flex items-center gap-1.5 ${
                selectedSector === pack.sectorId
                  ? 'bg-amber-500 text-slate-950 font-black shadow-2xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>{pack.emoji}</span>
              <span>{pack.sectorName}</span>
            </button>
          ))}
        </div>

        {/* Images Grid */}
        <div className="flex-1 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5 p-1">
          {filteredImages.map((img) => {
            const pack = SECTOR_DEFAULT_IMAGES[img.sectorId];
            return (
              <div
                key={img.id}
                onClick={() => {
                  onSelectImage(img.url);
                  onClose();
                }}
                className="group relative rounded-2xl overflow-hidden border-2 border-slate-200 hover:border-emerald-600 cursor-pointer shadow-xs transition-all bg-slate-100 flex flex-col"
              >
                <div className="relative aspect-video w-full overflow-hidden bg-slate-200">
                  <img
                    src={img.url}
                    alt={img.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 right-2 flex flex-wrap gap-1">
                    {img.isSectorDefault && (
                      <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-lg shadow-xs">
                        افتراضي للمجال ⭐
                      </span>
                    )}
                    <span className="bg-slate-900/80 text-white text-[10px] font-bold px-2 py-0.5 rounded-lg">
                      {img.assetType === 'logo'
                        ? 'شعار Logo'
                        : img.assetType === 'cover'
                        ? 'غلاف Cover'
                        : 'منتج / خدمة'}
                    </span>
                  </div>
                </div>
                <div className="p-2.5 bg-white flex-1 flex flex-col justify-between gap-1">
                  <div className="text-[11px] font-black text-slate-800 group-hover:text-emerald-700 line-clamp-1">
                    {img.title}
                  </div>
                  {pack && (
                    <div className="text-[10px] font-bold text-slate-500 flex items-center justify-between">
                      <span>
                        {pack.emoji} {pack.sectorName}
                      </span>
                      <span className="text-emerald-600 font-black">اختيار ←</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
