import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Business, FunctionalGroupId } from '../../types';
import {
  DEFAULT_BUSINESS_COVER_URL,
  getNonCompetingSponsoredAdsForContext,
} from '../../utils/rules';
import {
  ShieldCheck,
  Megaphone,
  Sparkles,
  Award,
  ExternalLink,
  Ban,
  MapPin,
  ArrowUpRight,
} from 'lucide-react';

export interface RegionalCoverAdItem {
  id?: string;
  image: string;
  badge: string;
  title: string;
  subtitle: string;
  governorates?: string[];
  businessId?: string;
}

interface NonCompetingSponsoredAdsStripProps {
  hostBusiness?: Business | null;
  excludeFunctionalGroupId?: FunctionalGroupId | null;
  pageLabel?: string;
  limit?: number;
  selectedGovernorate?: string;
  regionalCoverAds?: RegionalCoverAdItem[];
}

export const NonCompetingSponsoredAdsStrip: React.FC<NonCompetingSponsoredAdsStripProps> = ({
  hostBusiness = null,
  excludeFunctionalGroupId = null,
  limit = 8,
  selectedGovernorate = 'all',
  regionalCoverAds = [],
}) => {
  const {
    adRequests,
    businesses,
    subscribers,
    products,
    setSelectedBusinessId,
    setCurrentView,
    setAdModalType,
    setSmartMarketingTargetBiz,
  } = useApp();

  // Smart exchange algorithm with >= 50% guaranteed verified subscribers, ranked by package tier, discounts, and photos
  const {
    ads,
    blockedCompetitorsCount,
    hostSectorShortName,
    verifiedSubscribersRatioPercent,
  } = React.useMemo(
    () =>
      getNonCompetingSponsoredAdsForContext({
        adRequests,
        businesses,
        subscribers,
        products,
        hostBusiness,
        excludeFunctionalGroupId,
        limit: Math.max(limit, 8),
      }),
    [adRequests, businesses, subscribers, products, hostBusiness, excludeFunctionalGroupId, limit]
  );

  // Pool of exactly 7 rotating ads for dynamic staggered rotation
  const rotatingAdsPool = React.useMemo(() => {
    if (ads.length === 0) return [];
    if (ads.length >= 7) return ads.slice(0, 7);

    // If fewer than 7 ads, cycle and pad to ensure a full 7-item rotation pool
    const pool = [...ads];
    let i = 0;
    while (pool.length < 7) {
      pool.push({
        ...ads[i % ads.length],
        id: `${ads[i % ads.length].id}_rot_${pool.length}`,
      });
      i++;
    }
    return pool;
  }, [ads]);

  // Main Screen Regional Cover Ads (إعلانات الشاشة الرئيسية بنسبة غلاف الفيس بوك 820/312)
  const resolvedRegionalCoverAds = React.useMemo(() => {
    if (regionalCoverAds && regionalCoverAds.length > 0) {
      return regionalCoverAds;
    }

    const currentGov = selectedGovernorate || hostBusiness?.governorate || 'all';
    const list: RegionalCoverAdItem[] = [];

    // 1. Regional Cover Slides from Main Screen
    const defaultRegionalSlides: RegionalCoverAdItem[] = [
      {
        id: 'cover_info_1',
        image: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=1600&auto=format&fit=crop&q=80',
        badge: 'محتوى تعريفي • دليل الأنشطة',
        title: 'اكتشف الأنشطة والخدمات المتاحة',
        subtitle: 'ابحث حسب التخصص والموقع للوصول إلى صفحات الأنشطة.',
        governorates: ['all'],
      },
      {
        id: 'cover_info_2',
        image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1600&auto=format&fit=crop&q=80',
        badge: 'محتوى تعريفي • الكتالوجات',
        title: 'تصفح صفحات الأنشطة والكتالوجات',
        subtitle: 'راجع المنتجات والخدمات المعروضة في الصفحات المتاحة.',
        governorates: ['all'],
      },
      {
        id: 'cover_info_3',
        image: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=1600&auto=format&fit=crop&q=80',
        badge: 'محتوى تعريفي • البحث المحلي',
        title: 'حدد المحافظة والتخصص',
        subtitle: 'ضيّق نتائج الدليل للوصول إلى الأنشطة ذات الصلة.',
        governorates: ['all'],
      },
    ];

    for (const slide of defaultRegionalSlides) {
      if (currentGov === 'all' || slide.governorates?.includes('all') || slide.governorates?.includes(currentGov)) {
        list.push(slide);
      }
    }

    // 2. Approved billboard_banner ad requests matching non-competing rule
    const billboardAds = adRequests.filter(
      (req) => req.type === 'billboard_banner' && req.status === 'approved'
    );
    for (const bAd of billboardAds) {
      const biz = businesses.find((b) => b.id === bAd.businessId);
      if (excludeFunctionalGroupId && biz?.functionalGroupId === excludeFunctionalGroupId) continue;
      if (hostBusiness && biz?.functionalGroupId === hostBusiness.functionalGroupId) continue;
      list.push({
        id: bAd.id,
        image: bAd.imageUrl || biz?.coverUrl || DEFAULT_BUSINESS_COVER_URL,
        badge: `يافطة إعلانية • ${biz?.governorate || 'معتمد بالمنطقة'}`,
        title: bAd.title,
        subtitle: bAd.description,
        governorates: biz?.governorate ? [biz.governorate, 'all'] : ['all'],
        businessId: biz?.id,
      });
    }

    // 3. Verified regional businesses with rich covers
    for (const biz of businesses) {
      if (!biz.isVerified || !biz.coverUrl) continue;
      if (excludeFunctionalGroupId && biz.functionalGroupId === excludeFunctionalGroupId) continue;
      if (hostBusiness && biz.functionalGroupId === hostBusiness.functionalGroupId) continue;
      if (currentGov !== 'all' && biz.governorate !== currentGov) continue;
      if (list.some((item) => item.businessId === biz.id)) continue;

      list.push({
        id: `biz_cov_${biz.id}`,
        image: biz.coverUrl,
        badge: `نشاط موثق بالمنطقة • ${biz.governorate}`,
        title: biz.name,
        subtitle: biz.bio,
        governorates: [biz.governorate, 'all'],
        businessId: biz.id,
      });
      if (list.length >= 8) break;
    }

    return list.length > 0 ? list : defaultRegionalSlides;
  }, [regionalCoverAds, selectedGovernorate, hostBusiness, adRequests, businesses, excludeFunctionalGroupId]);

  // Dynamic rotation state: 3 seconds (3000ms) across 7 ads
  const [currentAdIndex, setCurrentAdIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Rotate ads every 3 seconds (3000ms) without any loading bar
  useEffect(() => {
    if (rotatingAdsPool.length <= 1 || isPaused) return;
    const interval = setInterval(() => {
      setCurrentAdIndex((prev) => (prev + 1) % rotatingAdsPool.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [rotatingAdsPool.length, isPaused]);

  if (rotatingAdsPool.length === 0) return null;

  // Active top featured ad
  const safeIndex = currentAdIndex % rotatingAdsPool.length;
  const activeAd = rotatingAdsPool[safeIndex] || rotatingAdsPool[0];
  const targetBiz = activeAd.resolvedBusiness;
  const bannerImage = activeAd.imageUrl || targetBiz?.coverUrl || DEFAULT_BUSINESS_COVER_URL;

  const handleSelectAd = (idx: number) => {
    setCurrentAdIndex(idx);
  };

  const handleOpenStorefront = (bizId?: string) => {
    if (bizId) {
      setSelectedBusinessId(bizId);
      setCurrentView('public_storefront');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Stack of 6 secondary slots (each will show a distinct staggered ad from the 7-item pool)
  const secondarySlotsCount = 6;

  return (
    <aside
      id="sponsored-ads-column"
      data-testid="left-sponsored-ads-column"
      aria-label="عمود الإعلانات الممولة بالشمال"
      className="w-full lg:w-80 xl:w-[340px] shrink-0 self-stretch flex flex-col scroll-mt-6"
      dir="rtl"
    >
      <div className="bg-gradient-to-b from-slate-900 via-slate-900 to-emerald-950 p-4 sm:p-5 rounded-3xl border border-amber-400/35 shadow-2xl text-white flex-1 flex flex-col justify-between gap-5">
        <div className="space-y-4">
          {/* Header with Non-Competing & 50% Verified Subscriber Quota Badges */}
          <div className="space-y-2.5 border-b border-white/10 pb-4">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="inline-flex items-center gap-1 bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-black px-2.5 py-0.5 rounded-full">
                <ShieldCheck className="w-3 h-3 text-emerald-400 shrink-0" />
                <span>عمود الإعلانات بالشمال • بدون تعارض 100%</span>
              </span>

              {hostBusiness && (
                <span className="inline-flex items-center gap-1 bg-rose-500/20 text-rose-200 border border-rose-400/30 text-[10px] font-black px-2.5 py-0.5 rounded-full">
                  <Ban className="w-3 h-3 text-rose-400 shrink-0" />
                  <span>
                    محظور منافسو ({hostSectorShortName})
                    {blockedCompetitorsCount > 0 ? ` • حجب ${blockedCompetitorsCount}` : ''}
                  </span>
                </span>
              )}
            </div>

            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h2 className="font-black text-sm sm:text-base text-white flex items-center gap-2 leading-snug">
                <Megaphone className="w-4 h-4 text-amber-400 shrink-0" />
                <span>شاشة ممولة ويافطات المنطقة</span>
              </h2>

              {/* 50% Verified Subscribers Quota Tag */}
              <span
                className="inline-flex items-center gap-1 bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-xs"
                title="نظام تبادل ذكي يخصص 50% أو أكثر للمشتركين الموثقين حسب الباقة والمنتجات التي لها خصم وصورة"
              >
                <Award className="w-3 h-3 text-amber-300 shrink-0" />
                <span>حصة الموثقين: {verifiedSubscribersRatioPercent}%</span>
              </span>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              إعلانات مربعة دوارة تتبدل كل 3 ثوانٍ بين 7 إعلانات مختلفة في كل موضع، تتخللها يافطات عريضة بنسبة غلاف الفيس بوك لأهم عروض المنطقة.
            </p>

            {/* Quick Action Buttons */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setSmartMarketingTargetBiz(hostBusiness || businesses[0] || null)}
                className="text-[11px] font-black text-slate-950 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 px-2.5 py-2 rounded-xl shadow-md flex items-center justify-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 shrink-0" />
                <span>توليد إعلان</span>
              </button>
              <button
                type="button"
                onClick={() => setAdModalType('sponsored_ad')}
                className="text-[11px] font-black text-amber-300 hover:text-white bg-white/10 hover:bg-white/15 border border-amber-400/30 px-2.5 py-2 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
              >
                <Megaphone className="w-3.5 h-3.5 shrink-0" />
                <span>تقديم إعلان</span>
              </button>
            </div>
          </div>

          {/* =========================================================================
              1. FEATURED 1:1 SQUARE SPONSORED AD (Slot #0)
              - دوران كل 3 ثوانٍ بين 7 إعلانات
              - نقاط التصفح على الإعلان نفسه (7 نقاط)
              - سطر واحد فقط لا يؤثر على إضاءة الإعلان (100% إضاءة كاملة)
              - بدون أي خط تحميل نهائياً
             ========================================================================= */}
          <div className="space-y-3">
            <div
              onMouseEnter={() => setIsPaused(true)}
              onMouseLeave={() => setIsPaused(false)}
              onClick={() => handleOpenStorefront(targetBiz?.id)}
              className={`aspect-square w-full rounded-3xl overflow-hidden relative group border cursor-pointer transition-all duration-500 bg-slate-950 shadow-2xl flex flex-col justify-between ${
                activeAd.isVerifiedSubscriber
                  ? 'border-emerald-400/80 hover:border-emerald-300 shadow-emerald-950/50'
                  : 'border-amber-400/80 hover:border-amber-300 shadow-amber-950/50'
              }`}
              style={{ aspectRatio: '1 / 1' }}
              title="اضغط لفتح النشاط أو المنتج مباشرة"
            >
              {/* Full Brightness Image (100% luminous, no dark gradient) */}
              <img
                src={bannerImage}
                alt={activeAd.title}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />

              {/* Top Bar on the Ad: Verified/Sponsored Badge (Right) + 7 Interactive Dots (Left) */}
              <div className="relative z-10 p-2.5 flex items-center justify-between">
                {/* Verified or Sponsored badge */}
                <div className="flex items-center gap-1 pointer-events-none">
                  {activeAd.isVerifiedSubscriber ? (
                    <span className="bg-emerald-600/90 backdrop-blur-md text-white text-[9px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 shadow-xs border border-emerald-400/40">
                      <span>⭐ موثق</span>
                      {activeAd.packageTierName && (
                        <span className="opacity-90">• {activeAd.packageTierName.split(' ')[2] || 'VIP'}</span>
                      )}
                    </span>
                  ) : (
                    <span className="bg-amber-500/90 backdrop-blur-md text-slate-950 text-[9px] font-black px-2 py-0.5 rounded-full shadow-xs border border-amber-300/40">
                      📢 ممول
                    </span>
                  )}
                </div>

                {/* 7 INTERACTIVE DOTS DIRECTLY ON THE AD (تتبدل كل 3 ثوانٍ) */}
                <div
                  className="flex items-center gap-1 bg-black/60 backdrop-blur-md px-2 py-1 rounded-full border border-white/20 shadow-lg"
                  onClick={(e) => e.stopPropagation()}
                >
                  {rotatingAdsPool.map((_, dotIdx) => (
                    <button
                      key={dotIdx}
                      type="button"
                      onClick={() => handleSelectAd(dotIdx)}
                      className={`transition-all duration-300 rounded-full cursor-pointer ${
                        dotIdx === safeIndex
                          ? 'w-4 h-1.5 bg-gradient-to-r from-amber-400 to-amber-300 shadow-xs'
                          : 'w-1.5 h-1.5 bg-white/50 hover:bg-white hover:scale-125'
                      }`}
                      title={`الانتقال إلى الإعلان الممول ${dotIdx + 1} من ${rotatingAdsPool.length}`}
                      aria-label={`إعلان ممول ${dotIdx + 1}`}
                    />
                  ))}
                </div>
              </div>

              {/* SINGLE DISCREET LINE OF TEXT (سطر واحد فقط لا يؤثر على إضاءة الإعلان) */}
              <div className="relative z-10 p-2.5">
                <div className="bg-slate-950/85 backdrop-blur-md border border-white/20 rounded-2xl px-3 py-2 text-white flex items-center justify-between gap-2 shadow-xl">
                  <div className="min-w-0 flex-1 flex items-center gap-1.5 truncate">
                    <span className="text-amber-300 font-black text-xs shrink-0 truncate max-w-[120px]">
                      {activeAd.businessName}
                    </span>
                    <span className="text-slate-300 text-[11px] truncate">
                      • {activeAd.oneLineSummary || activeAd.title}
                    </span>
                  </div>

                  {activeAd.discountPercent && activeAd.discountPercent > 0 ? (
                    <span className="bg-rose-500 text-white font-black text-[10px] px-2 py-0.5 rounded-md shrink-0 shadow-xs">
                      خصم {activeAd.discountPercent}%
                    </span>
                  ) : (
                    <ExternalLink className="w-3.5 h-3.5 text-amber-300 shrink-0 opacity-80" />
                  )}
                </div>
              </div>
            </div>

            {/* =========================================================================
                2. INTERLEAVED FEED: Alternates Facebook Cover Ratio & Staggered Rotating Square Ads
                - كل مربع متغير عن الآخر تماماً في أي لحظة!
                - كل مربع يتبدل كل 3 ثوانٍ بين الـ 7 إعلانات
                - بدون أي خط تحميل على أي إعلان
                - بين كل إعلان وإعلان: إعلان بنسبة غلاف الفيس بوك (820/312)
               ========================================================================= */}
            <div className="space-y-3 pt-1">
              {Array.from({ length: secondarySlotsCount }).map((_, loopIdx) => {
                const regionalCoverItem = resolvedRegionalCoverAds[loopIdx % resolvedRegionalCoverAds.length];
                // Staggered offset ensures that EVERY square card on screen displays a DIFFERENT ad at any moment!
                const squareAdIndex = (safeIndex + loopIdx + 1) % rotatingAdsPool.length;
                const squareAdItem = rotatingAdsPool[squareAdIndex];

                return (
                  <React.Fragment key={`interleaved_slot_${loopIdx}`}>
                    {/* A. FACEBOOK COVER RATIO BANNER (نسبة غلاف الفيس بوك 820/312 لإعلانات المنطقة) */}
                    {regionalCoverItem && (
                      <div
                        onClick={regionalCoverItem.businessId ? () => handleOpenStorefront(regionalCoverItem.businessId) : undefined}
                        className={`w-full rounded-2xl overflow-hidden relative group border border-cyan-400/50 shadow-xl bg-slate-950 transition-all duration-300 ${regionalCoverItem.businessId ? 'cursor-pointer hover:border-cyan-300 hover:shadow-cyan-950/50' : 'cursor-default'}`}
                        style={{ aspectRatio: '820 / 312' }}
                        title={regionalCoverItem.title}
                      >
                        {/* 100% Full Brightness Image */}
                        <img
                          src={regionalCoverItem.image}
                          alt={regionalCoverItem.title}
                          className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                        />

                        {/* Top: Regional Badge of Main Screen */}
                        <div className="relative z-10 p-2 flex items-center justify-between pointer-events-none">
                          <span className="bg-cyan-950/85 backdrop-blur-md text-cyan-200 border border-cyan-400/40 text-[9px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                            <MapPin className="w-2.5 h-2.5 text-cyan-300" />
                            <span>{regionalCoverItem.badge || 'إعلان المنطقة'}</span>
                          </span>
                          <span className="bg-black/60 backdrop-blur-md text-cyan-300 text-[8px] font-black px-1.5 py-0.5 rounded-md border border-cyan-400/30">
                            غلاف المنطقة
                          </span>
                        </div>

                        {/* Bottom: Single Discreet Line of Text */}
                        <div className="absolute inset-x-0 bottom-0 z-10 p-2 pt-0 pointer-events-none">
                          <div className="bg-slate-950/85 backdrop-blur-md border border-white/20 rounded-xl px-2.5 py-1 text-white flex items-center justify-between gap-1.5 shadow-md">
                            <div className="min-w-0 flex-1 truncate text-[10px] font-bold">
                              <span className="text-cyan-300 font-black ml-1">
                                {regionalCoverItem.title}
                              </span>
                              {regionalCoverItem.subtitle && (
                                <span className="text-slate-300 font-normal opacity-90 truncate">
                                  • {regionalCoverItem.subtitle}
                                </span>
                              )}
                            </div>
                            <ArrowUpRight className="w-3 h-3 text-cyan-300 shrink-0 opacity-80" />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* B. ROTATING SQUARE AD (مربع متغير ومختلف عن باقي المربعات، يتبدل كل 3 ثوانٍ بدون خط تحميل) */}
                    {squareAdItem && (
                      <div
                        onClick={() => handleOpenStorefront(squareAdItem.resolvedBusiness?.id)}
                        className={`w-full aspect-square rounded-2xl overflow-hidden relative group border cursor-pointer transition-all duration-500 bg-slate-950 shadow-xl flex flex-col justify-between ${
                          squareAdItem.isVerifiedSubscriber
                            ? 'border-emerald-400/70 hover:border-emerald-300 shadow-emerald-950/40'
                            : 'border-amber-400/70 hover:border-amber-300 shadow-amber-950/40'
                        }`}
                        style={{ aspectRatio: '1 / 1' }}
                        title="اضغط لفتح النشاط أو المنتج مباشرة"
                      >
                        {/* Full Brightness Image */}
                        <img
                          src={
                            squareAdItem.imageUrl ||
                            squareAdItem.resolvedBusiness?.coverUrl ||
                            DEFAULT_BUSINESS_COVER_URL
                          }
                          alt={squareAdItem.title}
                          className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                        />

                        {/* Top Badges */}
                        <div className="relative z-10 p-2.5 flex items-center justify-between pointer-events-none">
                          <div className="flex items-center gap-1">
                            {squareAdItem.isVerifiedSubscriber ? (
                              <span className="bg-emerald-600/90 backdrop-blur-md text-white text-[9px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 shadow-xs border border-emerald-400/40">
                                <span>⭐ موثق</span>
                                {squareAdItem.packageTierName && (
                                  <span className="opacity-90">• {squareAdItem.packageTierName.split(' ')[2] || 'VIP'}</span>
                                )}
                              </span>
                            ) : (
                              <span className="bg-amber-500/90 backdrop-blur-md text-slate-950 text-[9px] font-black px-2 py-0.5 rounded-full shadow-xs border border-amber-300/40">
                                📢 ممول
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1">
                            {squareAdItem.discountPercent && squareAdItem.discountPercent > 0 && (
                              <span className="bg-rose-600/95 backdrop-blur-md text-white font-black text-[9px] px-2 py-0.5 rounded-md shadow-xs border border-rose-300/30">
                                خصم {squareAdItem.discountPercent}%
                              </span>
                            )}
                            <span className="bg-black/60 backdrop-blur-xs text-amber-300 text-[8px] font-bold px-1.5 py-0.5 rounded-md border border-white/10">
                              3 ثوانٍ
                            </span>
                          </div>
                        </div>

                        {/* Bottom: Single Discreet Line */}
                        <div className="relative z-10 p-2.5 pt-0">
                          <div className="bg-slate-950/85 backdrop-blur-md border border-white/20 rounded-xl px-2.5 py-1.5 text-white flex items-center justify-between gap-2 shadow-lg">
                            <div className="min-w-0 flex-1 flex items-center gap-1 truncate text-[11px]">
                              <span className="text-amber-300 font-black truncate max-w-[110px]">
                                {squareAdItem.businessName}
                              </span>
                              <span className="text-slate-300 truncate">
                                • {squareAdItem.oneLineSummary || squareAdItem.title}
                              </span>
                            </div>
                            <ExternalLink className="w-3.5 h-3.5 text-amber-300 shrink-0 opacity-80" />
                          </div>
                        </div>
                      </div>
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        </div>

        {/* Column Footer: Book Ad Space */}
        <div className="pt-3 border-t border-white/10 space-y-2">
          <div className="bg-white/5 rounded-2xl p-3 border border-white/10 space-y-1.5">
            <div className="flex items-center gap-1.5 text-amber-300 text-xs font-black">
              <Sparkles className="w-3.5 h-3.5 shrink-0" />
              <span>حجز موضع إعلاني بالشاشة والقائمة</span>
            </div>
            <p className="text-[10px] text-slate-300 leading-relaxed">
              تتبدل إعلاناتك ضمن الشاشات المربعة كل 3 ثوانٍ بين 7 إعلانات متغيرة، وفي قائمة اليافطات المتتالية بدون أي تعارض قطاعي.
            </p>
            <button
              type="button"
              onClick={() => setAdModalType('billboard_banner')}
              className="w-full bg-purple-600 hover:bg-purple-500 text-white font-black text-xs py-2 px-3 rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>حجز يافطة إعلانية</span>
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};
