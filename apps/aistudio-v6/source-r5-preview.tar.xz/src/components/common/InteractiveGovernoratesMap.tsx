import React, { useEffect, useRef, useState, useMemo } from 'react';
import L from 'leaflet';
import { Business, FunctionalGroup, FunctionalGroupId } from '../../types';
import {
  resolveBusinessCoordinates,
  calculateGovernorateStats,
  EGYPT_GOVERNORATES_MAP,
  DEFAULT_EGYPT_CENTER,
  DEFAULT_EGYPT_ZOOM,
} from '../../utils/geoCoordinates';
import {
  MapPin,
  Search,
  Maximize2,
  Minimize2,
  RotateCcw,
  Building2,
  CheckCircle2,
  ExternalLink,
  Phone,
  MessageCircle,
  Clock,
  Layers,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  X,
  Compass,
  ArrowUpRight,
} from 'lucide-react';

interface InteractiveGovernoratesMapProps {
  businesses: Business[];
  functionalGroups: FunctionalGroup[];
  onSelectBusiness: (business: Business) => void;
  selectedGovFilter?: string;
  onGovChange?: (gov: string) => void;
}

const SECTOR_PIN_COLORS: Record<FunctionalGroupId | string, { bg: string; border: string; text: string }> = {
  healthcare: { bg: '#10b981', border: '#059669', text: '#ffffff' },
  dining: { bg: '#f59e0b', border: '#d97706', text: '#ffffff' },
  retail: { bg: '#3b82f6', border: '#2563eb', text: '#ffffff' },
  services: { bg: '#8b5cf6', border: '#7c3aed', text: '#ffffff' },
  crafts_maintenance: { bg: '#ea580c', border: '#c2410c', text: '#ffffff' },
  education_training: { bg: '#6366f1', border: '#4f46e5', text: '#ffffff' },
  real_estate: { bg: '#14b8a6', border: '#0d9488', text: '#ffffff' },
  tourism_hotels: { bg: '#06b6d4', border: '#0891b2', text: '#ffffff' },
  transport_logistics: { bg: '#f43f5e', border: '#e11d48', text: '#ffffff' },
  agriculture_livestock: { bg: '#65a30d', border: '#4d7c0f', text: '#ffffff' },
  technology_software: { bg: '#0284c7', border: '#0369a1', text: '#ffffff' },
  sports_fitness: { bg: '#eab308', border: '#ca8a04', text: '#ffffff' },
  events_entertainment: { bg: '#ec4899', border: '#db2777', text: '#ffffff' },
  legal_financial: { bg: '#78350f', border: '#542307', text: '#ffffff' },
  industrial_manufacturing: { bg: '#334155', border: '#1e293b', text: '#ffffff' },
};

export const InteractiveGovernoratesMap: React.FC<InteractiveGovernoratesMapProps> = ({
  businesses,
  functionalGroups,
  onSelectBusiness,
  selectedGovFilter = 'all',
  onGovChange,
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const markersMapRef = useRef<Map<string, L.Marker>>(new Map());

  // Component state
  const [activeGov, setActiveGov] = useState<string>(selectedGovFilter === 'all' ? '' : selectedGovFilter);
  const [activeSector, setActiveSector] = useState<string>('all');
  const [mapSearchQuery, setMapSearchQuery] = useState<string>('');
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [selectedPinBizId, setSelectedPinBizId] = useState<string | null>(null);
  const [showSidePanel, setShowSidePanel] = useState<boolean>(true);

  // Sync external governorate filter if it changes
  useEffect(() => {
    if (selectedGovFilter && selectedGovFilter !== 'all' && selectedGovFilter !== activeGov) {
      setActiveGov(selectedGovFilter);
    } else if (selectedGovFilter === 'all' && activeGov !== '') {
      setActiveGov('');
    }
  }, [selectedGovFilter]);

  // Calculate governorate statistics
  const governorateStats = useMemo(() => {
    return calculateGovernorateStats(businesses);
  }, [businesses]);

  // Filtered businesses for the map and list
  const filteredBusinesses = useMemo(() => {
    return businesses.filter((b) => {
      // Governorate match
      if (activeGov && b.governorate !== activeGov) {
        return false;
      }
      // Sector match
      if (activeSector !== 'all' && b.functionalGroupId !== activeSector) {
        return false;
      }
      // Search query match
      if (mapSearchQuery.trim()) {
        const q = mapSearchQuery.toLowerCase().trim();
        const matchesName = b.name.toLowerCase().includes(q);
        const matchesCat = (b.category || '').toLowerCase().includes(q);
        const matchesMarkaz = (b.markaz || '').toLowerCase().includes(q);
        const matchesGov = (b.governorate || '').toLowerCase().includes(q);
        if (!matchesName && !matchesCat && !matchesMarkaz && !matchesGov) {
          return false;
        }
      }
      return true;
    });
  }, [businesses, activeGov, activeSector, mapSearchQuery]);

  // Initialize Leaflet map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapRef.current) return; // Prevent double initialization

    try {
      const map = L.map(mapContainerRef.current, {
        center: [DEFAULT_EGYPT_CENTER.lat, DEFAULT_EGYPT_CENTER.lng],
        zoom: DEFAULT_EGYPT_ZOOM,
        scrollWheelZoom: true,
        attributionControl: false,
        zoomControl: false,
      });

      // Add Zoom Control at top-left
      L.control.zoom({ position: 'topleft' }).addTo(map);

      // Free, lightweight OpenStreetMap tiles (standard OSM tile server, no API key required)
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors',
      }).addTo(map);

      const markersGroup = L.layerGroup().addTo(map);
      markersLayerRef.current = markersGroup;
      mapRef.current = map;
    } catch (err) {
      console.error('Error initializing Leaflet map:', err);
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
        markersLayerRef.current = null;
        markersMapRef.current.clear();
      }
    };
  }, []);

  // Update map markers whenever filtered businesses or selection change
  useEffect(() => {
    const map = mapRef.current;
    const layer = markersLayerRef.current;
    if (!map || !layer) return;

    layer.clearLayers();
    markersMapRef.current.clear();

    const bounds: [number, number][] = [];

    filteredBusinesses.forEach((b) => {
      const coords = resolveBusinessCoordinates(b);
      bounds.push([coords.lat, coords.lng]);

      const colors = SECTOR_PIN_COLORS[b.functionalGroupId] || {
        bg: '#0f766e',
        border: '#115e59',
        text: '#ffffff',
      };
      const isSelected = selectedPinBizId === b.id;
      const verifiedBadge = b.isVerified
        ? `<div class="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-amber-400 border border-white flex items-center justify-center text-[8px] font-black text-slate-950 shadow">✓</div>`
        : '';

      const iconHtml = `
        <div class="custom-mantiqatix-pin ${isSelected ? 'active-pin' : ''} relative flex flex-col items-center cursor-pointer group">
          <div class="relative w-8 h-8 rounded-2xl flex items-center justify-center shadow-md border-2 transition-transform group-hover:scale-110" style="background-color: ${colors.bg}; border-color: ${isSelected ? '#f59e0b' : colors.border};">
            <img src="${b.logoUrl || 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=100'}" class="w-5.5 h-5.5 rounded-xl object-cover bg-white" alt="${b.name}" />
            ${verifiedBadge}
          </div>
          <div class="w-2 h-2 -mt-0.5 rotate-45 border-r border-b" style="background-color: ${colors.bg}; border-color: ${isSelected ? '#f59e0b' : colors.border};"></div>
          <div class="opacity-0 group-hover:opacity-100 ${isSelected ? 'opacity-100' : ''} transition-opacity duration-150 bg-slate-950/95 text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow-lg mt-1 whitespace-nowrap pointer-events-none border border-slate-700/60 max-w-[140px] truncate text-center">
            ${b.name}
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'custom-leaflet-div-icon',
        html: iconHtml,
        iconSize: [40, 54],
        iconAnchor: [20, 50],
        popupAnchor: [0, -50],
      });

      const marker = L.marker([coords.lat, coords.lng], { icon: customIcon });

      // Rich interactive popup HTML
      const popupContent = document.createElement('div');
      popupContent.className = 'w-[280px] sm:w-[320px] p-0 font-sans text-right select-none';
      popupContent.innerHTML = `
        <div class="relative h-28 w-full bg-slate-900 overflow-hidden">
          <img src="${b.coverUrl || b.logoUrl}" class="w-full h-full object-cover" alt="Cover" />
          <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
          <div class="absolute top-2 right-2">
            <span class="bg-slate-900/90 text-white text-[10px] font-black px-2 py-0.5 rounded-full border border-slate-700">
              ${b.category}
            </span>
          </div>
          ${
            b.isVerified
              ? `<div class="absolute top-2 left-2 flex items-center gap-1 bg-amber-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full shadow">
                  <span>موثق</span>
                </div>`
              : ''
          }
        </div>
        <div class="p-3.5 space-y-2.5 bg-white">
          <div class="flex items-start gap-2.5">
            <img src="${b.logoUrl}" class="w-10 h-10 rounded-xl object-cover border border-slate-200 shrink-0 shadow-xs" alt="Logo" />
            <div class="min-w-0 flex-1">
              <h4 class="font-black text-slate-900 text-sm leading-tight truncate">${b.name}</h4>
              <p class="text-[11px] font-medium text-slate-500 mt-0.5 flex items-center gap-1">
                <span>📍 ${b.governorate}</span>
                <span>•</span>
                <span>${b.markaz}</span>
              </p>
            </div>
          </div>

          <p class="text-xs text-slate-600 line-clamp-2 leading-relaxed font-normal">
            ${b.bio || 'نشاط تجاري معتمد مسجل في منصة MantiqatiX.'}
          </p>

          <div class="text-[11px] text-slate-500 bg-slate-50 p-2 rounded-xl flex items-center justify-between border border-slate-100">
            <span class="font-bold text-slate-700">ساعات العمل:</span>
            <span>${b.workingHours || 'يومياً: 9 ص - 10 م'}</span>
          </div>

          <div class="pt-1 flex items-center gap-2">
            <button
              id="btn-visit-storefront-${b.id}"
              class="flex-1 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-xs py-2 px-3 rounded-xl shadow-md flex items-center justify-center gap-1.5 transition-all cursor-pointer"
            >
              <span>زيارة النشاط والكتالوج</span>
              <span>↗</span>
            </button>
            ${
              b.ownerWhatsApp
                ? `<a
                    href="https://wa.me/${b.ownerWhatsApp.replace(/[^0-9]/g, '')}"
                    target="_blank"
                    rel="noreferrer"
                    class="w-8 h-8 rounded-xl bg-emerald-100 hover:bg-emerald-200 text-emerald-800 flex items-center justify-center text-xs font-black shadow-xs transition-colors shrink-0"
                    title="محادثة واتساب"
                  >
                    💬
                  </a>`
                : ''
            }
          </div>
        </div>
      `;

      // Attach click handler on popup button
      const visitBtn = popupContent.querySelector(`#btn-visit-storefront-${b.id}`);
      if (visitBtn) {
        visitBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          onSelectBusiness(b);
        });
      }

      marker.bindPopup(popupContent, {
        maxWidth: 340,
        className: 'custom-mantiqatix-popup',
      });

      marker.on('click', () => {
        setSelectedPinBizId(b.id);
      });

      marker.addTo(layer);
      markersMapRef.current.set(b.id, marker);
    });

    // Auto-fit bounds if we have markers and no explicit governorate was picked
    if (bounds.length > 0 && !activeGov && bounds.length <= 15) {
      try {
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
      } catch (e) {
        // Safe fallback
      }
    }
  }, [filteredBusinesses, selectedPinBizId, onSelectBusiness, activeGov]);

  // Handle governorate selection from pill bar
  const handleSelectGovernorate = (govName: string) => {
    setActiveGov(govName);
    if (onGovChange) {
      onGovChange(govName || 'all');
    }

    const map = mapRef.current;
    if (!map) return;

    if (!govName) {
      // Reset to all Egypt
      map.flyTo([DEFAULT_EGYPT_CENTER.lat, DEFAULT_EGYPT_CENTER.lng], DEFAULT_EGYPT_ZOOM, {
        duration: 1.2,
      });
      return;
    }

    const govInfo = EGYPT_GOVERNORATES_MAP[govName];
    if (govInfo) {
      map.flyTo([govInfo.center.lat, govInfo.center.lng], govInfo.zoom, {
        duration: 1.2,
      });
    }
  };

  // Fly to and open popup for a specific business
  const handleLocateBusiness = (business: Business) => {
    const map = mapRef.current;
    if (!map) return;

    const coords = resolveBusinessCoordinates(business);
    setSelectedPinBizId(business.id);

    map.flyTo([coords.lat, coords.lng], 15, {
      duration: 1.0,
    });

    const marker = markersMapRef.current.get(business.id);
    if (marker) {
      setTimeout(() => {
        marker.openPopup();
      }, 700);
    }
  };

  // Reset entire map view
  const handleResetView = () => {
    setActiveGov('');
    setActiveSector('all');
    setMapSearchQuery('');
    setSelectedPinBizId(null);
    if (onGovChange) {
      onGovChange('all');
    }
    const map = mapRef.current;
    if (map) {
      map.flyTo([DEFAULT_EGYPT_CENTER.lat, DEFAULT_EGYPT_CENTER.lng], DEFAULT_EGYPT_ZOOM, {
        duration: 1.0,
      });
    }
  };

  // Trigger leaflet resize on expand/collapse
  useEffect(() => {
    const timer = setTimeout(() => {
      mapRef.current?.invalidateSize();
    }, 250);
    return () => clearTimeout(timer);
  }, [isExpanded, showSidePanel]);

  return (
    <div
      className={`bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden transition-all duration-300 ${
        isExpanded ? 'p-4 sm:p-6' : 'p-4 sm:p-6'
      }`}
    >
      {/* MAP HEADER */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
              <Compass className="w-5 h-5 animate-pulse" />
            </div>
            <h3 className="font-black text-lg sm:text-xl text-slate-900 tracking-tight flex items-center gap-2">
              <span>خريطة الأنشطة والشركات التفاعلية بالمحافظات</span>
              <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-black px-2.5 py-0.5 rounded-full">
                تفاعلي ومباشر
              </span>
            </h3>
          </div>
          <p className="text-xs sm:text-sm font-medium text-slate-500 leading-relaxed">
            استكشف الأنشطة التجارية والشركات المسجلة جغرافياً في كل محافظة وموقعها الفعلي في جمهورية مصر العربية
          </p>
        </div>

        {/* MAP CONTROLS & ACTIONS */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Quick Search on Map */}
          <div className="relative min-w-[200px] sm:min-w-[240px]">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={mapSearchQuery}
              onChange={(e) => setMapSearchQuery(e.target.value)}
              placeholder="ابحث في الخريطة..."
              className="w-full pl-8 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            />
            {mapSearchQuery && (
              <button
                onClick={() => setMapSearchQuery('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Sector Filter */}
          <select
            value={activeSector}
            onChange={(e) => setActiveSector(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-slate-800 text-xs font-black py-2 px-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30 cursor-pointer"
          >
            <option value="all">كل القطاعات (15)</option>
            {functionalGroups.map((g) => (
              <option key={g.id} value={g.id}>
                {g.shortName}
              </option>
            ))}
          </select>

          {/* Toggle Activities Side Panel */}
          <button
            onClick={() => setShowSidePanel(!showSidePanel)}
            className={`px-3 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 border transition-all cursor-pointer ${
              showSidePanel
                ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
            }`}
            title="تبديل إظهار قائمة الأنشطة الجانبية"
          >
            <Building2 className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">قائمة الأنشطة</span>
            <span className="bg-amber-400 text-slate-950 font-black text-[10px] px-1.5 py-0.2 rounded-md">
              {filteredBusinesses.length}
            </span>
          </button>

          {/* Reset Map View */}
          <button
            onClick={handleResetView}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors cursor-pointer"
            title="إعادة ضبط الخريطة لكل مصر"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Expand / Minimize Map Height */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors cursor-pointer"
            title={isExpanded ? 'تصغير ارتفاع الخريطة' : 'تكبير الخريطة'}
          >
            {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* GOVERNORATE QUICK SELECTOR CHIPS */}
      <div className="py-3 border-b border-slate-100 overflow-x-auto scrollbar-none flex items-center gap-2 text-xs">
        <span className="font-bold text-slate-500 text-xs shrink-0 flex items-center gap-1 pr-1">
          <MapPin className="w-3.5 h-3.5 text-emerald-600" />
          <span>المحافظة:</span>
        </span>

        {/* All Egypt Chip */}
        <button
          onClick={() => handleSelectGovernorate('')}
          className={`shrink-0 px-3.5 py-1.5 rounded-xl font-black text-xs transition-all cursor-pointer border ${
            !activeGov
              ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20'
              : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
          }`}
        >
          كل المحافظات ({businesses.length})
        </button>

        {/* Dynamic Governorate Chips with Counts */}
        {governorateStats.map((gov) => {
          const isActive = activeGov === gov.name;
          return (
            <button
              key={gov.name}
              onClick={() => handleSelectGovernorate(gov.name)}
              className={`shrink-0 px-3.5 py-1.5 rounded-xl font-black text-xs transition-all cursor-pointer border flex items-center gap-1.5 ${
                isActive
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20 scale-105'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
              }`}
            >
              <span>{gov.name}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                  isActive ? 'bg-white text-emerald-800' : 'bg-slate-200 text-slate-600'
                }`}
              >
                {gov.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* MAP & SIDE LIST CONTAINER */}
      <div className="mt-4 flex flex-col lg:flex-row gap-4 items-stretch">
        {/* LEAFLET MAP */}
        <div
          className={`relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 shadow-inner transition-all duration-300 ${
            showSidePanel ? 'w-full lg:w-2/3 xl:w-3/4' : 'w-full'
          } ${isExpanded ? 'h-[580px] sm:h-[680px]' : 'h-[440px] sm:h-[500px]'}`}
        >
          <div ref={mapContainerRef} className="w-full h-full z-0" />

          {/* Floating Map Overlay Badge (Shows current active scope) */}
          <div className="absolute top-3 right-3 z-10 bg-slate-900/90 text-white backdrop-blur-md px-3.5 py-2 rounded-2xl border border-slate-700/60 shadow-lg flex items-center gap-2 pointer-events-none">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <div className="text-right">
              <div className="text-[10px] text-slate-400 font-bold">النطاق الجغرافي المعروض</div>
              <div className="text-xs font-black text-white">
                {activeGov ? `محافظة ${activeGov}` : 'كافة محافظات جمهورية مصر العربية'}
                <span className="text-emerald-400 mr-1.5">({filteredBusinesses.length} نشاط)</span>
              </div>
            </div>
          </div>

          {/* Map Legend (Bottom Right) */}
          <div className="absolute bottom-3 right-3 z-10 hidden sm:flex items-center gap-2 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-200 shadow-md text-[11px] font-bold text-slate-700 pointer-events-none">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>صحة</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span>مطاعم</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
              <span>تجزئة</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
              <span>خدمات</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-700" />
              <span>صناعة</span>
            </span>
          </div>
        </div>

        {/* SIDE ACTIVITY DRAWER / CARDS */}
        {showSidePanel && (
          <div
            className={`w-full lg:w-1/3 xl:w-1/4 flex flex-col bg-slate-50/70 rounded-2xl border border-slate-200 p-3.5 space-y-3 ${
              isExpanded ? 'h-[580px] sm:h-[680px]' : 'h-[440px] sm:h-[500px]'
            }`}
          >
            {/* Header of Side List */}
            <div className="flex items-center justify-between border-b border-slate-200/80 pb-2">
              <div className="flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-emerald-600" />
                <span className="font-black text-xs text-slate-800">
                  {activeGov ? `أنشطة ${activeGov}` : 'الأنشطة على الخريطة'}
                </span>
              </div>
              <span className="text-[11px] font-black bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                {filteredBusinesses.length} مسجل
              </span>
            </div>

            {/* Scrollable list of businesses in current scope */}
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 scrollbar-thin">
              {filteredBusinesses.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-2">
                  <Compass className="w-8 h-8 text-slate-300" />
                  <p className="text-xs font-bold text-slate-500">لا توجد أنشطة تطابق هذا الفلتر</p>
                  <button
                    onClick={handleResetView}
                    className="text-xs text-emerald-600 font-black hover:underline cursor-pointer"
                  >
                    عرض كل المحافظات
                  </button>
                </div>
              ) : (
                filteredBusinesses.map((biz) => {
                  const isSelected = selectedPinBizId === biz.id;
                  return (
                    <div
                      key={biz.id}
                      className={`p-3 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-white border-emerald-500 ring-2 ring-emerald-500/20 shadow-md'
                          : 'bg-white hover:bg-slate-50 border-slate-200 shadow-xs'
                      }`}
                      onClick={() => handleLocateBusiness(biz)}
                    >
                      <div className="flex items-start gap-2.5">
                        <img
                          src={biz.logoUrl}
                          alt={biz.name}
                          className="w-10 h-10 rounded-xl object-cover border border-slate-200 shrink-0 bg-slate-100"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1">
                            <h4 className="font-black text-xs text-slate-900 truncate">{biz.name}</h4>
                            {biz.isVerified && (
                              <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                            )}
                          </div>
                          <p className="text-[10px] text-slate-500 font-medium truncate mt-0.5">
                            📍 {biz.governorate} • {biz.markaz}
                          </p>
                          <div className="flex items-center gap-1.5 mt-1.5">
                            <span className="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md border border-slate-200">
                              {biz.category}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Action buttons on card */}
                      <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleLocateBusiness(biz);
                          }}
                          className="text-[10px] font-black text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer bg-emerald-50 hover:bg-emerald-100 px-2 py-1 rounded-lg"
                        >
                          <MapPin className="w-3 h-3" />
                          <span>تحديد على الخريطة</span>
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectBusiness(biz);
                          }}
                          className="text-[10px] font-black text-slate-700 hover:text-slate-950 flex items-center gap-1 cursor-pointer bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded-lg"
                        >
                          <span>زيارة النشاط</span>
                          <ArrowUpRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Quick summary stats in footer */}
            <div className="pt-2 border-t border-slate-200/80 text-[11px] text-slate-500 flex items-center justify-between font-bold">
              <span>المحافظات المغطاة: {governorateStats.length}</span>
              <span className="text-emerald-700">تحديث فوري</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
