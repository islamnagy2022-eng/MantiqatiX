import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { WalletPaymentChannel, WalletTransactionType } from '../../types';
import {
  Wallet,
  X,
  Eye,
  EyeOff,
  ArrowUpRight,
  ArrowDownLeft,
  ShieldCheck,
  Sparkles,
  CreditCard,
  History,
  Database,
  CheckCircle2,
  AlertCircle,
  Lock,
} from 'lucide-react';

export const WalletModal: React.FC = () => {
  const {
    isWalletModalOpen,
    setIsWalletModalOpen,
    wallets,
    activeWalletId,
    setActiveWalletId,
    currentWallet,
    walletTransactions,
    performWalletTransaction,
    enterpriseStateSummary,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'operations' | 'ledger' | 'architecture'>('overview');
  const [showNumbers, setShowNumbers] = useState<boolean>(true);
  const [opType, setOpType] = useState<WalletTransactionType>('deposit');
  const [opAmount, setOpAmount] = useState<number>(500);
  const [opChannel, setOpChannel] = useState<WalletPaymentChannel>('vodafone_cash');
  const [opDescription, setOpDescription] = useState<string>('');
  const [opFeedback, setOpFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isWalletModalOpen || !currentWallet) return null;

  const remainingCredit = Math.max(0, currentWallet.creditLimit - currentWallet.usedCredit);
  const walletLedger = walletTransactions.filter((t) => t.walletId === currentWallet.id);

  const formatMasked = (num: number) => {
    if (!showNumbers) return '•••••• ج.م';
    return `${num.toLocaleString('ar-EG')} ${currentWallet.currency}`;
  };

  const handleExecuteOperation = (e: React.FormEvent) => {
    e.preventDefault();
    setOpFeedback(null);

    const defaultLabels: Record<WalletTransactionType, string> = {
      deposit: 'شحن رصيد المحفظة الإلكترونية',
      withdrawal: 'سحب رصيد من المحفظة',
      commission_deduction: 'سداد عمولة المنصة الدورية',
      ad_payment: 'سداد حملة إعلانية ممولة',
      admin_free_ad_grant: 'منحة إعلان ممول مجاني 100% من الإدارة (0 ج.م)',
      cashback: 'إضافة كاش باك ومكافأة ولاء',
      credit_settlement: 'تسوية مديونية حد الائتمان',
    };

    const res = performWalletTransaction({
      walletId: currentWallet.id,
      type: opType,
      amount: opType === 'admin_free_ad_grant' ? 0 : opAmount,
      description: opDescription.trim() || defaultLabels[opType],
      paymentMethod: opType === 'admin_free_ad_grant' ? 'admin_grant' : opChannel,
      isFreeAdminGrant: opType === 'admin_free_ad_grant',
    });

    if (!res.success) {
      setOpFeedback({ type: 'error', text: res.error || 'تعذر إتمام العملية المالية.' });
      return;
    }

    setOpFeedback({
      type: 'success',
      text:
        opType === 'admin_free_ad_grant'
          ? 'تم اعتماد منحة الإعلان الممول المجاني للإدارة (0 ج.م) وتسجيلها في السجل المالي بنجاح!'
          : `تم تنفيذ العملية بنجاح وتحديث الرصيد المتاح إلى ${res.transaction?.balanceAfter.toLocaleString('ar-EG')} ج.م`,
    });
    setOpDescription('');
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      dir="rtl"
    >
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in duration-200">
        {/* Top Dark Header */}
        <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white p-5 sm:p-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-lg">
              <Wallet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-black text-base sm:text-lg text-white">
                  المحفظة الإلكترونية والنظام المالي الذكي
                </h2>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-black px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  <span>خصوصية تامة — يظهر الرصيد هنا فقط</span>
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                إدارة الرصيد، حد الائتمان، تسوية العمولات، ومنح الإعلانات الممولة المجانية للإدارة
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsWalletModalOpen(false)}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="إغلاق نافذة المحفظة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wallet Account Selector & Privacy Mask Toggle */}
        <div className="bg-slate-50 border-b border-slate-200 px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-1">
            <label htmlFor="wallet-account-select" className="text-xs font-black text-slate-700 whitespace-nowrap">
              المحفظة النشطة:
            </label>
            <select
              id="wallet-account-select"
              value={activeWalletId}
              onChange={(e) => {
                setActiveWalletId(e.target.value);
                setOpFeedback(null);
              }}
              className="bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-black text-slate-900 w-full max-w-md cursor-pointer shadow-2xs"
            >
              {wallets.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.ownerName} ({w.ownerType === 'admin' ? 'إدارة المنصة - إعلانات مجانية' : w.ownerType === 'business' ? 'نشاط تجاري' : 'مشترك'})
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={() => setShowNumbers((prev) => !prev)}
            className="inline-flex items-center justify-center gap-1.5 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 px-3 py-2 rounded-xl text-xs font-black cursor-pointer transition-colors"
          >
            {showNumbers ? (
              <>
                <EyeOff className="w-3.5 h-3.5 text-slate-600" />
                <span>إخفاء الأرقام</span>
              </>
            ) : (
              <>
                <Eye className="w-3.5 h-3.5 text-emerald-600" />
                <span>إظهار الأرقام</span>
              </>
            )}
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-5 pt-4 flex items-center gap-2 border-b border-slate-100 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 rounded-t-2xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'overview'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            الرصيد والائتمان
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('operations')}
            className={`px-4 py-2.5 rounded-t-2xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'operations'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            شحن وسحب وتسوية
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ledger')}
            className={`px-4 py-2.5 rounded-t-2xl text-xs font-black transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'ledger'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>سجل المعاملات ({walletLedger.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('architecture')}
            className={`px-4 py-2.5 rounded-t-2xl text-xs font-black transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'architecture'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>هيكل البيانات والحالة v4.0</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[70vh] overflow-y-auto">
          {activeTab === 'overview' && (
            <div className="space-y-5">
              {/* Primary Balance Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white p-5 rounded-2xl shadow-md space-y-1">
                  <span className="text-[11px] font-bold text-emerald-100">الرصيد النقدي المتاح</span>
                  <div className="text-2xl font-black tracking-tight" data-testid="wallet-available-balance">
                    {formatMasked(currentWallet.availableBalance)}
                  </div>
                  <span className="text-[10px] text-emerald-100 block">
                    الرصيد المعلق قيد التسوية: {formatMasked(currentWallet.pendingBalance)}
                  </span>
                </div>

                <div className="bg-slate-900 text-white p-5 rounded-2xl shadow-md space-y-1">
                  <span className="text-[11px] font-bold text-amber-300">حد الائتمان المتاح للسحب والطلبات</span>
                  <div className="text-2xl font-black text-amber-400 tracking-tight">
                    {formatMasked(remainingCredit)}
                  </div>
                  <span className="text-[10px] text-slate-400 block">
                    المستخدم: {formatMasked(currentWallet.usedCredit)} من أصل {formatMasked(currentWallet.creditLimit)}
                  </span>
                </div>

                <div className="bg-indigo-950 text-white p-5 rounded-2xl shadow-md space-y-1 border border-indigo-500/30">
                  <span className="text-[11px] font-bold text-indigo-200">رصيد منح الإعلانات الممولة</span>
                  <div className="text-xl font-black text-white tracking-tight">
                    {currentWallet.isFreeSponsoredAdsEnabled
                      ? 'مجاني بلا حدود للإدارة (0 ج.م)'
                      : formatMasked(currentWallet.adGrantBalance)}
                  </div>
                  <span className="text-[10px] text-indigo-300 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    <span>
                      {currentWallet.isFreeSponsoredAdsEnabled
                        ? 'إعفاء إعلاني رسمي 100% للإدارة'
                        : 'رصيد ترويجي لدعم حملات النشاط'}
                    </span>
                  </span>
                </div>
              </div>

              {/* Quick Actions inside Overview */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="text-xs font-black text-slate-900">
                    إجراءات المحفظة السريعة ({currentWallet.ownerName})
                  </div>
                  <p className="text-[11px] text-slate-500">
                    يمكنك شحن الرصيد عبر فودافون كاش أو إنستا باي أو Paymob، أو إطلاق إعلان ممول مجاني للإدارة.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setOpType('deposit');
                      setActiveTab('operations');
                    }}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-4 py-2.5 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <ArrowDownLeft className="w-4 h-4" />
                    <span>شحن المحفظة</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setOpType('admin_free_ad_grant');
                      setActiveTab('operations');
                    }}
                    className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>منحة إعلان مجاني للإدارة (0 ج.م)</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'operations' && (
            <form onSubmit={handleExecuteOperation} className="space-y-4">
              {opFeedback && (
                <div
                  className={`p-3.5 rounded-2xl border text-xs font-black flex items-center gap-2 ${
                    opFeedback.type === 'success'
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                      : 'bg-rose-50 border-rose-200 text-rose-800'
                  }`}
                >
                  {opFeedback.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span>{opFeedback.text}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1.5">نوع العملية المالية</label>
                  <select
                    value={opType}
                    onChange={(e) => setOpType(e.target.value as WalletTransactionType)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-black text-slate-900 cursor-pointer"
                  >
                    <option value="deposit">شحن وإيداع رصيد بالمحفظة (+)</option>
                    <option value="admin_free_ad_grant">منحة إعلان ممول مجاني للإدارة (0 ج.م)</option>
                    <option value="commission_deduction">سداد عمولة المنصة والطلبات (-)</option>
                    <option value="credit_settlement">تسوية وسداد حد الائتمان المستخدم</option>
                    <option value="withdrawal">سحب رصيد نقدي (-)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1.5">
                    المبلغ ({currentWallet.currency})
                  </label>
                  <input
                    type="number"
                    min={0}
                    disabled={opType === 'admin_free_ad_grant'}
                    value={opType === 'admin_free_ad_grant' ? 0 : opAmount}
                    onChange={(e) => setOpAmount(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-black text-slate-900 disabled:bg-slate-100 disabled:text-emerald-700"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1.5">وسيلة الدفع / التسوية</label>
                  <select
                    value={opChannel}
                    onChange={(e) => setOpChannel(e.target.value as WalletPaymentChannel)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold text-slate-900 cursor-pointer"
                  >
                    <option value="vodafone_cash">فودافون كاش / محافظ الهاتف</option>
                    <option value="instapay">إنستا باي (InstaPay Egypt)</option>
                    <option value="paymob_card">بطاقة بنكية عبر Paymob</option>
                    <option value="admin_grant">اعتماد مجاني مباشر من الإدارة (0 ج.م)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1.5">بيان العملية / ملاحظات</label>
                  <input
                    type="text"
                    value={opDescription}
                    onChange={(e) => setOpDescription(e.target.value)}
                    placeholder="مثال: شحن رصيد لحساب النشاط التجاري..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold text-slate-900"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs py-3.5 rounded-2xl shadow-md flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <CreditCard className="w-4 h-4" />
                <span>تنفيذ وتوثيق العملية في دفتر الأستاذ المالي</span>
              </button>
            </form>
          )}

          {activeTab === 'ledger' && (
            <div className="space-y-3">
              {walletLedger.length === 0 ? (
                <div className="text-center py-8 text-xs font-bold text-slate-400">
                  لا توجد حركات مالية مسجلة لهذه المحفظة حتى الآن.
                </div>
              ) : (
                walletLedger.map((tx) => {
                  const isPositive =
                    tx.type === 'deposit' || tx.type === 'cashback' || tx.type === 'admin_free_ad_grant';
                  return (
                    <div
                      key={tx.id}
                      className="p-4 rounded-2xl border border-slate-200 bg-white flex items-center justify-between gap-3"
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                            tx.isFreeAdminGrant
                              ? 'bg-amber-100 text-amber-800'
                              : isPositive
                              ? 'bg-emerald-100 text-emerald-700'
                              : 'bg-rose-100 text-rose-700'
                          }`}
                        >
                          {isPositive ? (
                            <ArrowDownLeft className="w-4 h-4" />
                          ) : (
                            <ArrowUpRight className="w-4 h-4" />
                          )}
                        </div>
                        <div className="space-y-0.5">
                          <div className="font-black text-xs text-slate-900">{tx.description}</div>
                          <div className="text-[11px] text-slate-500">
                            {tx.createdAt} • الوسيلة: {tx.paymentMethod}
                          </div>
                        </div>
                      </div>
                      <div className="text-left shrink-0">
                        <div
                          className={`font-black text-xs ${
                            tx.isFreeAdminGrant
                              ? 'text-amber-700 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200'
                              : isPositive
                              ? 'text-emerald-700'
                              : 'text-rose-700'
                          }`}
                        >
                          {tx.isFreeAdminGrant
                            ? 'مجاني للإدارة (0 ج.م)'
                            : `${isPositive ? '+' : '-'}${tx.amount.toLocaleString('ar-EG')} ج.م`}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          الرصيد بعدها: {formatMasked(tx.balanceAfter)}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {activeTab === 'architecture' && (
            <div className="space-y-4">
              <div className="bg-slate-900 text-white p-5 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-emerald-400">
                    هيكل البيانات والحالة الموحد (Normalized State Architecture {enterpriseStateSummary.schemaVersion})
                  </span>
                  <span className="text-[10px] bg-white/10 px-2.5 py-0.5 rounded-full">
                    محدث آنياً
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  تم تطوير هيكل البيانات والحالة بأسلوب مؤسسي يفصل بين كيانات الأنشطة الموثقة، الدليل المجاني، محافظ المستخدمين والإدارة، سجل المعاملات الذري (Atomic Ledger)، وحملات التسويق الذكي.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="text-lg font-black text-slate-900">{enterpriseStateSummary.totalBusinesses}</div>
                  <div className="text-[11px] font-bold text-slate-500">إجمالي الأنشطة</div>
                </div>
                <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200">
                  <div className="text-lg font-black text-emerald-800">{enterpriseStateSummary.totalWallets}</div>
                  <div className="text-[11px] font-bold text-emerald-700">المحافظ النشطة</div>
                </div>
                <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200">
                  <div className="text-lg font-black text-amber-900">{enterpriseStateSummary.activeSponsoredAds}</div>
                  <div className="text-[11px] font-bold text-amber-800">بنرات ممولة مربعة</div>
                </div>
                <div className="p-3.5 rounded-2xl bg-indigo-50 border border-indigo-200">
                  <div className="text-lg font-black text-indigo-900">{enterpriseStateSummary.totalGeneratedCampaigns}</div>
                  <div className="text-[11px] font-bold text-indigo-700">حملات تسويقية مولدة</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3.5 flex items-center justify-between text-xs">
          <span className="text-slate-500 font-bold flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>حماية خصوصية الرصيد مفعلة — لا يظهر الرصيد في الشريط العلوي أبداً</span>
          </span>
          <button
            type="button"
            onClick={() => setIsWalletModalOpen(false)}
            className="bg-slate-900 hover:bg-slate-800 text-white font-black px-5 py-2 rounded-xl cursor-pointer"
          >
            إغلاق المحفظة
          </button>
        </div>
      </div>
    </div>
  );
};
