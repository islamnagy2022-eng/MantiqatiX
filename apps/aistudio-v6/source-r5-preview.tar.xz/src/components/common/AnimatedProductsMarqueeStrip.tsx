import React, { useRef, useState, useEffect } from 'react';
import { Product, Business } from '../../types';
import {
  Sparkles,
  Flame,
  Award,
  ChevronRight,
  ChevronLeft,
  Pause,
  Play,
  CheckCircle2,
  Tag,
  ExternalLink,
  TrendingUp,
} from 'lucide-react';

export interface MarqueeProductItem {
  product: Product;
  business?: Business;
  sectorShortName?: string;
  rankIndex?: number;
  ordersCount?: number;
  highlightBadge?: string;
}

interface AnimatedProductsMarqueeStripProps {
  title: string;
  subtitle?: string;
  badgeLabel: string;
  badgeType: 'picked' | 'trending';
  items: MarqueeProductItem[];
  onOpenStorefront: (businessId: string) => void;
  speedMs?: number;
}

export const AnimatedProductsMarqueeStrip: React.FC<AnimatedProductsMarqueeStripProps> = ({
  title,
  badgeLabel,
  badgeType,
  items,
  onOpenStorefront,
  speedMs = 3000,
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  // Check scroll boundary
  const updateScrollButtons = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    const maxScroll = scrollWidth - clientWidth;
    const currentAbsScroll = Math.abs(scrollLeft);
    setCanScrollRight(currentAbsScroll < maxScroll - 5);
    setCanScrollLeft(currentAbsScroll > 5);
  };

  // Auto-scroll animation interval
  useEffect(() => {
    if (items.length <= 2 || isPaused) return;

    const timer = setInterval(() => {
      if (!scrollRef.current) return;
      const el = scrollRef.current;
      const cardWidth = 220; // compact width of one card + gap

      const maxScroll = el.scrollWidth - el.clientWidth;
      const currentScroll = Math.abs(el.scrollLeft);

      if (currentScroll >= maxScroll - 20) {
        // Reset to start smoothly
        el.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        // Step forward by one card in RTL
        const direction = -1;
        el.scrollBy({ left: direction * cardWidth, behavior: 'smooth' });
      }
    }, speedMs);

    return () => clearInterval(timer);
  }, [items.length, isPaused, speedMs]);

  const handleManualScroll = (direction: 'next' | 'prev') => {
    if (!scrollRef.current) return;
    const cardWidth = 230;
    const scrollAmount = direction === 'next' ? -cardWidth : cardWidth;
    scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
  };

  if (items.length === 0) return null;

  return (
    <section
      aria-label={title}
      className={`rounded-2xl sm:rounded-3xl p-3 sm:p-4 border shadow-xs transition-all ${
        badgeType === 'picked'
          ? 'bg-gradient-to-r from-emerald-50/70 via-white to-teal-50/50 border-emerald-200'
          : 'bg-gradient-to-r from-amber-50/70 via-white to-orange-50/50 border-amber-200'
      }`}
      dir="rtl"
    >
      {/* Sleek, Compact Header with Title, Badge, Item Count & Controls (بدون شروحات) */}
      <div className="flex items-center justify-between gap-3 border-b border-slate-200/70 pb-3 mb-3">
        <div className="flex items-center gap-2.5">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-xs ${
              badgeType === 'picked'
                ? 'bg-emerald-600 text-white'
                : 'bg-amber-500 text-slate-950'
            }`}
          >
            {badgeType === 'picked' ? (
              <Award className="w-5 h-5" />
            ) : (
              <Flame className="w-5 h-5" />
            )}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="font-black text-sm sm:text-base text-slate-900">{title}</h2>
            <span
              className={`text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 ${
                badgeType === 'picked'
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-amber-100 text-amber-900 border border-amber-300'
              }`}
            >
              <Sparkles className="w-2.5 h-2.5" />
              <span>{badgeLabel}</span>
            </span>
            <span className="text-[10px] font-black text-slate-600 bg-white px-2 py-0.5 rounded-md border border-slate-200 shadow-2xs">
              {items.length} نشاط متنوع
            </span>
          </div>
        </div>

        {/* Animation Controls: Play/Pause, Prev, Next */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setIsPaused(!isPaused)}
            className={`px-2 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer border ${
              isPaused
                ? 'bg-amber-500 text-slate-950 border-amber-400'
                : 'bg-white text-slate-700 hover:bg-slate-100 border-slate-200 shadow-2xs'
            }`}
            title={isPaused ? 'تشغيل الحركة' : 'إيقاف مؤقت'}
          >
            {isPaused ? (
              <>
                <Play className="w-3 h-3 fill-current" />
                <span>تشغيل</span>
              </>
            ) : (
              <>
                <Pause className="w-3 h-3" />
                <span>إيقاف</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => handleManualScroll('prev')}
            className="w-7 h-7 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 flex items-center justify-center cursor-pointer transition-colors shadow-2xs"
            title="السابق"
            aria-label="السابق"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={() => handleManualScroll('next')}
            className="w-7 h-7 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 flex items-center justify-center cursor-pointer transition-colors shadow-2xs"
            title="التالي"
            aria-label="التالي"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Moving Products Track: Compact Sleek Cards */}
      <div
        ref={scrollRef}
        onScroll={updateScrollButtons}
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        className="flex items-stretch gap-2.5 sm:gap-3 overflow-x-auto pb-1.5 scrollbar-none snap-x snap-mandatory"
        style={{ scrollBehavior: 'smooth' }}
      >
        {items.map((item, idx) => {
          const { product, business, sectorShortName, rankIndex, ordersCount, highlightBadge } = item;
          const hasDiscount = Boolean(
            typeof product.comparePrice === 'number' && product.comparePrice > product.price
          );
          const discountPercent = hasDiscount && product.comparePrice
            ? Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100)
            : 0;

          return (
            <div
              key={`marquee_${product.id}_${idx}`}
              className="w-48 sm:w-52 shrink-0 bg-white rounded-xl border border-slate-200 hover:border-emerald-400 p-2 sm:p-2.5 flex flex-col justify-between gap-2 transition-all duration-300 hover:shadow-md group snap-start"
            >
              {/* Product Photo with Badges */}
              <div
                onClick={() => business && onOpenStorefront(business.id)}
                className="relative aspect-[16/11] w-full rounded-lg overflow-hidden bg-slate-100 cursor-pointer"
                title={`عرض نشاط ${business?.name || ''}`}
              >
                <img
                  src={product.imageUrl || business?.coverUrl}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                {/* Top Badges */}
                <div className="absolute top-1.5 right-1.5 flex flex-col gap-1 items-start">
                  {hasDiscount && (
                    <span className="bg-rose-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded-md shadow-xs flex items-center gap-0.5">
                      <Tag className="w-2 h-2" />
                      <span>خصم {discountPercent}%</span>
                    </span>
                  )}
                  {rankIndex !== undefined && (
                    <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded-md shadow-xs">
                      #{rankIndex} طلب
                    </span>
                  )}
                  {highlightBadge && (
                    <span className="bg-emerald-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded-md shadow-xs">
                      {highlightBadge}
                    </span>
                  )}
                </div>

                {/* Orders count pill */}
                {ordersCount && (
                  <div className="absolute bottom-1.5 left-1.5 bg-black/75 backdrop-blur-xs text-white text-[9px] font-bold px-1.5 py-0.5 rounded-md flex items-center gap-1">
                    <TrendingUp className="w-2.5 h-2.5 text-amber-400" />
                    <span>{ordersCount} طلب</span>
                  </div>
                )}
              </div>

              {/* Product & Business Info - NO DESCRIPTIONS (بدون شروحات) */}
              <div className="space-y-1 min-w-0">
                {/* Business Tag */}
                {business && (
                  <div
                    onClick={() => onOpenStorefront(business.id)}
                    className="flex items-center gap-1 cursor-pointer hover:opacity-85 transition-opacity"
                  >
                    <img
                      src={business.logoUrl}
                      alt={business.name}
                      className="w-3.5 h-3.5 rounded-full object-cover shrink-0 border border-slate-200"
                    />
                    <span className="text-[10px] font-black text-slate-700 truncate">
                      {business.name}
                    </span>
                    <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                    {sectorShortName && (
                      <span className="text-[8px] text-slate-400 truncate hidden sm:inline">
                        • {sectorShortName}
                      </span>
                    )}
                  </div>
                )}

                {/* Product/Activity Name */}
                <h3
                  onClick={() => business && onOpenStorefront(business.id)}
                  className="font-black text-xs text-slate-900 group-hover:text-emerald-700 line-clamp-1 cursor-pointer transition-colors"
                  title={product.name}
                >
                  {product.name}
                </h3>

                {/* Price Display */}
                <div className="flex items-baseline gap-1.5 pt-0.5">
                  <span className="text-xs sm:text-sm font-black text-emerald-700">
                    {product.price === 0 ? 'متاح بالطلب' : `${product.price.toLocaleString('ar-EG')} ج.م`}
                  </span>
                  {hasDiscount && product.comparePrice && (
                    <span className="text-[10px] font-bold text-slate-400 line-through">
                      {product.comparePrice.toLocaleString('ar-EG')} ج.م
                    </span>
                  )}
                  {product.unit && (
                    <span className="text-[9px] text-slate-400 font-normal">/ {product.unit}</span>
                  )}
                </div>
              </div>

              {/* Compact Action Button */}
              <button
                type="button"
                onClick={() => business && onOpenStorefront(business.id)}
                className="w-full bg-slate-900 hover:bg-emerald-700 text-white text-[10px] font-black py-1.5 px-2 rounded-lg flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-2xs group-hover:bg-emerald-600"
              >
                <span>عرض النشاط والطلب</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </button>
            </div>
          );
        })}
      </div>
    </section>
  );
};
