import React, { useEffect, useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Business, FunctionalGroupId } from '../types';
import { executeEnterpriseSearch } from '../utils/searchEngine';
import { filterBusinessesBySubcategory, getSubcategoriesForSector } from '../utils/subCategoriesTaxonomy';
import { DIRECTORY_PAGE_SIZE, getNextDirectoryVisibleCount } from '../utils/directoryPagination';
import { resolveBusinessLogo } from '../data/imageAssets';
import { CheckCircle2, MapPin, MessageCircle, Phone, Search, Store, ChevronLeft, RefreshCw } from 'lucide-react';

const isBusinessVerified = (business: Business) => business.isVerified && (!business.verificationStatus || business.verificationStatus === 'verified');

export const DirectoryView: React.FC = () => {
  const {
    directoryBusinesses: businesses,
    directoryStatus,
    directoryError,
    refreshPublicDirectory,
    setSelectedBusinessId,
    setCurrentView,
  } = useApp();

  const [query, setQuery] = useState('');
  const [governorate, setGovernorate] = useState('all');
  const [selectedActivityId, setSelectedActivityId] = useState('all');
  const [selectedSpecialtyId, setSelectedSpecialtyId] = useState('all');
  const [verification, setVerification] = useState<'all' | 'verified' | 'unverified'>('all');
  const [visibleCount, setVisibleCount] = useState(DIRECTORY_PAGE_SIZE);

  const activityOptions = useMemo(() => {
    const unique = new Map<string, { id: string; name: string; functionalGroupId: FunctionalGroupId }>();
    businesses.forEach((business) => {
      const name = business.category?.trim();
      if (!name) return;
      const id = `${business.functionalGroupId}::${name}`;
      unique.set(id, { id, name, functionalGroupId: business.functionalGroupId });
    });
    return Array.from(unique.values()).sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  }, [businesses]);

  const selectedActivity = activityOptions.find((item) => item.id === selectedActivityId);
  const specialties = useMemo(
    () => selectedActivity ? getSubcategoriesForSector(selectedActivity.functionalGroupId) : [],
    [selectedActivity]
  );

  useEffect(() => setVisibleCount(DIRECTORY_PAGE_SIZE), [query, governorate, selectedActivityId, selectedSpecialtyId, verification]);
  useEffect(() => setSelectedSpecialtyId('all'), [selectedActivityId]);

  const governorates = useMemo(
    () => Array.from(new Set(businesses.map((item) => item.governorate).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'ar')),
    [businesses]
  );

  const filteredBusinesses = useMemo(() => {
    let result = executeEnterpriseSearch(businesses, {
      query,
      governorate,
      functionalGroupId: selectedActivity?.functionalGroupId || 'all',
      sortBy: 'verified_first',
    });

    if (selectedActivity) {
      result = result.filter((business) => business.category === selectedActivity.name && business.functionalGroupId === selectedActivity.functionalGroupId);
    }

    if (selectedSpecialtyId !== 'all' && selectedActivity) {
      result = filterBusinessesBySubcategory(result, selectedSpecialtyId, selectedActivity.functionalGroupId);
    }

    if (verification === 'verified') result = result.filter((business) => business.isVerified && business.verificationStatus !== 'suspended');
    if (verification === 'unverified') result = result.filter((business) => !business.isVerified || business.verificationStatus === 'unverified');
    return result;
  }, [businesses, query, governorate, selectedActivity, selectedSpecialtyId, verification]);

  const openBusiness = (business: Business) => {
    setSelectedBusinessId(business.id);
    setCurrentView('public_storefront');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getActivityCount = (activity: { name: string; functionalGroupId: FunctionalGroupId }) => businesses.filter((business) =>
    business.category === activity.name && business.functionalGroupId === activity.functionalGroupId
  ).length;

  return (
    <div className="min-h-screen bg-slate-50 pb-16" dir="rtl">
      <section className="bg-gradient-to-br from-slate-950 via-emerald-950 to-teal-900 px-4 py-10 text-white sm:py-14">
        <div className="mx-auto max-w-7xl space-y-5">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-300/30 bg-emerald-300/10 px-3 py-1 text-xs font-bold text-emerald-100">
            <Store className="h-4 w-4" /> دليل الأنشطة والكتالوجات
          </div>
          <h1 className="text-3xl font-black leading-tight sm:text-4xl">اكتشف الأنشطة والخدمات القريبة منك</h1>
          <p className="max-w-2xl text-sm leading-7 text-slate-200">ابحث باسم النشاط أو التخصص، وحدد المحافظة للوصول إلى بيانات الأنشطة المنشورة. الأنشطة الموثقة تظهر أولاً.</p>
          <div className="grid gap-3 rounded-2xl bg-white p-3 shadow-xl sm:grid-cols-[1fr_220px]">
            <label className="relative block">
              <Search className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-emerald-700" />
              <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث عن نشاط أو خدمة أو تخصص..." className="min-h-12 w-full rounded-xl border border-slate-200 bg-slate-50 pr-11 pl-3 text-sm font-semibold text-slate-900 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
            </label>
            <select value={governorate} onChange={(event) => setGovernorate(event.target.value)} className="min-h-12 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm font-bold text-slate-800 outline-none focus:border-emerald-500">
              <option value="all">كل المحافظات</option>
              {governorates.map((name) => <option key={name} value={name}>{name}</option>)}
            </select>
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-7xl space-y-8 px-4 py-8">
        <section className="space-y-4">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="text-xl font-black text-slate-900">الأنشطة</h2>
              <p className="mt-1 text-sm text-slate-500">اختر النشاط أولاً ثم حدد التخصص المطلوب.</p>
            </div>
            <button type="button" onClick={() => setSelectedActivityId('all')} className="text-xs font-bold text-emerald-800 hover:underline">عرض كل الأنشطة</button>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            <button type="button" onClick={() => setSelectedActivityId('all')} className={`rounded-2xl border p-4 text-right transition ${selectedActivityId === 'all' ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-100' : 'border-slate-200 bg-white hover:border-emerald-300'}`}>
              <span className="block text-sm font-black text-slate-900">كل الأنشطة</span>
              <span className="mt-1 block text-xs text-slate-500">{businesses.length} نشاط</span>
            </button>
            {activityOptions.map((activity) => (
              <button key={activity.id} type="button" onClick={() => setSelectedActivityId(activity.id)} className={`rounded-2xl border p-4 text-right transition ${selectedActivityId === activity.id ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-100' : 'border-slate-200 bg-white hover:border-emerald-300'}`}>
                <span className="block text-sm font-black text-slate-900">{activity.name}</span>
                <span className="mt-1 block text-xs text-slate-500">{getActivityCount(activity)} نشاط</span>
              </button>
            ))}
          </div>
        </section>

        {selectedActivity && specialties.length > 0 && (
          <section className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4">
            <h3 className="text-sm font-black text-slate-900">تخصصات: {selectedActivity.name}</h3>
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={() => setSelectedSpecialtyId('all')} className={`rounded-full px-3 py-2 text-xs font-bold ${selectedSpecialtyId === 'all' ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>كل التخصصات</button>
              {specialties.map((specialty) => (
                <button key={specialty.id} type="button" onClick={() => setSelectedSpecialtyId(specialty.id)} className={`rounded-full px-3 py-2 text-xs font-bold ${selectedSpecialtyId === specialty.id ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>{specialty.name}</button>
              ))}
            </div>
          </section>
        )}

        <section className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-xl font-black text-slate-900">الأنشطة المتاحة</h2>
              <p className="mt-1 text-sm text-slate-500">{filteredBusinesses.length} نتيجة مطابقة</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {(['all', 'verified', 'unverified'] as const).map((value) => (
                <button key={value} type="button" onClick={() => setVerification(value)} className={`rounded-lg px-3 py-2 text-xs font-bold ${verification === value ? 'bg-slate-900 text-white' : 'border border-slate-200 bg-white text-slate-600'}`}>
                  {value === 'all' ? 'الكل' : value === 'verified' ? 'موثق' : 'غير موثق'}
                </button>
              ))}
            </div>
          </div>

          {directoryStatus === 'loading' && <p className="rounded-xl bg-white p-6 text-center text-sm text-slate-500">جارٍ تحميل الدليل المنشور...</p>}
          {(directoryStatus === 'error' || directoryStatus === 'not_configured') && (
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-950">
              <p className="font-bold">تعذر تحميل الدليل من الخادم.</p>
              <p className="mt-1 text-xs">{directoryError || 'تحقق من إعداد اتصال الدليل العام.'}</p>
              <button type="button" onClick={refreshPublicDirectory} className="mt-3 inline-flex items-center gap-2 rounded-lg bg-amber-700 px-3 py-2 text-xs font-bold text-white"><RefreshCw className="h-4 w-4" /> إعادة المحاولة</button>
            </div>
          )}

          {directoryStatus === 'empty' && <p className="rounded-xl bg-white p-6 text-center text-sm text-slate-500">لا توجد أنشطة منشورة حتى الآن.</p>}

          {directoryStatus === 'ready' && filteredBusinesses.length === 0 && <p className="rounded-xl bg-white p-6 text-center text-sm text-slate-500">لا توجد نتائج مطابقة. جرّب تغيير البحث أو الفلاتر.</p>}

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filteredBusinesses.slice(0, visibleCount).map((business) => {
              const verified = isBusinessVerified(business);
              const phone = business.ownerWhatsApp || business.phone || '';
              const digits = phone.replace(/\D/g, '');
              const waDigits = digits.startsWith('0') ? `20${digits.slice(1)}` : digits;
              return (
                <article key={business.id} className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
                  <button type="button" onClick={() => openBusiness(business)} className="flex w-full items-center gap-3 p-4 text-right">
                    <img src={resolveBusinessLogo(business)} alt="" className="h-14 w-14 rounded-xl border border-slate-100 object-cover" loading="lazy" />
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-center gap-1.5">
                        <span className="truncate text-sm font-black text-slate-900">{business.name}</span>
                        {verified && <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-bold text-emerald-800"><CheckCircle2 className="h-3 w-3" /> موثق</span>}
                        {!verified && <span className="rounded-full bg-amber-50 px-2 py-1 text-[10px] font-bold text-amber-800">غير موثق</span>}
                      </span>
                      <span className="mt-1 block truncate text-xs text-slate-500">{business.category}</span>
                    </span>
                  </button>
                  <div className="space-y-2 px-4 pb-4 text-xs text-slate-600">
                    <p className="flex items-center gap-2"><MapPin className="h-4 w-4 shrink-0 text-slate-400" /><span className="truncate">{[business.governorate, business.markaz, business.village].filter(Boolean).join(' • ') || business.address}</span></p>
                    {phone && <p className="flex items-center gap-2"><Phone className="h-4 w-4 shrink-0 text-slate-400" /><span dir="ltr">{phone}</span></p>}
                    <div className="grid grid-cols-2 gap-2 pt-2">
                      {waDigits && <a href={`https://wa.me/${waDigits}`} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-10 items-center justify-center gap-1 rounded-lg bg-emerald-600 px-2 text-xs font-bold text-white"><MessageCircle className="h-4 w-4" /> واتساب</a>}
                      <button type="button" onClick={() => openBusiness(business)} className="inline-flex min-h-10 items-center justify-center gap-1 rounded-lg bg-slate-100 px-2 text-xs font-bold text-slate-800">عرض النشاط <ChevronLeft className="h-4 w-4" /></button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>

          {visibleCount < filteredBusinesses.length && (
            <div className="flex justify-center pt-2">
              <button type="button" onClick={() => setVisibleCount((current) => getNextDirectoryVisibleCount(current, filteredBusinesses.length))} className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-emerald-200 bg-white px-5 py-2.5 text-sm font-black text-emerald-800 hover:bg-emerald-50">رؤية المزيد <ChevronLeft className="h-4 w-4" /></button>
            </div>
          )}
        </section>
      </main>
    </div>
  );
};
