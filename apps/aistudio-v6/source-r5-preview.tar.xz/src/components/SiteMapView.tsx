import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DEFAULT_SITE_MAP_CONFIG } from '../data/seedData';
import { NonCompetingSponsoredAdsStrip } from './common/NonCompetingSponsoredAdsStrip';
import {
  Map,
  Sparkles,
  CheckCircle2,
  Layers,
  Store,
  ShieldCheck,
  MessageCircle,
  TrendingUp,
  Edit,
  Save,
  ArrowRight,
  Compass,
  Award,
  Users,
  Megaphone,
  FileText,
} from 'lucide-react';

const SECTOR_EMOJIS: Record<string, string> = {
  dining: '🍽️',
  retail: '🛍️',
  services: '📅',
  healthcare: '🩺',
  crafts_maintenance: '🔧',
  education_training: '🎓',
  real_estate: '🏢',
  tourism_hotels: '🧭',
  transport_logistics: '🚚',
  agriculture_livestock: '🌱',
  technology_software: '💻',
  sports_fitness: '🏋️',
  events_entertainment: '🎉',
  legal_financial: '⚖️',
  industrial_manufacturing: '🏭',
};

export const SiteMapView: React.FC = () => {
  const {
    adminSettings,
    updateAdminSettings,
    functionalGroups,
    businesses,
    authSession,
    setCurrentView,
    setSelectedFunctionalGroupFilter,
    setIsSubscribeModalOpen,
    setAdModalType,
  } = useApp();

  const isAdmin = authSession.role === 'admin' || authSession.role === 'super_admin';
  const siteMap = adminSettings.siteMapConfig || DEFAULT_SITE_MAP_CONFIG;

  const [isEditing, setIsEditing] = useState(false);
  const [heroTitle, setHeroTitle] = useState(siteMap.heroTitle);
  const [heroSubtitle, setHeroSubtitle] = useState(siteMap.heroSubtitle);
  const [importanceText, setImportanceText] = useState(siteMap.platformImportanceText);
  const [devStatusTitle, setDevStatusTitle] = useState(siteMap.developmentStatusTitle);
  const [devProgress, setDevProgress] = useState(siteMap.developmentProgressPercent);
  const [devPhase, setDevPhase] = useState(siteMap.developmentPhaseLabel);
  const [devNotes, setDevNotes] = useState(siteMap.developmentNotes);
  const [savedNotice, setSavedNotice] = useState(false);

  const handleSaveSiteMap = (e: React.FormEvent) => {
    e.preventDefault();
    updateAdminSettings({
      siteMapConfig: {
        ...siteMap,
        heroTitle,
        heroSubtitle,
        platformImportanceText: importanceText,
        developmentStatusTitle: devStatusTitle,
        developmentProgressPercent: Number(devProgress) || 95,
        developmentPhaseLabel: devPhase,
        developmentNotes: devNotes,
        lastUpdated: new Date().toISOString().split('T')[0],
      },
    });
    setIsEditing(false);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  return (
    <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 py-8 space-y-10" dir="rtl">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-emerald-950 rounded-3xl p-6 sm:p-10 text-white shadow-2xl border border-indigo-500/20 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-3 max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-black px-3.5 py-1 rounded-full">
              <Map className="w-4 h-4" />
              <span>خريطة الموقع ودليل العمل وحالة التطوير</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight leading-snug">
              {siteMap.heroTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {siteMap.heroSubtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {isAdmin && (
              <button
                type="button"
                onClick={() => setIsEditing(!isEditing)}
                className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs px-4 py-3 rounded-2xl shadow-lg flex items-center gap-2 cursor-pointer transition-all"
              >
                <Edit className="w-4 h-4" />
                <span>{isEditing ? 'إغلاق التعديل' : 'تعديل خريطة الموقع وحالة التطوير'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setCurrentView('directory')}
              className="bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-xs px-4 py-3 rounded-2xl flex items-center gap-2 cursor-pointer transition-all"
            >
              <ArrowRight className="w-4 h-4" />
              <span>العودة للشاشة الرئيسية</span>
            </button>
          </div>
        </div>
      </div>

      {/* BELOW COVER AREA: Main Content on Right + Vertical Sponsored Ads Column on Left (بالشمال من تحت مساحة الـ Cover) */}
      <div className="flex flex-col lg:flex-row gap-6 items-stretch">
        <div className="flex-1 min-w-0 space-y-10">
          {savedNotice && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-5 py-3.5 rounded-2xl text-xs font-black flex items-center gap-2 shadow-xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>تم تحديث بيانات خريطة الموقع وحالة التطوير بنجاح!</span>
            </div>
          )}

      {/* Admin Edit Form */}
      {isAdmin && isEditing && (
        <form
          onSubmit={handleSaveSiteMap}
          className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-amber-400 shadow-xl space-y-5"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 className="font-black text-base text-slate-900 flex items-center gap-2">
              <Edit className="w-5 h-5 text-amber-500" />
              <span>تعديل محتوى خريطة الموقع وحالة التطوير (متاح للإدارة)</span>
            </h2>
            <span className="text-[11px] font-bold text-slate-400">آخر تحديث: {siteMap.lastUpdated}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">العنوان الرئيسي لخريطة الموقع</label>
              <input
                type="text"
                value={heroTitle}
                onChange={(e) => setHeroTitle(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">عنوان حالة التطوير الحالية</label>
              <input
                type="text"
                value={devStatusTitle}
                onChange={(e) => setDevStatusTitle(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-black text-slate-700 mb-1">الوصف الترحيبي المختصر</label>
            <input
              type="text"
              value={heroSubtitle}
              onChange={(e) => setHeroSubtitle(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-black text-slate-700 mb-1">شرح أهمية الموقع للعميل وصاحب النشاط</label>
            <textarea
              rows={3}
              value={importanceText}
              onChange={(e) => setImportanceText(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">نسبة إنجاز التطوير (%)</label>
              <input
                type="number"
                min={1}
                max={100}
                value={devProgress}
                onChange={(e) => setDevProgress(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-black text-slate-700 mb-1">المرحلة التشغيلية الحالية</label>
              <input
                type="text"
                value={devPhase}
                onChange={(e) => setDevPhase(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-black text-slate-700 mb-1">تفاصيل حالة التطوير والميزات المفعلة</label>
            <textarea
              rows={2}
              value={devNotes}
              onChange={(e) => setDevNotes(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-2 cursor-pointer shadow-md"
            >
              <Save className="w-4 h-4" />
              <span>حفظ تحديثات خريطة الموقع</span>
            </button>
          </div>
        </form>
      )}

      {/* Section 1: Importance of the Platform & Live Development Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-black text-lg text-slate-900">أهمية منصة MantiqatiX وفلسفة العمل</h2>
              <p className="text-xs text-slate-500">لماذا تعتبر المنصة الخيار الأول للأنشطة والزوار؟</p>
            </div>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            {siteMap.platformImportanceText}
          </p>
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200">
              <div className="font-black text-emerald-900 text-xs">أنشطة موثقة بالكامل</div>
              <div className="text-[11px] text-emerald-700 mt-1">
                كتالوج منتجات وخدمات مستقل، سلة طلبات واتساب، دفع Paymob، وروابط مخصصة.
              </div>
            </div>
            <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200">
              <div className="font-black text-amber-900 text-xs">دليل مجاني للأنشطة (غير موثق)</div>
              <div className="text-[11px] text-amber-800 mt-1">
                يقتصر على الاسم والموقع والرقم لخدمة الزوار في كافة المجالات لحين التوثيق.
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                <h2 className="font-black text-lg text-slate-900">{siteMap.developmentStatusTitle}</h2>
                <p className="text-xs text-indigo-600 font-bold">{siteMap.developmentPhaseLabel}</p>
              </div>
            </div>
            <span className="bg-indigo-600 text-white font-black text-sm px-3.5 py-1.5 rounded-2xl shadow-xs">
              {siteMap.developmentProgressPercent}%
            </span>
          </div>

          <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-indigo-600 rounded-full transition-all duration-500"
              style={{ width: `${siteMap.developmentProgressPercent}%` }}
            />
          </div>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            {siteMap.developmentNotes}
          </p>

          <div className="flex flex-wrap gap-2 pt-1">
            <span className="text-[11px] font-bold bg-slate-100 text-slate-700 px-3 py-1 rounded-xl">
              ✓ 15 قطاعاً رئيسياً مفعلاً
            </span>
            <span className="text-[11px] font-bold bg-slate-100 text-slate-700 px-3 py-1 rounded-xl">
              ✓ نظام مالي وائتماني للنشاط
            </span>
            <span className="text-[11px] font-bold bg-slate-100 text-slate-700 px-3 py-1 rounded-xl">
              ✓ إعلانات ممولة ويافطات غير مزعجة
            </span>
            <span className="text-[11px] font-bold bg-slate-100 text-slate-700 px-3 py-1 rounded-xl">
              ✓ ربط Google AI Studio للإدارة
            </span>
          </div>
        </div>
      </div>

      {/* Section 2: Interactive Map of the 15 Economic Sectors */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="font-black text-lg sm:text-xl text-slate-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-emerald-600" />
              <span>خريطة القطاعات الـ 15 الشاملة في المنصة</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              اضغط على أي قطاع للانتقال مباشرة إلى الشاشة الرئيسية وتصفح الأنشطة المسجلة به
            </p>
          </div>
          <span className="text-xs font-black bg-emerald-50 text-emerald-700 border border-emerald-200 px-3 py-1.5 rounded-xl">
            إجمالي القطاعات المفعلة: {functionalGroups.length} قطاعاً
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {functionalGroups.map((group, idx) => {
            const count = businesses.filter((b) => b.functionalGroupId === group.id).length;
            return (
              <button
                key={group.id}
                type="button"
                onClick={() => {
                  setSelectedFunctionalGroupFilter(group.id);
                  setCurrentView('directory');
                }}
                className="p-4 rounded-2xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/40 text-right transition-all flex items-start justify-between gap-3 cursor-pointer group"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{SECTOR_EMOJIS[group.id] || '🏢'}</span>
                    <span className="font-black text-sm text-slate-900 group-hover:text-emerald-700">
                      {idx + 1}. {group.shortName}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 line-clamp-1">{group.name}</div>
                </div>
                <span className="bg-slate-100 group-hover:bg-emerald-600 group-hover:text-white text-slate-700 font-black text-xs px-2.5 py-1 rounded-xl transition-colors">
                  {count} نشاط
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Section 3: How to Benefit from Our Services */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2.5">
            <Users className="w-5 h-5 text-blue-600" />
            <h3 className="font-black text-base sm:text-lg text-slate-900">
              طرق الاستفادة للزائرين والعملاء
            </h3>
          </div>
          <ul className="space-y-2.5 text-xs sm:text-sm text-slate-600">
            {siteMap.visitorBenefits.map((item, i) => (
              <li key={i} className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
          <div className="pt-2 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setCurrentView('directory')}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-4 py-2.5 rounded-xl cursor-pointer"
            >
              تصفح الدليل الشامل الآن
            </button>
            <button
              type="button"
              onClick={() => setCurrentView('contact_us')}
              className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs px-4 py-2.5 rounded-xl cursor-pointer"
            >
              تواصل معنا أو أرسل استفساراً
            </button>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2.5">
            <Store className="w-5 h-5 text-amber-600" />
            <h3 className="font-black text-base sm:text-lg text-slate-900">
              طرق الاستفادة لأصحاب الأنشطة والمعلنين
            </h3>
          </div>
          <ul className="space-y-2.5 text-xs sm:text-sm text-slate-600">
            {siteMap.merchantBenefits.map((item, i) => (
              <li key={i} className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
          <div className="pt-2 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setIsSubscribeModalOpen(true)}
              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl cursor-pointer flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>أرغب في اشتراك نشاطي</span>
            </button>
            <button
              type="button"
              onClick={() => setAdModalType('sponsored_ad')}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl cursor-pointer flex items-center gap-1.5"
            >
              <Megaphone className="w-3.5 h-3.5" />
              <span>تقديم إعلان ممول</span>
            </button>
          </div>
        </div>
      </div>
        </div>

        <NonCompetingSponsoredAdsStrip
          pageLabel="خريطة الموقع وحالة التطوير"
          limit={5}
        />
      </div>
    </div>
  );
};
