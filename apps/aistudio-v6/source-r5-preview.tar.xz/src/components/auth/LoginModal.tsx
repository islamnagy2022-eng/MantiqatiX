import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AlertCircle, CheckCircle2, KeyRound, Loader2, Lock, Mail, ShieldCheck, Store, UserRound, X } from 'lucide-react';

export const LoginModal: React.FC = () => {
  const {
    isLoginModalOpen,
    setIsLoginModalOpen,
    authStatus,
    authEmail,
    authError,
    authCandidates,
    authBusinessSelectionRequired,
    requestLoginOtp,
    verifyLoginOtp,
    selectAuthMembership,
    logout,
  } = useApp();
  const [email, setEmail] = useState(authEmail);
  const [code, setCode] = useState('');
  const [resendSeconds, setResendSeconds] = useState(0);

  useEffect(() => {
    if (resendSeconds <= 0) return;
    const timer = window.setTimeout(() => setResendSeconds((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearTimeout(timer);
  }, [resendSeconds]);

  if (!isLoginModalOpen) return null;

  const busy = authStatus === 'sending_otp' || authStatus === 'verifying_otp';
  const isOtpStage = authStatus === 'otp_sent' || authStatus === 'verifying_otp';
  const isMembershipStage = authStatus === 'select_membership';

  const submitEmail = async (event: React.FormEvent) => {
    event.preventDefault();
    const sent = await requestLoginOtp(email);
    if (sent) setResendSeconds(60);
  };

  const submitCode = async (event: React.FormEvent) => {
    event.preventDefault();
    await verifyLoginOtp(code);
  };

  const candidateTitle = (candidate: typeof authCandidates[number]) => {
    if (candidate.role === 'super_admin') return 'إدارة المنصة العليا';
    if (candidate.role === 'customer') return 'حساب عميل';
    return 'لوحة صاحب النشاط';
  };

  const candidateDescription = (candidate: typeof authCandidates[number]) => {
    if (candidate.role === 'super_admin') return 'صلاحية المنصة الشاملة المعتمدة من الخادم';
    if (candidate.role === 'customer') return `حساب عميل — نطاق ${candidate.tenantId.slice(0, 8)}`;
    return `نشاط ${candidate.businessName || candidate.businessId?.slice(0, 8) || 'مرتبط بالحساب'}${candidate.branchId ? ` — فرع ${candidate.branchId.slice(0, 8)}` : ''}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="login-modal-title"
        className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl space-y-5 text-right"
        dir="rtl"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 id="login-modal-title" className="font-black text-base text-slate-900">تسجيل الدخول الآمن</h2>
              <p className="text-[11px] text-slate-500">رمز تحقق بالبريد الإلكتروني عبر Supabase Auth</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setIsLoginModalOpen(false)}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 flex items-center justify-center"
            aria-label="إغلاق نافذة تسجيل الدخول"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {authStatus === 'authenticated' ? (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-emerald-900 space-y-2">
            <CheckCircle2 className="w-6 h-6" />
            <p className="font-black text-sm">تم التحقق من الحساب والعضوية</p>
          </div>
        ) : null}

        {!isOtpStage && !isMembershipStage && authStatus !== 'no_membership' && authStatus !== 'authenticated' ? (
          <form onSubmit={submitEmail} className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="auth-email" className="block text-xs font-black text-slate-700">البريد الإلكتروني المسجل بالحساب</label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  id="auth-email"
                  type="email"
                  autoComplete="email"
                  dir="ltr"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  required
                  maxLength={254}
                  placeholder="name@example.com"
                  className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-3 pr-10 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                />
              </div>
            </div>
            <p className="text-[11px] leading-5 text-slate-500">
              لن يتم إنشاء حساب جديد من هذه الشاشة. يجب أن يكون البريد مرتبطًا بحساب موجود بالفعل، وسيتم إرسال رمز مؤقت للتحقق.
            </p>
            <button type="submit" disabled={busy} className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-black flex items-center justify-center gap-2">
              {authStatus === 'sending_otp' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
              إرسال رمز الدخول
            </button>
          </form>
        ) : null}

        {isOtpStage ? (
          <form onSubmit={submitCode} className="space-y-4">
            <div className="rounded-2xl border border-indigo-100 bg-indigo-50 p-3 text-xs leading-6 text-indigo-900">
              أرسلنا رمز تحقق إلى <b dir="ltr">{authEmail}</b>. أدخل الرمز المكوّن من 6 أرقام لإكمال التحقق.
            </div>
            <div className="space-y-2">
              <label htmlFor="auth-otp" className="block text-xs font-black text-slate-700">رمز التحقق</label>
              <div className="relative">
                <KeyRound className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  id="auth-otp"
                  type="text"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  dir="ltr"
                  pattern="[0-9]{6}"
                  maxLength={6}
                  value={code}
                  onChange={(event) => setCode(event.target.value.replace(/\D/g, '').slice(0, 6))}
                  required
                  className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-3 pr-10 text-center text-xl tracking-[0.5em] font-black outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                />
              </div>
            </div>
            <button type="submit" disabled={busy || code.length !== 6} className="w-full py-3 rounded-xl bg-indigo-700 hover:bg-indigo-800 disabled:opacity-50 text-white text-xs font-black flex items-center justify-center gap-2">
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
              التحقق من الرمز والعضوية
            </button>
            <button type="button" onClick={async () => { setCode(''); const sent = await requestLoginOtp(authEmail); if (sent) setResendSeconds(60); }} disabled={busy || resendSeconds > 0} className="w-full text-xs text-indigo-700 font-bold disabled:opacity-50">{resendSeconds > 0 ? `يمكن إعادة الإرسال بعد ${resendSeconds} ثانية` : 'إرسال رمز جديد'}</button>
            <button type="button" onClick={() => { logout(); setCode(''); setResendSeconds(0); }} disabled={busy} className="w-full text-xs text-slate-500 font-bold disabled:opacity-50">تغيير البريد الإلكتروني</button>
          </form>
        ) : null}

        {isMembershipStage ? (
          <div className="space-y-3">
            <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-3 text-xs leading-6 text-emerald-900">
              تم التحقق من هوية البريد وقراءة العضويات النشطة من الخادم. اختر نطاق العمل الذي تريد فتحه؛ لن يتم اختيار أول عضوية تلقائيًا.
            </div>
            {authCandidates.map((candidate) => (
              <button
                key={candidate.selectionKey}
                type="button"
                onClick={() => selectAuthMembership(candidate.selectionKey)}
                className="w-full rounded-2xl border border-slate-200 p-4 text-right hover:border-indigo-400 hover:bg-indigo-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
                    {candidate.role === 'super_admin' ? <ShieldCheck className="w-5 h-5" /> : candidate.role === 'subscriber' ? <Store className="w-5 h-5" /> : <UserRound className="w-5 h-5" />}
                  </span>
                  <span className="min-w-0">
                    <span className="block text-sm font-black text-slate-900">{candidateTitle(candidate)}</span>
                    <span className="block text-[11px] text-slate-500 mt-1">{candidateDescription(candidate)}</span>
                  </span>
                </div>
              </button>
            ))}
          </div>
        ) : null}

        {authStatus === 'no_membership' ? (
          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 space-y-2">
            <div className="flex items-center gap-2 text-amber-950 font-black text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>الحساب تم التحقق منه، لكن لا توجد عضوية قابلة للاختيار</span>
            </div>
            {authBusinessSelectionRequired > 0 ? <p className="text-xs leading-6 text-amber-900">توجد عضوية مالك على مستوى المستأجر تحتاج إلى اختيار نشاط محدد. لن نفتح لوحة النشاط دون إتمام هذا الربط.</p> : null}
          </div>
        ) : null}

        {authError ? (
          <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs leading-6 text-rose-800">{authError}</div>
        ) : null}

        {authStatus === 'no_membership' || authStatus === 'error' ? (
          <button type="button" onClick={() => { logout(); setEmail(''); setCode(''); }} className="w-full py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold">استخدام بريد آخر</button>
        ) : null}

        <button
          type="button"
          onClick={() => setIsLoginModalOpen(false)}
          className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-black text-xs rounded-xl transition-colors"
        >
          متابعة التصفح كزائر
        </button>
      </section>
    </div>
  );
};
