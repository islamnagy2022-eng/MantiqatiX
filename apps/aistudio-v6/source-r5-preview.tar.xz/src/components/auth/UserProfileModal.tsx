import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { PersonalSiteBookmark } from '../../types';
import {
  User,
  Mail,
  Phone,
  Store,
  X,
  CheckCircle2,
  ExternalLink,
  Globe,
  Plus,
  Trash2,
  Lock,
} from 'lucide-react';

export const UserProfileModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const {
    authSession,
    subscribers,
    updateSubscriber,
    businesses,
    setCurrentView,
    setSelectedBusinessId,
    openMemberMessagingForTarget,
  } = useApp();

  const currentSubscriber = authSession.role === 'subscriber' && authSession.subscriberId
    ? subscribers.find((s) => s.id === authSession.subscriberId)
    : undefined;
  const assignedBusiness = businesses.find((b) => b.id === (currentSubscriber?.businessId || authSession.businessId));

  const [fullName, setFullName] = useState(currentSubscriber?.fullName || authSession.subscriberName || '');
  const [email, setEmail] = useState(currentSubscriber?.email || authSession.userEmail || '');
  const [phone, setPhone] = useState(currentSubscriber?.phone || authSession.userPhone || '');
  const [personalSites, setPersonalSites] = useState<PersonalSiteBookmark[]>(currentSubscriber?.personalSites || []);
  const [newSiteTitle, setNewSiteTitle] = useState('');
  const [newSiteUrl, setNewSiteUrl] = useState('');
  const [siteError, setSiteError] = useState('');
  const [successMsg, setSuccessMsg] = useState(false);

  useEffect(() => {
    if (currentSubscriber) {
      setFullName(currentSubscriber.fullName || '');
      setEmail(currentSubscriber.email || '');
      setPhone(currentSubscriber.phone || '');
      setPersonalSites(currentSubscriber.personalSites || []);
    }
  }, [currentSubscriber?.id, isOpen]);

  if (!isOpen) return null;
  if (!currentSubscriber) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4" dir="rtl">
        <section role="dialog" aria-modal="true" aria-labelledby="profile-auth-required" className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 text-right">
          <h2 id="profile-auth-required" className="font-black text-base text-slate-900">ملف الحساب غير متاح</h2>
          <p className="text-xs leading-6 text-slate-600">تم التحقق من هوية الحساب، لكن ملف المشترك واهتماماته لم يتم ربطهما ببيانات الخادم بعد. لا نعرض أو نعدّل بيانات من التخزين المحلي حتى يكتمل الربط.</p>
          <button type="button" onClick={onClose} className="w-full rounded-xl bg-slate-900 text-white text-xs font-black py-3">إغلاق</button>
        </section>
      </div>
    );
  }

  const handleAddPersonalSite = () => {
    setSiteError('');
    if (!newSiteTitle.trim() || !newSiteUrl.trim()) {
      setSiteError('يرجى إدخال اسم الموقع والرابط.');
      return;
    }
    if (personalSites.length >= 15) {
      setSiteError('الحد الأقصى المسموح به هو 15 موقعاً لحفظ اهتماماتك الشخصية.');
      return;
    }
    const formattedUrl = newSiteUrl.trim().startsWith('http')
      ? newSiteUrl.trim()
      : `https://${newSiteUrl.trim()}`;

    const newBookmark: PersonalSiteBookmark = {
      id: `psite_${Date.now()}`,
      title: newSiteTitle.trim(),
      url: formattedUrl,
      status: 'pending',
      createdAt: new Date().toISOString().split('T')[0],
    };

    const updatedList = [...personalSites, newBookmark];
    setPersonalSites(updatedList);
    setNewSiteTitle('');
    setNewSiteUrl('');

    if (currentSubscriber) {
      updateSubscriber({
        ...currentSubscriber,
        personalSites: updatedList,
      });
    }
  };

  const handleRemovePersonalSite = (siteId: string) => {
    const updatedList = personalSites.filter((s) => s.id !== siteId);
    setPersonalSites(updatedList);
    if (currentSubscriber) {
      updateSubscriber({
        ...currentSubscriber,
        personalSites: updatedList,
      });
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentSubscriber) {
      updateSubscriber({
        ...currentSubscriber,
        fullName,
        email,
        phone,
        personalSites,
      });
    }
    setSuccessMsg(true);
    setTimeout(() => {
      setSuccessMsg(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-6 text-right max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-600 text-white flex items-center justify-center shadow-md font-black text-lg">
              {fullName ? fullName.charAt(0) : 'U'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-lg text-slate-900">صفحة الحساب الشخصي للمشترك</h3>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full">
                  خاص بالمشترك والإدارة فقط
                </span>
              </div>
              <p className="text-xs text-slate-500 font-bold">إدارة بيانات الحساب، النشاط المرتبط، وحفظ حتى 15 موقعاً لاهتماماتك</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {successMsg && (
          <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>تم حفظ التعديلات ومواقع الاهتمامات الشخصية بنجاح!</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">الاسم الكامل</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pr-10 pl-3 py-2.5 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">البريد الإلكتروني (Gmail)</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  dir="ltr"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pr-10 pl-3 py-2.5 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-hidden text-right"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">رقم الهاتف / الواتساب</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pr-10 pl-3 py-2.5 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-hidden text-right"
                />
              </div>
            </div>


          </div>

          {/* 15 Personal Sites Bookmark Section (لا يراه إلا المشترك والإدارة) */}
          <div className="p-4 bg-indigo-50/70 rounded-2xl border border-indigo-200 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-black text-indigo-950">
                  مواقع اهتماماتي الشخصية (حتى 15 موقعاً):
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold bg-indigo-100 text-indigo-800 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  <span>خاص: لا يراه إلا المشترك والإدارة للموافقة</span>
                </span>
                <span className="text-xs font-black text-indigo-700 bg-white px-2.5 py-0.5 rounded-lg border border-indigo-200">
                  {personalSites.length} / 15
                </span>
              </div>
            </div>

            {siteError && (
              <div className="text-[11px] font-bold text-rose-600 bg-rose-50 px-3 py-1.5 rounded-xl border border-rose-200">
                {siteError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
              <input
                type="text"
                placeholder="اسم الموقع أو الاهتمام (مثال: مورد خامات)"
                value={newSiteTitle}
                onChange={(e) => setNewSiteTitle(e.target.value)}
                className="sm:col-span-2 bg-white border border-indigo-200 rounded-xl px-3 py-2 text-xs font-bold"
              />
              <input
                type="text"
                dir="ltr"
                placeholder="الرابط (https://example.com)"
                value={newSiteUrl}
                onChange={(e) => setNewSiteUrl(e.target.value)}
                className="sm:col-span-2 bg-white border border-indigo-200 rounded-xl px-3 py-2 text-xs font-bold text-right"
              />
              <button
                type="button"
                onClick={handleAddPersonalSite}
                disabled={personalSites.length >= 15}
                className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-black text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة موقع</span>
              </button>
            </div>

            {personalSites.length > 0 ? (
              <div className="space-y-1.5 max-h-44 overflow-y-auto pt-1">
                {personalSites.map((site, idx) => (
                  <div
                    key={site.id}
                    className="flex items-center justify-between bg-white px-3 py-2 rounded-xl border border-indigo-100 text-xs shadow-2xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="font-black text-slate-400">{idx + 1}.</span>
                      <a
                        href={site.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-black text-indigo-700 hover:underline flex items-center gap-1 truncate"
                      >
                        <span>{site.title}</span>
                        <ExternalLink className="w-3 h-3 flex-shrink-0" />
                      </a>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          site.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : site.status === 'rejected'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {site.status === 'approved' ? 'معتمد من الإدارة ✓' : site.status === 'rejected' ? 'مرفوض' : 'بانتظار موافقة الإدارة'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemovePersonalSite(site.id)}
                      className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                      title="حذف الموقع"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[11px] text-slate-500 text-center py-2">
                لم تقم بإضافة مواقع شخصية بعد. يمكنك إضافة حتى 15 موقعاً لحفظ اهتماماتك ومراجعتها مع الإدارة.
              </p>
            )}
          </div>

          {/* Assigned Business Card */}
          {assignedBusiness && (
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Store className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-black text-slate-900">النشاط التجاري المرتبط بحسابك:</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedBusinessId(assignedBusiness.id);
                    setCurrentView('merchant_admin');
                    onClose();
                  }}
                  className="text-emerald-700 hover:text-emerald-800 text-xs font-black flex items-center gap-1 cursor-pointer"
                >
                  <span>إدارة الكتالوج</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>

              <div className="flex items-center gap-3">
                <img
                  src={assignedBusiness.logoUrl}
                  alt={assignedBusiness.name}
                  onClick={() => {
                    setSelectedBusinessId(assignedBusiness.id);
                    setCurrentView('public_storefront');
                    onClose();
                  }}
                  title="اضغط لعرض النشاط"
                  className="w-12 h-12 rounded-xl object-cover border border-slate-200 shadow-xs cursor-pointer hover:scale-105 transition-transform"
                />
                <div>
                  <h4
                    onClick={() => {
                      setSelectedBusinessId(assignedBusiness.id);
                      setCurrentView('public_storefront');
                      onClose();
                    }}
                    className="font-black text-sm text-slate-900 hover:text-emerald-700 cursor-pointer transition-colors"
                  >
                    {assignedBusiness.name}
                  </h4>
                  <p className="text-[11px] text-slate-500">{assignedBusiness.category} • {assignedBusiness.governorate}</p>
                </div>
              </div>
            </div>
          )}

          {/* Subscriber Personal Member Inbox & Privacy/Location Page Trigger */}
          <div className="p-4 bg-teal-50/80 rounded-2xl border border-teal-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="text-xs font-black text-teal-950 flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-teal-600" />
                <span>صفحة استقبال رسائل الأعضاء الخاصة بالمشترك</span>
              </div>
              <p className="text-[11px] text-teal-800">
                تحكم في تفعيل أو إيقاف استقبال الرسائل من الأعضاء حسب الخصوصية أو الموقع الجغرافي
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                openMemberMessagingForTarget('subscriber', currentSubscriber?.id);
                onClose();
              }}
              className="bg-teal-600 hover:bg-teal-700 text-white font-black text-xs px-4 py-2.5 rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>فتح صفحة رسائل الأعضاء</span>
            </button>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md shadow-emerald-600/20 cursor-pointer"
            >
              حفظ التعديلات
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

