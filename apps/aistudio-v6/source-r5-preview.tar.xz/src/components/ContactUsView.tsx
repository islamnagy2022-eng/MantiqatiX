import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ContactMessageType } from '../types';
import { generateContactUsWhatsAppUrl } from '../utils/rules';
import {
  MessageCircle,
  Send,
  CheckCircle2,
  Phone,
  Mail,
  AlertCircle,
  HelpCircle,
  FileText,
  Sparkles,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';

export const ContactUsView: React.FC = () => {
  const {
    authSession,
    adminSettings,
    directoryBusinesses,
    setCurrentView,
  } = useApp();

  const isSubscriber = authSession.role === 'subscriber';

  const [senderName, setSenderName] = useState(authSession.subscriberName || '');
  const [senderPhone, setSenderPhone] = useState(authSession.userPhone || '');
  const [messageType, setMessageType] = useState<ContactMessageType>('inquiry');
  const [relatedBusinessName, setRelatedBusinessName] = useState('');
  const [subject, setSubject] = useState('');
  const [content, setContent] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [submittedWhatsAppUrl, setSubmittedWhatsAppUrl] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!senderName.trim() || !senderPhone.trim() || !subject.trim() || !content.trim()) {
      setErrorMsg('يرجى ملء الاسم، رقم الهاتف أو الواتساب، الموضوع، وتفاصيل الرسالة.');
      return;
    }

    if (!adminSettings.adminWhatsApp?.trim()) {
      setErrorMsg('قناة واتساب الإدارة غير مفعلة حاليًا. لم يتم حفظ الرسالة أو إرسالها.');
      return;
    }

    // Prepare a WhatsApp handoff only. No local inbox or fake delivery claim.
    const waUrl = generateContactUsWhatsAppUrl(adminSettings.adminWhatsApp, {
      senderName: senderName.trim(),
      senderPhone: senderPhone.trim(),
      messageType,
      subject: subject.trim(),
      content: content.trim(),
      relatedBusinessName: relatedBusinessName.trim() || undefined,
    });

    setSubmittedWhatsAppUrl(waUrl);
  };

  return (
    <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-10 py-8 space-y-8" dir="rtl">
      {/* Welcome Banner (Cover Area) */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl border border-emerald-500/20">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2.5 max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-black px-3.5 py-1 rounded-full">
              <Sparkles className="w-3.5 h-3.5" />
              <span>بوابة التواصل المباشر والدعم الفني</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black">
              {isSubscriber
                ? `مرحباً بك يا ${authSession.subscriberName || 'مشتركنا العزيز'} في صفحة تواصل معنا`
                : 'مرحباً بك زائرنا الكريم ومشتركينا الأعزاء في منصة MantiqatiX'}
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
              اكتب رسالتك ثم افتح واتساب لإرسالها بنفسك. لا يتم حفظ الرسالة داخل المنصة أو اعتبارها مستلمة قبل الضغط على إرسال في واتساب.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setCurrentView('directory')}
            className="bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-xs px-4 py-3 rounded-2xl flex items-center gap-2 cursor-pointer self-start md:self-center"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة للرئيسية</span>
          </button>
        </div>
      </div>

      {/* BELOW COVER AREA: Main Content on Right + Vertical Sponsored Ads Column on Left (بالشمال من تحت مساحة الـ Cover) */}
      <div className="flex flex-col lg:flex-row gap-6 items-stretch">
        <div className="flex-1 min-w-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Form Card */}
            <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="font-black text-lg text-slate-900">تجهيز رسالة للتواصل</h2>
            <p className="text-xs text-slate-500 mt-1">
              املأ البيانات لتجهيز رسالة واتساب. لن تُرسل الرسالة إلا بعد تأكيدك داخل واتساب.
            </p>
          </div>

          {errorMsg && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {submittedWhatsAppUrl ? (
            <div className="bg-emerald-50 border-2 border-emerald-300 rounded-3xl p-6 text-center space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-lg">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="font-black text-lg text-emerald-950">
                  تم تجهيز الرسالة لواتساب
                </h3>
                <p className="text-xs text-emerald-800 max-w-md mx-auto leading-relaxed">
                  لم يتم إرسال الرسالة أو حفظها داخل المنصة. اضغط على زر واتساب ثم اضغط إرسال من تطبيق واتساب.
                </p>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <a
                  href={submittedWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm px-6 py-3.5 rounded-2xl shadow-lg flex items-center gap-2 cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>فتح واتساب وإرسال الرسالة المنسقة للإدارة</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <button
                  type="button"
                  onClick={() => {
                    setSubmittedWhatsAppUrl(null);
                    setSubject('');
                    setContent('');
                  }}
                  className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-bold text-xs px-4 py-3.5 rounded-2xl cursor-pointer"
                >
                  إرسال رسالة أخرى
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Message Type Selector */}
              <div>
                <label className="block text-xs font-black text-slate-700 mb-2">نوع المراسلة المطلوبة</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    { id: 'inquiry', label: 'استفسار ❓', color: 'border-blue-500 bg-blue-50 text-blue-900' },
                    { id: 'request', label: 'طلب خدمة 📋', color: 'border-emerald-500 bg-emerald-50 text-emerald-900' },
                    { id: 'message', label: 'رسالة عامة ✉️', color: 'border-indigo-500 bg-indigo-50 text-indigo-900' },
                    { id: 'complaint', label: 'شكوى أو مقترح ⚠️', color: 'border-rose-500 bg-rose-50 text-rose-900' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setMessageType(item.id as ContactMessageType)}
                      className={`py-2.5 px-3 rounded-2xl border text-xs font-black transition-all cursor-pointer ${
                        messageType === item.id
                          ? `${item.color} border-2 shadow-xs`
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">
                    الاسم الكامل <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="اكتب اسمك الكريم..."
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">
                    رقم الهاتف أو الواتساب <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    dir="ltr"
                    placeholder="01012345678"
                    value={senderPhone}
                    onChange={(e) => setSenderPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold text-right"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">
                    النشاط التجاري المرتبط <span className="text-slate-400 font-normal">(اختياري)</span>
                  </label>
                  <input
                    type="text"
                    list="contact-businesses-list"
                    placeholder="اسم نشاطك أو النشاط المستفسر عنه..."
                    value={relatedBusinessName}
                    onChange={(e) => setRelatedBusinessName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                  />
                  <datalist id="contact-businesses-list">
                    {directoryBusinesses.map((b) => (
                      <option key={b.id} value={b.name} />
                    ))}
                  </datalist>
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  عنوان الرسالة / الموضوع <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: استفسار عن تفعيل باقة النشاط أو طلب دعم فني..."
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  تفاصيل الرسالة أو الطلب أو الشكوى <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="اكتب كافة التفاصيل بوضوح ليتم الرد عليك في أسرع وقت..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm py-3.5 rounded-2xl shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Send className="w-4 h-4" />
                <span>فتح واتساب لإرسال الرسالة</span>
              </button>
            </form>
          )}
        </div>

        {/* Side Info Card */}
        <div className="space-y-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-black text-base text-slate-900">قنوات التواصل المباشر</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              يمكنك التواصل مع إدارة المنصة عبر واتساب أو البريد الرسمي الموضح أدناه.
            </p>
            <div className="space-y-3 text-xs">
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-emerald-50 border border-emerald-200">
                <MessageCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                <div>
                  <div className="font-black text-emerald-950">واتساب الإدارة المباشر</div>
                  <div dir="ltr" className="font-mono text-emerald-700 font-bold">
                    {adminSettings.adminWhatsApp}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <Mail className="w-5 h-5 text-indigo-600 flex-shrink-0" />
                <div>
                  <div className="font-black text-slate-900">البريد الرسمي للمنصة</div>
                  <div className="text-slate-600 font-bold">{adminSettings.platformEmail}</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-amber-50 rounded-3xl p-6 border border-amber-200 space-y-2">
            <div className="font-black text-sm text-amber-950 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-amber-600" />
              <span>تأكيد إرسال الرسالة</span>
            </div>
            <p className="text-xs text-amber-900 leading-relaxed">
              تجهيز الرسالة لا يعني وصولها. لن تُرسل إلا بعد فتح واتساب والضغط على زر الإرسال من جهازك.
            </p>
          </div>
        </div>
      </div>
        </div>

      </div>
    </div>
  );
};
