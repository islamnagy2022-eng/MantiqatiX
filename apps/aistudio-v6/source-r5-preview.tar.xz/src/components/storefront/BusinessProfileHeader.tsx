import React from 'react';
import { useApp } from '../../context/AppContext';
import { resolveBusinessCover, resolveBusinessLogo } from '../../data/imageAssets';
import { CheckCircle2, MapPin, Phone, Clock, MessageCircle, ShieldAlert } from 'lucide-react';

interface BusinessProfileHeaderProps {
  children?: React.ReactNode;
}

export const BusinessProfileHeader: React.FC<BusinessProfileHeaderProps> = ({ children }) => {
  const { currentBusiness } = useApp();

  if (!currentBusiness) {
    return <div className="mx-auto max-w-4xl px-4 py-16 text-center text-sm text-slate-500" dir="rtl">لم يتم العثور على النشاط المطلوب.</div>;
  }

  const business = currentBusiness;
  const verified = business.isVerified && (!business.verificationStatus || business.verificationStatus === 'verified');
  const suspended = business.verificationStatus === 'suspended';
  const unavailable = business.isFrozen;
  const phone = business.ownerWhatsApp || business.phone || '';
  const digits = phone.replace(/\D/g, '');
  const waDigits = digits.startsWith('0') ? `20${digits.slice(1)}` : digits;

  return (
    <div className="min-h-screen bg-slate-50 pb-12" dir="rtl">
      <section className="relative h-52 overflow-hidden bg-slate-900 sm:h-64 lg:h-80">
        <img src={resolveBusinessCover(business)} alt="" className="h-full w-full object-cover opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/10 to-transparent" />
      </section>

      <main className="mx-auto -mt-14 max-w-6xl space-y-6 px-4 relative z-10">
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-lg sm:p-7">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <img src={resolveBusinessLogo(business)} alt="" className="h-20 w-20 rounded-2xl border-4 border-white object-cover shadow-md" />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl font-black text-slate-900">{business.name}</h1>
                {verified ? <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-800"><CheckCircle2 className="h-4 w-4" /> نشاط موثق</span> : <span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-bold text-amber-800">نشاط غير موثق</span>}
              </div>
              <p className="mt-1 text-sm font-semibold text-slate-600">{business.category}</p>
              {verified && business.bio && <p className="mt-2 text-sm leading-7 text-slate-600">{business.bio}</p>}
            </div>
          </div>

          <div className="mt-5 grid gap-3 border-t border-slate-100 pt-4 sm:grid-cols-2">
            <p className="flex items-start gap-2 text-sm text-slate-600"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-emerald-700" /><span>{[business.governorate, business.markaz, business.village, business.address].filter(Boolean).join(' • ')}</span></p>
            {phone && <p className="flex items-center gap-2 text-sm text-slate-700"><Phone className="h-4 w-4 shrink-0 text-emerald-700" /><span dir="ltr">{phone}</span></p>}
            {verified && business.workingHours && <p className="flex items-center gap-2 text-sm text-slate-600"><Clock className="h-4 w-4 shrink-0 text-emerald-700" />{business.workingHours}</p>}
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {digits && <a href={`tel:${phone}`} className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 text-sm font-bold text-slate-800"><Phone className="h-4 w-4" /> اتصال</a>}
            {waDigits && <a href={`https://wa.me/${waDigits}`} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-bold text-white"><MessageCircle className="h-4 w-4" /> واتساب</a>}
          </div>
        </section>

        {suspended || unavailable ? (
          <div className="rounded-2xl border border-rose-200 bg-rose-50 p-5 text-sm text-rose-900"><div className="flex items-center gap-2 font-black"><ShieldAlert className="h-5 w-5" /> النشاط غير متاح حاليًا</div><p className="mt-1 text-xs">لا يمكن عرض الكتالوج حاليًا. تواصل مع النشاط أو إدارة المنصة لمعرفة الحالة.</p></div>
        ) : verified ? children : (
          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-950"><div className="font-black">الدليل المجاني</div><p className="mt-1 text-xs leading-6">تظهر بيانات الاسم والموقع ووسيلة الاتصال فقط إلى حين اكتمال توثيق النشاط.</p></div>
        )}
      </main>
    </div>
  );
};
