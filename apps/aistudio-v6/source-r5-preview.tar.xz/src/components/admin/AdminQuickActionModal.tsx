import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Business } from '../../types';
import {
  getSectorDefaultCover,
  getSectorDefaultLogo,
  resolveBusinessCover,
  resolveBusinessLogo,
} from '../../utils/rules';
import { ImageLibraryModal } from '../common/ImageLibraryModal';
import {
  X,
  Edit,
  User,
  Coins,
  Megaphone,
  Ban,
  Trash2,
  Check,
  Building2,
  Sparkles,
  Plus,
  Globe,
  Trash,
  Image as ImageIcon,
} from 'lucide-react';

interface AdminQuickActionModalProps {
  business: Business | null;
  initialAction: 'edit' | 'owner' | 'commission' | 'ad' | null;
  onClose: () => void;
}

export const AdminQuickActionModal: React.FC<AdminQuickActionModalProps> = ({
  business,
  initialAction,
  onClose,
}) => {
  const { updateBusiness, deleteBusiness, subscribers, updateSubscriber } = useApp();

  if (!business || !initialAction) return null;

  const [modalAction, setModalAction] = useState<'edit' | 'owner' | 'commission' | 'ad'>(initialAction);

  // Edit form state
  const [name, setName] = useState(business.name);
  const [category, setCategory] = useState(business.category);
  const [logoUrl, setLogoUrl] = useState(resolveBusinessLogo(business));
  const [coverUrl, setCoverUrl] = useState(resolveBusinessCover(business));
  const [imageLibTarget, setImageLibTarget] = useState<'logo' | 'cover' | null>(null);
  const [governorate, setGovernorate] = useState(business.governorate || 'القاهرة');
  const [markaz, setMarkaz] = useState(business.markaz || '');
  const [village, setVillage] = useState(business.village || '');
  const [phone, setPhone] = useState(business.phone || '');
  const [whatsapp, setWhatsapp] = useState(business.ownerWhatsApp || '');
  const [bio, setBio] = useState(business.bio || '');

  // Social / Web Links (مواقع تعرض على الإدارة للموافقة - حتى 10 لينكات)
  const [socialLinks, setSocialLinks] = useState<Array<{ name: string; url: string; status: 'pending' | 'approved' }>>(
    business.socialLinks || []
  );
  const [newSiteName, setNewSiteName] = useState('');
  const [newSiteUrl, setNewSiteUrl] = useState('');

  // Owner state
  const [ownerSubId, setOwnerSubId] = useState(business.ownerSubscriberId || '');

  // Commission state
  const [commissionType, setCommissionType] = useState(business.commissionType || 'all_combined');
  const [monthlySubFee, setMonthlySubFee] = useState(business.monthlySubscriptionFee || 500);
  const [commissionPct, setCommissionPct] = useState(business.commissionPercentage || 1.0);
  const [commissionFixed, setCommissionFixed] = useState(business.commissionFixed || 2.0);
  const [commissionFixedPerItem, setCommissionFixedPerItem] = useState(business.commissionFixedPerItem || 1.0);

  // Ad Boost state
  const [adTitle, setAdTitle] = useState(`إعلان مميز لـ ${business.name} - خصومات كبرى وحصرياً عبر MantiqatiX`);
  const [adDurationDays, setAdDurationDays] = useState(30);
  const [adPayer, setAdPayer] = useState<'admin' | 'subscriber'>('admin');
  const [adBuyerSubId, setAdBuyerSubId] = useState(business.ownerSubscriberId || subscribers[0]?.id || '');
  const [costPerDay] = useState(15);

  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleAddSocialLink = () => {
    if (!newSiteName.trim() || !newSiteUrl.trim()) return;
    if (socialLinks.length >= 10) {
      setErrorMsg('الحد الأقصى المسموح به هو 10 روابط فقط.');
      return;
    }
    setSocialLinks([
      ...socialLinks,
      { name: newSiteName.trim(), url: newSiteUrl.trim(), status: 'pending' },
    ]);
    setNewSiteName('');
    setNewSiteUrl('');
    setErrorMsg('');
  };

  const handleRemoveSocialLink = (index: number) => {
    setSocialLinks(socialLinks.filter((_, i) => i !== index));
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!governorate.trim() || !markaz.trim()) {
      setErrorMsg('المحافظة والمركز حقلان إجباربان.');
      return;
    }

    updateBusiness({
      ...business,
      name,
      category,
      logoUrl: resolveBusinessLogo({ logoUrl, functionalGroupId: business.functionalGroupId }),
      coverUrl: resolveBusinessCover({ coverUrl, functionalGroupId: business.functionalGroupId }),
      governorate,
      markaz,
      village,
      phone,
      ownerWhatsApp: whatsapp,
      bio,
      socialLinks,
    });
    setSuccessMsg('تم تحديث بيانات النشاط وروابط المواقع بنجاح (مع إرسالها للمراجعة)!');
    setTimeout(() => {
      setSuccessMsg('');
      onClose();
    }, 1200);
  };

  const handleSaveOwner = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusiness({
      ...business,
      ownerSubscriberId: ownerSubId || undefined,
    });
    setSuccessMsg('تم تعيين مالك النشاط بنجاح!');
    setTimeout(() => {
      setSuccessMsg('');
      onClose();
    }, 1200);
  };

  const handleSaveCommission = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusiness({
      ...business,
      commissionType,
      monthlySubscriptionFee: Number(monthlySubFee),
      commissionPercentage: Number(commissionPct),
      commissionFixed: Number(commissionFixed),
      commissionFixedPerItem: Number(commissionFixedPerItem),
    });
    setSuccessMsg('تم حفظ نظام العمولات والاشتراك بنجاح!');
    setTimeout(() => {
      setSuccessMsg('');
      onClose();
    }, 1200);
  };

  const handleSaveAd = (e: React.FormEvent) => {
    e.preventDefault();
    const totalCost = adDurationDays * costPerDay;

    if (adPayer === 'subscriber') {
      const sub = subscribers.find((s) => s.id === adBuyerSubId);
      if (!sub) {
        setErrorMsg('يرجى تحديد المشتري / صاحب النشاط المسدد للتكلفة.');
        return;
      }
      const currentBalance = sub.walletBalance || 0;
      if (currentBalance < totalCost) {
        setErrorMsg(`رصيد محفظة المشتري (${currentBalance} ج.م) غير كافٍ لتغطية تكلفة الإعلان (${totalCost} ج.م).`);
        return;
      }

      updateSubscriber({
        ...sub,
        walletBalance: currentBalance - totalCost,
      });
    }

    updateBusiness({
      ...business,
      isVerified: true,
      verificationStatus: 'verified',
    });

    const msg =
      adPayer === 'admin'
        ? `تم نشر الإعلان المميز مجاناً من قبل الإدارة لمدة ${adDurationDays} يوماً في واجهة المنصة!`
        : `تم نشر الإعلان المميز لمدة ${adDurationDays} يوماً وخصم مبلغ ${totalCost} ج.م بنجاح من محفظة المشتري (${
            subscribers.find((s) => s.id === adBuyerSubId)?.fullName || ''
          })!`;

    setSuccessMsg(msg);
    setTimeout(() => {
      setSuccessMsg('');
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 text-right shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header & Quick Switch Tabs */}
        <div className="flex items-center gap-3.5 pb-4 border-b border-slate-100">
          <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center shadow-md font-black">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-black text-base text-slate-900">إدارة نشاط: {business.name}</h2>
            <p className="text-xs text-slate-500">التحكم الفوري من نافذة منبثقة بدون مغادرة الصفحة.</p>
          </div>
        </div>

        {/* Action Tabs Selector */}
        <div className="grid grid-cols-4 gap-1.5 bg-slate-100 p-1.5 rounded-2xl text-[11px] font-bold">
          <button
            onClick={() => setModalAction('edit')}
            className={`py-2 px-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
              modalAction === 'edit' ? 'bg-white text-slate-900 shadow-xs font-black' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Edit className="w-3.5 h-3.5 text-blue-600" />
            <span>التعديل</span>
          </button>
          <button
            onClick={() => setModalAction('owner')}
            className={`py-2 px-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
              modalAction === 'owner' ? 'bg-white text-slate-900 shadow-xs font-black' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-3.5 h-3.5 text-amber-600" />
            <span>المالك</span>
          </button>
          <button
            onClick={() => setModalAction('commission')}
            className={`py-2 px-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
              modalAction === 'commission' ? 'bg-white text-slate-900 shadow-xs font-black' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Coins className="w-3.5 h-3.5 text-emerald-600" />
            <span>العمولات</span>
          </button>
          <button
            onClick={() => setModalAction('ad')}
            className={`py-2 px-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
              modalAction === 'ad' ? 'bg-white text-slate-900 shadow-xs font-black' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Megaphone className="w-3.5 h-3.5 text-purple-600" />
            <span>إعلان</span>
          </button>
        </div>

        {successMsg && (
          <div className="p-3.5 bg-emerald-50 text-emerald-800 rounded-2xl text-xs font-black border border-emerald-200 flex items-center gap-2 animate-fadeIn">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>{successMsg}</span>
          </div>
        )}

        {errorMsg && (
          <div className="p-3.5 bg-rose-50 text-rose-800 rounded-2xl text-xs font-black border border-rose-200 flex items-center gap-2">
            <span>{errorMsg}</span>
          </div>
        )}

        {/* TAB 1: EDIT BUSINESS DATA */}
        {modalAction === 'edit' && (
          <form onSubmit={handleSaveEdit} className="space-y-4">
            {/* Logo & Cover Selection from Default Images */}
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                  <span>شعار النشاط (Logo) والغلاف (Cover) الافتراضيان:</span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setLogoUrl(getSectorDefaultLogo(business.functionalGroupId));
                    setCoverUrl(getSectorDefaultCover(business.functionalGroupId));
                  }}
                  className="text-[10px] font-black bg-amber-100 hover:bg-amber-200 text-amber-950 px-2.5 py-1 rounded-lg cursor-pointer"
                >
                  استعادة افتراضي المجال ⭐
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex items-center gap-2.5 bg-white p-2 rounded-xl border border-slate-200">
                  <img
                    src={resolveBusinessLogo({ logoUrl, functionalGroupId: business.functionalGroupId })}
                    alt="Logo"
                    className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-[11px] font-black text-slate-800">شعار النشاط (Logo)</div>
                    <button
                      type="button"
                      onClick={() => setImageLibTarget('logo')}
                      className="text-[11px] font-black text-indigo-600 hover:underline cursor-pointer"
                    >
                      اختر من الصور الافتراضية ←
                    </button>
                  </div>
                </div>
                <div className="flex items-center gap-2.5 bg-white p-2 rounded-xl border border-slate-200">
                  <img
                    src={resolveBusinessCover({ coverUrl, functionalGroupId: business.functionalGroupId })}
                    alt="Cover"
                    className="w-18 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-[11px] font-black text-slate-800">غلاف النشاط (Cover)</div>
                    <button
                      type="button"
                      onClick={() => setImageLibTarget('cover')}
                      className="text-[11px] font-black text-indigo-600 hover:underline cursor-pointer"
                    >
                      اختر من الأغلفة الافتراضية ←
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">اسم النشاط التجاري</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  المحافظة <span className="text-rose-500">* (إجباري)</span>
                </label>
                <input
                  type="text"
                  required
                  value={governorate}
                  onChange={(e) => setGovernorate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                  placeholder="مثال: الدقهلية"
                />
              </div>
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  المركز / المدينة <span className="text-rose-500">* (إجباري)</span>
                </label>
                <input
                  type="text"
                  required
                  value={markaz}
                  onChange={(e) => setMarkaz(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                  placeholder="مثال: المنصورة"
                />
              </div>
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">
                  القرية أو المنطقة <span className="text-slate-400 font-normal">(اختياري)</span>
                </label>
                <input
                  type="text"
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                  placeholder="مثال: حي الجامعة"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">رقم الهاتف (اتصال)</label>
                <input
                  type="text"
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold text-right"
                  placeholder="0502345678"
                />
              </div>
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">رقم الواتساب</label>
                <input
                  type="text"
                  dir="ltr"
                  value={whatsapp}
                  onChange={(e) => setWhatsapp(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold text-right"
                  placeholder="201010171770"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">التصنيف</label>
              <input
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-black text-slate-700 mb-1">نبذة تعريفية مختصرة</label>
              <textarea
                rows={2}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
              ></textarea>
            </div>

            {/* Social/Web Links Section (مواقع تعرض على الإدارة للموافقة - حتى 10 لينكات) */}
            <div className="p-4 bg-indigo-50/60 rounded-2xl border border-indigo-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-black text-xs text-indigo-950 flex items-center gap-1.5">
                  <Globe className="w-4 h-4 text-indigo-600" />
                  <span>مواقع وروابط إضافية تعرض على الإدارة للموافقة (حتى 10 لينكات):</span>
                </span>
                <span className="text-[10px] font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-md">
                  {socialLinks.length} / 10
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                <input
                  type="text"
                  placeholder="اسم الموقع (مثل: facebook)"
                  value={newSiteName}
                  onChange={(e) => setNewSiteName(e.target.value)}
                  className="sm:col-span-2 bg-white border border-indigo-200 rounded-xl p-2.5 text-xs font-bold"
                />
                <input
                  type="text"
                  dir="ltr"
                  placeholder="لينك الموقع (www.facebook.com)"
                  value={newSiteUrl}
                  onChange={(e) => setNewSiteUrl(e.target.value)}
                  className="sm:col-span-2 bg-white border border-indigo-200 rounded-xl p-2.5 text-xs font-bold text-right"
                />
                <button
                  type="button"
                  onClick={handleAddSocialLink}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs py-2.5 px-3 rounded-xl shadow-xs flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة</span>
                </button>
              </div>

              {socialLinks.length > 0 && (
                <div className="space-y-1.5 pt-2 max-h-36 overflow-y-auto">
                  {socialLinks.map((link, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-indigo-100 text-xs shadow-xs">
                      <div className="flex items-center gap-2 truncate">
                        <span className="font-black text-indigo-900">{link.name}:</span>
                        <span dir="ltr" className="text-slate-600 truncate">{link.url}</span>
                        <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded-md font-bold">
                          {link.status === 'approved' ? 'معتمد' : 'قيد موافقة الإدارة'}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveSocialLink(idx)}
                        className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                      >
                        <Trash className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs py-3 rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>حفظ التعديلات وتقديم الروابط للمراجعة</span>
              </button>
            </div>
          </form>
        )}

        {/* TAB 2: ASSIGN OWNER */}
        {modalAction === 'owner' && (
          <form onSubmit={handleSaveOwner} className="space-y-4">
            <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 space-y-3">
              <label className="block text-xs font-black text-amber-950 flex items-center gap-1.5">
                <User className="w-4 h-4 text-amber-700" />
                <span>تعيين مالك النشاط (مشترك مسجل - إدارة فقط):</span>
              </label>
              <select
                value={ownerSubId}
                onChange={(e) => setOwnerSubId(e.target.value)}
                className="w-full bg-white border border-amber-300 rounded-xl p-3 text-xs font-bold text-slate-900 cursor-pointer"
              >
                <option value="">-- بدون مالك مسند حالياً --</option>
                {subscribers.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.fullName} ({sub.email} - {sub.phone})
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-amber-800">
                عند ربط النشاط بمشترك، يستطيع المشترك إدارة منتجاته وموظفيه من لوحة تحكمه.
              </p>
            </div>
            <button
              type="submit"
              className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs py-3 rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>تثبيت المالك المعين</span>
            </button>
          </form>
        )}

        {/* TAB 3: COMMISSION & SUBSCRIPTION */}
        {modalAction === 'commission' && (
          <form onSubmit={handleSaveCommission} className="space-y-4">
            <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-200 space-y-3">
              <label className="block text-xs font-black text-indigo-950 flex items-center gap-1.5">
                <Coins className="w-4 h-4 text-indigo-700" />
                <span>نظام التحصيل والعمولات والاشتراك (يمكن تحديد أكثر من وسيلة أو الكل):</span>
              </label>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">طريقة التحصيل والعمولات</label>
                <select
                  value={commissionType}
                  onChange={(e: any) => setCommissionType(e.target.value)}
                  className="w-full bg-white border border-indigo-200 rounded-xl p-2.5 text-xs font-bold text-slate-900 cursor-pointer"
                >
                  <option value="all_combined">تفعيل جميع وسائل التحصيل معاً (اشتراك + نسبة مبيعات + ثابت للطلب + ثابت للقطعة)</option>
                  <option value="percentage_plus_fixed">اشتراك شهري + نسبة مئوية + مبلغ ثابت لكل طلب</option>
                  <option value="subscription_only">اشتراك شهري ثابت فقط</option>
                  <option value="percentage">نسبة مئوية من المبيعات فقط</option>
                  <option value="fixed">رقم ثابت لكل طلب أو قطعة فقط</option>
                </select>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">الاشتراك (ج.م)</label>
                  <input
                    type="number"
                    value={monthlySubFee}
                    onChange={(e) => setMonthlySubFee(Number(e.target.value))}
                    className="w-full bg-white border border-indigo-200 rounded-xl p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">النسبة (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={commissionPct}
                    onChange={(e) => setCommissionPct(Number(e.target.value))}
                    className="w-full bg-white border border-indigo-200 rounded-xl p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">ثابت للطلب (ج.م)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={commissionFixed}
                    onChange={(e) => setCommissionFixed(Number(e.target.value))}
                    className="w-full bg-white border border-indigo-200 rounded-xl p-2 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">ثابت للقطعة (ج.م)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={commissionFixedPerItem}
                    onChange={(e) => setCommissionFixedPerItem(Number(e.target.value))}
                    className="w-full bg-white border border-indigo-200 rounded-xl p-2 text-xs font-bold"
                  />
                </div>
              </div>
            </div>
            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs py-3 rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>حفظ العمولات والاشتراك</span>
            </button>
          </form>
        )}

        {/* TAB 4: PROMOTIONAL AD BOOST */}
        {modalAction === 'ad' && (
          <form onSubmit={handleSaveAd} className="space-y-4">
            <div className="p-4 bg-purple-50 rounded-2xl border border-purple-200 space-y-3">
              <label className="block text-xs font-black text-purple-950 flex items-center gap-1.5">
                <Megaphone className="w-4 h-4 text-purple-700" />
                <span>وضع إعلان مميز في واجهة المنصة:</span>
              </label>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">عنوان الإعلان ومحتواه</label>
                <input
                  type="text"
                  value={adTitle}
                  onChange={(e) => setAdTitle(e.target.value)}
                  className="w-full bg-white border border-purple-200 rounded-xl p-3 text-xs font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">مدة العرض (بالأيام)</label>
                  <select
                    value={adDurationDays}
                    onChange={(e) => setAdDurationDays(Number(e.target.value))}
                    className="w-full bg-white border border-purple-200 rounded-xl p-2.5 text-xs font-bold cursor-pointer"
                  >
                    <option value={7}>7 أيام (أسبوع مميز - {7 * costPerDay} ج.م)</option>
                    <option value={15}>15 يوم (نصف شهر - {15 * costPerDay} ج.م)</option>
                    <option value={30}>30 يوم (شهر كامل - {30 * costPerDay} ج.م)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">الجهة المسددة للتكلفة</label>
                  <select
                    value={adPayer}
                    onChange={(e: any) => setAdPayer(e.target.value)}
                    className="w-full bg-white border border-purple-200 rounded-xl p-2.5 text-xs font-bold cursor-pointer"
                  >
                    <option value="admin">الإدارة (مجاناً تماماً)</option>
                    <option value="subscriber">مشتري / صاحب النشاط (خصم من محفظته)</option>
                  </select>
                </div>
              </div>

              {adPayer === 'subscriber' && (
                <div className="space-y-2 pt-1 border-t border-purple-200/60">
                  <label className="block text-[11px] font-bold text-slate-700">اختر المشتري / صاحب النشاط المسدد:</label>
                  <select
                    value={adBuyerSubId}
                    onChange={(e) => setAdBuyerSubId(e.target.value)}
                    className="w-full bg-white border border-purple-200 rounded-xl p-2.5 text-xs font-bold cursor-pointer"
                  >
                    {subscribers.map((sub) => (
                      <option key={sub.id} value={sub.id}>
                        {sub.fullName} (رصيد المحفظة: {sub.walletBalance || 0} ج.م)
                      </option>
                    ))}
                  </select>
                  <p className="text-[10px] text-purple-900 font-bold">
                    التكلفة الإجمالية: {adDurationDays * costPerDay} ج.م ({costPerDay} ج.م / يوم) ستخصم مباشرة من محفظة المشتري المختار.
                  </p>
                </div>
              )}
            </div>
            <button
              type="submit"
              className="w-full bg-purple-600 hover:bg-purple-700 text-white font-black text-xs py-3 rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>نشر الإعلان المميز فوراً</span>
            </button>
          </form>
        )}
      </div>

      <ImageLibraryModal
        isOpen={Boolean(imageLibTarget)}
        onClose={() => setImageLibTarget(null)}
        defaultSectorId={business.functionalGroupId}
        defaultAssetType={imageLibTarget === 'logo' ? 'logo' : 'cover'}
        onSelectImage={(url) => {
          if (imageLibTarget === 'logo') setLogoUrl(url);
          if (imageLibTarget === 'cover') setCoverUrl(url);
          setImageLibTarget(null);
        }}
      />
    </div>
  );
};
