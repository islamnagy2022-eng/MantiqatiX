import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Business,
  FunctionalGroupId,
  Product,
  SubscriptionPlanTier,
  SubscriptionRequest,
} from '../../types';
import {
  DEFAULT_BUSINESS_COVER_URL,
  DEFAULT_BUSINESS_LOGO_URL,
  SECTOR_DEFAULT_IMAGES,
  getSectorDefaultCover,
  getSectorDefaultLogo,
  getSectorDefaultProductImage,
  getSelectableImagesForSector,
  resolveBusinessCover,
  resolveBusinessLogo,
  resolveProductImage,
  getDefaultTierConfiguration,
} from '../../utils/rules';
import {
  Package,
  Plus,
  Edit,
  Trash2,
  CheckCircle2,
  ExternalLink,
  Sparkles,
  Phone,
  Store,
  MapPin,
  MessageCircle,
  ShieldCheck,
  Mail,
  Building2,
  RefreshCw,
  Coins,
  CreditCard,
  QrCode,
  Cpu,
  Users,
  Crown,
  Check,
  Image as ImageIcon,
  User,
  Megaphone,
  LayoutTemplate,
  Bookmark,
  Eye,
  TrendingUp,
  BadgeCheck,
  ShieldAlert,
  Link2,
} from 'lucide-react';
import { QRCodeModal } from '../common/QRCodeModal';
import { ImageLibraryModal } from '../common/ImageLibraryModal';

type SidebarTab =
  | 'merchant_products'
  | 'merchant_finance'
  | 'merchant_branding'
  | 'merchant_employees'
  | 'merchant_qr'
  | 'admin_businesses'
  | 'admin_subscription_requests'
  | 'admin_inbox'
  | 'admin_ads'
  | 'admin_personal_sites'
  | 'admin_billing'
  | 'admin_ai_studio';

export const UnifiedEnterpriseDashboard: React.FC = () => {
  const {
    authSession,
    businesses,
    currentBusiness,
    setSelectedBusinessId,
    setCurrentView,
    businessProducts,
    addProduct,
    updateProduct,
    deleteProduct,
    updateBusiness,
    adminSettings,
    functionalGroups,
    subscribers,
    updateSubscriber,
    updateAdminSettings,
    addBusiness,
    adRequests,
    updateAdRequestStatus,
    updateAdRequestDetails,
    contactMessages,
    markContactMessageRead,
    deleteContactMessage,
    unreadMessagesCount,
    subscriptionRequests,
    updateSubscriptionRequest,
    approveSubscriptionRequestToBusiness,
    adminActiveTabOverride,
    setAdminActiveTabOverride,
    lastLiveSyncTimestamp,
  } = useApp();

  const isAdmin = authSession.role === 'admin' || authSession.role === 'super_admin';

  const [activeTab, setActiveTab] = useState<SidebarTab>(
    isAdmin ? 'admin_businesses' : 'merchant_products'
  );

  // Sync tab override when clicking unread messages badge in header/navbar
  useEffect(() => {
    if (adminActiveTabOverride) {
      setActiveTab(adminActiveTabOverride as SidebarTab);
      setAdminActiveTabOverride(null);
    }
  }, [adminActiveTabOverride, setAdminActiveTabOverride]);

  // Sync merchant profile inputs when currentBusiness changes
  useEffect(() => {
    if (currentBusiness) {
      setBizName(currentBusiness.name || '');
      setBizBio(currentBusiness.bio || '');
      setBizLogoUrl(resolveBusinessLogo(currentBusiness));
      setBizCoverUrl(resolveBusinessCover(currentBusiness));
      setBizOwnerWhatsApp(currentBusiness.ownerWhatsApp || '');
      setBizAddress(currentBusiness.address || '');
      setBizWorkingHours(currentBusiness.workingHours || '');
    }
  }, [currentBusiness]);

  // Merchant Product state
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formType, setFormType] = useState<'product' | 'service'>('product');
  const [formPrice, setFormPrice] = useState<number>(50);
  const [formComparePrice, setFormComparePrice] = useState<string>('');
  const [formDescription, setFormDescription] = useState('');
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formUnit, setFormUnit] = useState('قطعة');
  const [formError, setFormError] = useState('');
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);

  // Image Library Modal state
  const [isImageLibOpen, setIsImageLibOpen] = useState(false);
  const [imageLibTarget, setImageLibTarget] = useState<
    'product' | 'logo' | 'cover' | 'admin_logo' | 'admin_cover' | null
  >(null);

  // Employee State
  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false);
  const [empName, setEmpName] = useState('');
  const [empRole, setEmpRole] = useState('مشرف صالة / خدمة عملاء');
  const [empPhone, setEmpPhone] = useState('');
  const [empShift, setEmpShift] = useState('الوردية الصباحية (8 ص - 4 م)');

  // Business Profile Form State & Custom Links/Phones/WhatsApp
  const [bizName, setBizName] = useState(currentBusiness?.name || '');
  const [bizBio, setBizBio] = useState(currentBusiness?.bio || '');
  const [bizLogoUrl, setBizLogoUrl] = useState(resolveBusinessLogo(currentBusiness));
  const [bizCoverUrl, setBizCoverUrl] = useState(resolveBusinessCover(currentBusiness));
  const [bizOwnerWhatsApp, setBizOwnerWhatsApp] = useState(currentBusiness?.ownerWhatsApp || '');
  const [bizAddress, setBizAddress] = useState(currentBusiness?.address || '');
  const [bizWorkingHours, setBizWorkingHours] = useState(currentBusiness?.workingHours || '');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Custom links/numbers/whatsapp state
  const [newCustomLabel, setNewCustomLabel] = useState('');
  const [newCustomUrl, setNewCustomUrl] = useState('');
  const [newCustomType, setNewCustomType] = useState<'link' | 'phone' | 'whatsapp'>('whatsapp');

  // Merchant Finance / Credit Sale Form
  const [saleCustomerName, setSaleCustomerName] = useState('');
  const [saleAmount, setSaleAmount] = useState<number>(250);
  const [saleType, setSaleType] = useState<'product' | 'service'>('product');
  const [salePaymentMode, setSalePaymentMode] = useState<'cash' | 'credit'>('cash');
  const [financeToast, setFinanceToast] = useState<string | null>(null);

  // Admin Business Modal (موثق أو غير موثق + تعيين مالك + باقة الاشتراك + عمولات)
  const [isBizModalOpen, setIsBizModalOpen] = useState(false);
  const [editingBiz, setEditingBiz] = useState<Business | null>(null);
  const [adminBizName, setAdminBizName] = useState('');
  const [adminBizFunctionalGroup, setAdminBizFunctionalGroup] = useState<FunctionalGroupId>('dining');
  const [adminBizCategory, setAdminBizCategory] = useState('مطاعم ومأكولات');
  const [adminBizLogoUrl, setAdminBizLogoUrl] = useState(getSectorDefaultLogo('dining'));
  const [adminBizCoverUrl, setAdminBizCoverUrl] = useState(getSectorDefaultCover('dining'));
  const [adminBizGov, setAdminBizGov] = useState('القاهرة');
  const [adminBizMarkaz, setAdminBizMarkaz] = useState('مدينة نصر');
  const [adminBizAddress, setAdminBizAddress] = useState('الشارع الرئيسي');
  const [adminBizWhatsApp, setAdminBizWhatsApp] = useState('201010171770');
  const [adminBizOwnerSubId, setAdminBizOwnerSubId] = useState('');
  const [adminBizIsVerified, setAdminBizIsVerified] = useState<boolean>(true);
  const [adminBizTier, setAdminBizTier] = useState<SubscriptionPlanTier>('regular');
  const [adminBizMaxAllowedBusinesses, setAdminBizMaxAllowedBusinesses] = useState<number>(2);
  const [adminBizCreditLimit, setAdminBizCreditLimit] = useState<number>(5000);
  const [adminCommissionType, setAdminCommissionType] = useState<'percentage' | 'fixed' | 'percentage_plus_fixed' | 'subscription_only' | 'all_combined'>('all_combined');
  const [adminMonthlySubFee, setAdminMonthlySubFee] = useState<number>(300);
  const [adminCommissionPct, setAdminCommissionPct] = useState<number>(1.5);
  const [adminCommissionFixed, setAdminCommissionFixed] = useState<number>(2.0);
  const [adminCommissionFixedPerItem, setAdminCommissionFixedPerItem] = useState<number>(1.0);

  // Admin Subscription Request Review Modal State
  const [reviewingSubReq, setReviewingSubReq] = useState<SubscriptionRequest | null>(null);
  const [reqTier, setReqTier] = useState<SubscriptionPlanTier>('regular');
  const [reqVerifyNow, setReqVerifyNow] = useState<boolean>(true);
  const [reqAllowedBizCount, setReqAllowedBizCount] = useState<number>(2);
  const [reqMonthlyFee, setReqMonthlyFee] = useState<number>(300);
  const [reqCommPct, setReqCommPct] = useState<number>(1.5);
  const [reqCommFixed, setReqCommFixed] = useState<number>(2.0);

  // Admin Ad Edit State
  const [editingAdId, setEditingAdId] = useState<string | null>(null);
  const [editAdTitle, setEditAdTitle] = useState('');
  const [editAdDesc, setEditAdDesc] = useState('');
  const [editAdDuration, setEditAdDuration] = useState<number>(7);

  // AI Studio Developer Assistant State
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiTaskType, setAiTaskType] = useState<'Code Enhancement' | 'New Feature' | 'Database Schema' | 'UI & Styling' | 'Marketing Content'>('New Feature');
  const [aiResult, setAiResult] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [copiedAi, setCopiedAi] = useState(false);

  const handleRunAiStudioAssist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiPrompt.trim()) return;
    setIsAiLoading(true);
    setAiResult('');
    try {
      const res = await fetch('/api/ai-studio-assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: aiPrompt, taskType: aiTaskType }),
      });
      const data = await res.json();
      if (data.success) {
        setAiResult(data.result);
      } else {
        setAiResult('عذراً، حدث خطأ أثناء الاتصال بنموذج Google AI Studio.');
      }
    } catch (err: any) {
      setAiResult('خطأ في الاتصال بالخادم: ' + (err.message || 'فشل الاتصال'));
    } finally {
      setIsAiLoading(false);
    }
  };

  if (!currentBusiness && !isAdmin) {
    return <div className="p-16 text-center text-slate-500 font-bold text-base">يرجى اختيار نشاط تجاري أولاً للمتابعة.</div>;
  }

  // Handle Product Submit
  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentBusiness) return;
    setFormError('');

    if (!formName.trim()) {
      setFormError('يرجى إدخال اسم المنتج أو الخدمة.');
      return;
    }

    const comparePriceVal = formComparePrice ? parseFloat(formComparePrice) : undefined;

    const resolvedProductImg = resolveProductImage(
      { imageUrl: formImageUrl },
      currentBusiness.functionalGroupId
    );

    if (editingProduct) {
      updateProduct({
        ...editingProduct,
        name: formName,
        category: formCategory || 'عام',
        type: formType,
        price: formPrice,
        comparePrice: comparePriceVal,
        description: formDescription,
        imageUrl: resolvedProductImg,
        unit: formUnit,
      });
      setIsProductModalOpen(false);
    } else {
      const res = addProduct({
        businessId: currentBusiness.id,
        name: formName,
        category: formCategory || 'عام',
        type: formType,
        price: formPrice,
        comparePrice: comparePriceVal,
        description: formDescription,
        imageUrl: resolvedProductImg,
        isAvailable: true,
        unit: formUnit,
      });

      if (!res.success) {
        setFormError(res.message || 'فشل إضافة المنتج.');
        return;
      }
      setIsProductModalOpen(false);
    }
  };

  // Handle Employee Add
  const handleAddEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentBusiness || !empName.trim()) return;
    const currentEmployees = currentBusiness.employees || [];
    const newEmp = {
      id: 'emp_' + Date.now(),
      name: empName,
      role: empRole,
      phone: empPhone,
      shift: empShift,
    };
    updateBusiness({
      ...currentBusiness,
      employees: [newEmp, ...currentEmployees],
    });
    setEmpName('');
    setEmpPhone('');
    setIsEmployeeModalOpen(false);
  };

  const handleDeleteEmployee = (empId: string) => {
    if (!currentBusiness) return;
    const currentEmployees = currentBusiness.employees || [];
    updateBusiness({
      ...currentBusiness,
      employees: currentEmployees.filter((e) => e.id !== empId),
    });
  };

  // Handle Merchant Branding & Static Logo/Cover Update
  const handleSaveBranding = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentBusiness) return;
    updateBusiness({
      ...currentBusiness,
      name: bizName.trim() || currentBusiness.name,
      bio: bizBio,
      logoUrl: resolveBusinessLogo({
        logoUrl: bizLogoUrl,
        functionalGroupId: currentBusiness.functionalGroupId,
      }),
      coverUrl: resolveBusinessCover({
        coverUrl: bizCoverUrl,
        functionalGroupId: currentBusiness.functionalGroupId,
      }),
      ownerWhatsApp: bizOwnerWhatsApp.trim() || currentBusiness.ownerWhatsApp,
      address: bizAddress.trim() || currentBusiness.address,
      workingHours: bizWorkingHours.trim() || currentBusiness.workingHours,
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  // Handle Add Custom Link / Phone / WhatsApp
  const handleAddCustomButton = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentBusiness || !newCustomLabel.trim() || !newCustomUrl.trim()) return;
    const existing = currentBusiness.customLinks || [];
    updateBusiness({
      ...currentBusiness,
      customLinks: [
        ...existing,
        {
          label: newCustomLabel.trim(),
          url: newCustomUrl.trim(),
          type: newCustomType,
        },
      ],
    });
    setNewCustomLabel('');
    setNewCustomUrl('');
  };

  const handleRemoveCustomButton = (index: number) => {
    if (!currentBusiness) return;
    const existing = currentBusiness.customLinks || [];
    updateBusiness({
      ...currentBusiness,
      customLinks: existing.filter((_, idx) => idx !== index),
    });
  };

  // Handle Merchant Record Financial Sale / Credit Operation
  const handleRecordMerchantSale = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentBusiness || saleAmount <= 0) return;
    const creditLimit = currentBusiness.creditLimit ?? 5000;
    const usedCredit = currentBusiness.usedCreditBalance ?? 0;

    if (salePaymentMode === 'credit' && usedCredit + saleAmount > creditLimit) {
      setFinanceToast('⚠️ تنبيه: قيمة العملية تتجاوز حد الائتمان المتاح لهذا النشاط!');
      setTimeout(() => setFinanceToast(null), 3500);
      return;
    }

    updateBusiness({
      ...currentBusiness,
      totalSalesAmount: (currentBusiness.totalSalesAmount || 0) + (saleType === 'product' ? saleAmount : 0),
      totalServicesSalesAmount: (currentBusiness.totalServicesSalesAmount || 0) + (saleType === 'service' ? saleAmount : 0),
      totalOrdersCount: (currentBusiness.totalOrdersCount || 0) + 1,
      usedCreditBalance: salePaymentMode === 'credit' ? usedCredit + saleAmount : usedCredit,
    });
    setSaleCustomerName('');
    setFinanceToast('تم تسجيل حركة المبيعات وتحديث التقارير المالية وحد الائتمان بنجاح!');
    setTimeout(() => setFinanceToast(null), 3000);
  };

  // Handle Admin Business Save (موثق أو غير موثق + تعيين المالك والعمولات والاشتراك)
  const handleAdminSaveBusiness = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminBizName.trim()) return;

    const tierConfig = getDefaultTierConfiguration(adminBizTier);
    const matchingGroup = functionalGroups.find((g) => g.id === adminBizFunctionalGroup);

    const resolvedAdminLogo = resolveBusinessLogo({
      logoUrl: adminBizLogoUrl,
      functionalGroupId: adminBizFunctionalGroup,
    });
    const resolvedAdminCover = resolveBusinessCover({
      coverUrl: adminBizCoverUrl,
      functionalGroupId: adminBizFunctionalGroup,
    });

    if (editingBiz) {
      updateBusiness({
        ...editingBiz,
        name: adminBizName.trim(),
        functionalGroupId: adminBizFunctionalGroup,
        category: adminBizCategory || matchingGroup?.shortName || 'عام',
        logoUrl: resolvedAdminLogo,
        coverUrl: resolvedAdminCover,
        governorate: adminBizGov,
        markaz: adminBizMarkaz,
        address: adminBizAddress,
        ownerWhatsApp: adminBizWhatsApp,
        phone: adminBizWhatsApp,
        ownerSubscriberId: adminBizOwnerSubId || undefined,
        isVerified: adminBizIsVerified,
        verificationStatus: adminBizIsVerified ? 'verified' : 'unverified',
        subscriptionTier: adminBizTier,
        maxAllowedBusinesses: adminBizMaxAllowedBusinesses,
        creditLimit: adminBizCreditLimit,
        permissions: tierConfig.permissions,
        commissionType: adminCommissionType,
        monthlySubscriptionFee: Number(adminMonthlySubFee) || 0,
        commissionPercentage: Number(adminCommissionPct) || 0,
        commissionFixed: Number(adminCommissionFixed) || 0,
        commissionFixedPerItem: Number(adminCommissionFixedPerItem) || 0,
      });
    } else {
      addBusiness({
        name: adminBizName.trim(),
        slug: adminBizName.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now().toString().slice(-3),
        category: adminBizCategory || matchingGroup?.shortName || 'مطاعم ومأكولات',
        functionalGroupId: adminBizFunctionalGroup,
        logoUrl: resolvedAdminLogo,
        coverUrl: resolvedAdminCover,
        bio: adminBizIsVerified
          ? 'نشاط تجاري موثق من قبل إدارة منصة MantiqatiX.'
          : 'دليل مجاني — نشاط غير موثق يقتصر على الاسم والموقع والرقم لحين التوثيق.',
        ownerWhatsApp: adminBizWhatsApp || '201010171770',
        phone: adminBizWhatsApp || '01010171770',
        ownerSubscriberId: adminBizOwnerSubId || undefined,
        subscriptionTier: adminBizTier,
        maxAllowedBusinesses: adminBizMaxAllowedBusinesses,
        creditLimit: adminBizCreditLimit,
        usedCreditBalance: 0,
        permissions: tierConfig.permissions,
        commissionType: adminCommissionType,
        monthlySubscriptionFee: Number(adminMonthlySubFee) || 0,
        commissionPercentage: Number(adminCommissionPct) || 0,
        commissionFixed: Number(adminCommissionFixed) || 0,
        commissionFixedPerItem: Number(adminCommissionFixedPerItem) || 0,
        address: adminBizAddress || 'الشارع الرئيسي',
        governorate: adminBizGov,
        markaz: adminBizMarkaz || 'المركز الرئيسي',
        village: '',
        workingHours: '9 صباحاً - 11 مساءً',
        maxProductsLimit: tierConfig.maxProductsLimit,
        registrationDate: new Date().toISOString().split('T')[0],
        paymentDueDay: 1,
        paymentDueDate: new Date().toISOString().split('T')[0],
        commissionPerOrder: 0.01,
        totalOrdersCount: 0,
        paymentStatus: 'paid',
        overdueDaysCount: 0,
        isFrozen: false,
        paymentConfirmedByAdmin: true,
        isVerified: adminBizIsVerified,
        verificationStatus: adminBizIsVerified ? 'verified' : 'unverified',
      });
    }

    setAdminBizName('');
    setEditingBiz(null);
    setIsBizModalOpen(false);
  };

  // All personal bookmark sites across all subscribers for Admin review
  const allSubscribersWithPersonalSites = subscribers.filter(
    (s) => s.personalSites && s.personalSites.length > 0
  );

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row text-slate-800" dir="rtl">
      {/* =========================================================================
          SIDEBAR NAVIGATION
         ========================================================================= */}
      <aside className="w-full md:w-76 bg-slate-900 text-slate-300 flex flex-col border-l border-slate-800 shadow-2xl flex-shrink-0">
        <div className="p-5 border-b border-slate-800 flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-indigo-600 text-white flex items-center justify-center font-black text-base shadow-lg shadow-emerald-500/20">
            MX
          </div>
          <div>
            <div className="font-black text-white text-sm tracking-tight">إدارة MantiqatiX</div>
            <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              {isAdmin ? 'لوحة الإدارة العليا الشاملة' : `نشاط: ${currentBusiness?.name}`}
            </div>
          </div>
        </div>

        {isAdmin && (
          <div className="p-3.5 border-b border-slate-800 bg-slate-950/60">
            <label className="block text-[10px] font-bold text-slate-400 mb-1.5">اختر النشاط التجاري لمعاينته أو إدارته:</label>
            <select
              value={currentBusiness?.id || ''}
              onChange={(e) => setSelectedBusinessId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-xs text-white font-bold rounded-xl px-3 py-2.5 focus:outline-hidden cursor-pointer"
            >
              {businesses.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name} ({b.isVerified ? 'موثق' : 'دليل مجاني'})
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-3.5 space-y-6 no-scrollbar">
          {/* Merchant Navigation (Shown to Merchant AND also accessible to Admin for selected business) */}
          {currentBusiness && (
            <div className="space-y-1">
              <div className="text-[10px] font-black text-emerald-400 uppercase tracking-wider px-3 mb-2">
                إدارة النشاط التجاري ({currentBusiness.name.slice(0, 18)})
              </div>
              <button
                onClick={() => setActiveTab('merchant_products')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'merchant_products'
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Package className="w-4 h-4 text-emerald-300" />
                <span>المنتجات والخدمات</span>
                <span className="mr-auto bg-slate-800 text-emerald-300 px-2 py-0.5 rounded-lg text-[10px]">
                  {businessProducts.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('merchant_finance')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'merchant_finance'
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <TrendingUp className="w-4 h-4 text-amber-400" />
                <span>النظام المالي والائتمان والمبيعات</span>
              </button>

              <button
                onClick={() => setActiveTab('merchant_branding')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'merchant_branding'
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Store className="w-4 h-4 text-blue-400" />
                <span>الصورة والغلاف والروابط المنسقة</span>
              </button>

              <button
                onClick={() => setActiveTab('merchant_employees')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'merchant_employees'
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Users className="w-4 h-4 text-amber-400" />
                <span>الموظفون وفريق العمل</span>
                <span className="mr-auto bg-slate-800 text-amber-300 px-2 py-0.5 rounded-lg text-[10px]">
                  {currentBusiness.employees?.length || 0}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('merchant_qr')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'merchant_qr'
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <QrCode className="w-4 h-4 text-purple-400" />
                <span>QR كود المتجر والروابط</span>
              </button>
            </div>
          )}

          {/* Super Admin Navigation */}
          {isAdmin && (
            <div className="space-y-1 pt-2 border-t border-slate-800">
              <div className="text-[10px] font-black text-amber-400 uppercase tracking-wider px-3 mb-2 flex items-center gap-1.5">
                <Crown className="w-3.5 h-3.5" />
                <span>تحكم الإدارة العليا (Super Admin)</span>
              </div>

              <button
                onClick={() => setActiveTab('admin_businesses')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'admin_businesses'
                    ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Building2 className="w-4 h-4 text-blue-400" />
                <span>الأنشطة (موثقة / دليل مجاني)</span>
                <span className="mr-auto bg-slate-800 text-slate-200 px-2 py-0.5 rounded-lg text-[10px]">
                  {businesses.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('admin_subscription_requests')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'admin_subscription_requests'
                    ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <BadgeCheck className="w-4 h-4 text-emerald-400" />
                <span>طلبات اشتراك الأنشطة</span>
                <span className="mr-auto bg-emerald-600 text-white px-2 py-0.5 rounded-lg text-[10px]">
                  {subscriptionRequests.filter((r) => r.status === 'pending').length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('admin_inbox')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'admin_inbox'
                    ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Mail className="w-4 h-4 text-rose-400" />
                <span>صندوق رسائل تواصل معنا</span>
                <span
                  className={`mr-auto px-2 py-0.5 rounded-lg text-[10px] font-black ${
                    unreadMessagesCount > 0 ? 'bg-rose-600 text-white animate-pulse' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {unreadMessagesCount} غير مقروء
                </span>
              </button>

              <button
                onClick={() => setActiveTab('admin_ads')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'admin_ads'
                    ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Megaphone className="w-4 h-4 text-amber-300" />
                <span>الإعلانات الممولة واليافطات</span>
                <span className="mr-auto bg-slate-800 text-amber-300 px-2 py-0.5 rounded-lg text-[10px]">
                  {adRequests.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('admin_personal_sites')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'admin_personal_sites'
                    ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Bookmark className="w-4 h-4 text-indigo-400" />
                <span>مواقع المشتركين (15 موقع)</span>
              </button>

              <button
                onClick={() => setActiveTab('admin_billing')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'admin_billing'
                    ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Coins className="w-4 h-4 text-amber-300" />
                <span>الاشتراكات ونظام العمولات</span>
              </button>

              <button
                onClick={() => setActiveTab('admin_ai_studio')}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                  activeTab === 'admin_ai_studio'
                    ? 'bg-purple-600 text-white shadow-lg font-black'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Cpu className="w-4 h-4 text-purple-400" />
                <span>تطوير AI Studio الذكي</span>
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* =========================================================================
          MAIN WORKSPACE CONTENT
         ========================================================================= */}
      <main className="flex-1 flex flex-col overflow-y-auto p-5 lg:p-8 space-y-6 bg-slate-50">
        {/* =========================================================================
            ADMIN TOP VISITORS COUNTER & LIVE METRICS BAR (عداد زوار الموقع)
           ========================================================================= */}
        {isAdmin && (
          <div className="bg-gradient-to-l from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-5 text-white shadow-lg border border-indigo-500/30 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-300 shrink-0">
                  <Eye className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="font-black text-base text-white">ملخص بيانات المعاينة</h2>
                    <span className="bg-amber-500/15 text-amber-200 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-amber-300/30">
                      غير متصل بمصدر تحليلات إنتاجي
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    الأعداد التالية تصف حالة التطبيق الحالية فقط. لا تثبت اعتماد البيانات أو وجود مزامنة مع قاعدة إنتاج مشتركة. آخر حفظ للمعاينة: {lastLiveSyncTimestamp}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white/10 backdrop-blur-xs border border-white/15 rounded-2xl px-4 py-2.5 text-center">
                  <div className="text-[10px] text-emerald-300 font-bold">إجمالي زوار الموقع</div>
                  <div className="text-lg font-black text-white">غير متاح</div>
                </div>
                <div className="bg-white/10 backdrop-blur-xs border border-white/15 rounded-2xl px-4 py-2.5 text-center">
                  <div className="text-[10px] text-amber-300 font-bold">زوار اليوم</div>
                  <div className="text-lg font-black text-white">غير متاح</div>
                </div>
                <div className="bg-white/10 backdrop-blur-xs border border-white/15 rounded-2xl px-4 py-2.5 text-center">
                  <div className="text-[10px] text-rose-300 font-bold">رسائل غير مقروءة</div>
                  <div className="text-lg font-black text-white">{unreadMessagesCount}</div>
                </div>
                <div className="bg-white/10 backdrop-blur-xs border border-white/15 rounded-2xl px-4 py-2.5 text-center">
                  <div className="text-[10px] text-indigo-300 font-bold">الأنشطة في المعاينة</div>
                  <div className="text-lg font-black text-white">{businesses.length}</div>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/10">
              <div className="flex items-center gap-2 text-xs text-amber-200 font-bold" role="status">
                <ShieldAlert className="w-4 h-4 text-amber-300 shrink-0" aria-hidden="true" />
                <span>
                  الحفظ المشترك غير متاح من هذه الشاشة. يتطلب ربط خدمة خلفية موثقة ومصادقة وصلاحيات قبل تفعيله.
                </span>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB: MERCHANT PRODUCTS
           ========================================================================= */}
        {activeTab === 'merchant_products' && currentBusiness && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs">
              <div>
                <h1 className="font-black text-xl text-slate-900">إدارة المنتجات والخدمات ({currentBusiness.name})</h1>
                <p className="text-xs text-slate-500 mt-1">
                  الحد الأقصى المسموح في باقتك الحالية:{' '}
                  <strong className="text-emerald-700">
                    {businessProducts.length} من {currentBusiness.maxProductsLimit || 150} صنف
                  </strong>
                </p>
              </div>
              <button
                onClick={() => {
                  setEditingProduct(null);
                  setFormName('');
                  setFormPrice(50);
                  setFormDescription('');
                  setFormImageUrl(getSectorDefaultProductImage(currentBusiness.functionalGroupId));
                  setIsProductModalOpen(true);
                }}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-5 py-3 rounded-2xl shadow-md shadow-emerald-600/20 flex items-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة منتج أو خدمة جديدة</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {businessProducts.map((p) => (
                <div key={p.id} className="bg-white rounded-3xl border border-slate-200/80 overflow-hidden shadow-xs flex flex-col hover:shadow-md transition-shadow">
                  <div className="relative h-44 bg-slate-100">
                    <img
                      src={resolveProductImage(p, currentBusiness.functionalGroupId)}
                      alt={p.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = getSectorDefaultProductImage(
                          currentBusiness.functionalGroupId
                        );
                      }}
                    />
                    <span className="absolute top-3 right-3 bg-slate-900/80 text-white text-[10px] font-black px-3 py-1 rounded-full backdrop-blur-xs">
                      {p.category} • {p.type === 'service' ? 'خدمة' : 'منتج'}
                    </span>
                  </div>
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-1">
                      <h3 className="font-black text-base text-slate-900">{p.name}</h3>
                      <p className="text-xs text-slate-500 line-clamp-2">{p.description}</p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                      <div className="font-black text-emerald-700 text-sm">
                        {p.price} {adminSettings.currency || 'ج.م'}
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setEditingProduct(p);
                            setFormName(p.name);
                            setFormCategory(p.category);
                            setFormType(p.type);
                            setFormPrice(p.price);
                            setFormDescription(p.description);
                            setFormImageUrl(p.imageUrl);
                            setIsProductModalOpen(true);
                          }}
                          className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                          title="تعديل"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteProduct(p.id)}
                          className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer"
                          title="حذف"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB: MERCHANT FINANCIAL SYSTEM, SALES REPORTS & CREDIT LIMIT
           ========================================================================= */}
        {activeTab === 'merchant_finance' && currentBusiness && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
              <h1 className="font-black text-xl text-slate-900">
                النظام المالي وتقارير المبيعات وحد الائتمان ({currentBusiness.name})
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                متابعة دقيقة لمبيعات المنتجات والخدمات، رصيد المحفظة، وحد الائتمان المسموح به للنشاط.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-3xl border border-emerald-200 shadow-xs">
                <div className="text-xs font-bold text-slate-500">مبيعات السلع والمنتجات</div>
                <div className="text-2xl font-black text-emerald-700 mt-1">
                  {(currentBusiness.totalSalesAmount || 12450).toLocaleString('ar-EG')} ج.م
                </div>
                <div className="text-[11px] text-emerald-600 font-bold mt-1">إجمالي الطلبات: {currentBusiness.totalOrdersCount || 18} طلب</div>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-indigo-200 shadow-xs">
                <div className="text-xs font-bold text-slate-500">إيرادات الخدمات والحجوزات</div>
                <div className="text-2xl font-black text-indigo-700 mt-1">
                  {(currentBusiness.totalServicesSalesAmount || 4800).toLocaleString('ar-EG')} ج.م
                </div>
                <div className="text-[11px] text-indigo-600 font-bold mt-1">حجوزات واستشارات مكتملة</div>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-amber-200 shadow-xs">
                <div className="text-xs font-bold text-slate-500">حد الائتمان المسموح للنشاط</div>
                <div className="text-2xl font-black text-amber-700 mt-1">
                  {(currentBusiness.creditLimit ?? 5000).toLocaleString('ar-EG')} ج.م
                </div>
                <div className="text-[11px] text-slate-600 font-bold mt-1">
                  المستخدم: {(currentBusiness.usedCreditBalance ?? 650).toLocaleString('ar-EG')} ج.م • المتبقي:{' '}
                  {Math.max(0, (currentBusiness.creditLimit ?? 5000) - (currentBusiness.usedCreditBalance ?? 650)).toLocaleString('ar-EG')} ج.م
                </div>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-purple-200 shadow-xs">
                <div className="text-xs font-bold text-slate-500">باقة الاشتراك والعمولة</div>
                <div className="text-lg font-black text-purple-800 mt-1">
                  {currentBusiness.subscriptionTier === 'advanced'
                    ? 'الباقة المتقدمة الشاملة'
                    : currentBusiness.subscriptionTier === 'free'
                    ? 'الباقة المجانية'
                    : 'الباقة العادية القياسية'}
                </div>
                <div className="text-[11px] text-slate-600 font-bold mt-1">
                  اشتراك: {currentBusiness.monthlySubscriptionFee || 300} ج.م | عمولة: {currentBusiness.commissionPercentage || 1}%
                </div>
              </div>
            </div>

            {financeToast && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 p-4 rounded-2xl text-xs font-black">
                {financeToast}
              </div>
            )}

            <form onSubmit={handleRecordMerchantSale} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
              <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600" />
                <span>تسجيل حركة بيع جديدة (نقدي أو آجل ضمن حد الائتمان)</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">اسم العميل / البيان</label>
                  <input
                    type="text"
                    required
                    value={saleCustomerName}
                    onChange={(e) => setSaleCustomerName(e.target.value)}
                    placeholder="مثال: فاتورة عميل #105"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">نوع العملية</label>
                  <select
                    value={saleType}
                    onChange={(e: any) => setSaleType(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold cursor-pointer"
                  >
                    <option value="product">بيع منتج / سلعة</option>
                    <option value="service">تقديم خدمة / حجز</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">طريقة السداد</label>
                  <select
                    value={salePaymentMode}
                    onChange={(e: any) => setSalePaymentMode(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold cursor-pointer"
                  >
                    <option value="cash">نقدي / فوري</option>
                    <option value="credit">آجل (يخصم من حد الائتمان)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">المبلغ (ج.م)</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={saleAmount}
                    onChange={(e) => setSaleAmount(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-6 py-3 rounded-2xl shadow-md cursor-pointer"
              >
                تسجيل العملية وتحديث التقرير المالي
              </button>
            </form>
          </div>
        )}

        {/* =========================================================================
            TAB: MERCHANT BRANDING (STATIC LOGO/COVER + AUTOMATIC CUSTOM BUTTONS)
           ========================================================================= */}
        {activeTab === 'merchant_branding' && currentBusiness && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <h1 className="font-black text-xl text-slate-900">الهوية والصورة الثابتة والغلاف والروابط المنسقة</h1>
                  <p className="text-xs text-slate-500 mt-1">
                    لكل نشاط صورة ثابتة (Logo) وغلاف ثابت (Cover) منذ أول تسجيل للنشاط، ويمكنك كمالك للنشاط تغييرهما في أي وقت من هنا.
                  </p>
                </div>
                {saveSuccess && (
                  <span className="bg-emerald-100 text-emerald-800 font-black text-xs px-4 py-2 rounded-xl flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>تم حفظ التعديلات بنجاح!</span>
                  </span>
                )}
              </div>

              <form onSubmit={handleSaveBranding} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {/* Logo Preview & Selectable Presets */}
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={resolveBusinessLogo({
                          logoUrl: bizLogoUrl,
                          functionalGroupId: currentBusiness.functionalGroupId,
                        })}
                        alt="شعار النشاط"
                        className="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500 bg-white shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <label className="block text-xs font-black text-slate-800">
                          صورة شعار النشاط (Logo)
                        </label>
                        <p className="text-[11px] text-slate-500">
                          ثابت افتراضياً لمجال (
                          {SECTOR_DEFAULT_IMAGES[currentBusiness.functionalGroupId]?.sectorName || 'النشاط'}
                          ) أو اختر من الصور الجاهزة
                        </p>
                      </div>
                      <div className="flex flex-col gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            setImageLibTarget('logo');
                            setIsImageLibOpen(true);
                          }}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[11px] px-3 py-1.5 rounded-xl cursor-pointer flex items-center justify-center gap-1"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          <span>مكتبة الصور</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setBizLogoUrl(getSectorDefaultLogo(currentBusiness.functionalGroupId))
                          }
                          className="bg-amber-100 hover:bg-amber-200 text-amber-950 font-black text-[10px] px-2.5 py-1 rounded-xl cursor-pointer"
                        >
                          افتراضي المجال ⭐
                        </button>
                      </div>
                    </div>

                    {/* Quick Selectable Sector Default Logos */}
                    <div className="space-y-1">
                      <span className="text-[10px] font-black text-slate-600">
                        شعارات افتراضية جاهزة للاختيار السريع:
                      </span>
                      <div className="flex items-center gap-2 overflow-x-auto pb-1">
                        {getSelectableImagesForSector(currentBusiness.functionalGroupId, 'logo')
                          .concat(getSelectableImagesForSector('all', 'logo').slice(0, 6))
                          .filter((v, i, a) => a.findIndex((t) => t.url === v.url) === i)
                          .slice(0, 8)
                          .map((preset) => (
                            <button
                              key={preset.id}
                              type="button"
                              onClick={() => setBizLogoUrl(preset.url)}
                              title={preset.title}
                              className={`w-11 h-11 rounded-xl overflow-hidden border-2 shrink-0 cursor-pointer transition-all ${
                                bizLogoUrl === preset.url
                                  ? 'border-emerald-600 ring-2 ring-emerald-500/30 scale-105'
                                  : 'border-slate-200 hover:border-slate-400 opacity-85 hover:opacity-100'
                              }`}
                            >
                              <img src={preset.url} alt={preset.title} className="w-full h-full object-cover" />
                            </button>
                          ))}
                      </div>
                    </div>

                    <input
                      type="text"
                      value={bizLogoUrl}
                      onChange={(e) => setBizLogoUrl(e.target.value)}
                      placeholder="رابط صورة الشعار (أو اتركه فارغاً لاستخدام الشعار الافتراضي للمجال)..."
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold"
                    />
                  </div>

                  {/* Cover Preview & Selectable Presets */}
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={resolveBusinessCover({
                          coverUrl: bizCoverUrl,
                          functionalGroupId: currentBusiness.functionalGroupId,
                        })}
                        alt="غلاف النشاط"
                        className="w-24 h-16 rounded-2xl object-cover border-2 border-emerald-500 bg-white shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <label className="block text-xs font-black text-slate-800">
                          صورة غلاف النشاط (Cover)
                        </label>
                        <p className="text-[11px] text-slate-500">
                          ثابت افتراضياً لمجال (
                          {SECTOR_DEFAULT_IMAGES[currentBusiness.functionalGroupId]?.sectorName || 'النشاط'}
                          ) أو اختر من الأغلفة الجاهزة
                        </p>
                      </div>
                      <div className="flex flex-col gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            setImageLibTarget('cover');
                            setIsImageLibOpen(true);
                          }}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[11px] px-3 py-1.5 rounded-xl cursor-pointer flex items-center justify-center gap-1"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          <span>مكتبة الصور</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setBizCoverUrl(getSectorDefaultCover(currentBusiness.functionalGroupId))
                          }
                          className="bg-amber-100 hover:bg-amber-200 text-amber-950 font-black text-[10px] px-2.5 py-1 rounded-xl cursor-pointer"
                        >
                          افتراضي المجال ⭐
                        </button>
                      </div>
                    </div>

                    {/* Quick Selectable Sector Default Covers */}
                    <div className="space-y-1">
                      <span className="text-[10px] font-black text-slate-600">
                        أغلفة (Covers) افتراضية جاهزة للاختيار السريع:
                      </span>
                      <div className="flex items-center gap-2 overflow-x-auto pb-1">
                        {getSelectableImagesForSector(currentBusiness.functionalGroupId, 'cover')
                          .concat(getSelectableImagesForSector('all', 'cover').slice(0, 6))
                          .filter((v, i, a) => a.findIndex((t) => t.url === v.url) === i)
                          .slice(0, 8)
                          .map((preset) => (
                            <button
                              key={preset.id}
                              type="button"
                              onClick={() => setBizCoverUrl(preset.url)}
                              title={preset.title}
                              className={`w-16 h-11 rounded-xl overflow-hidden border-2 shrink-0 cursor-pointer transition-all ${
                                bizCoverUrl === preset.url
                                  ? 'border-emerald-600 ring-2 ring-emerald-500/30 scale-105'
                                  : 'border-slate-200 hover:border-slate-400 opacity-85 hover:opacity-100'
                              }`}
                            >
                              <img src={preset.url} alt={preset.title} className="w-full h-full object-cover" />
                            </button>
                          ))}
                      </div>
                    </div>

                    <input
                      type="text"
                      value={bizCoverUrl}
                      onChange={(e) => setBizCoverUrl(e.target.value)}
                      placeholder="رابط صورة الغلاف (أو اتركه فارغاً لاستخدام الغلاف الافتراضي للمجال)..."
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">اسم النشاط</label>
                    <input
                      type="text"
                      value={bizName}
                      onChange={(e) => setBizName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">رقم واتساب النشاط الرئيسي</label>
                    <input
                      type="text"
                      value={bizOwnerWhatsApp}
                      onChange={(e) => setBizOwnerWhatsApp(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">العنوان التفصيلي</label>
                    <input
                      type="text"
                      value={bizAddress}
                      onChange={(e) => setBizAddress(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-slate-700 mb-1">مواعيد العمل</label>
                    <input
                      type="text"
                      value={bizWorkingHours}
                      onChange={(e) => setBizWorkingHours(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">النبذة التعريفية للنشاط</label>
                  <textarea
                    rows={2}
                    value={bizBio}
                    onChange={(e) => setBizBio(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                  />
                </div>

                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-6 py-3 rounded-2xl shadow-md cursor-pointer"
                >
                  حفظ تحديثات الهوية والصورة والغلاف
                </button>
              </form>
            </div>

            {/* Automatic Coordinated Custom Links / Phones / WhatsApp Manager */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
              <div>
                <h2 className="font-black text-lg text-slate-900 flex items-center gap-2">
                  <Link2 className="w-5 h-5 text-indigo-600" />
                  <span>إضافة لينكات أو أرقام أو واتس (تظهر أوتوماتيكياً كأزرار منسقة بالنشاط)</span>
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  أي إضافة سواء لينكات أو أرقام اتصال أو أرقام واتساب يظهر لها أوتوماتيكياً زر منسق في كارت النشاط وواجهة المتجر.
                </p>
              </div>

              <form onSubmit={handleAddCustomButton} className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div>
                  <label className="block text-[11px] font-black text-slate-700 mb-1">نوع الزر المنسق</label>
                  <select
                    value={newCustomType}
                    onChange={(e: any) => setNewCustomType(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold cursor-pointer"
                  >
                    <option value="whatsapp">زر واتساب مباشر (WhatsApp)</option>
                    <option value="phone">زر رقم اتصال مباشر (Phone)</option>
                    <option value="link">زر رابط خارجي / منيو / موقع (Link)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-black text-slate-700 mb-1">اسم الزر الظاهر للعميل</label>
                  <input
                    type="text"
                    required
                    value={newCustomLabel}
                    onChange={(e) => setNewCustomLabel(e.target.value)}
                    placeholder="مثال: واتساب المبيعات / الخط الساخن"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-black text-slate-700 mb-1">
                    {newCustomType === 'link' ? 'الرابط (URL)' : 'الرقم'}
                  </label>
                  <input
                    type="text"
                    required
                    value={newCustomUrl}
                    onChange={(e) => setNewCustomUrl(e.target.value)}
                    placeholder={newCustomType === 'link' ? 'https://...' : '01010171770'}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-bold"
                  />
                </div>
                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs py-2.5 px-4 rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إضافة الزر فوراً</span>
                  </button>
                </div>
              </form>

              <div className="flex flex-wrap gap-2.5">
                {(currentBusiness.customLinks || []).length === 0 ? (
                  <p className="text-xs text-slate-400 font-bold">لم يتم إضافة أزرار إضافية بعد. أضف أي رابط أو رقم أو واتس ليظهر فوراً.</p>
                ) : (
                  (currentBusiness.customLinks || []).map((item, idx) => (
                    <div
                      key={idx}
                      className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-black border ${
                        item.type === 'whatsapp'
                          ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                          : item.type === 'phone'
                          ? 'bg-blue-50 text-blue-900 border-blue-200'
                          : 'bg-indigo-50 text-indigo-900 border-indigo-200'
                      }`}
                    >
                      {item.type === 'whatsapp' ? (
                        <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                      ) : item.type === 'phone' ? (
                        <Phone className="w-3.5 h-3.5 text-blue-600" />
                      ) : (
                        <ExternalLink className="w-3.5 h-3.5 text-indigo-600" />
                      )}
                      <span>{item.label}</span>
                      <span className="text-[10px] opacity-70">({item.url})</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveCustomButton(idx)}
                        className="text-rose-600 hover:text-rose-800 mr-1 cursor-pointer"
                        title="حذف الزر"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB: MERCHANT EMPLOYEES
           ========================================================================= */}
        {activeTab === 'merchant_employees' && currentBusiness && (
          <div className="space-y-6">
            <div className="flex items-center justify-between bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
              <div>
                <h1 className="font-black text-xl text-slate-900">فريق العمل والموظفون ({currentBusiness.name})</h1>
                <p className="text-xs text-slate-500 mt-1">إدارة موظفي النشاط والورديات وأرقام التواصل.</p>
              </div>
              <button
                onClick={() => setIsEmployeeModalOpen(true)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-5 py-3 rounded-2xl shadow-md flex items-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة موظف جديد</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(currentBusiness.employees || []).map((emp) => (
                <div key={emp.id} className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="font-black text-sm text-slate-900">{emp.name}</div>
                    <div className="text-xs text-emerald-700 font-bold">{emp.role}</div>
                    <div className="text-[11px] text-slate-500">{emp.phone} • {emp.shift}</div>
                  </div>
                  <button
                    onClick={() => handleDeleteEmployee(emp.id)}
                    className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB: MERCHANT QR CODE
           ========================================================================= */}
        {activeTab === 'merchant_qr' && currentBusiness && (
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xs text-center space-y-4">
            <QrCode className="w-14 h-14 text-emerald-600 mx-auto" />
            <h2 className="font-black text-xl text-slate-900">QR كود المتجر والروابط المباشرة ({currentBusiness.name})</h2>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              شارك رمز الاستجابة السريعة (QR Code) مع عملائك لفتح كتالوج نشاطك مباشرة والطلب عبر الواتساب.
            </p>
            <button
              onClick={() => setIsQrModalOpen(true)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-6 py-3 rounded-2xl shadow-md cursor-pointer"
            >
              عرض وتحميل QR كود النشاط
            </button>
          </div>
        )}

        {/* =========================================================================
            ADMIN TAB: BUSINESSES (VERIFIED vs UNVERIFIED FREE DIRECTORY)
           ========================================================================= */}
        {isAdmin && activeTab === 'admin_businesses' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
              <div>
                <h1 className="font-black text-xl text-slate-900">
                  إدارة الأنشطة الموثقة وأنشطة الدليل المجاني (غير الموثقة لحين التوثيق)
                </h1>
                <p className="text-xs text-slate-500 mt-1">
                  يمكن للإدارة إضافة أنشطة موثقة كاملة أو أنشطة غير موثقة تقتصر على (الاسم والموقع والرقم) لحين التوثيق، مع تعيين المالك ونظام الاشتراك والعمولات.
                </p>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => {
                    setEditingBiz(null);
                    setAdminBizName('');
                    setAdminBizFunctionalGroup('dining');
                    setAdminBizLogoUrl(getSectorDefaultLogo('dining'));
                    setAdminBizCoverUrl(getSectorDefaultCover('dining'));
                    setAdminBizIsVerified(true);
                    setAdminBizTier('regular');
                    setAdminBizOwnerSubId(subscribers[0]?.id || '');
                    setIsBizModalOpen(true);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-4 py-3 rounded-2xl shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة نشاط موثق</span>
                </button>
                <button
                  onClick={() => {
                    setEditingBiz(null);
                    setAdminBizName('');
                    setAdminBizFunctionalGroup('dining');
                    setAdminBizLogoUrl(getSectorDefaultLogo('dining'));
                    setAdminBizCoverUrl(getSectorDefaultCover('dining'));
                    setAdminBizIsVerified(false);
                    setAdminBizTier('free');
                    setAdminBizOwnerSubId('');
                    setIsBizModalOpen(true);
                  }}
                  className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs px-4 py-3 rounded-2xl shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة نشاط غير موثق (دليل مجاني)</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {businesses.map((b) => {
                const ownerSub = subscribers.find((s) => s.id === b.ownerSubscriberId);
                const isVerifiedBiz = b.isVerified && b.verificationStatus !== 'unverified';
                const groupObj = functionalGroups.find((g) => g.id === b.functionalGroupId);

                return (
                  <div
                    key={b.id}
                    className={`bg-white rounded-3xl border overflow-hidden shadow-xs p-5 space-y-4 ${
                      isVerifiedBiz ? 'border-slate-200' : 'border-amber-300 bg-amber-50/20'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <img
                          src={resolveBusinessLogo(b)}
                          alt={b.name}
                          onClick={() => {
                            setSelectedBusinessId(b.id);
                            setCurrentView('public_storefront');
                          }}
                          title={`اضغط لعرض نشاط ${b.name}`}
                          className="w-12 h-12 rounded-2xl object-cover border border-slate-200 cursor-pointer hover:scale-105 transition-transform"
                        />
                        <div>
                          <h3
                            onClick={() => {
                              setSelectedBusinessId(b.id);
                              setCurrentView('public_storefront');
                            }}
                            className="font-black text-sm text-slate-900 hover:text-emerald-700 cursor-pointer transition-colors"
                          >
                            {b.name}
                          </h3>
                          <p className="text-[11px] text-slate-500">
                            {groupObj?.icon} {groupObj?.shortName || b.category} • {b.governorate} - {b.markaz}
                          </p>
                        </div>
                      </div>
                      <span
                        className={`text-[10px] font-black px-2.5 py-1 rounded-full shrink-0 ${
                          isVerifiedBiz
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-amber-100 text-amber-900 border border-amber-300'
                        }`}
                      >
                        {isVerifiedBiz ? 'موثق رسمياً' : 'غير موثق (دليل مجاني)'}
                      </span>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500 font-bold">الباقة والصلاحيات:</span>
                        <span className="font-black text-indigo-700">
                          {b.subscriptionTier === 'advanced'
                            ? 'متقدم'
                            : b.subscriptionTier === 'free'
                            ? 'مجاني'
                            : 'عادي'}{' '}
                          ({b.maxAllowedBusinesses || 1} نشاط متاح)
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500 font-bold">المالك المعين:</span>
                        <span className="font-bold text-slate-800 truncate max-w-[170px]">
                          {ownerSub ? ownerSub.fullName : 'دليل عام / بدون مالك'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500 font-bold">الرقم:</span>
                        <span className="font-bold text-emerald-700">{b.ownerWhatsApp || b.phone}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() =>
                          updateBusiness({
                            ...b,
                            isVerified: !isVerifiedBiz,
                            verificationStatus: !isVerifiedBiz ? 'verified' : 'unverified',
                          })
                        }
                        className={`px-3 py-2 rounded-xl text-[11px] font-black cursor-pointer ${
                          isVerifiedBiz
                            ? 'bg-amber-100 hover:bg-amber-200 text-amber-900'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        }`}
                      >
                        {isVerifiedBiz ? 'تحويل لدليل مجاني' : 'توثيق النشاط فوراً ✓'}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setEditingBiz(b);
                          setAdminBizName(b.name);
                          setAdminBizFunctionalGroup(b.functionalGroupId);
                          setAdminBizCategory(b.category);
                          setAdminBizLogoUrl(resolveBusinessLogo(b));
                          setAdminBizCoverUrl(resolveBusinessCover(b));
                          setAdminBizGov(b.governorate);
                          setAdminBizMarkaz(b.markaz);
                          setAdminBizAddress(b.address);
                          setAdminBizWhatsApp(b.ownerWhatsApp);
                          setAdminBizOwnerSubId(b.ownerSubscriberId || '');
                          setAdminBizIsVerified(isVerifiedBiz);
                          setAdminBizTier(b.subscriptionTier || 'regular');
                          setAdminBizMaxAllowedBusinesses(b.maxAllowedBusinesses || 1);
                          setAdminBizCreditLimit(b.creditLimit || 5000);
                          setAdminCommissionType(b.commissionType || 'percentage_plus_fixed');
                          setAdminMonthlySubFee(b.monthlySubscriptionFee || 300);
                          setAdminCommissionPct(b.commissionPercentage || 1.0);
                          setAdminCommissionFixed(b.commissionFixed || 2.0);
                          setIsBizModalOpen(true);
                        }}
                        className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-[11px] font-black cursor-pointer"
                      >
                        إعدادات الاشتراك والمالك
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* =========================================================================
            ADMIN TAB: SUBSCRIPTION REQUESTS (طلبات أرغب في اشتراك نشاطي)
           ========================================================================= */}
        {isAdmin && activeTab === 'admin_subscription_requests' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
              <h1 className="font-black text-xl text-slate-900">
                طلبات اشتراك الأنشطة ("أرغب في اشتراك نشاطي") وتحديد الصلاحيات والعمولات
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                تواصل مع مقدم الطلب عبر الواتساب، وحدد نظام اشتراكه (مجاني / عادي / متقدم)، عمولاته، صلاحياته، وعدد النشاطات المتاحة له ثم اعتمد تفعيل النشاط.
              </p>
            </div>

            <div className="space-y-4">
              {subscriptionRequests.map((req) => {
                const groupObj = functionalGroups.find((g) => g.id === req.functionalGroupId);
                const cleanPhone = req.phoneOrWhatsApp.replace(/[^\d]/g, '');
                const waPhone = cleanPhone.startsWith('20') ? cleanPhone : `2${cleanPhone}`;

                return (
                  <div
                    key={req.id}
                    className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-5"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-black text-base text-slate-900">{req.businessName}</span>
                        <span className="bg-indigo-50 text-indigo-800 border border-indigo-200 text-[11px] font-black px-2.5 py-0.5 rounded-full">
                          {groupObj?.icon} {groupObj?.shortName || req.category}
                        </span>
                        <span
                          className={`text-[11px] font-black px-2.5 py-0.5 rounded-full ${
                            req.status === 'approved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : req.status === 'rejected'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-900'
                          }`}
                        >
                          {req.status === 'approved' ? 'تم التفعيل والاعتماد' : req.status === 'rejected' ? 'مرفوض' : 'قيد المراجعة'}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 font-bold">
                        <span>المالك: {req.ownerName || 'غير محدد'}</span>
                        <span>•</span>
                        <span className="text-emerald-700">الهاتف/الواتس: {req.phoneOrWhatsApp}</span>
                        <span>•</span>
                        <span>
                          الموقع: {req.governorate} - مركز {req.markaz} {req.detailedAddress ? `(${req.detailedAddress})` : ''}
                        </span>
                      </div>

                      {req.notes && <p className="text-xs text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100">{req.notes}</p>}
                    </div>

                    <div className="flex items-center gap-2.5 flex-wrap shrink-0">
                      <a
                        href={`https://wa.me/${waPhone}?text=${encodeURIComponent(
                          `مرحباً بك من إدارة منصة MantiqatiX بخصوص طلب اشتراك نشاطك (${req.businessName}) في ${req.governorate} - ${req.markaz}.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-4 py-2.5 rounded-xl flex items-center gap-1.5 cursor-pointer"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>مراسلة مقدم الطلب (واتساب)</span>
                      </a>

                      <button
                        type="button"
                        onClick={() => {
                          setReviewingSubReq(req);
                          setReqTier(req.requestedTier || 'regular');
                          setReqVerifyNow(!req.isUnverifiedFreeDirectory);
                          setReqAllowedBizCount(req.assignedMaxAllowedBusinesses || 2);
                          setReqMonthlyFee(req.assignedMonthlyFee ?? 300);
                          setReqCommPct(req.assignedCommissionPercentage ?? 1.5);
                          setReqCommFixed(req.assignedCommissionFixed ?? 2.0);
                        }}
                        className="bg-slate-900 hover:bg-slate-800 text-white font-black text-xs px-4 py-2.5 rounded-xl cursor-pointer"
                      >
                        تحديد نظام الاشتراك والعمولات والتفعيل
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* =========================================================================
            ADMIN TAB: CONTACT US INBOX (صندوق رسائل الإدارة)
           ========================================================================= */}
        {isAdmin && activeTab === 'admin_inbox' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
              <div>
                <h1 className="font-black text-xl text-slate-900">
                  صندوق رسائل وطلبات وشكاوى "تواصل معنا" ({unreadMessagesCount} غير مقروءة)
                </h1>
                <p className="text-xs text-slate-500 mt-1">
                  جميع الرسائل المرسلة من نموذج "تواصل معنا" تصل هنا وتُحول أيضاً بشكل منسق إلى واتساب الإدارة.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {contactMessages.map((msg) => {
                const cleanPhone = msg.senderPhone.replace(/[^\d]/g, '');
                const waPhone = cleanPhone.startsWith('20') ? cleanPhone : `2${cleanPhone}`;

                return (
                  <div
                    key={msg.id}
                    className={`p-5 rounded-3xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                      msg.isRead ? 'bg-white border-slate-200' : 'bg-rose-50/40 border-rose-300 shadow-sm'
                    }`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        {!msg.isRead && (
                          <span className="bg-rose-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                            جديد غير مقروء
                          </span>
                        )}
                        <span className="font-black text-sm text-slate-900">{msg.subject}</span>
                        <span className="bg-slate-100 text-slate-700 text-[10px] font-black px-2.5 py-0.5 rounded-full">
                          {msg.messageType === 'complaint'
                            ? 'شكوى'
                            : msg.messageType === 'request'
                            ? 'طلب'
                            : msg.messageType === 'inquiry'
                            ? 'استفسار'
                            : 'رسالة'}
                        </span>
                        <span className="text-[11px] text-slate-400">{msg.createdAt}</span>
                      </div>
                      <p className="text-xs text-slate-700 font-medium leading-relaxed">{msg.content}</p>
                      <div className="text-[11px] text-slate-500 font-bold">
                        المرسل: {msg.senderName} ({msg.senderRole}) • هاتف/واتس: {msg.senderPhone}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => markContactMessageRead(msg.id, !msg.isRead)}
                        className={`px-3 py-2 rounded-xl text-xs font-black cursor-pointer ${
                          msg.isRead
                            ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        }`}
                      >
                        {msg.isRead ? 'تحديد كغير مقروء' : 'تأشير كمقروء ✓'}
                      </button>

                      <a
                        href={`https://wa.me/${waPhone}?text=${encodeURIComponent(
                          `مرحباً أ/ ${msg.senderName}، نتواصل معك من إدارة منصة MantiqatiX بخصوص رسالتك (${msg.subject}).`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-emerald-100 hover:bg-emerald-200 text-emerald-800 px-3 py-2 rounded-xl text-xs font-black flex items-center gap-1 cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>رد واتساب</span>
                      </a>

                      <button
                        type="button"
                        onClick={() => deleteContactMessage(msg.id)}
                        className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer"
                        title="حذف الرسالة"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* =========================================================================
            ADMIN TAB: SPONSORED ADS & BILLBOARD BANNERS
           ========================================================================= */}
        {isAdmin && activeTab === 'admin_ads' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
              <h1 className="font-black text-xl text-slate-900">
                إدارة طلبات الإعلانات الممولة وحجز اليافطات الإعلانية
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                يمكن للإدارة النشر المباشر من خلال الموافقة فقط أو التعديل على الطلب قبل النشر. تظهر الإعلانات المعتمدة داخل الموقع في نوافذ ثابتة أو منبثقة هادئة غير متعبة للزوار.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {adRequests.map((ad) => (
                <div key={ad.id} className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs p-5 space-y-4">
                  <div className="flex items-start gap-3.5">
                    {ad.imageUrl && (
                      <img src={ad.imageUrl} alt={ad.title} className="w-20 h-20 rounded-2xl object-cover shrink-0 border border-slate-200" />
                    )}
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className={`text-[10px] font-black px-2.5 py-0.5 rounded-full ${
                            ad.type === 'billboard_banner'
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'bg-amber-100 text-amber-900'
                          }`}
                        >
                          {ad.type === 'billboard_banner' ? 'يافطة إعلانية' : 'إعلان ممول'}
                        </span>
                        <span
                          className={`text-[10px] font-black px-2.5 py-0.5 rounded-full ${
                            ad.status === 'approved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : ad.status === 'rejected'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-900'
                          }`}
                        >
                          {ad.status === 'approved' ? 'منشور ومعتمد ✓' : ad.status === 'rejected' ? 'مرفوض' : 'قيد مراجعة الإدارة'}
                        </span>
                      </div>
                      <h3 className="font-black text-sm text-slate-900">{ad.title}</h3>
                      <p className="text-xs text-slate-600">{ad.description}</p>
                      <div className="text-[11px] text-slate-400 font-bold">
                        مقدم الطلب: {ad.businessName} • واتساب: {ad.contactWhatsApp} • المدة: {ad.durationDays} يوم
                      </div>
                    </div>
                  </div>

                  {editingAdId === ad.id ? (
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                      <input
                        type="text"
                        value={editAdTitle}
                        onChange={(e) => setEditAdTitle(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold"
                        placeholder="عنوان الإعلان"
                      />
                      <textarea
                        rows={2}
                        value={editAdDesc}
                        onChange={(e) => setEditAdDesc(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-xl p-2.5 text-xs font-bold"
                        placeholder="وصف الإعلان"
                      />
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setEditingAdId(null)}
                          className="px-3 py-1.5 bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                        >
                          إلغاء
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            updateAdRequestDetails({
                              ...ad,
                              title: editAdTitle,
                              description: editAdDesc,
                              durationDays: editAdDuration,
                              status: 'approved',
                            });
                            setEditingAdId(null);
                          }}
                          className="px-4 py-1.5 bg-emerald-600 text-white rounded-xl text-xs font-black cursor-pointer"
                        >
                          حفظ التعديل والموافقة للنشر
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingAdId(ad.id);
                          setEditAdTitle(ad.title);
                          setEditAdDesc(ad.description);
                          setEditAdDuration(ad.durationDays);
                        }}
                        className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-black cursor-pointer flex items-center gap-1"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>تعديل الطلب</span>
                      </button>
                      {ad.status !== 'approved' && (
                        <button
                          type="button"
                          onClick={() => updateAdRequestStatus(ad.id, 'approved')}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black cursor-pointer flex items-center gap-1"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>موافقة ونشر فوري</span>
                        </button>
                      )}
                      {ad.status !== 'rejected' && (
                        <button
                          type="button"
                          onClick={() => updateAdRequestStatus(ad.id, 'rejected')}
                          className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-black cursor-pointer"
                        >
                          إيقاف / رفض
                        </button>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* =========================================================================
            ADMIN TAB: SUBSCRIBERS' 15 PERSONAL BOOKMARK SITES (خاص بالمشترك والإدارة فقط)
           ========================================================================= */}
        {isAdmin && activeTab === 'admin_personal_sites' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
              <h1 className="font-black text-xl text-slate-900">
                مراجعة واعتماد مواقع اهتمامات المشتركين (حتى 15 موقعاً لكل مشترك)
              </h1>
              <p className="text-xs text-slate-500 mt-1">
                هذه المواقع خاصة بكل مشترك لحفظ اهتماماته ولا يراها أحد غير المشترك صاحب الحساب والإدارة فقط للموافقة عليها.
              </p>
            </div>

            {allSubscribersWithPersonalSites.length === 0 ? (
              <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center text-xs text-slate-500 font-bold">
                لا توجد مواقع شخصية مضافة من المشتركين حالياً.
              </div>
            ) : (
              <div className="space-y-4">
                {allSubscribersWithPersonalSites.map((sub) => (
                  <div key={sub.id} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                      <div>
                        <h3 className="font-black text-base text-slate-900">{sub.fullName}</h3>
                        <p className="text-xs text-slate-500">{sub.email} • {sub.phone}</p>
                      </div>
                      <span className="bg-indigo-50 text-indigo-800 text-xs font-black px-3 py-1 rounded-full border border-indigo-200">
                        {(sub.personalSites || []).length} / 15 موقع محفوظ
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {(sub.personalSites || []).map((site) => (
                        <div key={site.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <div className="font-black text-xs text-slate-900 truncate">{site.title}</div>
                            <a
                              href={site.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[11px] text-indigo-600 hover:underline truncate block"
                              dir="ltr"
                            >
                              {site.url}
                            </a>
                            <span className="text-[10px] text-slate-500">{site.category || 'عام'}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              const updatedSites = (sub.personalSites || []).map((s) =>
                                s.id === site.id ? { ...s, approvedByAdmin: !s.approvedByAdmin } : s
                              );
                              updateSubscriber({ ...sub, personalSites: updatedSites });
                            }}
                            className={`px-3 py-1.5 rounded-xl text-[10px] font-black shrink-0 cursor-pointer ${
                              site.approvedByAdmin
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                : 'bg-amber-500 text-slate-950'
                            }`}
                          >
                            {site.approvedByAdmin ? 'معتمد ✓' : 'موافقة الإدارة'}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* =========================================================================
            ADMIN TAB: BILLING & COMMISSION CONFIGURATION
           ========================================================================= */}
        {isAdmin && activeTab === 'admin_billing' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
              <h1 className="font-black text-xl text-slate-900 mb-1">نظام العمولات والاشتراكات الشهرية المتقدم</h1>
              <p className="text-xs text-slate-500">تحديد نظام العمولات لكل نشاط (اشتراك شهري ثابت، نسبة مبيعات، رقم ثابت لكل طلب، أو كلاهما).</p>
            </div>

            <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
              <table className="w-full text-right border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold">
                    <th className="py-4 px-5">النشاط التجاري</th>
                    <th className="py-4 px-5">الباقة والتوثيق</th>
                    <th className="py-4 px-5">الاشتراك الشهري</th>
                    <th className="py-4 px-5">النسبة (%) / الثابت (ج.م)</th>
                    <th className="py-4 px-5 text-center">الإجراء</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {businesses.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-50/70">
                      <td className="py-4 px-5 font-bold text-slate-900">{b.name}</td>
                      <td className="py-4 px-5">
                        <span className="bg-indigo-50 text-indigo-800 px-3 py-1 rounded-xl font-bold border border-indigo-200">
                          {b.subscriptionTier === 'advanced' ? 'متقدم' : b.subscriptionTier === 'free' ? 'مجاني' : 'عادي'} •{' '}
                          {b.isVerified ? 'موثق' : 'غير موثق'}
                        </span>
                      </td>
                      <td className="py-4 px-5 font-black text-emerald-700">{b.monthlySubscriptionFee ?? 300} ج.م</td>
                      <td className="py-4 px-5 font-bold text-slate-700">
                        {b.commissionPercentage ?? 1.0}% + {b.commissionFixed ?? 2.0} ج.م
                      </td>
                      <td className="py-4 px-5 text-center">
                        <button
                          onClick={() => {
                            setEditingBiz(b);
                            setAdminBizName(b.name);
                            setAdminBizFunctionalGroup(b.functionalGroupId);
                            setAdminBizCategory(b.category);
                            setAdminBizGov(b.governorate);
                            setAdminBizMarkaz(b.markaz);
                            setAdminBizAddress(b.address);
                            setAdminBizWhatsApp(b.ownerWhatsApp);
                            setAdminBizOwnerSubId(b.ownerSubscriberId || '');
                            setAdminBizIsVerified(b.isVerified);
                            setAdminBizTier(b.subscriptionTier || 'regular');
                            setAdminCommissionType(b.commissionType || 'percentage_plus_fixed');
                            setAdminMonthlySubFee(b.monthlySubscriptionFee || 300);
                            setAdminCommissionPct(b.commissionPercentage || 1.0);
                            setAdminCommissionFixed(b.commissionFixed || 2.0);
                            setIsBizModalOpen(true);
                          }}
                          className="px-3 py-1.5 bg-amber-500 text-slate-950 rounded-xl font-bold cursor-pointer"
                        >
                          تعديل العمولة والاشتراك
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* =========================================================================
            ADMIN TAB: GOOGLE AI STUDIO DEVELOPER ASSISTANT
           ========================================================================= */}
        {isAdmin && activeTab === 'admin_ai_studio' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-md">
                  <Cpu className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-black">مساعد التطوير المباشر عبر Google AI Studio</h2>
                  <p className="text-xs text-purple-200">
                    اكتب أي طلب لتطوير أو تعديل أو إضافة ميزات جديدة للموقع الإنتاجي، وسيقوم نموذج Gemini بتوليد الكود والتوصيات فوريًا.
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={handleRunAiStudioAssist} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">نوع مهمة التطوير</label>
                  <select
                    value={aiTaskType}
                    onChange={(e: any) => setAiTaskType(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold cursor-pointer"
                  >
                    <option value="New Feature">إضافة ميزة برمجية جديدة (New Feature)</option>
                    <option value="Code Enhancement">تطوير وتحسين كود حالي (Code Enhancement)</option>
                    <option value="Database Schema">تطوير هيكل البيانات والحالة (Database & State)</option>
                    <option value="UI & Styling">تطوير التصميم والواجهات (UI & Styling)</option>
                    <option value="Marketing Content">توليد محتوى تسويقي وذكاء اصطناعي (Marketing Content)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-700 mb-1">نموذج الذكاء الاصطناعي (Gemini)</label>
                  <input
                    type="text"
                    disabled
                    value="gemini-2.5-flash (Google AI Studio Production)"
                    className="w-full bg-slate-100 border border-slate-200 rounded-xl p-3 text-xs font-bold text-slate-500 cursor-not-allowed"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 mb-1">تفاصيل طلب التطوير أو التعديل للموقع الإنتاجي</label>
                <textarea
                  rows={4}
                  required
                  placeholder="مثال: أضف نظام تقييم بالنجوم وتعليقات للأنشطة التجارية في الدليل..."
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold"
                />
              </div>

              <button
                type="submit"
                disabled={isAiLoading}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white font-black text-xs py-3.5 rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2 transition-all disabled:opacity-50"
              >
                {isAiLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>جاري المعالجة والتوليد المباشر عبر Google AI Studio...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>تنفيذ وتوليد التطوير الفوري (AI Studio)</span>
                  </>
                )}
              </button>
            </form>

            {aiResult && (
              <div className="bg-slate-900 text-white p-6 rounded-3xl border border-slate-800 shadow-xl space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <span className="font-black text-xs text-amber-400 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>نتيجة التوليد والتطوير من Google AI Studio:</span>
                  </span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(aiResult);
                      setCopiedAi(true);
                      setTimeout(() => setCopiedAi(false), 2000);
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold px-3 py-1.5 rounded-lg cursor-pointer"
                  >
                    {copiedAi ? 'تم النسخ ✓' : 'نسخ النتيجة'}
                  </button>
                </div>
                <pre dir="ltr" className="text-xs font-mono whitespace-pre-wrap text-slate-200 overflow-x-auto bg-slate-950 p-4 rounded-2xl border border-slate-800">
                  {aiResult}
                </pre>
              </div>
            )}
          </div>
        )}
      </main>

      {/* =========================================================================
          MODAL 1: ADMIN BUSINESS ADD/EDIT (VERIFIED OR UNVERIFIED FREE DIRECTORY)
         ========================================================================= */}
      {isBizModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-7 space-y-4 text-right shadow-2xl max-h-[92vh] overflow-y-auto">
            <h3 className="font-black text-base text-slate-900">
              {editingBiz ? 'تعديل النشاط والباقة والمالك ونظام العمولات' : 'إضافة نشاط جديد (موثق أو غير موثق للدليل المجاني)'}
            </h3>

            <form onSubmit={handleAdminSaveBusiness} className="space-y-4">
              {/* Verification Mode Selector */}
              <div className="grid grid-cols-2 gap-2.5 p-2 bg-slate-100 rounded-2xl">
                <button
                  type="button"
                  onClick={() => setAdminBizIsVerified(true)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    adminBizIsVerified ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600'
                  }`}
                >
                  ✓ نشاط موثق من الإدارة (كتالوج كامل)
                </button>
                <button
                  type="button"
                  onClick={() => setAdminBizIsVerified(false)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    !adminBizIsVerified ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-600'
                  }`}
                >
                  📋 نشاط غير موثق (الاسم والموقع والرقم)
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">اسم النشاط *</label>
                  <input
                    type="text"
                    required
                    value={adminBizName}
                    onChange={(e) => setAdminBizName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">القطاع الرئيسي (15 قطاعاً)</label>
                  <select
                    value={adminBizFunctionalGroup}
                    onChange={(e) => {
                      const gId = e.target.value as FunctionalGroupId;
                      setAdminBizFunctionalGroup(gId);
                      setAdminBizLogoUrl(getSectorDefaultLogo(gId));
                      setAdminBizCoverUrl(getSectorDefaultCover(gId));
                      const grp = functionalGroups.find((g) => g.id === gId);
                      if (grp) setAdminBizCategory(grp.shortName || grp.name);
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-bold cursor-pointer"
                  >
                    {functionalGroups.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.icon} {g.shortName || g.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">المحافظة *</label>
                  <input
                    type="text"
                    required
                    value={adminBizGov}
                    onChange={(e) => setAdminBizGov(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">المركز / المدينة *</label>
                  <input
                    type="text"
                    required
                    value={adminBizMarkaz}
                    onChange={(e) => setAdminBizMarkaz(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">رقم الهاتف أو الواتساب *</label>
                  <input
                    type="text"
                    required
                    value={adminBizWhatsApp}
                    onChange={(e) => setAdminBizWhatsApp(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">العنوان التفصيلي</label>
                  <input
                    type="text"
                    value={adminBizAddress}
                    onChange={(e) => setAdminBizAddress(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-bold"
                  />
                </div>
              </div>

              {/* Sector Default Logo & Cover Preview + Selectable Library in Admin Business Modal */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-black text-slate-800">
                    الشعار (Logo) والغلاف (Cover) الافتراضيان للمجال (أو اختر من المكتبة):
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setAdminBizLogoUrl(getSectorDefaultLogo(adminBizFunctionalGroup));
                      setAdminBizCoverUrl(getSectorDefaultCover(adminBizFunctionalGroup));
                    }}
                    className="text-[10px] font-black bg-amber-100 hover:bg-amber-200 text-amber-950 px-2.5 py-1 rounded-lg cursor-pointer"
                  >
                    استعادة افتراضي المجال ⭐
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="flex items-center gap-2.5 bg-white p-2 rounded-xl border border-slate-200">
                    <img
                      src={resolveBusinessLogo({
                        logoUrl: adminBizLogoUrl,
                        functionalGroupId: adminBizFunctionalGroup,
                      })}
                      alt="Logo"
                      className="w-11 h-11 rounded-lg object-cover border border-slate-200 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-black text-slate-800">شعار النشاط</div>
                      <button
                        type="button"
                        onClick={() => {
                          setImageLibTarget('admin_logo');
                          setIsImageLibOpen(true);
                        }}
                        className="text-[10px] font-black text-indigo-600 hover:underline cursor-pointer"
                      >
                        اختيار شعار من المكتبة ←
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2.5 bg-white p-2 rounded-xl border border-slate-200">
                    <img
                      src={resolveBusinessCover({
                        coverUrl: adminBizCoverUrl,
                        functionalGroupId: adminBizFunctionalGroup,
                      })}
                      alt="Cover"
                      className="w-16 h-11 rounded-lg object-cover border border-slate-200 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-black text-slate-800">غلاف النشاط (Cover)</div>
                      <button
                        type="button"
                        onClick={() => {
                          setImageLibTarget('admin_cover');
                          setIsImageLibOpen(true);
                        }}
                        className="text-[10px] font-black text-indigo-600 hover:underline cursor-pointer"
                      >
                        اختيار غلاف من المكتبة ←
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Subscription Tier & Allowed Businesses Count */}
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-3">
                <label className="block text-xs font-black text-emerald-950">
                  تحديد باقة الاشتراك وصلاحيات النشاط وعدد الأنشطة المتاحة:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">نظام الاشتراك</label>
                    <select
                      value={adminBizTier}
                      onChange={(e) => setAdminBizTier(e.target.value as SubscriptionPlanTier)}
                      className="w-full bg-white border border-emerald-300 rounded-xl p-2 text-xs font-bold cursor-pointer"
                    >
                      <option value="free">مجاني (Free)</option>
                      <option value="regular">عادي قياسي (Regular)</option>
                      <option value="advanced">متقدم شامل (Advanced)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">عدد النشاطات المتاحة للمشترك</label>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={adminBizMaxAllowedBusinesses}
                      onChange={(e) => setAdminBizMaxAllowedBusinesses(Number(e.target.value))}
                      className="w-full bg-white border border-emerald-300 rounded-xl p-2 text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">حد الائتمان (ج.م)</label>
                    <input
                      type="number"
                      min={0}
                      value={adminBizCreditLimit}
                      onChange={(e) => setAdminBizCreditLimit(Number(e.target.value))}
                      className="w-full bg-white border border-emerald-300 rounded-xl p-2 text-xs font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Owner Assignment */}
              <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 space-y-1.5">
                <label className="block text-xs font-black text-amber-950">تعيين مالك النشاط (مشترك مسجل):</label>
                <select
                  value={adminBizOwnerSubId}
                  onChange={(e) => setAdminBizOwnerSubId(e.target.value)}
                  className="w-full bg-white border border-amber-300 rounded-xl p-2.5 text-xs font-bold text-slate-900 cursor-pointer"
                >
                  <option value="">-- بدون مالك مسند حالياً (دليل عام) --</option>
                  {subscribers.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.fullName} ({sub.email} - {sub.phone})
                    </option>
                  ))}
                </select>
              </div>

              {/* Commission & Subscription Configuration */}
              <div className="p-3.5 bg-indigo-50 rounded-2xl border border-indigo-200 space-y-2.5">
                <label className="block text-xs font-black text-indigo-950">نظام التحصيل والعمولات والاشتراك:</label>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">الاشتراك الشهري (ج.م)</label>
                    <input
                      type="number"
                      min={0}
                      value={adminMonthlySubFee}
                      onChange={(e) => setAdminMonthlySubFee(Number(e.target.value))}
                      className="w-full bg-white border border-indigo-200 rounded-xl p-2 text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">نسبة العمولة (%)</label>
                    <input
                      type="number"
                      step="0.1"
                      min={0}
                      value={adminCommissionPct}
                      onChange={(e) => setAdminCommissionPct(Number(e.target.value))}
                      className="w-full bg-white border border-indigo-200 rounded-xl p-2 text-xs font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">ثابت للطلب (ج.م)</label>
                    <input
                      type="number"
                      step="0.5"
                      min={0}
                      value={adminCommissionFixed}
                      onChange={(e) => setAdminCommissionFixed(Number(e.target.value))}
                      className="w-full bg-white border border-indigo-200 rounded-xl p-2 text-xs font-bold"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsBizModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black cursor-pointer shadow-md"
                >
                  حفظ واعتماد النشاط
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 2: REVIEW & APPROVE SUBSCRIPTION REQUEST (تحديد باقة وصلاحيات طلب الاشتراك)
         ========================================================================= */}
      {reviewingSubReq && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 text-right shadow-2xl">
            <h3 className="font-black text-base text-slate-900">
              اعتماد وتحديد اشتراك وصلاحيات طلب: {reviewingSubReq.businessName}
            </h3>
            <p className="text-xs text-slate-500">
              حدد باقة المشترك (مجاني / عادي / متقدم)، العمولات، وعدد النشاطات المتاحة له ثم اضغط تفعيل.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-black text-slate-700 mb-1">نظام الاشتراك والصلاحيات</label>
                <select
                  value={reqTier}
                  onChange={(e) => {
                    const t = e.target.value as SubscriptionPlanTier;
                    setReqTier(t);
                    const cfg = getDefaultTierConfiguration(t);
                    setReqAllowedBizCount(cfg.maxAllowedBusinesses);
                    setReqMonthlyFee(cfg.monthlySubscriptionFee);
                    setReqCommPct(cfg.commissionPercentage);
                    setReqCommFixed(cfg.commissionFixed);
                  }}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold cursor-pointer"
                >
                  <option value="free">مجاني (Free) — كتالوج أساسي أو دليل مجاني</option>
                  <option value="regular">عادي (Regular) — متجر موثق + واتساب + تقارير مبيعات</option>
                  <option value="advanced">متقدم (Advanced) — جميع الصلاحيات + إعلانات + ائتمان موسع</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-black text-slate-700 mb-1">عدد الأنشطة المتاحة للمشترك</label>
                  <input
                    type="number"
                    min={1}
                    max={25}
                    value={reqAllowedBizCount}
                    onChange={(e) => setReqAllowedBizCount(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold"
                  />
                </div>
                <div>
                  <label className="block font-black text-slate-700 mb-1">حالة التوثيق عند التفعيل</label>
                  <select
                    value={reqVerifyNow ? 'verified' : 'unverified'}
                    onChange={(e) => setReqVerifyNow(e.target.value === 'verified')}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold cursor-pointer"
                  >
                    <option value="verified">تفعيل كنشاط موثق رسمياً</option>
                    <option value="unverified">إدراج في الدليل المجاني (غير موثق لحين التوثيق)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">الاشتراك الشهري</label>
                  <input
                    type="number"
                    value={reqMonthlyFee}
                    onChange={(e) => setReqMonthlyFee(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">النسبة (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={reqCommPct}
                    onChange={(e) => setReqCommPct(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">الثابت (ج.م)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={reqCommFixed}
                    onChange={(e) => setReqCommFixed(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 font-bold"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setReviewingSubReq(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => {
                  const cfg = getDefaultTierConfiguration(reqTier);
                  const updated: SubscriptionRequest = {
                    ...reviewingSubReq,
                    status: 'approved',
                    assignedTier: reqTier,
                    assignedMonthlyFee: reqMonthlyFee,
                    assignedCommissionPercentage: reqCommPct,
                    assignedCommissionFixed: reqCommFixed,
                    assignedMaxAllowedBusinesses: reqAllowedBizCount,
                    assignedPermissions: cfg.permissions,
                    isUnverifiedFreeDirectory: !reqVerifyNow,
                  };
                  updateSubscriptionRequest(updated);
                  approveSubscriptionRequestToBusiness(updated, reqVerifyNow);
                  setReviewingSubReq(null);
                }}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black cursor-pointer shadow-md"
              >
                اعتماد الطلب وإدراج النشاط بالدليل فوراً
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Product Add/Edit Modal */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 text-right shadow-2xl">
            <h3 className="font-black text-base text-slate-900">
              {editingProduct ? 'تعديل المنتج أو الخدمة' : 'إضافة منتج أو خدمة جديدة'}
            </h3>
            {formError && <div className="bg-rose-50 text-rose-700 p-3 rounded-xl text-xs font-bold">{formError}</div>}
            <form onSubmit={handleProductSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">الاسم *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">السعر (ج.م) *</label>
                  <input
                    type="number"
                    required
                    value={formPrice}
                    onChange={(e) => setFormPrice(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">النوع</label>
                  <select
                    value={formType}
                    onChange={(e: any) => setFormType(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold cursor-pointer"
                  >
                    <option value="product">منتج</option>
                    <option value="service">خدمة / حجز</option>
                  </select>
                </div>
              </div>
              {/* Product Image Selection (Sector Default + Selectable Presets + Image Library Modal) */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={resolveProductImage(
                        { imageUrl: formImageUrl },
                        currentBusiness?.functionalGroupId
                      )}
                      alt="معاينة المنتج"
                      className="w-14 h-14 rounded-xl object-cover border-2 border-emerald-500 bg-white shrink-0"
                    />
                    <div>
                      <label className="block font-black text-slate-800">صورة المنتج أو الخدمة</label>
                      <p className="text-[10px] text-slate-500">
                        صورة افتراضية ثابتة للمجال تلقائياً أو اختر من الصور الجاهزة
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setImageLibTarget('product');
                        setIsImageLibOpen(true);
                      }}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[10px] px-2.5 py-1.5 rounded-xl cursor-pointer flex items-center gap-1"
                    >
                      <ImageIcon className="w-3 h-3" />
                      <span>مكتبة الصور</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setFormImageUrl(
                          getSectorDefaultProductImage(currentBusiness?.functionalGroupId)
                        )
                      }
                      className="bg-amber-100 hover:bg-amber-200 text-amber-950 font-black text-[10px] px-2 py-1 rounded-xl cursor-pointer"
                    >
                      افتراضي المجال ⭐
                    </button>
                  </div>
                </div>

                {/* Quick Selectable Product Presets */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  {getSelectableImagesForSector(
                    currentBusiness?.functionalGroupId || 'all',
                    'product'
                  )
                    .concat(getSelectableImagesForSector('all', 'product').slice(0, 6))
                    .filter((v, i, a) => a.findIndex((t) => t.url === v.url) === i)
                    .slice(0, 8)
                    .map((preset) => (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => setFormImageUrl(preset.url)}
                        title={preset.title}
                        className={`w-11 h-11 rounded-xl overflow-hidden border-2 shrink-0 cursor-pointer transition-all ${
                          formImageUrl === preset.url
                            ? 'border-emerald-600 ring-2 ring-emerald-500/30 scale-105'
                            : 'border-slate-200 hover:border-slate-400 opacity-85 hover:opacity-100'
                        }`}
                      >
                        <img src={preset.url} alt={preset.title} className="w-full h-full object-cover" />
                      </button>
                    ))}
                </div>

                <input
                  type="text"
                  value={formImageUrl}
                  onChange={(e) => setFormImageUrl(e.target.value)}
                  placeholder="رابط الصورة (أو اتركه فارغاً للصورة الافتراضية للمجال)..."
                  className="w-full bg-white border border-slate-200 rounded-xl p-2 font-bold text-[11px]"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">الوصف</label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white rounded-xl font-black cursor-pointer"
                >
                  حفظ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Employee Modal */}
      {isEmployeeModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 text-right shadow-2xl">
            <h3 className="font-black text-base text-slate-900">إضافة موظف جديد</h3>
            <form onSubmit={handleAddEmployee} className="space-y-3 text-xs">
              <input
                type="text"
                required
                placeholder="اسم الموظف"
                value={empName}
                onChange={(e) => setEmpName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold"
              />
              <input
                type="text"
                required
                placeholder="الوظيفة / الدور"
                value={empRole}
                onChange={(e) => setEmpRole(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold"
              />
              <input
                type="text"
                required
                placeholder="رقم الهاتف"
                value={empPhone}
                onChange={(e) => setEmpPhone(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold"
              />
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEmployeeModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button type="submit" className="px-5 py-2 bg-emerald-600 text-white rounded-xl font-black cursor-pointer">
                  إضافة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QR Code & Image Library Modals */}
      {currentBusiness && (
        <QRCodeModal business={currentBusiness} isOpen={isQrModalOpen} onClose={() => setIsQrModalOpen(false)} />
      )}
      <ImageLibraryModal
        isOpen={isImageLibOpen}
        onClose={() => setIsImageLibOpen(false)}
        defaultSectorId={
          imageLibTarget === 'admin_logo' || imageLibTarget === 'admin_cover'
            ? adminBizFunctionalGroup
            : currentBusiness?.functionalGroupId || 'all'
        }
        defaultAssetType={
          imageLibTarget === 'logo' || imageLibTarget === 'admin_logo'
            ? 'logo'
            : imageLibTarget === 'cover' || imageLibTarget === 'admin_cover'
            ? 'cover'
            : imageLibTarget === 'product'
            ? 'product'
            : 'all'
        }
        onSelectImage={(url) => {
          if (imageLibTarget === 'logo') setBizLogoUrl(url);
          if (imageLibTarget === 'cover') setBizCoverUrl(url);
          if (imageLibTarget === 'product') setFormImageUrl(url);
          if (imageLibTarget === 'admin_logo') setAdminBizLogoUrl(url);
          if (imageLibTarget === 'admin_cover') setAdminBizCoverUrl(url);
          setIsImageLibOpen(false);
        }}
      />
    </div>
  );
};
