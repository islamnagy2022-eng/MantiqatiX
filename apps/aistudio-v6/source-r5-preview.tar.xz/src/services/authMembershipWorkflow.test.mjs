import test from 'node:test';
import assert from 'node:assert/strict';
import { fetchAuthenticatedMembershipChoices } from './authMembershipWorkflow.ts';

const config = { supabaseUrl: 'https://example-project.supabase.co', publishableKey: 'sb_publishable_test_key' };
const response = (body, status = 200) => ({ ok: status >= 200 && status < 300, status, json: async () => body });

test('combines direct memberships with tenant OWNER businesses returned by the server', async () => {
  const calls = [];
  const choices = await fetchAuthenticatedMembershipChoices(config, 'access-token', 'user-1', {
    fetchImpl: async (url, init) => {
      calls.push({ url, init });
      if (url.endsWith('/functions/v1/api/api/v1/me')) {
        return response({ id: 'user-1', memberships: [
          { id: 'business-owner-membership', tenant_id: 'tenant-1', business_id: 'business-direct', role: 'BUSINESS_OWNER', status: 'ACTIVE', permissions: {} },
          { id: 'tenant-owner-membership', tenant_id: 'tenant-1', business_id: null, branch_id: null, role: 'OWNER', status: 'ACTIVE', permissions: { catalog: true } },
        ] });
      }
      return response({ businesses: [
        { id: 'business-a', tenantId: 'tenant-1', name: 'النشاط أ', status: 'ACTIVE' },
        { id: 'business-b', tenantId: 'tenant-1', name: 'النشاط ب', status: 'ACTIVE' },
      ] });
    },
  });
  assert.equal(calls.length, 2);
  assert.deepEqual(choices.candidates.map((item) => item.selectionKey), [
    'business-owner-membership',
    'owner:tenant-owner-membership:business-a',
    'owner:tenant-owner-membership:business-b',
  ]);
  assert.deepEqual(choices.candidates.slice(1).map((item) => item.businessName), ['النشاط أ', 'النشاط ب']);
  assert.equal(choices.unresolvedBusinessSelectionCount, 0);
});

test('keeps unresolved tenant OWNER when the server returns no active business', async () => {
  const choices = await fetchAuthenticatedMembershipChoices(config, 'access-token', 'user-1', {
    fetchImpl: async (url) => url.endsWith('/functions/v1/api/api/v1/me')
      ? response({ id: 'user-1', memberships: [{ id: 'owner', tenant_id: 'tenant-1', role: 'OWNER', status: 'ACTIVE' }] })
      : response({ businesses: [] }),
  });
  assert.equal(choices.candidates.length, 0);
  assert.equal(choices.unresolvedBusinessSelectionCount, 1);
});
