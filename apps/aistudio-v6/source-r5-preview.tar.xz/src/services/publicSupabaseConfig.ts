export interface PublicSupabaseConfig {
  supabaseUrl: string;
  publishableKey: string;
}

type PublicRuntimeConfig = {
  supabaseUrl?: unknown;
  supabaseKey?: unknown;
};

export function isPublicSupabaseKey(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  const key = value.trim();
  if (/^sb_publishable_[A-Za-z0-9_-]+$/.test(key)) return true;
  if (!/^eyJ[A-Za-z0-9._-]+$/.test(key)) return false;

  try {
    const payloadPart = key.split('.')[1];
    const base64 = payloadPart.replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64.padEnd(Math.ceil(base64.length / 4) * 4, '=');
    const payload = JSON.parse(atob(padded)) as { role?: unknown };
    return payload.role === 'anon';
  } catch {
    return false;
  }
}

export function validatePublicSupabaseConfig(
  supabaseUrlValue: unknown,
  publishableKeyValue: unknown,
): PublicSupabaseConfig | null {
  if (typeof supabaseUrlValue !== 'string' || typeof publishableKeyValue !== 'string') return null;
  const supabaseUrl = supabaseUrlValue.trim().replace(/\/+$/, '');
  const publishableKey = publishableKeyValue.trim();
  if (!isPublicSupabaseKey(publishableKey)) return null;

  try {
    const parsed = new URL(supabaseUrl);
    if (parsed.protocol !== 'https:' || !parsed.hostname.endsWith('.supabase.co')) return null;
  } catch {
    return null;
  }

  return { supabaseUrl, publishableKey };
}

export function getPublicSupabaseConfig(): PublicSupabaseConfig | null {
  const env = (import.meta as ImportMeta & {
    env?: Record<string, string | undefined>;
  }).env ?? {};
  const runtime = typeof window !== 'undefined'
    ? (window as Window & { MNTY_CONFIG?: PublicRuntimeConfig }).MNTY_CONFIG
    : undefined;

  return validatePublicSupabaseConfig(
    env.VITE_SUPABASE_URL || runtime?.supabaseUrl,
    env.VITE_SUPABASE_PUBLISHABLE_KEY || runtime?.supabaseKey,
  );
}
