import test from 'node:test';
import assert from 'node:assert/strict';
import { fetchPublicCatalogDirectory, resolvePublicFunctionalGroup } from './publicCatalogDirectory.ts';

const fixture = {
  accessMode: 'PUBLIC_DIRECTORY_READ_ONLY',
  businesses: [{
    id: 'a6e25fb4-8b58-4bb9-961f-938d6f0a0c11',
    name: 'صيدلية النور',
    slug: 'alnoor-pharmacy',
    category: 'pharmacy',
    profile: {
      bio: 'صيدلية لخدمة المنطقة',
      governorate: 'المنوفية',
      markaz: 'بركة السبع',
      village: 'بركة السبع',
      logoUrl: 'https://cdn.example.test/logo.png',
      coverUrl: 'https://cdn.example.test/cover.png',
      whatsappPhone: '201001234567',
      medical_specialty_id: 'spec_internal',
      google_maps_url: 'https://maps.example.test/place/1',
    },
    provider: { verified: true, description: 'خدمات دوائية' },
    branches: [{ id: 'branch-1', phone: '201001234567', address: 'شارع المحطة' }],
    selectedBranchId: 'branch-1',
    operationallyAvailable: true,
    items: [
      { id: 'item-1', item_type: 'PRODUCT', name_ar: 'فيتامين', description: 'وصف', metadata: { catalog_public: { category: 'مكملات', is_available: true, show_price: true, image_url: 'https://cdn.example.test/item.png' } } },
      { id: 'item-2', item_type: 'SERVICE', name_ar: 'استشارة', metadata: { catalog_public: { is_available: true, show_price: false } } },
      { id: 'item-3', item_type: 'PRODUCT', name_ar: 'منتج غير متاح', metadata: { catalog_public: { is_available: false, show_price: true } } },
    ],
    prices: [
      { catalog_item_id: 'item-1', branch_id: 'branch-1', unit_price: 125, currency: 'EGP' },
      { catalog_item_id: 'item-2', branch_id: 'branch-1', unit_price: 50, currency: 'EGP' },
      { catalog_item_id: 'item-3', branch_id: 'branch-1', unit_price: 10, currency: 'EGP' },
    ],
  }],
};

function makeResponse(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
}

test('resolves public category labels to the V6 activity taxonomy', () => {
  assert.equal(resolvePublicFunctionalGroup('صيدلية'), 'healthcare');
  assert.equal(resolvePublicFunctionalGroup('مطاعم ومقاهي'), 'dining');
  assert.equal(resolvePublicFunctionalGroup('أعمال التشطيب والصيانة'), 'crafts_maintenance');
});

test('loads and maps only public businesses and priced, available catalog items', async () => {
  let requestedUrl = '';
  let requestedHeaders;
  const result = await fetchPublicCatalogDirectory(
    { supabaseUrl: 'https://project.example.test/', publishableKey: 'sb_publishable_test' },
    { fetchImpl: async (url, init) => { requestedUrl = String(url); requestedHeaders = init.headers; return makeResponse(fixture); } },
  );

  assert.equal(requestedUrl, 'https://project.example.test/functions/v1/public-catalog-directory');
  assert.equal(requestedHeaders.apikey, 'sb_publishable_test');
  assert.equal(result.businesses.length, 1);
  assert.equal(result.businesses[0].name, 'صيدلية النور');
  assert.equal(result.businesses[0].functionalGroupId, 'healthcare');
  assert.equal(result.businesses[0].isVerified, true);
  assert.equal(result.businesses[0].paymentStatus, 'pending');
  assert.equal(result.businesses[0].paymobConfig.enabled, false);
  assert.equal(result.products.length, 1);
  assert.equal(result.products[0].name, 'فيتامين');
  assert.equal(result.products[0].price, 125);
  assert.equal(result.products[0].type, 'product');
});

test('rejects insecure non-local Supabase URLs', async () => {
  await assert.rejects(
    () => fetchPublicCatalogDirectory({ supabaseUrl: 'http://example.test', publishableKey: 'key' }),
    /MUST_USE_HTTPS/,
  );
});

test('surfaces HTTP failures without pretending the directory is empty', async () => {
  await assert.rejects(
    () => fetchPublicCatalogDirectory(
      { supabaseUrl: 'https://project.example.test', publishableKey: 'key' },
      { fetchImpl: async () => makeResponse({ error: 'denied' }, 403) },
    ),
    /HTTP_403/,
  );
});
