import type { Business, FunctionalGroupId, Product } from '../types';
import { getPublicSupabaseConfig } from './publicSupabaseConfig';

export interface PublicCatalogDirectoryConfig {
  supabaseUrl: string;
  publishableKey: string;
}

export interface PublicCatalogDirectoryData {
  businesses: Business[];
  products: Product[];
}

interface PublicCatalogDirectoryResponse {
  businesses?: unknown;
  accessMode?: string;
  error?: string;
}

const asRecord = (value: unknown): Record<string, unknown> =>
  value && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};

const cleanText = (value: unknown, max = 1500): string =>
  typeof value === 'string' ? value.trim().slice(0, max) : '';

const safeUrl = (value: unknown): string => {
  const raw = cleanText(value, 1500);
  if (!raw) return '';
  try {
    const parsed = new URL(raw);
    return parsed.protocol === 'https:' ? parsed.toString() : '';
  } catch {
    return '';
  }
};

export function resolvePublicFunctionalGroup(category: string): FunctionalGroupId {
  const value = category.toLocaleLowerCase();
  if (/مطعم|مطاعم|مقهى|مقاهي|مأكول|قهوة|كافيه|مخبز|حلويات|food|restaurant|cafe|coffee|bakery/.test(value)) return 'dining';
  if (/صيدل|طبي|عياد|مستشفى|معمل|تحاليل|health|medical|pharmacy|clinic|hospital|laborator|lab/.test(value)) return 'healthcare';
  if (/صيان|تشطيب|ديكور|سباك|نجار|حداد|maintenance|repair|plumb|carpenter|construction/.test(value)) return 'crafts_maintenance';
  if (/عقار|عقارات|real estate|property/.test(value)) return 'real_estate';
  if (/تعليم|تدريب|مدرس|education|training|school/.test(value)) return 'education_training';
  if (/سيار|نقل|شحن|توصيل|transport|logistic|auto|vehicle/.test(value)) return 'transport_logistics';
  if (/برمج|تكنولوجيا|تقنية|رقمي|software|technology|digital|it /.test(value)) return 'technology_software';
  if (/سفر|سياح|فندق|travel|tourism|hotel/.test(value)) return 'tourism_hotels';
  if (/رياض|لياقة|جيم|fitness|gym|sport/.test(value)) return 'sports_fitness';
  if (/زراع|مواش|أعلاف|agriculture|livestock|farm/.test(value)) return 'agriculture_livestock';
  if (/قانون|محام|محاسب|تمويل|مال|legal|finance|account/.test(value)) return 'legal_financial';
  return 'retail';
}

function mapPublicBusiness(rawValue: unknown): Business | null {
  const raw = asRecord(rawValue);
  const profile = asRecord(raw.profile);
  const provider = asRecord(raw.provider);
  const branches = Array.isArray(raw.branches) ? raw.branches.map(asRecord) : [];
  const selectedBranchId = cleanText(raw.selectedBranchId, 100);
  const branch = branches.find((item) => cleanText(item.id, 100) === selectedBranchId) ?? branches[0] ?? {};
  const id = cleanText(raw.id, 100);
  const name = cleanText(raw.name, 180);
  if (!id || !name) return null;

  const category = cleanText(raw.category || profile.category || provider.kind, 120) || 'نشاط تجاري';
  const medicalKindRaw = cleanText(profile.medicalType || profile.medical_type || provider.medicalType || provider.kind || category, 80).toLowerCase();
  const medicalType = (
    /صيدل|pharmacy/.test(medicalKindRaw) ? 'pharmacy' :
    /عياد|clinic/.test(medicalKindRaw) ? 'clinic' :
    /مستشفى|hospital/.test(medicalKindRaw) ? 'hospital' :
    /معمل|تحاليل|laborator|\blab\b/.test(medicalKindRaw) ? 'lab' :
    /أشعة|radiolog/.test(medicalKindRaw) ? 'radiology' :
    /طبيب|دكتور|doctor/.test(medicalKindRaw) ? 'doctor' : undefined
  ) as Business['medicalType'];
  const medicalSpecialtyId = cleanText(profile.medicalSpecialtyId || profile.medical_specialty_id || raw.medicalSpecialtyId, 100) || undefined;
  const isMedical = Boolean(medicalType || /طب|صيدل|عياد|مستشفى|معمل|تحاليل|أشعة|health|medical|doctor|pharmacy|clinic|hospital|laborator|radiolog/i.test(`${category} ${medicalKindRaw}`));
  const phone = cleanText(branch.phone || raw.contactPhone, 40);
  const whatsapp = cleanText(profile.whatsappPhone || raw.contactPhone, 40);
  const verified = provider.verified === true;
  const operationallyAvailable = raw.operationallyAvailable !== false;
  const socialLinks = Object.assign([], {
    facebook: cleanText(profile.facebookUrl, 500) || undefined,
    instagram: cleanText(profile.instagramUrl, 500) || undefined,
    website: cleanText(profile.websiteUrl, 500) || undefined,
  }) as NonNullable<Business['socialLinks']>;

  return {
    id,
    name,
    slug: cleanText(raw.slug, 180) || id,
    category,
    functionalGroupId: resolvePublicFunctionalGroup(category),
    isMedical,
    medicalType,
    medicalSpecialtyId,
    logoUrl: safeUrl(profile.logoUrl),
    coverUrl: safeUrl(profile.coverUrl),
    bio: cleanText(profile.bio || provider.description, 1500),
    ownerWhatsApp: whatsapp,
    phone,
    address: cleanText(branch.address || profile.address, 500),
    country: 'مصر',
    countryCode: 'EG',
    governorate: cleanText(profile.governorate, 100),
    markaz: cleanText(profile.markaz, 100),
    village: cleanText(profile.village, 100),
    googleMapsUrl: safeUrl(profile.google_maps_url),
    workingHours: cleanText(profile.workingHours, 180),
    verificationStatus: verified ? 'verified' : 'unverified',
    isVerified: verified,
    maxProductsLimit: 150,
    createdAt: '',
    registrationDate: '',
    paymentDueDay: 1,
    paymentDueDate: '',
    commissionPerOrder: 0,
    totalOrdersCount: 0,
    paymentStatus: 'pending',
    overdueDaysCount: 0,
    isFrozen: !operationallyAvailable,
    paymentConfirmedByAdmin: false,
    paymobConfig: {
      enabled: false,
      feeType: 'percentage',
      feePercentage: 0,
      feeFixed: 0,
      acceptedChannels: [],
      merchantApiKey: '',
      integrationIdCard: '',
      integrationIdWallet: '',
      iframeId: '',
    },
    socialLinks,
  };
}

function mapPublicProducts(rawValue: unknown, businessId: string): Product[] {
  const business = asRecord(rawValue);
  const items = Array.isArray(business.items) ? business.items.map(asRecord) : [];
  const prices = Array.isArray(business.prices) ? business.prices.map(asRecord) : [];
  const defaultBranchId = cleanText(business.selectedBranchId, 100);

  return items.flatMap((item): Product[] => {
    const itemId = cleanText(item.id, 100);
    const metadata = asRecord(item.metadata);
    const publicMetadata = asRecord(metadata.catalog_public);
    if (!itemId || publicMetadata.is_available === false || publicMetadata.show_price === false) return [];

    const matchingPrices = prices.filter((price) => cleanText(price.catalog_item_id, 100) === itemId);
    const selectedPrice = matchingPrices.find((price) => cleanText(price.branch_id, 100) === defaultBranchId)
      ?? matchingPrices.find((price) => !cleanText(price.branch_id, 100));
    const numericPrice = Number(selectedPrice?.unit_price);
    // Quote-only and unpriced entries are intentionally excluded from the priced storefront model.
    if (!selectedPrice || !Number.isFinite(numericPrice) || numericPrice < 0) return [];

    const itemType = cleanText(item.item_type, 30).toUpperCase();
    const productType: Product['type'] = itemType === 'SERVICE' ? 'service' : 'product';
    const image = safeUrl(publicMetadata.image_url || metadata.image_url);
    const comparePrice = Number(publicMetadata.compare_price);
    return [{
      id: itemId,
      businessId,
      name: cleanText(item.name_ar || item.name_en, 180),
      category: cleanText(publicMetadata.category, 100) || (itemType === 'SERVICE' ? 'خدمات' : 'منتجات'),
      type: productType,
      price: numericPrice,
      comparePrice: Number.isFinite(comparePrice) && comparePrice >= 0 ? comparePrice : undefined,
      description: cleanText(item.description, 1000),
      imageUrl: image,
      isAvailable: true,
      unit: cleanText(publicMetadata.unit, 40) || undefined,
    }];
  });
}

export function getPublicCatalogDirectoryConfig(): PublicCatalogDirectoryConfig | null {
  return getPublicSupabaseConfig();
}

export async function fetchPublicCatalogDirectory(
  config: PublicCatalogDirectoryConfig,
  options: { signal?: AbortSignal; fetchImpl?: typeof fetch } = {},
): Promise<PublicCatalogDirectoryData> {
  const base = new URL(config.supabaseUrl);
  if (base.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(base.hostname)) {
    throw new Error('SUPABASE_URL_MUST_USE_HTTPS');
  }
  if (!config.publishableKey.trim()) throw new Error('SUPABASE_PUBLISHABLE_KEY_REQUIRED');

  const endpoint = `${base.origin}/functions/v1/public-catalog-directory`;
  const fetchImpl = options.fetchImpl ?? fetch;
  const response = await fetchImpl(endpoint, {
    method: 'GET',
    headers: {
      apikey: config.publishableKey,
      Accept: 'application/json',
    },
    cache: 'no-store',
    signal: options.signal,
  });
  if (!response.ok) throw new Error(`PUBLIC_DIRECTORY_HTTP_${response.status}`);

  const payload = await response.json() as PublicCatalogDirectoryResponse;
  if (!Array.isArray(payload.businesses)) {
    throw new Error(cleanText(payload.error, 100) || 'PUBLIC_DIRECTORY_INVALID_RESPONSE');
  }

  const businesses = payload.businesses
    .map(mapPublicBusiness)
    .filter((business): business is Business => business !== null);
  const products = payload.businesses.flatMap((business) => {
    const raw = asRecord(business);
    const businessId = cleanText(raw.id, 100);
    return businessId ? mapPublicProducts(raw, businessId) : [];
  });
  return { businesses, products };
}
