import {
  toV6TenantOwnerBusinessCandidate,
  type ActiveMembershipCandidate,
  type MembershipResolution,
} from './authMembership.ts';
import {
  fetchAuthenticatedMemberships,
  fetchTenantOwnerBusinesses,
  type AuthMembershipApiConfig,
  type AuthMembershipApiOptions,
} from './authMembershipApi.ts';

export interface AuthenticatedMembershipChoices {
  userId: string;
  candidates: ActiveMembershipCandidate[];
  unresolvedBusinessSelectionCount: number;
  ignoredMembershipCount: number;
}

/**
 * Resolve all role choices against existing server contracts. Ordinary active
 * memberships come from /api/v1/me. Tenant-level OWNER memberships are expanded
 * only through catalog-admin BUSINESS_LIST, which independently checks the
 * caller's actual active OWNER membership before returning active tenant rows.
 */
export async function fetchAuthenticatedMembershipChoices(
  config: AuthMembershipApiConfig,
  accessToken: string,
  expectedUserId: string,
  options: AuthMembershipApiOptions = {},
): Promise<AuthenticatedMembershipChoices> {
  const resolution: MembershipResolution = await fetchAuthenticatedMemberships(
    config,
    accessToken,
    expectedUserId,
    options,
  );

  const ownerBusinessResults = await Promise.all(resolution.requiresBusinessSelection.map(async (requirement) => {
    const businesses = await fetchTenantOwnerBusinesses(config, accessToken, requirement.tenantId, options);
    return businesses.map((business) => toV6TenantOwnerBusinessCandidate(requirement, business));
  }));

  const expandedCandidates = ownerBusinessResults.flat();
  return {
    userId: resolution.userId,
    candidates: [...resolution.candidates, ...expandedCandidates],
    unresolvedBusinessSelectionCount: Math.max(0, resolution.requiresBusinessSelection.length - ownerBusinessResults.filter((rows) => rows.length > 0).length),
    ignoredMembershipCount: resolution.ignoredMembershipCount,
  };
}
