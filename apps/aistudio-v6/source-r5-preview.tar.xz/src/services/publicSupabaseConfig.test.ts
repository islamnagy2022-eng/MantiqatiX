import { test } from 'node:test';
import assert from 'node:assert/strict';
import { getPublicSupabaseConfig, isPublicSupabaseKey, validatePublicSupabaseConfig } from './publicSupabaseConfig';

const token = (role: string) => `eyJhbGciOiJIUzI1NiJ9.${Buffer.from(JSON.stringify({ role })).toString('base64url')}.signature`;

test('accepts only public Supabase publishable or anon keys', () => {
  assert.equal(isPublicSupabaseKey('sb_publishable_example_123'), true);
  assert.equal(isPublicSupabaseKey(token('anon')), true);
  assert.equal(isPublicSupabaseKey(token('service_role')), false);
  assert.equal(isPublicSupabaseKey('sb_secret_example'), false);
  assert.equal(isPublicSupabaseKey('not-a-key'), false);
});

test('validates HTTPS Supabase URL and public key together', () => {
  assert.deepEqual(validatePublicSupabaseConfig('https://example.supabase.co/', 'sb_publishable_example'), {
    supabaseUrl: 'https://example.supabase.co',
    publishableKey: 'sb_publishable_example',
  });
  assert.equal(validatePublicSupabaseConfig('http://example.supabase.co', 'sb_publishable_example'), null);
  assert.equal(validatePublicSupabaseConfig('https://example.com', 'sb_publishable_example'), null);
  assert.equal(validatePublicSupabaseConfig('https://example.supabase.co', token('service_role')), null);
});

test('reads the shared public browser config when build-time env is absent', () => {
  const previousWindow = (globalThis as typeof globalThis & { window?: unknown }).window;
  Object.defineProperty(globalThis, 'window', {
    configurable: true,
    value: { MNTY_CONFIG: { supabaseUrl: 'https://runtime.supabase.co', supabaseKey: 'sb_publishable_runtime' } },
  });
  try {
    assert.deepEqual(getPublicSupabaseConfig(), {
      supabaseUrl: 'https://runtime.supabase.co',
      publishableKey: 'sb_publishable_runtime',
    });
  } finally {
    if (previousWindow === undefined) delete (globalThis as typeof globalThis & { window?: unknown }).window;
    else Object.defineProperty(globalThis, 'window', { configurable: true, value: previousWindow });
  }
});
