import type { AuthMembershipApiConfig } from './authMembershipApi.ts';

export interface SupabaseAuthUser {
  id: string;
  email?: string;
  is_anonymous?: boolean;
}

export interface SupabaseAuthSession {
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
  user: SupabaseAuthUser;
}

export interface SupabaseAuthRestOptions {
  fetchImpl?: typeof fetch;
  signal?: AbortSignal;
}

type UnknownRecord = Record<string, unknown>;

const asRecord = (value: unknown): UnknownRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? value as UnknownRecord : {};

const clean = (value: unknown): string => typeof value === 'string' ? value.trim() : '';

async function readError(response: Response): Promise<string> {
  try {
    const body = asRecord(await response.json());
    const code = clean(body.code) || clean(body.error_code) || clean(body.error);
    const description = clean(body.msg) || clean(body.message) || clean(body.error_description);
    return (code || description || `AUTH_HTTP_${response.status}`).slice(0, 180);
  } catch {
    return `AUTH_HTTP_${response.status}`;
  }
}

function endpoint(config: AuthMembershipApiConfig, path: string): string {
  const base = clean(config.supabaseUrl).replace(/\/+$/, '');
  if (!base || !clean(config.publishableKey)) throw new Error('AUTH_API_CONFIG_REQUIRED');
  const parsed = new URL(base);
  if (parsed.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(parsed.hostname)) {
    throw new Error('SUPABASE_URL_MUST_USE_HTTPS');
  }
  return `${parsed.origin}/auth/v1/${path.replace(/^\/+/, '')}`;
}

function requestHeaders(config: AuthMembershipApiConfig, accessToken?: string): HeadersInit {
  return {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    apikey: config.publishableKey,
    ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
  };
}

async function parseSession(response: Response): Promise<SupabaseAuthSession> {
  if (!response.ok) throw new Error(await readError(response));
  const body = asRecord(await response.json());
  const user = asRecord(body.user);
  const accessToken = clean(body.access_token);
  const refreshToken = clean(body.refresh_token);
  const userId = clean(user.id);
  const expiresIn = Number(body.expires_in);
  if (!accessToken || !refreshToken || !userId || !Number.isFinite(expiresIn) || expiresIn <= 0) {
    throw new Error('AUTH_SESSION_RESPONSE_INVALID');
  }
  return {
    accessToken,
    refreshToken,
    expiresAt: Date.now() + Math.max(1, expiresIn) * 1000,
    user: {
      id: userId,
      email: clean(user.email) || undefined,
      is_anonymous: user.is_anonymous === true,
    },
  };
}

/** Request a six-digit email OTP for an existing account only. */
export async function requestEmailOtp(
  config: AuthMembershipApiConfig,
  emailValue: string,
  options: SupabaseAuthRestOptions = {},
): Promise<void> {
  const email = clean(emailValue).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    throw new Error('AUTH_EMAIL_INVALID');
  }
  const fetcher = options.fetchImpl ?? fetch;
  const response = await fetcher(endpoint(config, 'otp'), {
    method: 'POST',
    headers: requestHeaders(config),
    body: JSON.stringify({ email, create_user: false }),
    cache: 'no-store',
    signal: options.signal,
  });
  if (!response.ok) throw new Error(await readError(response));
}

/** Verify the email OTP and require the Auth server to confirm the user identity. */
export async function verifyEmailOtp(
  config: AuthMembershipApiConfig,
  emailValue: string,
  tokenValue: string,
  options: SupabaseAuthRestOptions = {},
): Promise<SupabaseAuthSession> {
  const email = clean(emailValue).toLowerCase();
  const token = clean(tokenValue).replace(/\s/g, '');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('AUTH_EMAIL_INVALID');
  if (!/^\d{6}$/.test(token)) throw new Error('AUTH_OTP_INVALID');

  const fetcher = options.fetchImpl ?? fetch;
  const response = await fetcher(endpoint(config, 'verify'), {
    method: 'POST',
    headers: requestHeaders(config),
    body: JSON.stringify({ email, token, type: 'email' }),
    cache: 'no-store',
    signal: options.signal,
  });
  const session = await parseSession(response);
  if (session.user.is_anonymous) throw new Error('AUTH_ANONYMOUS_USER_NOT_ALLOWED');

  const verifiedUser = await getAuthenticatedUser(config, session.accessToken, { fetchImpl: fetcher, signal: options.signal });
  if (verifiedUser.id !== session.user.id) throw new Error('AUTH_VERIFIED_USER_MISMATCH');
  if (verifiedUser.is_anonymous) throw new Error('AUTH_ANONYMOUS_USER_NOT_ALLOWED');
  return { ...session, user: verifiedUser };
}

/** Ask Supabase Auth to validate the bearer token and return its server-side user identity. */
export async function getAuthenticatedUser(
  config: AuthMembershipApiConfig,
  accessToken: string,
  options: SupabaseAuthRestOptions = {},
): Promise<SupabaseAuthUser> {
  const token = clean(accessToken);
  if (!token) throw new Error('AUTH_ACCESS_TOKEN_REQUIRED');
  const fetcher = options.fetchImpl ?? fetch;
  const response = await fetcher(endpoint(config, 'user'), {
    method: 'GET',
    headers: requestHeaders(config, token),
    cache: 'no-store',
    signal: options.signal,
  });
  if (!response.ok) throw new Error(await readError(response));
  const body = asRecord(await response.json());
  const id = clean(body.id);
  if (!id) throw new Error('AUTH_USER_RESPONSE_INVALID');
  return {
    id,
    email: clean(body.email) || undefined,
    is_anonymous: body.is_anonymous === true,
  };
}

/** Rotate the refresh token in memory; the caller must replace the old session atomically. */
export async function refreshAuthSession(
  config: AuthMembershipApiConfig,
  refreshTokenValue: string,
  options: SupabaseAuthRestOptions = {},
): Promise<SupabaseAuthSession> {
  const refreshToken = clean(refreshTokenValue);
  if (!refreshToken) throw new Error('AUTH_REFRESH_TOKEN_REQUIRED');
  const fetcher = options.fetchImpl ?? fetch;
  const response = await fetcher(endpoint(config, 'token?grant_type=refresh_token'), {
    method: 'POST',
    headers: requestHeaders(config),
    body: JSON.stringify({ refresh_token: refreshToken }),
    cache: 'no-store',
    signal: options.signal,
  });
  return parseSession(response);
}

/** Revoke the remote Auth session. Local state should be cleared even if this request fails. */
export async function revokeAuthSession(
  config: AuthMembershipApiConfig,
  accessToken: string,
  options: SupabaseAuthRestOptions = {},
): Promise<void> {
  const token = clean(accessToken);
  if (!token) return;
  const fetcher = options.fetchImpl ?? fetch;
  const response = await fetcher(endpoint(config, 'logout'), {
    method: 'POST',
    headers: requestHeaders(config, token),
    cache: 'no-store',
    signal: options.signal,
  });
  if (!response.ok && response.status !== 401) throw new Error(await readError(response));
}
