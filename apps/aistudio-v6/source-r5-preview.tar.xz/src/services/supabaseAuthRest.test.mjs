import test from 'node:test';
import assert from 'node:assert/strict';
import {
  requestEmailOtp,
  verifyEmailOtp,
  getAuthenticatedUser,
  refreshAuthSession,
  revokeAuthSession,
} from './supabaseAuthRest.ts';

const config = { supabaseUrl: 'https://example-project.supabase.co', publishableKey: 'sb_publishable_test_key' };
const user = { id: 'user-1', email: 'owner@example.com', is_anonymous: false };
const sessionBody = { access_token: 'access-1', refresh_token: 'refresh-1', expires_in: 3600, user };
const response = (body, status = 200) => ({ ok: status >= 200 && status < 300, status, json: async () => body });

test('requests email OTP only for an existing account', async () => {
  let call;
  await requestEmailOtp(config, 'Owner@Example.com', { fetchImpl: async (url, init) => { call = { url, init }; return response({}); } });
  assert.equal(call.url, 'https://example-project.supabase.co/auth/v1/otp');
  assert.equal(call.init.method, 'POST');
  assert.equal(call.init.headers.apikey, config.publishableKey);
  assert.deepEqual(JSON.parse(call.init.body), { email: 'owner@example.com', create_user: false });
  assert.equal(call.init.cache, 'no-store');
});

test('rejects malformed email and OTP before network calls', async () => {
  let called = false;
  await assert.rejects(requestEmailOtp(config, 'not-an-email', { fetchImpl: async () => { called = true; return response({}); } }), { message: 'AUTH_EMAIL_INVALID' });
  await assert.rejects(verifyEmailOtp(config, 'owner@example.com', '12345', { fetchImpl: async () => { called = true; return response(sessionBody); } }), { message: 'AUTH_OTP_INVALID' });
  assert.equal(called, false);
});

test('verifies email OTP and confirms identity with Auth user endpoint', async () => {
  const calls = [];
  const session = await verifyEmailOtp(config, 'owner@example.com', '123456', {
    fetchImpl: async (url, init) => {
      calls.push({ url, init });
      return calls.length === 1 ? response(sessionBody) : response(user);
    },
  });
  assert.equal(calls[0].url, 'https://example-project.supabase.co/auth/v1/verify');
  assert.deepEqual(JSON.parse(calls[0].init.body), { email: 'owner@example.com', token: '123456', type: 'email' });
  assert.equal(calls[1].url, 'https://example-project.supabase.co/auth/v1/user');
  assert.equal(calls[1].init.headers.Authorization, 'Bearer access-1');
  assert.equal(session.user.id, 'user-1');
});

test('rejects mismatched Auth identity and anonymous users', async () => {
  await assert.rejects(verifyEmailOtp(config, 'owner@example.com', '123456', {
    fetchImpl: async (_url, init) => init.method === 'POST' ? response(sessionBody) : response({ ...user, id: 'other-user' }),
  }), { message: 'AUTH_VERIFIED_USER_MISMATCH' });
  await assert.rejects(verifyEmailOtp(config, 'owner@example.com', '123456', {
    fetchImpl: async (_url, init) => init.method === 'POST' ? response({ ...sessionBody, user: { ...user, is_anonymous: true } }) : response(user),
  }), { message: 'AUTH_ANONYMOUS_USER_NOT_ALLOWED' });
});

test('refreshes using refresh_token grant and returns rotated tokens', async () => {
  let call;
  const refreshed = { ...sessionBody, access_token: 'access-2', refresh_token: 'refresh-2' };
  const session = await refreshAuthSession(config, 'refresh-1', { fetchImpl: async (url, init) => { call = { url, init }; return response(refreshed); } });
  assert.equal(call.url, 'https://example-project.supabase.co/auth/v1/token?grant_type=refresh_token');
  assert.deepEqual(JSON.parse(call.init.body), { refresh_token: 'refresh-1' });
  assert.equal(session.accessToken, 'access-2');
  assert.equal(session.refreshToken, 'refresh-2');
});

test('revokes session with bearer token and tolerates already-expired 401', async () => {
  let call;
  await revokeAuthSession(config, 'access-1', { fetchImpl: async (url, init) => { call = { url, init }; return response({}, 401); } });
  assert.equal(call.url, 'https://example-project.supabase.co/auth/v1/logout');
  assert.equal(call.init.headers.Authorization, 'Bearer access-1');
});

test('Auth user check requires a valid non-empty response', async () => {
  await assert.rejects(getAuthenticatedUser(config, 'access-1', { fetchImpl: async () => response({ email: 'missing-id@example.com' }) }), { message: 'AUTH_USER_RESPONSE_INVALID' });
});
