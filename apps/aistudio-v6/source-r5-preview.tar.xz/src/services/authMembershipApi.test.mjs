import test from 'node:test';
import assert from 'node:assert/strict';
import { fetchAuthenticatedMemberships } from './authMembershipApi.ts';

const config = {
  supabaseUrl: 'https://example-project.supabase.co',
  publishableKey: 'sb_publishable_test_key_123',
};
const payload = {
  id: 'user-1',
  memberships: [{
    id: 'membership-1', tenant_id: 'tenant-1', business_id: 'business-1',
    branch_id: null, organization_id: 'org-1', role: 'OWNER', status: 'ACTIVE', permissions: {},
  }],
};

function response(body, status = 200) {
  return { ok: status >= 200 && status < 300, status, json: async () => body };
}

test('calls the existing API endpoint with bearer token and publishable key', async () => {
  let captured;
  const result = await fetchAuthenticatedMemberships(config, 'access-token', 'user-1', {
    fetchImpl: async (url, init) => {
      captured = { url, init };
      return response(payload);
    },
  });
  assert.equal(captured.url, 'https://example-project.supabase.co/functions/v1/api/api/v1/me');
  assert.equal(captured.init.method, 'GET');
  assert.equal(captured.init.headers.Authorization, 'Bearer access-token');
  assert.equal(captured.init.headers.apikey, config.publishableKey);
  assert.equal(captured.init.cache, 'no-store');
  assert.equal(result.candidates.length, 1);
  assert.equal(result.candidates[0].businessId, 'business-1');
});

test('rejects server response for a different authenticated user', async () => {
  await assert.rejects(
    fetchAuthenticatedMemberships(config, 'access-token', 'another-user', {
      fetchImpl: async () => response(payload),
    }),
    { message: 'AUTHENTICATED_USER_MISMATCH' },
  );
});

test('maps expired or invalid bearer tokens to a stable auth error', async () => {
  await assert.rejects(
    fetchAuthenticatedMemberships(config, 'expired-token', 'user-1', {
      fetchImpl: async () => response({ error: 'Unauthorized' }, 401),
    }),
    { message: 'AUTH_SESSION_REJECTED' },
  );
});

test('does not infer permissions when the server returns forbidden', async () => {
  await assert.rejects(
    fetchAuthenticatedMemberships(config, 'access-token', 'user-1', {
      fetchImpl: async () => response({ error: 'Forbidden' }, 403),
    }),
    { message: 'AUTH_MEMBERSHIP_FORBIDDEN' },
  );
});

test('rejects empty credentials before making a network request', async () => {
  let called = false;
  await assert.rejects(fetchAuthenticatedMemberships(config, '', 'user-1', {
    fetchImpl: async () => { called = true; return response(payload); },
  }), { message: 'AUTH_ACCESS_TOKEN_REQUIRED' });
  assert.equal(called, false);
});

test('lists tenant-owner businesses through catalog-admin with the authenticated bearer token', async () => {
  let captured;
  const businesses = await (await import('./authMembershipApi.ts')).fetchTenantOwnerBusinesses(config, 'access-token', 'tenant-1', {
    fetchImpl: async (url, init) => {
      captured = { url, init };
      return response({ businesses: [
        { id: 'business-1', tenantId: 'tenant-1', name: 'النشاط الأول', status: 'ACTIVE', code: 'B1' },
        { id: 'business-2', tenantId: 'tenant-2', name: 'خارج النطاق', status: 'ACTIVE' },
        { id: 'business-3', tenantId: 'tenant-1', name: 'متوقف', status: 'INACTIVE' },
        { id: '', tenantId: 'tenant-1', name: 'بلا معرّف', status: 'ACTIVE' },
      ] });
    },
  });
  assert.equal(captured.url, 'https://example-project.supabase.co/functions/v1/catalog-admin');
  assert.equal(captured.init.method, 'POST');
  assert.equal(captured.init.headers.Authorization, 'Bearer access-token');
  assert.deepEqual(JSON.parse(captured.init.body), { action: 'BUSINESS_LIST', tenantId: 'tenant-1' });
  assert.deepEqual(businesses.map((item) => [item.id, item.name]), [['business-1', 'النشاط الأول']]);
});

test('rejects tenant-owner business listing when the existing server policy denies access', async () => {
  const { fetchTenantOwnerBusinesses } = await import('./authMembershipApi.ts');
  await assert.rejects(fetchTenantOwnerBusinesses(config, 'access-token', 'tenant-1', {
    fetchImpl: async () => response({ error: 'CATALOG_BUSINESS_LIST_FORBIDDEN' }, 403),
  }), { message: 'AUTH_BUSINESS_SELECTION_FORBIDDEN' });
});
