import type { AuthSession } from '../types/index.ts';

export type V6MembershipRole = 'super_admin' | 'subscriber' | 'customer';

export interface ActiveMembershipCandidate {
  userId: string;
  membershipId: string;
  selectionKey: string;
  role: V6MembershipRole;
  backendRole: string;
  tenantId: string;
  organizationId?: string;
  businessId?: string;
  businessName?: string;
  businessCode?: string;
  branchId?: string;
  permissions: Record<string, unknown>;
}

export interface BusinessSelectionRequirement {
  userId: string;
  membershipId: string;
  backendRole: 'OWNER';
  tenantId: string;
  organizationId?: string;
  permissions: Record<string, unknown>;
}

export interface MembershipResolution {
  userId: string;
  candidates: ActiveMembershipCandidate[];
  requiresBusinessSelection: BusinessSelectionRequirement[];
  ignoredMembershipCount: number;
}

type UnknownRecord = Record<string, unknown>;

const isRecord = (value: unknown): value is UnknownRecord =>
  Boolean(value) && typeof value === 'object' && !Array.isArray(value);

const cleanString = (value: unknown): string =>
  typeof value === 'string' ? value.trim() : '';

const normalizePermissions = (value: unknown): Record<string, unknown> =>
  isRecord(value) ? value : {};

const BUSINESS_DASHBOARD_ROLES = new Set(['BUSINESS_OWNER', 'OWNER', 'ADMIN', 'MANAGER']);

/**
 * Convert the existing api /api/v1/me response into explicit V6 membership
 * choices. Never chooses the first membership and never upgrades a backend
 * role based on browser/user metadata.
 */
export function resolveV6Memberships(payload: unknown, expectedUserId?: string): MembershipResolution {
  if (!isRecord(payload)) throw new Error('INVALID_MEMBERSHIP_RESPONSE');
  const userId = cleanString(payload.id);
  if (!userId) throw new Error('AUTHENTICATED_USER_ID_MISSING');
  if (expectedUserId && userId !== cleanString(expectedUserId)) {
    throw new Error('AUTHENTICATED_USER_MISMATCH');
  }
  if (!Array.isArray(payload.memberships)) throw new Error('MEMBERSHIPS_NOT_AN_ARRAY');

  const candidates: ActiveMembershipCandidate[] = [];
  const requiresBusinessSelection: BusinessSelectionRequirement[] = [];
  let ignoredMembershipCount = 0;

  for (const raw of payload.memberships) {
    if (!isRecord(raw)) {
      ignoredMembershipCount += 1;
      continue;
    }

    if (cleanString(raw.status).toUpperCase() !== 'ACTIVE') {
      ignoredMembershipCount += 1;
      continue;
    }

    const membershipId = cleanString(raw.id);
    const backendRole = cleanString(raw.role).toUpperCase();
    const tenantId = cleanString(raw.tenant_id);
    const organizationId = cleanString(raw.organization_id) || undefined;
    const businessId = cleanString(raw.business_id) || undefined;
    const branchId = cleanString(raw.branch_id) || undefined;
    const permissions = normalizePermissions(raw.permissions);

    if (!membershipId || !backendRole || !tenantId) {
      ignoredMembershipCount += 1;
      continue;
    }

    // Platform-wide access is granted only by the same strict contract used
    // by the live catalog-admin and catalog-platform-admin Edge Functions.
    if (
      backendRole === 'SUPER_ADMIN' &&
      !businessId &&
      !branchId &&
      permissions.scope === 'PLATFORM' &&
      permissions.full_control === true
    ) {
      candidates.push({
        userId, membershipId, selectionKey: membershipId, role: 'super_admin', backendRole, tenantId,
        organizationId, permissions,
      });
      continue;
    }

    if (backendRole === 'CUSTOMER') {
      candidates.push({ userId, membershipId, selectionKey: membershipId, role: 'customer', backendRole, tenantId, permissions });
      continue;
    }

    if (BUSINESS_DASHBOARD_ROLES.has(backendRole) && businessId) {
      candidates.push({
        userId, membershipId, selectionKey: membershipId, role: 'subscriber', backendRole, tenantId,
        organizationId, businessId, branchId, permissions,
      });
      continue;
    }

    // Tenant-scoped OWNER memberships need an explicit business choice before
    // a merchant workspace can be created. Do not invent a businessId.
    if (backendRole === 'OWNER' && !businessId && !branchId) {
      requiresBusinessSelection.push({
        userId, membershipId, backendRole: 'OWNER', tenantId, organizationId, permissions,
      });
      continue;
    }

    // Employee, support, provider, regional, and incomplete/global memberships
    // remain unprivileged until a dedicated V6 capability matrix is implemented.
    ignoredMembershipCount += 1;
  }

  return { userId, candidates, requiresBusinessSelection, ignoredMembershipCount };
}


export interface TenantBusinessSelectionOption {
  id: string;
  tenantId: string;
  organizationId?: string;
  name: string;
  code?: string;
  status: string;
}

/**
 * Expand a tenant-level OWNER membership only with businesses returned by the
 * server-authorized catalog-admin BUSINESS_LIST action for that same tenant.
 * Each business remains a distinct explicit choice; no business ID is guessed.
 */
export function toV6TenantOwnerBusinessCandidate(
  requirement: BusinessSelectionRequirement,
  business: TenantBusinessSelectionOption,
): ActiveMembershipCandidate {
  const businessId = cleanString(business.id);
  const tenantId = cleanString(business.tenantId);
  const businessName = cleanString(business.name);
  if (!businessId || !tenantId || tenantId !== requirement.tenantId || !businessName) {
    throw new Error('AUTH_BUSINESS_SELECTION_INVALID');
  }
  if (cleanString(business.status).toUpperCase() !== 'ACTIVE') {
    throw new Error('AUTH_BUSINESS_SELECTION_INACTIVE');
  }
  return {
    userId: requirement.userId,
    membershipId: requirement.membershipId,
    selectionKey: `owner:${requirement.membershipId}:${businessId}`,
    role: 'subscriber',
    backendRole: 'OWNER',
    tenantId,
    organizationId: cleanString(business.organizationId) || requirement.organizationId,
    businessId,
    businessName,
    businessCode: cleanString(business.code) || undefined,
    permissions: { ...requirement.permissions },
  };
}

/**
 * Convert one explicitly selected server-resolved membership into the app
 * session shape. The caller must first validate the user ID against Supabase
 * Auth and let the user select one candidate when several are returned.
 */
export function toV6AuthSession(candidate: ActiveMembershipCandidate): AuthSession {
  return {
    role: candidate.role,
    userId: candidate.userId,
    membershipId: candidate.membershipId,
    subscriberName: candidate.businessName,
    tenantId: candidate.tenantId,
    organizationId: candidate.organizationId,
    businessId: candidate.businessId,
    branchId: candidate.branchId,
    backendRole: candidate.backendRole,
    membershipPermissions: { ...candidate.permissions },
  };
}
