import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveV6Memberships, toV6AuthSession } from './authMembership.ts';

const base = (overrides = {}) => ({
  id: 'user-1',
  memberships: [],
  ...overrides,
});
const membership = (id, role, overrides = {}) => ({
  id,
  tenant_id: 'tenant-1',
  organization_id: null,
  business_id: null,
  branch_id: null,
  role,
  status: 'ACTIVE',
  permissions: {},
  ...overrides,
});

test('grants platform dashboard only to a correctly scoped SUPER_ADMIN membership', () => {
  const result = resolveV6Memberships(base({ memberships: [membership('m1', 'SUPER_ADMIN', {
    permissions: { scope: 'PLATFORM', full_control: true },
  })] }));
  assert.equal(result.candidates.length, 1);
  assert.equal(result.candidates[0].role, 'super_admin');
  assert.equal(result.candidates[0].tenantId, 'tenant-1');
});

test('does not elevate SUPER_ADMIN without full-control platform scope or with a business/branch scope', () => {
  const result = resolveV6Memberships(base({ memberships: [
    membership('m1', 'SUPER_ADMIN', { permissions: { scope: 'PLATFORM', full_control: false } }),
    membership('m2', 'SUPER_ADMIN', { permissions: { scope: 'PLATFORM', full_control: true }, business_id: 'biz-1' }),
    membership('m3', 'SUPER_ADMIN', { permissions: { scope: 'PLATFORM', full_control: true }, branch_id: 'branch-1' }),
  ] }));
  assert.equal(result.candidates.length, 0);
  assert.equal(result.ignoredMembershipCount, 3);
});

test('maps only scoped business roles to a subscriber session', () => {
  const result = resolveV6Memberships(base({ memberships: [
    membership('owner', 'BUSINESS_OWNER', { business_id: 'biz-1' }),
    membership('branch-manager', 'MANAGER', { business_id: 'biz-2', branch_id: 'branch-7' }),
  ] }));
  assert.deepEqual(result.candidates.map((item) => [item.role, item.businessId, item.branchId]), [
    ['subscriber', 'biz-1', undefined],
    ['subscriber', 'biz-2', 'branch-7'],
  ]);
});

test('requires explicit business selection for tenant-scoped OWNER', () => {
  const result = resolveV6Memberships(base({ memberships: [membership('owner', 'OWNER')] }));
  assert.equal(result.candidates.length, 0);
  assert.equal(result.requiresBusinessSelection.length, 1);
  assert.equal(result.requiresBusinessSelection[0].tenantId, 'tenant-1');
});

test('maps CUSTOMER without merchant scope and ignores unsupported staff/provider roles', () => {
  const result = resolveV6Memberships(base({ memberships: [
    membership('customer', 'CUSTOMER', { business_id: 'legacy-biz-id' }),
    membership('employee', 'EMPLOYEE', { business_id: 'biz-1' }),
    membership('staff', 'STAFF', { business_id: 'biz-1' }),
    membership('provider', 'SERVICE_PROVIDER', { business_id: 'biz-1' }),
  ] }));
  assert.deepEqual(result.candidates.map((item) => [item.role, item.businessId]), [['customer', undefined]]);
  assert.equal(result.ignoredMembershipCount, 3);
});

test('ignores inactive, malformed, and missing-scope memberships', () => {
  const result = resolveV6Memberships(base({ memberships: [
    membership('inactive', 'BUSINESS_OWNER', { business_id: 'biz-1', status: 'INACTIVE' }),
    membership('', 'BUSINESS_OWNER', { business_id: 'biz-2' }),
    membership('missing-tenant', 'BUSINESS_OWNER', { tenant_id: '', business_id: 'biz-3' }),
  ] }));
  assert.equal(result.candidates.length, 0);
  assert.equal(result.ignoredMembershipCount, 3);
});

test('does not select the first of multiple active memberships', () => {
  const result = resolveV6Memberships(base({ memberships: [
    membership('owner-1', 'BUSINESS_OWNER', { business_id: 'biz-1' }),
    membership('owner-2', 'BUSINESS_OWNER', { business_id: 'biz-2' }),
  ] }));
  assert.equal(result.candidates.length, 2);
  assert.deepEqual(result.candidates.map((item) => item.businessId), ['biz-1', 'biz-2']);
});

test('creates an AuthSession only from an explicit membership candidate', () => {
  const result = resolveV6Memberships(base({ memberships: [membership('owner', 'BUSINESS_OWNER', { business_id: 'biz-9', branch_id: 'branch-2' })] }), 'user-1');
  const session = toV6AuthSession(result.candidates[0]);
  assert.deepEqual({
    role: session.role, userId: session.userId, membershipId: session.membershipId,
    tenantId: session.tenantId, businessId: session.businessId, branchId: session.branchId,
    backendRole: session.backendRole,
  }, {
    role: 'subscriber', userId: 'user-1', membershipId: 'owner', tenantId: 'tenant-1',
    businessId: 'biz-9', branchId: 'branch-2', backendRole: 'BUSINESS_OWNER',
  });
});

test('rejects an API membership payload belonging to a different authenticated user', () => {
  assert.throws(() => resolveV6Memberships(base(), 'another-user'), /AUTHENTICATED_USER_MISMATCH/);
});

test('rejects invalid API response envelopes', () => {
  assert.throws(() => resolveV6Memberships(null), /INVALID_MEMBERSHIP_RESPONSE/);
  assert.throws(() => resolveV6Memberships({ memberships: [] }), /AUTHENTICATED_USER_ID_MISSING/);
  assert.throws(() => resolveV6Memberships({ id: 'user-1', memberships: {} }), /MEMBERSHIPS_NOT_AN_ARRAY/);
});

test('expands tenant OWNER only from active same-tenant server business choices', async () => {
  const { toV6TenantOwnerBusinessCandidate } = await import('./authMembership.ts');
  const result = resolveV6Memberships(base({ memberships: [membership('owner', 'OWNER')] }));
  const candidate = toV6TenantOwnerBusinessCandidate(result.requiresBusinessSelection[0], {
    id: 'business-9', tenantId: 'tenant-1', name: 'نشاط موثّق', status: 'ACTIVE', code: 'B9',
  });
  assert.equal(candidate.role, 'subscriber');
  assert.equal(candidate.backendRole, 'OWNER');
  assert.equal(candidate.businessId, 'business-9');
  assert.equal(candidate.businessName, 'نشاط موثّق');
  assert.equal(candidate.selectionKey, 'owner:owner:business-9');
  assert.throws(() => toV6TenantOwnerBusinessCandidate(result.requiresBusinessSelection[0], {
    id: 'business-10', tenantId: 'another-tenant', name: 'نشاط خارج النطاق', status: 'ACTIVE',
  }), /AUTH_BUSINESS_SELECTION_INVALID/);
  assert.throws(() => toV6TenantOwnerBusinessCandidate(result.requiresBusinessSelection[0], {
    id: 'business-11', tenantId: 'tenant-1', name: 'نشاط متوقف', status: 'INACTIVE',
  }), /AUTH_BUSINESS_SELECTION_INACTIVE/);
});
