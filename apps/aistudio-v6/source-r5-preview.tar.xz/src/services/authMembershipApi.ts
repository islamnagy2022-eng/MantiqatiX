import {
  resolveV6Memberships,
  type MembershipResolution,
} from './authMembership.ts';
import { getPublicSupabaseConfig } from './publicSupabaseConfig';

export interface AuthMembershipApiConfig {
  supabaseUrl: string;
  publishableKey: string;
}

export interface AuthMembershipApiOptions {
  signal?: AbortSignal;
  fetchImpl?: typeof fetch;
}

export function getAuthMembershipApiConfig(): AuthMembershipApiConfig | null {
  return getPublicSupabaseConfig();
}

/**
 * Calls the existing production API Edge Function using the user's Supabase
 * access token. The server verifies the JWT and returns active memberships.
 * This function never persists the token or derives roles from client data.
 */
export async function fetchAuthenticatedMemberships(
  config: AuthMembershipApiConfig,
  accessToken: string,
  expectedUserId: string,
  options: AuthMembershipApiOptions = {},
): Promise<MembershipResolution> {
  const token = accessToken.trim();
  const userId = expectedUserId.trim();
  if (!token) throw new Error('AUTH_ACCESS_TOKEN_REQUIRED');
  if (!userId) throw new Error('AUTH_USER_ID_REQUIRED');
  if (!config.supabaseUrl || !config.publishableKey) throw new Error('AUTH_API_CONFIG_REQUIRED');

  const base = config.supabaseUrl.replace(/\/+$/, '');
  const endpoint = `${base}/functions/v1/api/api/v1/me`;
  const fetcher = options.fetchImpl ?? fetch;
  const response = await fetcher(endpoint, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
      apikey: config.publishableKey,
      Authorization: `Bearer ${token}`,
    },
    cache: 'no-store',
    signal: options.signal,
  });

  if (response.status === 401) throw new Error('AUTH_SESSION_REJECTED');
  if (response.status === 403) throw new Error('AUTH_MEMBERSHIP_FORBIDDEN');
  if (!response.ok) throw new Error(`AUTH_MEMBERSHIP_API_FAILED_${response.status}`);

  const payload: unknown = await response.json();
  return resolveV6Memberships(payload, userId);
}

export interface TenantOwnerBusinessOption {
  id: string;
  tenantId: string;
  organizationId?: string;
  name: string;
  code?: string;
  status: string;
  sector?: string;
}

/**
 * Lists only the active businesses that the existing catalog-admin Edge
 * Function authorizes for this authenticated tenant-level OWNER membership.
 * The browser supplies no owner role or business IDs; the server derives the
 * membership from the verified bearer token.
 */
export async function fetchTenantOwnerBusinesses(
  config: AuthMembershipApiConfig,
  accessToken: string,
  tenantIdValue: string,
  options: AuthMembershipApiOptions = {},
): Promise<TenantOwnerBusinessOption[]> {
  const token = accessToken.trim();
  const tenantId = tenantIdValue.trim();
  if (!token) throw new Error('AUTH_ACCESS_TOKEN_REQUIRED');
  if (!tenantId) throw new Error('AUTH_TENANT_ID_REQUIRED');
  if (!config.supabaseUrl || !config.publishableKey) throw new Error('AUTH_API_CONFIG_REQUIRED');

  const endpoint = `${config.supabaseUrl.replace(/\/+$/, '')}/functions/v1/catalog-admin`;
  const fetcher = options.fetchImpl ?? fetch;
  const response = await fetcher(endpoint, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      apikey: config.publishableKey,
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ action: 'BUSINESS_LIST', tenantId }),
    cache: 'no-store',
    signal: options.signal,
  });
  if (response.status === 401) throw new Error('AUTH_SESSION_REJECTED');
  if (response.status === 403) throw new Error('AUTH_BUSINESS_SELECTION_FORBIDDEN');
  if (!response.ok) throw new Error(`AUTH_BUSINESS_LIST_FAILED_${response.status}`);

  const payload: unknown = await response.json();
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new Error('AUTH_BUSINESS_LIST_INVALID_RESPONSE');
  }
  const rawBusinesses = (payload as Record<string, unknown>).businesses;
  if (!Array.isArray(rawBusinesses)) throw new Error('AUTH_BUSINESS_LIST_INVALID_RESPONSE');

  return rawBusinesses.flatMap((value): TenantOwnerBusinessOption[] => {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return [];
    const row = value as Record<string, unknown>;
    const id = typeof row.id === 'string' ? row.id.trim() : '';
    const rowTenantId = typeof row.tenantId === 'string' ? row.tenantId.trim() : '';
    const name = typeof row.name === 'string' ? row.name.trim() : '';
    const status = typeof row.status === 'string' ? row.status.trim().toUpperCase() : '';
    if (!id || rowTenantId !== tenantId || !name || status !== 'ACTIVE') return [];
    return [{
      id,
      tenantId: rowTenantId,
      organizationId: typeof row.organizationId === 'string' ? row.organizationId.trim() || undefined : undefined,
      name,
      code: typeof row.code === 'string' ? row.code.trim() || undefined : undefined,
      status,
      sector: typeof row.sector === 'string' ? row.sector.trim() || undefined : undefined,
    }];
  });
}
