import React, { createContext, useContext, useEffect, useState } from 'react';
import { getAuthMembershipApiConfig } from '../services/authMembershipApi';
import { fetchAuthenticatedMembershipChoices } from '../services/authMembershipWorkflow';
import { toV6AuthSession, type ActiveMembershipCandidate } from '../services/authMembership';
import { getAuthenticatedUser, refreshAuthSession, requestEmailOtp, revokeAuthSession, verifyEmailOtp, type SupabaseAuthSession } from '../services/supabaseAuthRest';
import { fetchPublicCatalogDirectory, getPublicCatalogDirectoryConfig } from '../services/publicCatalogDirectory';
import {
  ActivityCategory,
  AdminSettings,
  AdRequest,
  AdRequestStatus,
  AdRequestType,
  AuthRole,
  AuthSession,
  Business,
  BusinessPermissions,
  CartItem,
  ContactMessage,
  CustomerOrderData,
  EnterpriseStateArchitectureSummary,
  FunctionalGroup,
  FunctionalGroupId,
  GeneratedMarketingCampaign,
  LoadTestBenchmarkResult,
  MarketingCampaignGoal,
  MedicalSpecialty,
  MemberDirectMessage,
  MessagingPrivacyConfig,
  PaymobConfig,
  Product,
  SaleRecord,
  SectorPackageLevel,
  Subscriber,
  SubscriptionPlanTier,
  SubscriptionRequest,
  TelemetryMetrics,
  VerificationStatus,
  WalletAccount,
  WalletPaymentChannel,
  WalletTransaction,
  WalletTransactionType,
} from '../types';
import {
  DEFAULT_CATEGORIES,
  DEFAULT_FUNCTIONAL_GROUPS,
  DEFAULT_MEDICAL_SPECIALTIES,
  DEFAULT_PAYMOB_CONFIG,
  DEFAULT_SITE_MAP_CONFIG,
  INITIAL_ADMIN_SETTINGS,
  INITIAL_AD_REQUESTS,
  INITIAL_BUSINESSES,
  INITIAL_CONTACT_MESSAGES,
  INITIAL_PRODUCTS,
  INITIAL_SUBSCRIBERS,
  INITIAL_SUBSCRIPTION_REQUESTS,
} from '../data/seedData';
import {
  simulateEnterpriseLoadTest,
  getLiveTelemetryMetrics,
} from '../utils/loadTestingEngine';
import { resolveProtectedView } from '../utils/accessPolicy';
import {
  ADMIN_MAIN_WALLET_ID,
  buildEnterpriseStateSummary,
  canAddProduct,
  createBackupPayload,
  createInitialPlatformWallets,
  executeWalletLedgerOperation,
  formatDirectCredentialsText,
  generateAdminCatalogRequestWhatsAppUrl,
  generateBusinessMarketingCampaign,
  generateGmailInviteUrl,
  generateStorePublicUrl,
  generateWhatsAppOrderUrl,
  getMostRequestedBusinesses,
  getPickedForYouBusinesses,
  MAX_PRODUCTS_PER_BUSINESS,
  validateAndParseBackup,
  applyAdminPaymentConfirmation,
  advanceOverdueDay,
  DEFAULT_COMMISSION_PER_ORDER,
  ensureBusinessStaticImages,
  resolveProductImage,
  mergeFunctionalGroups,
  getDefaultTierConfiguration,
  applySectorPackageUpgradeToBusiness,
  getSectorDevelopmentBlueprint,
  getDefaultMessagingPrivacyConfig,
  evaluateMessagingPrivacyAndLocation,
} from '../utils/rules';

export type ViewMode =
  | 'public_storefront'
  | 'merchant_admin'
  | 'super_admin'
  | 'login'
  | 'directory'
  | 'medical_directory'
  | 'site_map'
  | 'contact_us'
  | 'member_messages'
  | 'mantygo_bidding';

interface AppContextType {
  // Navigation & View Mode
  currentView: ViewMode;
  setCurrentView: (view: ViewMode) => void;
  selectedBusinessId: string;
  setSelectedBusinessId: (id: string) => void;
  currentBusiness: Business | undefined;

  // Taxonomy & Functional Groups Filter
  functionalGroups: FunctionalGroup[];
  categories: ActivityCategory[];
  addCategory: (cat: { name: string; functionalGroupId: FunctionalGroupId; description?: string }) => ActivityCategory;
  updateCategory: (cat: ActivityCategory) => void;
  deleteCategory: (id: string) => void;
  selectedFunctionalGroupFilter: string;
  setSelectedFunctionalGroupFilter: (id: string) => void;
  selectedCategoryFilter: string;
  setSelectedCategoryFilter: (id: string) => void;

  // Authentication & Session
  authSession: AuthSession;
  authStatus: 'idle' | 'sending_otp' | 'otp_sent' | 'verifying_otp' | 'select_membership' | 'no_membership' | 'authenticated' | 'error';
  authEmail: string;
  authError: string;
  authCandidates: ActiveMembershipCandidate[];
  authBusinessSelectionRequired: number;
  requestLoginOtp: (email: string) => Promise<boolean>;
  verifyLoginOtp: (code: string) => Promise<boolean>;
  selectAuthMembership: (membershipId: string) => boolean;
  loginAsSubscriber: (identifier: string, password: string) => { success: boolean; error?: string };
  loginAsAdmin: (password: string) => { success: boolean; error?: string };
  logout: () => void;
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (open: boolean) => void;
  isUserProfileModalOpen: boolean;
  setIsUserProfileModalOpen: (open: boolean) => void;

  // Data Collections
  businesses: Business[];
  products: Product[];
  directoryBusinesses: Business[];
  directoryProducts: Product[];
  directoryStatus: 'loading' | 'ready' | 'empty' | 'not_configured' | 'error';
  directoryError: string;
  refreshPublicDirectory: () => void;
  subscribers: Subscriber[];
  adminSettings: AdminSettings;

  // Medical & Healthcare Specialties
  medicalSpecialties: MedicalSpecialty[];
  selectedMedicalSpecialtyFilter: string;
  setSelectedMedicalSpecialtyFilter: (id: string) => void;
  userGeoCoords: { lat: number; lng: number } | null;
  setUserGeoCoords: (coords: { lat: number; lng: number } | null) => void;

  // Business Actions & 5-Tier Verification System
  updateBusiness: (business: Business) => void;
  updateBusinessVerificationStatus: (businessId: string, status: VerificationStatus, notes?: string) => void;
  updateBusinessVerification: (businessId: string, status: VerificationStatus, notes?: string) => void;
  addBusiness: (business: Omit<Business, 'id' | 'createdAt'>) => string;
  deleteBusiness: (id: string) => void;
  getStorePublicLink: (business: Business) => string;
  updateBusinessLocation: (
    businessId: string,
    loc: { governorate: string; markaz: string; village: string; address?: string; coordinates?: { lat: number; lng: number } }
  ) => void;

  // Enterprise Observability, Telemetry & Load Testing (Hyperscale 100M Simulation)
  telemetryMetrics: TelemetryMetrics;
  loadTestHistory: LoadTestBenchmarkResult[];
  runLoadTest: (vus: number) => LoadTestBenchmarkResult;
  isLoadTesting: boolean;
  lastLoadTestResult: LoadTestBenchmarkResult | null;

  // Admin Billing, Commission & Overdue / Freeze Actions (ولا يراه صاحب النشاط)
  confirmAdminPayment: (businessId: string) => void;
  advanceBusinessOverdueDay: (businessId: string) => void;
  toggleBusinessFreeze: (businessId: string) => void;
  updateBusinessCommissionRate: (businessId: string, rate: number) => void;
  updateBusinessPaymobConfig: (businessId: string, config: Partial<PaymobConfig>) => void;

  // Product Actions (enforcing 150 items limit)
  businessProducts: Product[];
  addProduct: (product: Omit<Product, 'id'>) => { success: boolean; message?: string };
  updateProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  bulkAddDemoProducts: (businessId: string, count: number) => { success: boolean; added: number };

  // Subscriber management. Authentication and invitations are server-owned only.
  addSubscriber: (data: {
    fullName: string;
    email: string;
    phone: string;
    businessId: string;
    username?: string;
    password?: string;
    authMethod: 'direct_password' | 'gmail_invite';
    notes?: string;
  }) => Subscriber;
  updateSubscriber: (subscriber: Subscriber) => void;
  deleteSubscriber: (id: string) => void;
  sendGmailInvite: (subscriberId: string) => string;
  getSubscriberCredentialsText: (subscriberId: string) => string;

  // Admin Settings
  updateAdminSettings: (settings: Partial<AdminSettings>) => void;
  addBusinessCategory: (category: string) => void;

  // Cart & Ordering for Active Business
  cartItems: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  submitOrderViaWhatsApp: (customer: CustomerOrderData) => { success: boolean; url?: string; error?: string };

  // Catalog Request via Admin WhatsApp
  requestCatalogViaAdminWhatsApp: (business?: Business) => string;

  // Backup & Restore
  exportBackupJSON: () => string;
  downloadBackupFile: () => void;
  importBackupJSON: (jsonString: string) => {
    success: boolean;
    error?: string;
    counts?: { businesses: number; products: number; subscribers: number };
  };

  // Official Live Production Data Persistence
  resetToDefaultData: () => void;
  isOfficialLiveProduction: boolean;
  lastLiveSyncTimestamp: string;
  commitCurrentDataAsOfficialLive: () => Promise<{ success: boolean; committedAt: string }>;

  // Financial & Sales Reports
  salesRecords: SaleRecord[];
  addSaleRecord: (sale: Omit<SaleRecord, 'id' | 'createdAt'>) => SaleRecord;

  // Ad Requests (Sponsored Ads & Billboard Banners)
  adRequests: AdRequest[];
  addAdRequest: (req: Omit<AdRequest, 'id' | 'createdAt' | 'status'>) => AdRequest;
  updateAdRequest: (req: AdRequest) => void;
  updateAdRequestStatus: (id: string, status: AdRequestStatus) => void;
  updateAdRequestDetails: (req: AdRequest) => void;
  deleteAdRequest: (id: string) => void;
  adModalType: AdRequestType | null;
  setAdModalType: (type: AdRequestType | null) => void;

  // Contact Messages & Admin Inbox
  contactMessages: ContactMessage[];
  unreadMessagesCount: number;
  addContactMessage: (msg: Omit<ContactMessage, 'id' | 'createdAt' | 'isRead'>) => ContactMessage;
  markContactMessageRead: (id: string, isRead?: boolean) => void;
  deleteContactMessage: (id: string) => void;

  // Business Subscription & Free Directory Requests ("أرغب في اشتراك نشاطي")
  subscriptionRequests: SubscriptionRequest[];
  submitSubscriptionRequest: (data: {
    businessName: string;
    ownerName?: string;
    phoneOrWhatsApp: string;
    governorate: string;
    markaz: string;
    detailedAddress?: string;
    functionalGroupId: FunctionalGroupId;
    category: string;
    notes?: string;
    isFreeDirectoryOnly?: boolean;
  }) => { request: SubscriptionRequest; businessId: string };
  reviewSubscriptionRequest: (
    requestId: string,
    decision: 'approved' | 'rejected',
    config: {
      assignedTier: SubscriptionPlanTier;
      maxAllowedBusinesses: number;
      maxProductsLimit: number;
      commissionType: 'percentage' | 'fixed' | 'percentage_plus_fixed' | 'subscription_only' | 'all_combined';
      monthlySubscriptionFee: number;
      commissionPercentage: number;
      commissionFixed: number;
      creditLimit: number;
      permissions: BusinessPermissions;
      isVerified: boolean;
    }
  ) => void;
  updateSubscriptionRequest: (req: SubscriptionRequest) => void;
  approveSubscriptionRequestToBusiness: (req: SubscriptionRequest, isVerified: boolean) => void;
  isSubscribeModalOpen: boolean;
  setIsSubscribeModalOpen: (open: boolean) => void;
  adminActiveTabOverride: string | null;
  setAdminActiveTabOverride: (tab: string | null) => void;

  // Enterprise Wallet & Privacy Popup Modal State
  wallets: WalletAccount[];
  walletTransactions: WalletTransaction[];
  activeWalletId: string;
  setActiveWalletId: (id: string) => void;
  currentWallet: WalletAccount;
  isWalletModalOpen: boolean;
  setIsWalletModalOpen: (open: boolean) => void;
  performWalletTransaction: (input: {
    walletId?: string;
    type: WalletTransactionType;
    amount: number;
    description: string;
    paymentMethod?: WalletPaymentChannel;
    referenceId?: string;
    isFreeAdminGrant?: boolean;
  }) => { success: boolean; error?: string; transaction?: WalletTransaction };

  // Smart Marketing System for Every Business & Free Admin Sponsored Ads
  generatedCampaigns: GeneratedMarketingCampaign[];
  smartMarketingTargetBiz: Business | null;
  setSmartMarketingTargetBiz: (biz: Business | null) => void;
  generateMarketingForBusiness: (
    businessId: string,
    options?: {
      goal?: MarketingCampaignGoal;
      discountPercent?: number;
      customOfferText?: string;
    }
  ) => GeneratedMarketingCampaign | null;
  publishCampaignAsFreeAdminAd: (
    campaignId: string,
    adType?: AdRequestType,
    durationDays?: number
  ) => { success: boolean; adRequest?: AdRequest; error?: string };

  // Curated Home Screen Sections & Enterprise State Summary
  pickedForYouBusinesses: Business[];
  mostRequestedBusinesses: Business[];
  enterpriseStateSummary: EnterpriseStateArchitectureSummary;

  // 15-Sector Specialized Development & 3-Tier Package Studio
  sectorDevelopmentTargetGroup: FunctionalGroupId | null;
  setSectorDevelopmentTargetGroup: (groupId: FunctionalGroupId | null) => void;
  sectorDevelopmentTargetBiz: Business | null;
  setSectorDevelopmentTargetBiz: (biz: Business | null) => void;
  openSectorDevelopmentStudio: (groupId: FunctionalGroupId, biz?: Business | null) => void;
  upgradeBusinessSectorPackage: (
    businessId: string,
    targetLevel: SectorPackageLevel,
    paymentMode?: 'wallet' | 'admin_free'
  ) => { success: boolean; message: string; updatedBusiness?: Business };

  // Member & Business Direct Messaging Inbox with Privacy & Location Controls
  memberDirectMessages: MemberDirectMessage[];
  messagingTargetType: 'business' | 'subscriber';
  messagingTargetId: string;
  openMemberMessagingForTarget: (type: 'business' | 'subscriber', id?: string) => void;
  updateRecipientMessagingPrivacy: (
    type: 'business' | 'subscriber',
    id: string,
    config: MessagingPrivacyConfig
  ) => void;
  sendMemberDirectMessage: (input: {
    recipientType: 'business' | 'subscriber';
    recipientId: string;
    senderName: string;
    senderPhone: string;
    senderGovernorate: string;
    senderMarkaz: string;
    senderRole?: 'subscriber' | 'visitor' | 'admin';
    subject: string;
    content: string;
    category?: MemberDirectMessage['category'];
  }) => { success: boolean; error?: string; message?: MemberDirectMessage };
  replyToMemberDirectMessage: (msgId: string, replyText: string) => void;
  markMemberDirectMessageRead: (msgId: string, isRead?: boolean) => void;
  deleteMemberDirectMessage: (msgId: string) => void;
}

const STORAGE_KEYS = {
  BUSINESSES: 'mantiqatix_businesses_v3',
  PRODUCTS: 'mantiqatix_products_v5',
  SUBSCRIBERS: 'mantiqatix_subscribers_v3',
  SETTINGS: 'mantiqatix_settings_v3',
  ACTIVE_BIZ: 'mantiqatix_active_biz_v3',
  CURRENT_VIEW: 'mantiqatix_view_v3',
  SALES: 'mantiqatix_sales_v3',
  AD_REQUESTS: 'mantiqatix_ad_requests_v4',
  CONTACT_MESSAGES: 'mantiqatix_contact_messages_v3',
  SUB_REQUESTS: 'mantiqatix_sub_requests_v3',
  WALLETS: 'mantiqatix_wallets_v4',
  WALLET_TXS: 'mantiqatix_wallet_txs_v4',
  CAMPAIGNS: 'mantiqatix_marketing_campaigns_v4',
  MEMBER_MESSAGES: 'mantiqatix_member_messages_v1',
  ADOPTED_BASELINE: 'mantiqatix_official_live_baseline_v1',
};

const authMessage = (error: unknown): string => {
  const code = error instanceof Error ? error.message : 'AUTH_UNAVAILABLE';
  const messages: Record<string, string> = {
    AUTH_API_CONFIG_REQUIRED: 'إعدادات تسجيل الدخول غير متاحة حاليًا.',
    AUTH_EMAIL_INVALID: 'أدخل بريدًا إلكترونيًا صحيحًا.',
    AUTH_OTP_INVALID: 'رمز التحقق يجب أن يتكون من 6 أرقام.',
    AUTH_SESSION_REJECTED: 'انتهت صلاحية جلسة الدخول. اطلب رمزًا جديدًا.',
    AUTH_MEMBERSHIP_FORBIDDEN: 'لا توجد صلاحية خادمية لقراءة عضويات هذا الحساب.',
    AUTH_BUSINESS_SELECTION_FORBIDDEN: 'الخادم لم يسمح بتحميل أنشطة هذا المالك. لا يمكن فتح لوحة النشاط دون نطاق معتمد.',
    AUTHENTICATED_USER_MISMATCH: 'تعذر مطابقة هوية الحساب مع العضويات المسجلة.',
    AUTH_REFRESH_USER_MISMATCH: 'تغيرت هوية جلسة الدخول. تم إيقاف الوصول.',
    AUTH_MEMBERSHIP_REVOKED: 'تم إلغاء العضوية المختارة أو لم تعد نشطة.',
    AUTH_ANONYMOUS_USER_NOT_ALLOWED: 'الحسابات المجهولة غير مسموح لها بدخول لوحات الإدارة.',
  };
  if (messages[code]) return messages[code];
  if (/rate|limit|too many/i.test(code)) return 'تم طلب رموز كثيرة خلال وقت قصير. انتظر قليلًا ثم حاول مرة أخرى.';
  if (/invalid.*(otp|token)|otp.*expired/i.test(code)) return 'رمز الدخول غير صحيح أو انتهت صلاحيته.';
  return 'تعذر إكمال تسجيل الدخول. راجع البريد والاتصال ثم حاول مرة أخرى.';
};

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial from localStorage or defaults
  const [businesses, setBusinesses] = useState<Business[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.BUSINESSES);
      if (saved) {
        const parsed: Business[] = JSON.parse(saved);
        const existingIds = new Set(parsed.map((b) => b.id));
        const missingSeeds = INITIAL_BUSINESSES.filter((b) => !existingIds.has(b.id));
        const combined = [...parsed, ...missingSeeds];

        return combined.map((b) => {
          let fg: FunctionalGroupId = b.functionalGroupId || 'retail';
          if (!b.functionalGroupId) {
            if (b.category?.includes('مطاعم') || b.category?.includes('قهوة') || b.category?.includes('حلويات')) {
              fg = 'dining';
            } else if (b.category?.includes('خدمات') || b.category?.includes('استوديو')) {
              fg = 'services';
            } else if (b.category?.includes('صيدل') || b.category?.includes('طب')) {
              fg = 'healthcare';
            } else if (b.category?.includes('صيان') || b.category?.includes('ورش')) {
              fg = 'crafts_maintenance';
            }
          }
          const staticImages = ensureBusinessStaticImages(b.logoUrl, b.coverUrl, fg);
          return {
            ...b,
            logoUrl: staticImages.logoUrl,
            coverUrl: staticImages.coverUrl,
            functionalGroupId: fg,
            categoryId: b.categoryId || DEFAULT_CATEGORIES.find((c) => c.name === b.category)?.id,
            paymobConfig: b.paymobConfig || { ...DEFAULT_PAYMOB_CONFIG },
            verificationStatus: b.verificationStatus || (b.isVerified ? 'verified' : 'unverified'),
            country: b.country || 'مصر',
            countryCode: b.countryCode || 'EG',
          };
        });
      }
      return INITIAL_BUSINESSES.map((b) => {
        const staticImages = ensureBusinessStaticImages(b.logoUrl, b.coverUrl, b.functionalGroupId);
        return { ...b, logoUrl: staticImages.logoUrl, coverUrl: staticImages.coverUrl };
      });
    } catch {
      return INITIAL_BUSINESSES.map((b) => {
        const staticImages = ensureBusinessStaticImages(b.logoUrl, b.coverUrl, b.functionalGroupId);
        return { ...b, logoUrl: staticImages.logoUrl, coverUrl: staticImages.coverUrl };
      });
    }
  });

  const [publicDirectoryState, setPublicDirectoryState] = useState<{
    businesses: Business[];
    products: Product[];
    status: 'loading' | 'ready' | 'empty' | 'not_configured' | 'error';
    error: string;
  }>({ businesses: [], products: [], status: 'loading', error: '' });
  const [publicDirectoryRevision, setPublicDirectoryRevision] = useState(0);
  const refreshPublicDirectory = () => setPublicDirectoryRevision((current) => current + 1);

  const [products, setProducts] = useState<Product[]>(() => {
    const resolveList = (list: Product[]) =>
      list.map((p) => {
        const ownerBiz = INITIAL_BUSINESSES.find((b) => b.id === p.businessId);
        return {
          ...p,
          imageUrl: resolveProductImage(p, ownerBiz?.functionalGroupId),
        };
      });
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (saved) {
        const parsed: Product[] = JSON.parse(saved);
        const existingIds = new Set(parsed.map((p) => p.id));
        const missingSeeds = INITIAL_PRODUCTS.filter((p) => !existingIds.has(p.id));
        return resolveList([...parsed, ...missingSeeds]);
      }
      return resolveList(INITIAL_PRODUCTS);
    } catch {
      return resolveList(INITIAL_PRODUCTS);
    }
  });

  const [subscribers, setSubscribers] = useState<Subscriber[]>(() => {
    const sanitizeLegacySubscribers = (rows: Subscriber[]) => rows.map((row) => {
      const { password: _legacyPassword, ...safeRow } = row;
      return {
        ...safeRow,
        authMethod: 'gmail_invite' as const,
        inviteStatus: row.inviteStatus === 'sent' ? 'pending' as const : row.inviteStatus,
        status: row.authMethod === 'direct_password' ? 'pending' as const : row.status,
      };
    });
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SUBSCRIBERS);
      return sanitizeLegacySubscribers(saved ? JSON.parse(saved) as Subscriber[] : INITIAL_SUBSCRIBERS);
    } catch {
      return sanitizeLegacySubscribers(INITIAL_SUBSCRIBERS);
    }
  });

  const [salesRecords, setSalesRecords] = useState<SaleRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SALES);
      if (saved) return JSON.parse(saved);
      return [
        {
          id: 'sale_1',
          businessId: 'biz_1',
          itemType: 'product',
          itemName: 'وجبة مشويات ملكية',
          quantity: 2,
          unitPrice: 250,
          totalAmount: 500,
          platformCommission: 15,
          netRevenue: 485,
          customerName: 'أحمد محمود',
          customerPhone: '01012345678',
          createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
          status: 'completed',
        },
        {
          id: 'sale_2',
          businessId: 'biz_1',
          itemType: 'service',
          itemName: 'حجز طاولة VIP',
          quantity: 1,
          unitPrice: 150,
          totalAmount: 150,
          platformCommission: 5,
          netRevenue: 145,
          customerName: 'سارة إبراهيم',
          customerPhone: '01234567890',
          createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
          status: 'completed',
        },
      ];
    } catch {
      return [];
    }
  });

  const addSaleRecord = (saleData: Omit<SaleRecord, 'id' | 'createdAt'>): SaleRecord => {
    const newSale: SaleRecord = {
      ...saleData,
      id: `sale_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
    };
    setSalesRecords((prev) => [newSale, ...prev]);
    return newSale;
  };

  const [adminSettings, setAdminSettings] = useState<AdminSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_ADMIN_SETTINGS,
          ...parsed,
          adminPassword: '',
          currency: 'ج.م',
          platformName: 'MantiqatiX',
          functionalGroups: mergeFunctionalGroups(parsed.functionalGroups, DEFAULT_FUNCTIONAL_GROUPS),
          categories: parsed.categories || DEFAULT_CATEGORIES,
          siteMapConfig: {
            ...DEFAULT_SITE_MAP_CONFIG,
            ...(parsed.siteMapConfig || {}),
            developmentProgressPercent: 100,
            developmentStatusTitle: 'حالة التشغيل الفعلي للمنصة (النسخة الحقيقية المعتمدة 100%)',
          },
        };
      }
      return {
        ...INITIAL_ADMIN_SETTINGS,
        functionalGroups: DEFAULT_FUNCTIONAL_GROUPS,
        siteMapConfig: DEFAULT_SITE_MAP_CONFIG,
      };
    } catch {
      return {
        ...INITIAL_ADMIN_SETTINGS,
        functionalGroups: DEFAULT_FUNCTIONAL_GROUPS,
        siteMapConfig: DEFAULT_SITE_MAP_CONFIG,
      };
    }
  });

  // Ad Requests state
  const [adRequests, setAdRequests] = useState<AdRequest[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.AD_REQUESTS);
      return saved ? JSON.parse(saved) : INITIAL_AD_REQUESTS;
    } catch {
      return INITIAL_AD_REQUESTS;
    }
  });
  const [adModalType, setAdModalType] = useState<AdRequestType | null>(null);

  // Contact Messages (Inbox) state
  const [contactMessages, setContactMessages] = useState<ContactMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONTACT_MESSAGES);
      return saved ? JSON.parse(saved) : INITIAL_CONTACT_MESSAGES;
    } catch {
      return INITIAL_CONTACT_MESSAGES;
    }
  });

  const unreadMessagesCount = contactMessages.filter((m) => !m.isRead).length;

  // Business Subscription Requests state
  const [subscriptionRequests, setSubscriptionRequests] = useState<SubscriptionRequest[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SUB_REQUESTS);
      return saved ? JSON.parse(saved) : INITIAL_SUBSCRIPTION_REQUESTS;
    } catch {
      return INITIAL_SUBSCRIPTION_REQUESTS;
    }
  });
  const [isSubscribeModalOpen, setIsSubscribeModalOpen] = useState(false);
  const [adminActiveTabOverride, setAdminActiveTabOverride] = useState<string | null>(null);

  // Taxonomy states — always guarantee all 15 functional groups
  const functionalGroups = mergeFunctionalGroups(adminSettings.functionalGroups, DEFAULT_FUNCTIONAL_GROUPS);
  const categories = adminSettings.categories || DEFAULT_CATEGORIES;
  const medicalSpecialties = DEFAULT_MEDICAL_SPECIALTIES;

  const [selectedFunctionalGroupFilter, setSelectedFunctionalGroupFilter] = useState<string>('all');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [selectedMedicalSpecialtyFilter, setSelectedMedicalSpecialtyFilter] = useState<string>('all');
  const [userGeoCoords, setUserGeoCoords] = useState<{ lat: number; lng: number } | null>(null);

  // Enterprise Telemetry Metrics & Load Testing State (Hyperscale 100M Simulation)
  const [telemetryMetrics, setTelemetryMetrics] = useState<TelemetryMetrics>(() => getLiveTelemetryMetrics(1));
  const [isLoadTesting, setIsLoadTesting] = useState(false);
  const [lastLoadTestResult, setLastLoadTestResult] = useState<LoadTestBenchmarkResult | null>(() => simulateEnterpriseLoadTest(10000));
  const [loadTestHistory, setLoadTestHistory] = useState<LoadTestBenchmarkResult[]>([
    simulateEnterpriseLoadTest(1000),
    simulateEnterpriseLoadTest(10000),
  ]);

  const runLoadTest = (vus: number): LoadTestBenchmarkResult => {
    setIsLoadTesting(true);
    const result = simulateEnterpriseLoadTest(vus);
    setLastLoadTestResult(result);
    setLoadTestHistory((prev) => [result, ...prev]);
    const loadMultiplier = vus >= 500000 ? 5 : vus >= 100000 ? 3.5 : vus >= 10000 ? 2 : 1;
    setTelemetryMetrics(getLiveTelemetryMetrics(loadMultiplier));
    setTimeout(() => {
      setIsLoadTesting(false);
    }, 350);
    return result;
  };

  // Auth Session State
  // Tokens stay in React memory only. Reloading the page ends this temporary
  // session and requires a fresh OTP; no role or token is restored from storage.
  const [authSession, setAuthSession] = useState<AuthSession>({ role: 'guest' });
  const [authTokens, setAuthTokens] = useState<SupabaseAuthSession | null>(null);
  const [authStatus, setAuthStatus] = useState<AppContextType['authStatus']>('idle');
  const [authEmail, setAuthEmail] = useState('');
  const [authError, setAuthError] = useState('');
  const [authCandidates, setAuthCandidates] = useState<ActiveMembershipCandidate[]>([]);
  const [authBusinessSelectionRequired, setAuthBusinessSelectionRequired] = useState(0);
  const [selectedAuthMembershipId, setSelectedAuthMembershipId] = useState<string | null>(null);

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isUserProfileModalOpen, setIsUserProfileModalOpen] = useState(false);

  // Read URL query parameter for ?store=slug-or-id
  const getInitialStoreId = () => {
    try {
      const params = new URLSearchParams(window.location.search);
      const storeParam = params.get('store');
      if (storeParam) {
        const matched = businesses.find(
          (b) => b.slug === storeParam || b.id === storeParam
        );
        if (matched) return matched.id;
      }
      const saved = localStorage.getItem(STORAGE_KEYS.ACTIVE_BIZ);
      return saved || businesses[0]?.id || '';
    } catch {
      return businesses[0]?.id || '';
    }
  };

  const [selectedBusinessId, setSelectedBusinessId] = useState<string>(getInitialStoreId);

  useEffect(() => {
    try {
      const storeParam = new URLSearchParams(window.location.search).get('store');
      if (!storeParam) return;
      const match = publicDirectoryState.businesses.find((business) => business.slug === storeParam || business.id === storeParam);
      if (match) setSelectedBusinessId(match.id);
    } catch {
      // Ignore malformed URL state; normal directory navigation remains available.
    }
  }, [publicDirectoryState.businesses]);

  const [currentView, setCurrentViewRaw] = useState<ViewMode>(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('store')) return 'public_storefront';
      return 'directory';
    } catch {
      return 'directory';
    }
  });

  // Central client-side route guard. Protected screens still require backend authorization.
  const setCurrentView = (requestedView: ViewMode) => {
    const safeView = resolveProtectedView(
      requestedView,
      authSession.role,
      authSession.businessId,
    ) as ViewMode;
    const requiresSignIn =
      requestedView === 'super_admin' ||
      requestedView === 'merchant_admin' ||
      requestedView === 'member_messages';
    if (requiresSignIn && authSession.role === 'guest') {
      setIsLoginModalOpen(true);
      setCurrentViewRaw('directory');
      return;
    }
    if (requiresSignIn && authSession.role !== 'guest' && safeView !== requestedView) {
      setAuthError('العضوية التي اخترتها لا تمنح صلاحية الوصول إلى هذه الشاشة.');
      setIsLoginModalOpen(true);
      setCurrentViewRaw('directory');
      return;
    }
    if (requiresSignIn && authSession.role !== 'guest') {
      // Auth is now real, but these V6 workspaces still contain local/demo-backed
      // operational state. Keep them closed until their reads/writes use the
      // existing server-authorized API/RPC contracts.
      setAuthError('تم التحقق من الحساب والعضوية. لوحة العمل المطلوبة ما زالت في مرحلة ربط البيانات والصلاحيات الخادمية؛ أبقيناها مغلقة حتى لا تعرض بيانات محلية أو تسمح بتعديلات غير محفوظة في قاعدة الإنتاج.');
      setIsLoginModalOpen(true);
      setCurrentViewRaw('directory');
      return;
    }
    setCurrentViewRaw(safeView);
  };

  // Revoke a protected screen immediately if its session role or business scope disappears.
  useEffect(() => {
    const safeView = resolveProtectedView(
      currentView,
      authSession.role,
      authSession.businessId,
    ) as ViewMode;
    if (safeView !== currentView) setCurrentViewRaw(safeView);
  }, [currentView, authSession.role, authSession.businessId]);

  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Read-only public directory integration. It never hydrates private account, wallet,
  // admin, or payment state from browser storage or from the public endpoint.
  useEffect(() => {
    const controller = new AbortController();
    const config = getPublicCatalogDirectoryConfig();
    if (!config) {
      setPublicDirectoryState({ businesses: [], products: [], status: 'not_configured', error: 'PUBLIC_DIRECTORY_CONFIG_MISSING' });
      return () => controller.abort();
    }

    setPublicDirectoryState((current) => ({ ...current, status: 'loading', error: '' }));
    fetchPublicCatalogDirectory(config, { signal: controller.signal })
      .then((data) => {
        if (controller.signal.aborted) return;
        setPublicDirectoryState({
          businesses: data.businesses,
          products: data.products,
          status: data.businesses.length ? 'ready' : 'empty',
          error: '',
        });
      })
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        const code = error instanceof Error ? error.message : 'PUBLIC_DIRECTORY_UNAVAILABLE';
        setPublicDirectoryState({ businesses: [], products: [], status: 'error', error: code });
      });

    return () => controller.abort();
  }, [publicDirectoryRevision]);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BUSINESSES, JSON.stringify(businesses));
  }, [businesses]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SUBSCRIBERS, JSON.stringify(subscribers));
  }, [subscribers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(adminSettings));
  }, [adminSettings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_BIZ, selectedBusinessId);
    setCartItems([]);
  }, [selectedBusinessId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CURRENT_VIEW, currentView);
  }, [currentView]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(salesRecords));
  }, [salesRecords]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AD_REQUESTS, JSON.stringify(adRequests));
  }, [adRequests]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONTACT_MESSAGES, JSON.stringify(contactMessages));
  }, [contactMessages]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SUB_REQUESTS, JSON.stringify(subscriptionRequests));
  }, [subscriptionRequests]);

  // Tenant Isolation logic
  const currentBusiness = (() => {
    if (currentView === 'merchant_admin') {
      if (authSession.role !== 'subscriber' || !authSession.businessId) return undefined;
      return businesses.find((b) => b.id === authSession.businessId);
    }
    if (currentView === 'public_storefront' || currentView === 'directory') {
      // Public-facing business identity must always come from the server-read directory.
      return publicDirectoryState.businesses.find((b) => b.id === selectedBusinessId);
    }
    if (authSession.role === 'admin' || authSession.role === 'super_admin') {
      return businesses.find((b) => b.id === selectedBusinessId);
    }
    return undefined;
  })();

  const businessProducts = currentBusiness && publicDirectoryState.businesses.some((b) => b.id === currentBusiness.id)
    ? publicDirectoryState.products.filter((p) => p.businessId === currentBusiness.id)
    : products.filter((p) => p.businessId === currentBusiness?.id);

  // Taxonomy Category Handlers
  const addCategory = (data: { name: string; functionalGroupId: FunctionalGroupId; description?: string }): ActivityCategory => {
    const id = `cat_custom_${Date.now()}`;
    const newCat: ActivityCategory = {
      id,
      name: data.name.trim(),
      functionalGroupId: data.functionalGroupId,
      description: data.description?.trim(),
      isCustom: true,
    };

    setAdminSettings((prev) => ({
      ...prev,
      categories: [...(prev.categories || DEFAULT_CATEGORIES), newCat],
      defaultCategories: Array.from(new Set([...(prev.defaultCategories || []), newCat.name])),
    }));

    return newCat;
  };

  const updateCategory = (updated: ActivityCategory) => {
    setAdminSettings((prev) => ({
      ...prev,
      categories: (prev.categories || DEFAULT_CATEGORIES).map((c) => (c.id === updated.id ? updated : c)),
    }));
  };

  const deleteCategory = (id: string) => {
    setAdminSettings((prev) => {
      const remaining = (prev.categories || DEFAULT_CATEGORIES).filter((c) => c.id !== id);
      return {
        ...prev,
        categories: remaining,
        defaultCategories: remaining.map((c) => c.name),
      };
    });
  };

  const requestLoginOtp = async (email: string): Promise<boolean> => {
    setAuthStatus('sending_otp');
    setAuthError('');
    const config = getAuthMembershipApiConfig();
    if (!config) {
      setAuthStatus('error');
      setAuthError('إعدادات Supabase Auth غير مكتملة في نسخة الموقع.');
      return false;
    }
    try {
      await requestEmailOtp(config, email);
      setAuthEmail(email.trim().toLowerCase());
      setAuthStatus('otp_sent');
      return true;
    } catch (error) {
      setAuthStatus('error');
      setAuthError(authMessage(error));
      return false;
    }
  };

  const verifyLoginOtp = async (code: string): Promise<boolean> => {
    setAuthStatus('verifying_otp');
    setAuthError('');
    const config = getAuthMembershipApiConfig();
    if (!config || !authEmail) {
      setAuthStatus('error');
      setAuthError('ابدأ بطلب رمز الدخول إلى بريدك الإلكتروني أولًا.');
      return false;
    }
    let pendingSession: SupabaseAuthSession | null = null;
    let otpVerified = false;
    try {
      const session = await verifyEmailOtp(config, authEmail, code);
      pendingSession = session;
      otpVerified = true;
      const choices = await fetchAuthenticatedMembershipChoices(config, session.accessToken, session.user.id);
      setAuthCandidates(choices.candidates);
      setAuthBusinessSelectionRequired(choices.unresolvedBusinessSelectionCount);
      setSelectedAuthMembershipId(null);
      setAuthSession({ role: 'guest' });
      if (choices.candidates.length > 0) {
        setAuthTokens(session);
        setAuthStatus('select_membership');
      } else {
        setAuthTokens(null);
        void revokeAuthSession(config, session.accessToken).catch(() => undefined);
        setAuthStatus('no_membership');
        setAuthError(choices.unresolvedBusinessSelectionCount > 0
          ? 'تم التحقق من الحساب، لكن لم يُرجع الخادم نشاطًا نشطًا ومصرحًا به لهذه العضوية. لا يمكن فتح لوحة النشاط قبل ربط نشاط محدد.'
          : 'تم التحقق من البريد، لكن لا توجد عضوية نشطة تمنح هذا الحساب صلاحية دخول إلى لوحة المنصة.');
      }
      return choices.candidates.length > 0;
    } catch (error) {
      if (pendingSession) void revokeAuthSession(config, pendingSession.accessToken).catch(() => undefined);
      setAuthTokens(null);
      setAuthCandidates([]);
      setAuthBusinessSelectionRequired(0);
      const errorCode = error instanceof Error ? error.message : '';
      const canRetryOtp = !otpVerified && /otp|token|invalid_credentials/i.test(errorCode);
      setAuthStatus(canRetryOtp ? 'otp_sent' : 'error');
      setAuthError(authMessage(error));
      return false;
    }
  };

  const selectAuthMembership = (membershipId: string): boolean => {
    const candidate = authCandidates.find((entry) => entry.selectionKey === membershipId);
    if (!candidate || !authTokens || candidate.userId !== authTokens.user.id) {
      setAuthError('اختيار العضوية غير صالح. أعد تسجيل الدخول وحاول مرة أخرى.');
      return false;
    }
    const session = toV6AuthSession(candidate);
    session.userEmail = authTokens.user.email;
    setAuthSession(session);
    setSelectedAuthMembershipId(candidate.selectionKey);
    if (candidate.businessId) setSelectedBusinessId(candidate.businessId);
    setAuthStatus('authenticated');
    setAuthError('');
    setIsLoginModalOpen(false);
    return true;
  };

  // Legacy password entry points are deliberately non-functional. The only
  // supported route is the verified email OTP flow above.
  const loginAsSubscriber = (_identifier: string, _passwordInput: string) => ({
    success: false,
    error: 'استخدم تسجيل الدخول برمز البريد الإلكتروني والتحقق من العضوية.',
  });

  const loginAsAdmin = (_passwordInput: string) => ({
    success: false,
    error: 'استخدم تسجيل الدخول برمز البريد الإلكتروني والتحقق من صلاحية إدارة المنصة.',
  });

  const logout = () => {
    const previousToken = authTokens?.accessToken;
    const config = getAuthMembershipApiConfig();
    setAuthTokens(null);
    setAuthSession({ role: 'guest' });
    setAuthCandidates([]);
    setAuthBusinessSelectionRequired(0);
    setSelectedAuthMembershipId(null);
    setAuthStatus('idle');
    setAuthEmail('');
    setAuthError('');
    setCurrentViewRaw('directory');
    if (config && previousToken) void revokeAuthSession(config, previousToken).catch(() => undefined);
  };

  // Rotate the refresh token before expiry and re-check both Auth identity and
  // the selected server membership. A revoked membership immediately loses UI access.
  useEffect(() => {
    if (!authTokens) return;
    let cancelled = false;
    const delay = Math.max(5000, authTokens.expiresAt - Date.now() - 60_000);
    const timer = window.setTimeout(async () => {
      const config = getAuthMembershipApiConfig();
      if (!config) {
        setAuthTokens(null);
        setAuthSession({ role: 'guest' });
        setAuthCandidates([]);
        setAuthBusinessSelectionRequired(0);
        setSelectedAuthMembershipId(null);
        setAuthStatus('error');
        setAuthError('إعدادات Supabase Auth غير متاحة؛ تم إغلاق الجلسة محليًا.');
        setCurrentViewRaw('directory');
        return;
      }
      let tokenToRevoke = authTokens.accessToken;
      try {
        const refreshed = await refreshAuthSession(config, authTokens.refreshToken);
        tokenToRevoke = refreshed.accessToken;
        const verifiedUser = await getAuthenticatedUser(config, refreshed.accessToken);
        if (verifiedUser.id !== authTokens.user.id || verifiedUser.is_anonymous) {
          throw new Error('AUTH_REFRESH_USER_MISMATCH');
        }
        const choices = await fetchAuthenticatedMembershipChoices(config, refreshed.accessToken, verifiedUser.id);
        if (cancelled) return;
        setAuthTokens({ ...refreshed, user: verifiedUser });
        setAuthCandidates(choices.candidates);
        setAuthBusinessSelectionRequired(choices.unresolvedBusinessSelectionCount);
        if (selectedAuthMembershipId) {
          const selected = choices.candidates.find((entry) => entry.selectionKey === selectedAuthMembershipId);
          if (!selected) throw new Error('AUTH_MEMBERSHIP_REVOKED');
          const nextSession = toV6AuthSession(selected);
          nextSession.userEmail = verifiedUser.email;
          setAuthSession(nextSession);
        }
      } catch (error) {
        if (cancelled) return;
        setAuthTokens(null);
        setAuthSession({ role: 'guest' });
        setAuthCandidates([]);
        setAuthBusinessSelectionRequired(0);
        setSelectedAuthMembershipId(null);
        setAuthStatus('error');
        setAuthError(authMessage(error));
        setCurrentViewRaw('directory');
        void revokeAuthSession(config, tokenToRevoke).catch(() => undefined);
      }
    }, delay);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [authTokens, selectedAuthMembershipId]);

  // Business Actions
  const updateBusiness = (updated: Business) => {
    // If category changed, auto-align functionalGroupId if needed
    const matchedCategory = categories.find((c) => c.name === updated.category || c.id === updated.categoryId);
    const resolvedGroup = updated.functionalGroupId || matchedCategory?.functionalGroupId || 'retail';
    const staticImages = ensureBusinessStaticImages(updated.logoUrl, updated.coverUrl, resolvedGroup);

    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === updated.id
          ? {
              ...updated,
              functionalGroupId: resolvedGroup,
              logoUrl: staticImages.logoUrl,
              coverUrl: staticImages.coverUrl,
            }
          : b
      )
    );
  };

  const addBusiness = (data: Omit<Business, 'id' | 'createdAt'>): string => {
    const id = `biz_${Date.now()}`;
    const todayStr = new Date().toISOString().split('T')[0];

    // Determine functional group from category if not explicitly specified
    let group = data.functionalGroupId;
    if (!group) {
      const matchedCategory = categories.find((c) => c.name === data.category || c.id === data.categoryId);
      group = matchedCategory?.functionalGroupId || 'retail';
    }

    const staticImages = ensureBusinessStaticImages(data.logoUrl, data.coverUrl, group);

    const newBiz: Business = {
      ...data,
      id,
      logoUrl: staticImages.logoUrl,
      coverUrl: staticImages.coverUrl,
      functionalGroupId: group,
      createdAt: todayStr,
      governorate: data.governorate || 'القاهرة',
      markaz: data.markaz || '',
      village: data.village || '',
      registrationDate: data.registrationDate || todayStr,
      paymentDueDay: data.paymentDueDay || 1,
      paymentDueDate: data.paymentDueDate || todayStr,
      commissionPerOrder: data.commissionPerOrder ?? (adminSettings.defaultCommissionPerOrder || DEFAULT_COMMISSION_PER_ORDER),
      totalOrdersCount: data.totalOrdersCount || 0,
      paymentStatus: data.paymentStatus || 'paid',
      overdueDaysCount: data.overdueDaysCount || 0,
      isFrozen: data.isFrozen || false,
      paymentConfirmedByAdmin: data.paymentConfirmedByAdmin ?? true,
      lastPaymentDate: data.lastPaymentDate || todayStr,
      maxProductsLimit: data.maxProductsLimit || MAX_PRODUCTS_PER_BUSINESS,
      paymobConfig: data.paymobConfig || { ...DEFAULT_PAYMOB_CONFIG },
      verificationStatus: data.verificationStatus || 'unverified',
      isVerified: data.verificationStatus === 'verified' || data.isVerified || false,
      country: data.country || 'مصر',
      countryCode: data.countryCode || 'EG',
      viewsCount: 0,
    };
    setBusinesses((prev) => [newBiz, ...prev]);
    return id;
  };

  const updateBusinessVerificationStatus = (
    businessId: string,
    status: VerificationStatus,
    notes?: string
  ) => {
    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === businessId
          ? {
              ...b,
              verificationStatus: status,
              isVerified: status === 'verified',
              verificationNotes: notes || b.verificationNotes,
              verifiedAt: status === 'verified' ? new Date().toISOString() : b.verifiedAt,
            }
          : b
      )
    );
  };

  const updateBusinessPaymobConfig = (businessId: string, config: Partial<PaymobConfig>) => {
    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === businessId
          ? {
              ...b,
              paymobConfig: {
                ...(b.paymobConfig || DEFAULT_PAYMOB_CONFIG),
                ...config,
              },
            }
          : b
      )
    );
  };

  const updateBusinessLocation = (
    businessId: string,
    loc: { governorate: string; markaz: string; village: string; address?: string; coordinates?: { lat: number; lng: number } }
  ) => {
    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === businessId
          ? {
              ...b,
              governorate: loc.governorate,
              markaz: loc.markaz,
              village: loc.village,
              address: loc.address !== undefined ? loc.address : b.address,
              coordinates: loc.coordinates || b.coordinates,
            }
          : b
      )
    );
  };

  // Admin Billing, Commission & Overdue / Freeze Actions (ولا يراه صاحب النشاط)
  const confirmAdminPayment = (businessId: string) => {
    const todayStr = new Date().toISOString().split('T')[0];
    setBusinesses((prev) =>
      prev.map((b) => (b.id === businessId ? applyAdminPaymentConfirmation(b, todayStr) : b))
    );
  };

  const advanceBusinessOverdueDay = (businessId: string) => {
    setBusinesses((prev) =>
      prev.map((b) => (b.id === businessId ? advanceOverdueDay(b) : b))
    );
  };

  const toggleBusinessFreeze = (businessId: string) => {
    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === businessId
          ? {
              ...b,
              isFrozen: !b.isFrozen,
              paymentStatus: !b.isFrozen ? 'frozen' : b.paymentStatus === 'frozen' ? 'pending' : b.paymentStatus,
            }
          : b
      )
    );
  };

  const updateBusinessCommissionRate = (businessId: string, rate: number) => {
    setBusinesses((prev) =>
      prev.map((b) => (b.id === businessId ? { ...b, commissionPerOrder: rate } : b))
    );
  };

  const deleteBusiness = (id: string) => {
    setBusinesses((prev) => prev.filter((b) => b.id !== id));
    setProducts((prev) => prev.filter((p) => p.businessId !== id));
    if (selectedBusinessId === id && businesses.length > 1) {
      setSelectedBusinessId(businesses.find((b) => b.id !== id)?.id || '');
    }
  };

  const getStorePublicLink = (business: Business): string => {
    const origin = window.location.origin;
    return generateStorePublicUrl(origin, business.slug || business.id);
  };

  // Product Actions enforcing 150 items limit
  const addProduct = (data: Omit<Product, 'id'>): { success: boolean; message?: string } => {
    const targetBusiness = businesses.find((b) => b.id === data.businessId);
    const limit = targetBusiness?.maxProductsLimit || MAX_PRODUCTS_PER_BUSINESS;
    const currentCount = products.filter((p) => p.businessId === data.businessId).length;

    if (!canAddProduct(currentCount, limit)) {
      return {
        success: false,
        message: `عذراً، لقد بلغت الحد الأقصى المسموح به لهذا النشاط (${limit} منتج أو خدمة).`,
      };
    }

    const newProd: Product = {
      ...data,
      imageUrl: resolveProductImage(data, targetBusiness?.functionalGroupId),
      id: `prod_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    };

    setProducts((prev) => [newProd, ...prev]);
    return { success: true };
  };

  const updateProduct = (updated: Product) => {
    const targetBusiness = businesses.find((b) => b.id === updated.businessId);
    const normalized: Product = {
      ...updated,
      imageUrl: resolveProductImage(updated, targetBusiness?.functionalGroupId),
    };
    setProducts((prev) => prev.map((p) => (p.id === normalized.id ? normalized : p)));
    setCartItems((prev) =>
      prev.map((item) => (item.product.id === normalized.id ? { ...item, product: normalized } : item))
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    removeFromCart(id);
  };

  const bulkAddDemoProducts = (businessId: string, count: number): { success: boolean; added: number } => {
    const targetBusiness = businesses.find((b) => b.id === businessId);
    const limit = targetBusiness?.maxProductsLimit || MAX_PRODUCTS_PER_BUSINESS;
    const currentCount = products.filter((p) => p.businessId === businessId).length;
    const remaining = Math.max(0, limit - currentCount);

    const toAdd = Math.min(count, remaining);
    if (toAdd <= 0) {
      return { success: false, added: 0 };
    }

    const demoCategories = ['عروض خاصة', 'الأكثر طلباً', 'إصدارات جديدة', 'باقات مميزة'];
    const newItems: Product[] = [];
    const defaultSectorProductImg = resolveProductImage(null, targetBusiness?.functionalGroupId);

    for (let i = 1; i <= toAdd; i++) {
      const idx = currentCount + i;
      const cat = demoCategories[idx % demoCategories.length];
      const isService = idx % 4 === 0;
      newItems.push({
        id: `prod_demo_${Date.now()}_${idx}`,
        businessId,
        name: isService ? `خدمة رقمية مميزة #${idx}` : `منتج إضافي فائق الجودة #${idx}`,
        category: cat,
        type: isService ? 'service' : 'product',
        price: 35 + (idx % 10) * 15,
        comparePrice: (idx % 2 === 0) ? 50 + (idx % 10) * 15 : undefined,
        description: `وصف تفصيلي عالي الجودة لل${isService ? 'خدمة' : 'منتج'} رقم ${idx} يوضح المميزات والمواصفات للعميل.`,
        imageUrl: defaultSectorProductImg,
        isAvailable: true,
        unit: isService ? 'جلسة' : 'قطعة',
      });
    }

    setProducts((prev) => [...prev, ...newItems]);
    return { success: true, added: toAdd };
  };

  // Subscriber rows are local drafts only until Supabase Auth and server-side membership creation are wired.
  const addSubscriber = (data: {
    fullName: string;
    email: string;
    phone: string;
    businessId: string;
    username?: string;
    password?: string;
    authMethod: 'direct_password' | 'gmail_invite';
    notes?: string;
  }): Subscriber => {
    const newSub: Subscriber = {
      id: `sub_draft_${Date.now()}`,
      fullName: data.fullName,
      email: data.email,
      phone: data.phone,
      businessId: data.businessId,
      username: data.username?.trim() || data.email.split('@')[0],
      authMethod: 'gmail_invite',
      inviteStatus: 'pending',
      status: 'pending',
      notes: data.notes,
      joinedDate: new Date().toISOString().split('T')[0],
    };

    setSubscribers((prev) => [newSub, ...prev]);
    return newSub;
  };

  const updateSubscriber = (updated: Subscriber) => {
    const { password: _legacyPassword, ...safeSubscriber } = updated;
    setSubscribers((prev) => prev.map((s) => (s.id === updated.id ? {
      ...safeSubscriber,
      authMethod: 'gmail_invite',
      inviteStatus: s.inviteStatus,
    } : s)));
  };

  const deleteSubscriber = (id: string) => {
    setSubscribers((prev) => prev.filter((s) => s.id !== id));
  };

  const sendGmailInvite = (_subscriberId: string): string => {
    // Do not compose email containing client-generated passwords or claim an account was created.
    return '';
  };

  const getSubscriberCredentialsText = (_subscriberId: string): string =>
    'لم يتم إنشاء بيانات دخول. يجب إنشاء الحساب عبر Supabase Auth وربط العضوية من الخادم.';

  // Admin Settings
  const updateAdminSettings = (settings: Partial<AdminSettings>) => {
    setAdminSettings((prev) => ({ ...prev, ...settings, adminPassword: '' }));
  };

  const addBusinessCategory = (category: string) => {
    const trimmed = category.trim();
    if (!trimmed || adminSettings.defaultCategories.includes(trimmed)) return;
    setAdminSettings((prev) => ({
      ...prev,
      defaultCategories: [...prev.defaultCategories, trimmed],
    }));
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1) => {
    if (currentBusiness?.isFrozen) {
      return;
    }

    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { product, quantity }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const submitOrderViaWhatsApp = (
    customer: CustomerOrderData
  ): { success: boolean; url?: string; error?: string } => {
    if (currentBusiness?.isFrozen) {
      return {
        success: false,
        error: 'عذراً، هذا النشاط التجاري مجمد حالياً لعدم سداد المستحقات المالية للإدارة.',
      };
    }
    if (cartItems.length === 0) {
      return { success: false, error: 'السلة فارغة، يرجى إضافة منتجات أولاً.' };
    }
    if (!currentBusiness?.ownerWhatsApp) {
      return { success: false, error: 'رقم واتساب صاحب النشاط غير متوفر.' };
    }
    if (!customer.customerName.trim() || !customer.customerPhone.trim()) {
      return { success: false, error: 'يرجى كتابة الاسم ورقم الجوال للطلب.' };
    }

    const url = generateWhatsAppOrderUrl(
      currentBusiness.ownerWhatsApp,
      currentBusiness.name,
      cartItems,
      customer,
      adminSettings.currency || 'ج.م'
    );

    // Increment orders count for platform commission tracking
    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === currentBusiness.id
          ? { ...b, totalOrdersCount: (b.totalOrdersCount || 0) + 1 }
          : b
      )
    );

    return { success: true, url };
  };

  const requestCatalogViaAdminWhatsApp = (business = currentBusiness): string => {
    if (!business) return '';
    return generateAdminCatalogRequestWhatsAppUrl(
      adminSettings.adminWhatsApp,
      business.name,
      business.category
    );
  };

  // Local browser state is a preview/cache only. It is never an authoritative
  // production record. A verified server-side Supabase contract must replace
  // this placeholder before production writes are enabled.
  const [lastLiveSyncTimestamp] = useState<string>('');

  const commitCurrentDataAsOfficialLive = async (): Promise<{ success: boolean; committedAt: string }> => {
    return {
      success: false,
      committedAt: '',
    };
  };

  const resetToDefaultData = () => {
    // Reset only the local preview state. This does not write to production.
    setBusinesses(INITIAL_BUSINESSES.map((b) => ({
      ...b,
      paymobConfig: { ...DEFAULT_PAYMOB_CONFIG },
    })));
    setProducts(INITIAL_PRODUCTS);
    setSubscribers(INITIAL_SUBSCRIBERS);
    setAdminSettings(INITIAL_ADMIN_SETTINGS);
  };

  // Backup & Restore Implementations
  const exportBackupJSON = (): string => {
    return createBackupPayload(businesses, products, subscribers, adminSettings);
  };

  const downloadBackupFile = () => {
    const jsonString = exportBackupJSON();
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0];
    link.href = url;
    link.download = `mantiqatix-backup-${dateStr}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const importBackupJSON = (
    jsonString: string
  ): {
    success: boolean;
    error?: string;
    counts?: { businesses: number; products: number; subscribers: number };
  } => {
    const res = validateAndParseBackup(jsonString);
    if (!res.valid || !res.data) {
      return { success: false, error: res.error || 'الملف غير صالح.' };
    }

    const { businesses: b, products: p, subscribers: s, adminSettings: a } = res.data;
    setBusinesses(b);
    setProducts(p);
    setSubscribers(s);
    if (a) setAdminSettings(a);
    if (b.length > 0) setSelectedBusinessId(b[0].id);

    return {
      success: true,
      counts: {
        businesses: b.length,
        products: p.length,
        subscribers: s.length,
      },
    };
  };

  // Ad Requests Handlers
  const addAdRequest = (req: Omit<AdRequest, 'id' | 'createdAt' | 'status'>): AdRequest => {
    const newReq: AdRequest = {
      ...req,
      id: `ad_req_${Date.now()}`,
      status: 'pending',
      createdAt: new Date().toISOString().split('T')[0],
    };
    setAdRequests((prev) => [newReq, ...prev]);
    return newReq;
  };

  const updateAdRequest = (updated: AdRequest) => {
    setAdRequests((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
  };

  const updateAdRequestStatus = (id: string, status: AdRequestStatus) => {
    setAdRequests((prev) => prev.map((r) => (r.id === id ? { ...r, status } : r)));
  };

  const updateAdRequestDetails = (updated: AdRequest) => {
    setAdRequests((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
  };

  const deleteAdRequest = (id: string) => {
    setAdRequests((prev) => prev.filter((r) => r.id !== id));
  };

  // Contact Messages (Admin Inbox) Handlers
  const addContactMessage = (msg: Omit<ContactMessage, 'id' | 'createdAt' | 'isRead'>): ContactMessage => {
    const nowStr = new Date().toLocaleString('ar-EG', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
    const newMsg: ContactMessage = {
      ...msg,
      id: `msg_${Date.now()}`,
      isRead: false,
      createdAt: nowStr,
    };
    setContactMessages((prev) => [newMsg, ...prev]);
    return newMsg;
  };

  const markContactMessageRead = (id: string, isRead = true) => {
    setContactMessages((prev) => prev.map((m) => (m.id === id ? { ...m, isRead } : m)));
  };

  const deleteContactMessage = (id: string) => {
    setContactMessages((prev) => prev.filter((m) => m.id !== id));
  };

  // Business Subscription & Free Directory Request Handlers
  const submitSubscriptionRequest = (data: {
    businessName: string;
    ownerName?: string;
    phoneOrWhatsApp: string;
    governorate: string;
    markaz: string;
    detailedAddress?: string;
    functionalGroupId: FunctionalGroupId;
    category: string;
    notes?: string;
    isFreeDirectoryOnly?: boolean;
  }): { request: SubscriptionRequest; businessId: string } => {
    const defaultTier: SubscriptionPlanTier = data.isFreeDirectoryOnly ? 'free' : 'regular';
    const defaultConfig = getDefaultTierConfiguration(defaultTier);
    const staticImgs = ensureBusinessStaticImages(undefined, undefined, data.functionalGroupId);

    const newBusinessId = addBusiness({
      name: data.businessName.trim(),
      slug: `biz-${Date.now()}`,
      category: data.category.trim() || 'عام',
      functionalGroupId: data.functionalGroupId,
      logoUrl: staticImgs.logoUrl,
      coverUrl: staticImgs.coverUrl,
      bio:
        data.notes?.trim() ||
        'دليل مجاني - نشاط مسجل حديثاً يقتصر على الاسم والموقع والرقم لحين التوثيق من الإدارة.',
      ownerWhatsApp: data.phoneOrWhatsApp.trim(),
      phone: data.phoneOrWhatsApp.trim(),
      address: data.detailedAddress?.trim() || `${data.governorate.trim()} - ${data.markaz.trim()}`,
      governorate: data.governorate.trim(),
      markaz: data.markaz.trim(),
      village: data.detailedAddress?.trim() || '',
      workingHours: 'يومياً',
      isVerified: false,
      verificationStatus: 'unverified',
      subscriptionTier: defaultTier,
      maxAllowedBusinesses: defaultConfig.maxAllowedBusinesses,
      maxProductsLimit: defaultConfig.maxProductsLimit,
      creditLimit: defaultConfig.creditLimit,
      usedCredit: 0,
      permissions: defaultConfig.permissions,
      registrationDate: new Date().toISOString().split('T')[0],
      paymentDueDay: 1,
      paymentDueDate: new Date().toISOString().split('T')[0],
      commissionPerOrder: 0.01,
      totalOrdersCount: 0,
      paymentStatus: 'paid',
      overdueDaysCount: 0,
      isFrozen: false,
      paymentConfirmedByAdmin: true,
    });

    const newReq: SubscriptionRequest = {
      id: `sub_req_${Date.now()}`,
      businessId: newBusinessId,
      businessName: data.businessName.trim(),
      ownerName: data.ownerName?.trim(),
      phoneOrWhatsApp: data.phoneOrWhatsApp.trim(),
      governorate: data.governorate.trim(),
      markaz: data.markaz.trim(),
      detailedAddress: data.detailedAddress?.trim(),
      functionalGroupId: data.functionalGroupId,
      category: data.category.trim() || 'عام',
      notes: data.notes?.trim(),
      status: 'pending_review',
      assignedTier: defaultTier,
      ...defaultConfig,
      commissionType: 'percentage_plus_fixed',
      createdAt: new Date().toISOString().split('T')[0],
    };

    setSubscriptionRequests((prev) => [newReq, ...prev]);
    return { request: newReq, businessId: newBusinessId };
  };

  const reviewSubscriptionRequest = (
    requestId: string,
    decision: 'approved' | 'rejected',
    config: {
      assignedTier: SubscriptionPlanTier;
      maxAllowedBusinesses: number;
      maxProductsLimit: number;
      commissionType: 'percentage' | 'fixed' | 'percentage_plus_fixed' | 'subscription_only' | 'all_combined';
      monthlySubscriptionFee: number;
      commissionPercentage: number;
      commissionFixed: number;
      creditLimit: number;
      permissions: BusinessPermissions;
      isVerified: boolean;
    }
  ) => {
    const req = subscriptionRequests.find((r) => r.id === requestId);
    if (!req) return;

    setSubscriptionRequests((prev) =>
      prev.map((r) =>
        r.id === requestId
          ? {
              ...r,
              status: decision,
              assignedTier: config.assignedTier,
              maxAllowedBusinesses: config.maxAllowedBusinesses,
              maxProductsLimit: config.maxProductsLimit,
              commissionType: config.commissionType,
              monthlySubscriptionFee: config.monthlySubscriptionFee,
              commissionPercentage: config.commissionPercentage,
              commissionFixed: config.commissionFixed,
              creditLimit: config.creditLimit,
              permissions: config.permissions,
              reviewedAt: new Date().toISOString().split('T')[0],
            }
          : r
      )
    );

    if (decision === 'approved') {
      setBusinesses((prev) =>
        prev.map((b) =>
          b.id === req.businessId
            ? {
                ...b,
                isVerified: config.isVerified,
                verificationStatus: config.isVerified ? 'verified' : 'unverified',
                subscriptionTier: config.assignedTier,
                maxAllowedBusinesses: config.maxAllowedBusinesses,
                maxProductsLimit: config.maxProductsLimit,
                commissionType: config.commissionType,
                monthlySubscriptionFee: config.monthlySubscriptionFee,
                commissionPercentage: config.commissionPercentage,
                commissionFixed: config.commissionFixed,
                creditLimit: config.creditLimit,
                permissions: config.permissions,
              }
            : b
        )
      );
    }
  };

  const updateSubscriptionRequest = (updated: SubscriptionRequest) => {
    setSubscriptionRequests((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
  };

  const approveSubscriptionRequestToBusiness = (req: SubscriptionRequest, isVerified: boolean) => {
    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === req.businessId
          ? {
              ...b,
              isVerified,
              verificationStatus: isVerified ? 'verified' : 'unverified',
              subscriptionTier: req.assignedTier,
              maxAllowedBusinesses: req.assignedMaxAllowedBusinesses ?? req.maxAllowedBusinesses,
              monthlySubscriptionFee: req.assignedMonthlyFee ?? req.monthlySubscriptionFee,
              commissionPercentage: req.assignedCommissionPercentage ?? req.commissionPercentage,
              commissionFixed: req.assignedCommissionFixed ?? req.commissionFixed,
              permissions: req.assignedPermissions ?? req.permissions,
            }
          : b
      )
    );
  };

  // ============================================================================
  // ENTERPRISE WALLET, LEDGER & SMART MARKETING SYSTEM
  // ============================================================================
  const [wallets, setWallets] = useState<WalletAccount[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.WALLETS);
      if (saved) {
        const parsed: WalletAccount[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return createInitialPlatformWallets(INITIAL_BUSINESSES, INITIAL_SUBSCRIBERS);
    } catch {
      return createInitialPlatformWallets(INITIAL_BUSINESSES, INITIAL_SUBSCRIBERS);
    }
  });

  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.WALLET_TXS);
      if (saved) return JSON.parse(saved);
      return [
        {
          id: 'tx_seed_1',
          walletId: ADMIN_MAIN_WALLET_ID,
          ownerName: 'محفظة الإدارة العامة (MantiqatiX)',
          type: 'admin_free_ad_grant',
          amount: 0,
          balanceAfter: 48500,
          description: 'إطلاق حملة إعلان ممول مربع مجاني 100% للإدارة — مقهى ومحمصة الأفق',
          paymentMethod: 'admin_grant',
          isFreeAdminGrant: true,
          status: 'completed',
          createdAt: '2026-02-22 10:00 ص',
        },
        {
          id: 'tx_seed_2',
          walletId: ADMIN_MAIN_WALLET_ID,
          ownerName: 'محفظة الإدارة العامة (MantiqatiX)',
          type: 'deposit',
          amount: 3500,
          balanceAfter: 48500,
          description: 'تحصيل اشتراكات الأنشطة الموثقة والعمولات الدورية عبر Paymob',
          paymentMethod: 'paymob_card',
          isFreeAdminGrant: false,
          status: 'completed',
          createdAt: '2026-02-21 04:30 م',
        },
      ];
    } catch {
      return [];
    }
  });

  const [activeWalletId, setActiveWalletIdState] = useState<string>(ADMIN_MAIN_WALLET_ID);
  const [isWalletModalOpen, setIsWalletModalOpenState] = useState<boolean>(false);
  // Wallet balances and ledger are still local demonstration state. Do not expose
  // them as customer financial records or allow local mutations to look official.
  const FINANCIAL_BACKEND_READY = false;
  const setActiveWalletId = (walletId: string) => {
    if (authSession.role !== 'admin' && authSession.role !== 'super_admin') return;
    if (!FINANCIAL_BACKEND_READY) return;
    setActiveWalletIdState(walletId);
  };
  const setIsWalletModalOpen = (open: boolean) => {
    if (!open) {
      setIsWalletModalOpenState(false);
      return;
    }
    if (authSession.role === 'guest') {
      setIsLoginModalOpen(true);
      return;
    }
    // No shared ledger / wallet API is wired into V6 yet. Keep the local mock closed.
    setIsWalletModalOpenState(false);
  };

  // Sync active wallet when role or selected business changes
  useEffect(() => {
    if (authSession.role === 'admin' || authSession.role === 'super_admin') {
      setActiveWalletId(ADMIN_MAIN_WALLET_ID);
    } else if (authSession.role === 'subscriber' && authSession.businessId) {
      const bizWallet = wallets.find((w) => w.ownerType === 'business' && w.ownerId === authSession.businessId);
      if (bizWallet) setActiveWalletId(bizWallet.id);
    }
  }, [authSession.role, authSession.businessId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WALLETS, JSON.stringify(wallets));
  }, [wallets]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WALLET_TXS, JSON.stringify(walletTransactions));
  }, [walletTransactions]);

  const currentWallet =
    wallets.find((w) => w.id === activeWalletId) ||
    wallets.find((w) => w.ownerType === 'business' && w.ownerId === currentBusiness?.id) ||
    wallets[0];

  const performWalletTransaction = (input: {
    walletId?: string;
    type: WalletTransactionType;
    amount: number;
    description: string;
    paymentMethod?: WalletPaymentChannel;
    referenceId?: string;
    isFreeAdminGrant?: boolean;
  }): { success: boolean; error?: string; transaction?: WalletTransaction } => {
    if (!FINANCIAL_BACKEND_READY) {
      return { success: false, error: 'المحفظة متوقفة مؤقتاً حتى ربط دفتر الأستاذ الخادمي والتحقق من صلاحيات النشاط والفرع.' };
    }
    if (authSession.role === 'guest') {
      return { success: false, error: 'يجب تسجيل الدخول والتحقق من العضوية قبل استخدام المحفظة.' };
    }
    const targetId = input.walletId || currentWallet?.id || ADMIN_MAIN_WALLET_ID;
    const targetWallet = wallets.find((w) => w.id === targetId) || wallets[0];
    if (!targetWallet) {
      return { success: false, error: 'لم يتم العثور على المحفظة المطلوبة.' };
    }

    const res = executeWalletLedgerOperation(targetWallet, input);
    if (!res.success || !res.transaction) {
      return { success: false, error: res.error };
    }

    setWallets((prev) => prev.map((w) => (w.id === targetWallet.id ? res.updatedWallet : w)));
    setWalletTransactions((prev) => [res.transaction!, ...prev]);

    // Sync business credit usage if business wallet
    if (targetWallet.ownerType === 'business') {
      setBusinesses((prev) =>
        prev.map((b) =>
          b.id === targetWallet.ownerId
            ? {
                ...b,
                usedCredit: res.updatedWallet.usedCredit,
                usedCreditBalance: res.updatedWallet.usedCredit,
              }
            : b
        )
      );
    }

    return { success: true, transaction: res.transaction };
  };

  // Smart Marketing System State
  const [generatedCampaigns, setGeneratedCampaigns] = useState<GeneratedMarketingCampaign[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CAMPAIGNS);
      if (saved) return JSON.parse(saved);
      const firstBiz = INITIAL_BUSINESSES[0];
      return firstBiz ? [generateBusinessMarketingCampaign(firstBiz, { goal: 'sales_boost', discountPercent: 30, isAdminMode: true })] : [];
    } catch {
      return [];
    }
  });

  const [smartMarketingTargetBiz, setSmartMarketingTargetBizState] = useState<Business | null>(null);
  const setSmartMarketingTargetBiz = (biz: Business | null) => {
    if (!biz) {
      setSmartMarketingTargetBizState(null);
      return;
    }
    if (authSession.role !== 'admin' && authSession.role !== 'super_admin') {
      setIsLoginModalOpen(true);
      return;
    }
    setSmartMarketingTargetBizState(biz);
  };

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CAMPAIGNS, JSON.stringify(generatedCampaigns));
  }, [generatedCampaigns]);

  const generateMarketingForBusiness = (
    businessId: string,
    options?: {
      goal?: MarketingCampaignGoal;
      discountPercent?: number;
      customOfferText?: string;
    }
  ): GeneratedMarketingCampaign | null => {
    if (authSession.role !== 'admin' && authSession.role !== 'super_admin') return null;
    const targetBiz = businesses.find((b) => b.id === businessId);
    if (!targetBiz) return null;

    const bizProds = products.filter((p) => p.businessId === targetBiz.id);
    const isAdminUser = authSession.role === 'admin' || authSession.role === 'super_admin';

    const campaign = generateBusinessMarketingCampaign(targetBiz, {
      ...options,
      isAdminMode: isAdminUser,
      featuredProducts: bizProds,
    });

    setGeneratedCampaigns((prev) => [campaign, ...prev]);
    return campaign;
  };

  const publishCampaignAsFreeAdminAd = (
    campaignId: string,
    adType: AdRequestType = 'sponsored_ad',
    durationDays: number = 14
  ): { success: boolean; adRequest?: AdRequest; error?: string } => {
    if (authSession.role !== 'admin' && authSession.role !== 'super_admin') {
      return { success: false, error: 'نشر الحملات المجانية متاح لإدارة المنصة المعتمدة فقط.' };
    }
    return { success: false, error: 'لم يتم ربط نشر الإعلانات ودفترها المالي بالخادم بعد؛ لم يتم إنشاء إعلان أو معاملة.' };
  };


  // Curated Home Screen Selectors & Enterprise State Summary
  const pickedForYouBusinesses = React.useMemo(
    () => getPickedForYouBusinesses(businesses, 6),
    [businesses]
  );

  const mostRequestedBusinesses = React.useMemo(
    () => getMostRequestedBusinesses(businesses, 6),
    [businesses]
  );

  const enterpriseStateSummary = React.useMemo(
    () =>
      buildEnterpriseStateSummary({
        businesses,
        products,
        wallets,
        transactions: walletTransactions,
        campaigns: generatedCampaigns,
        adRequests,
      }),
    [businesses, products, wallets, walletTransactions, generatedCampaigns, adRequests]
  );

  // 15-Sector Specialized Development & 3-Tier Package Studio State
  const [sectorDevelopmentTargetGroup, setSectorDevelopmentTargetGroup] = useState<FunctionalGroupId | null>(null);
  const [sectorDevelopmentTargetBiz, setSectorDevelopmentTargetBiz] = useState<Business | null>(null);

  const openSectorDevelopmentStudio = (groupId: FunctionalGroupId, biz: Business | null = null) => {
    setSectorDevelopmentTargetGroup(groupId);
    setSectorDevelopmentTargetBiz(biz);
  };

  const upgradeBusinessSectorPackage = (
    businessId: string,
    targetLevel: SectorPackageLevel,
    paymentMode: 'wallet' | 'admin_free' = 'admin_free'
  ): { success: boolean; message: string; updatedBusiness?: Business } => {
    const isPlatformAdmin = authSession.role === 'admin' || authSession.role === 'super_admin';
    const ownsBusiness = authSession.role === 'subscriber' && authSession.businessId === businessId;
    if (!isPlatformAdmin && !ownsBusiness) {
      return { success: false, message: 'يجب تسجيل الدخول بحساب مخوّل لإدارة هذا النشاط قبل طلب الترقية.' };
    }
    return { success: false, message: 'لم يتم ربط الترقية والاشتراك ودفتر المعاملات بالخادم بعد؛ لم يتم تفعيل أي باقة أو خصم رصيد.' };
  };

  // =========================================================================
  // MEMBER & BUSINESS DIRECT MESSAGING INBOX WITH PRIVACY & LOCATION CONTROLS
  // =========================================================================
  const [messagingTargetType, setMessagingTargetType] = useState<'business' | 'subscriber'>('business');
  const [messagingTargetId, setMessagingTargetId] = useState<string>(
    () => selectedBusinessId || businesses[0]?.id || ''
  );

  // Private inbox data must come from an authenticated backend. Ignore any
  // browser-stored or seeded messages until that contract is integrated.
  const [memberDirectMessages, setMemberDirectMessages] = useState<MemberDirectMessage[]>([]);

  const openMemberMessagingForTarget = (
    type: 'business' | 'subscriber',
    id?: string
  ) => {
    if (authSession.role === 'guest') {
      setIsLoginModalOpen(true);
      return;
    }
    const resolvedId = id || (type === 'business'
      ? selectedBusinessId || ''
      : authSession.subscriberId || '');
    const isPlatformAdmin = authSession.role === 'admin' || authSession.role === 'super_admin';
    const ownsRequestedTarget = authSession.role === 'subscriber' && Boolean(resolvedId) && (
      (type === 'business' && resolvedId === authSession.businessId) ||
      (type === 'subscriber' && resolvedId === authSession.subscriberId)
    );
    if (!isPlatformAdmin && !ownsRequestedTarget) return;
    setMessagingTargetType(type);
    setMessagingTargetId(resolvedId);
    setCurrentView('member_messages');
  };

  const updateRecipientMessagingPrivacy = (
    type: 'business' | 'subscriber',
    id: string,
    config: MessagingPrivacyConfig
  ) => {
    const isPlatformAdmin = authSession.role === 'admin' || authSession.role === 'super_admin';
    const ownsTarget = authSession.role === 'subscriber' && (
      (type === 'business' && id === authSession.businessId) ||
      (type === 'subscriber' && id === authSession.subscriberId)
    );
    if (!isPlatformAdmin && !ownsTarget) return;
    // Shared privacy settings stay read-only until the authenticated server endpoint is available.
    return;
  };

  const sendMemberDirectMessage = (input: {
    recipientType: 'business' | 'subscriber';
    recipientId: string;
    senderName: string;
    senderPhone: string;
    senderGovernorate: string;
    senderMarkaz: string;
    senderRole?: 'subscriber' | 'visitor' | 'admin';
    subject: string;
    content: string;
    category?: MemberDirectMessage['category'];
  }): { success: boolean; error?: string; message?: MemberDirectMessage } => {
    return { success: false, error: 'صندوق الرسائل الداخلي غير متصل بالخادم بعد. لم يتم حفظ أو إرسال الرسالة.' };
  };

  const canManageMessage = (msgId: string) => {
    const message = memberDirectMessages.find((item) => item.id === msgId);
    if (!message) return false;
    if (authSession.role === 'admin' || authSession.role === 'super_admin') return true;
    return authSession.role === 'subscriber' && (
      (message.recipientType === 'business' && message.recipientId === authSession.businessId) ||
      (message.recipientType === 'subscriber' && message.recipientId === authSession.subscriberId)
    );
  };

  const replyToMemberDirectMessage = (msgId: string, replyText: string) => {
    if (!canManageMessage(msgId)) return;
    setMemberDirectMessages((prev) =>
      prev.map((m) =>
        m.id === msgId
          ? {
              ...m,
              replyText: replyText.trim(),
              repliedAt: new Date().toLocaleString('ar-EG'),
              isRead: true,
            }
          : m
      )
    );
  };

  const markMemberDirectMessageRead = (msgId: string, isRead: boolean = true) => {
    if (!canManageMessage(msgId)) return;
    setMemberDirectMessages((prev) =>
      prev.map((m) => (m.id === msgId ? { ...m, isRead } : m))
    );
  };

  const deleteMemberDirectMessage = (msgId: string) => {
    if (!canManageMessage(msgId)) return;
    setMemberDirectMessages((prev) => prev.filter((m) => m.id !== msgId));
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        selectedBusinessId,
        setSelectedBusinessId,
        currentBusiness,
        functionalGroups,
        categories,
        addCategory,
        updateCategory,
        deleteCategory,
        selectedFunctionalGroupFilter,
        setSelectedFunctionalGroupFilter,
        selectedCategoryFilter,
        setSelectedCategoryFilter,
        authSession,
        authStatus,
        authEmail,
        authError,
        authCandidates,
        authBusinessSelectionRequired,
        requestLoginOtp,
        verifyLoginOtp,
        selectAuthMembership,
        loginAsSubscriber,
        loginAsAdmin,
        logout,
        isLoginModalOpen,
        setIsLoginModalOpen,
        isUserProfileModalOpen,
        setIsUserProfileModalOpen,
        businesses,
        products,
        directoryBusinesses: publicDirectoryState.businesses,
        directoryProducts: publicDirectoryState.products,
        directoryStatus: publicDirectoryState.status,
        directoryError: publicDirectoryState.error,
        refreshPublicDirectory,
        subscribers,
        adminSettings,
        updateBusiness,
        updateBusinessVerificationStatus,
        updateBusinessVerification: updateBusinessVerificationStatus,
        addBusiness,
        deleteBusiness,
        getStorePublicLink,
        updateBusinessLocation,
        medicalSpecialties,
        selectedMedicalSpecialtyFilter,
        setSelectedMedicalSpecialtyFilter,
        userGeoCoords,
        setUserGeoCoords,
        telemetryMetrics,
        loadTestHistory,
        runLoadTest,
        isLoadTesting,
        lastLoadTestResult,
        confirmAdminPayment,
        advanceBusinessOverdueDay,
        toggleBusinessFreeze,
        updateBusinessCommissionRate,
        updateBusinessPaymobConfig,
        businessProducts,
        addProduct,
        updateProduct,
        deleteProduct,
        bulkAddDemoProducts,
        addSubscriber,
        updateSubscriber,
        deleteSubscriber,
        sendGmailInvite,
        getSubscriberCredentialsText,
        updateAdminSettings,
        addBusinessCategory,
        cartItems,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        submitOrderViaWhatsApp,
        requestCatalogViaAdminWhatsApp,
        exportBackupJSON,
        downloadBackupFile,
        importBackupJSON,
        resetToDefaultData,
        isOfficialLiveProduction: false,
        lastLiveSyncTimestamp,
        commitCurrentDataAsOfficialLive,
        salesRecords,
        addSaleRecord,
        adRequests,
        addAdRequest,
        updateAdRequest,
        updateAdRequestStatus,
        updateAdRequestDetails,
        deleteAdRequest,
        adModalType,
        setAdModalType,
        contactMessages,
        unreadMessagesCount,
        addContactMessage,
        markContactMessageRead,
        deleteContactMessage,
        subscriptionRequests,
        submitSubscriptionRequest,
        reviewSubscriptionRequest,
        updateSubscriptionRequest,
        approveSubscriptionRequestToBusiness,
        isSubscribeModalOpen,
        setIsSubscribeModalOpen,
        adminActiveTabOverride,
        setAdminActiveTabOverride,
        wallets,
        walletTransactions,
        activeWalletId,
        setActiveWalletId,
        currentWallet,
        isWalletModalOpen,
        setIsWalletModalOpen,
        performWalletTransaction,
        generatedCampaigns,
        smartMarketingTargetBiz,
        setSmartMarketingTargetBiz,
        generateMarketingForBusiness,
        publishCampaignAsFreeAdminAd,
        pickedForYouBusinesses,
        mostRequestedBusinesses,
        enterpriseStateSummary,
        sectorDevelopmentTargetGroup,
        setSectorDevelopmentTargetGroup,
        sectorDevelopmentTargetBiz,
        setSectorDevelopmentTargetBiz,
        openSectorDevelopmentStudio,
        upgradeBusinessSectorPackage,
        memberDirectMessages,
        messagingTargetType,
        messagingTargetId,
        openMemberMessagingForTarget,
        updateRecipientMessagingPrivacy,
        sendMemberDirectMessage,
        replyToMemberDirectMessage,
        markMemberDirectMessageRead,
        deleteMemberDirectMessage,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
