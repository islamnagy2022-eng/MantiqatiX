# MANTIQATIX ENTERPRISE 100M — ARCHITECTURE BLUEPRINT
## High-Scale Distributed Digital Ecosystem
**Version:** 4.0-Enterprise  
**Target Capacity:** 100,000,000 Registered Accounts | 10M+ MAU | 500k Peak Concurrent VUs  
**Primary Region:** Egypt (MENA Hub) with Multi-Region Expansion Ready (GCC, North Africa, Global)

---

## 1. Executive Summary & Design Principles

MantiqatiX Enterprise is architected as a **Modular Monolith transitioning to Microservices**, built to scale horizontally from day one without requiring costly rip-and-replace rewrites when traffic explodes.

### Core Architectural Axioms
1. **Stateless Compute**: Every application instance is 100% stateless. Session state resides in high-throughput distributed memory caches (Redis Cluster), enabling linear horizontal auto-scaling.
2. **Read/Write Asymmetry**: 95% of traffic in a business directory and catalog platform is read-heavy (browsing, search, catalog views). Writes (registrations, catalog updates, order dispatches) are separated into asynchronous queues and dedicated write masters.
3. **Multi-Tier Caching Hierarchy**: Browser (L1) -> CDN Edge (L2) -> Application In-Memory LRU (L3) -> Distributed Redis Cache (L4) -> PostgreSQL Read Replicas (L5).
4. **Resilient Decoupling**: Non-critical services (AI descriptions, analytics, audit logging, search re-indexing) communicate via Event Bus and Message Queues (RabbitMQ / Kafka). If the search engine or AI layer experiences transient latency, core catalog browsing and WhatsApp order dispatch remain 100% operational.
5. **Zero Single Point of Failure (SPOF)**: Every component—load balancers, web instances, database replicas, object storage, caches—is deployed across at least 3 Availability Zones (AZs) with automated failover.

---

## 2. Global System Topology

```
+-----------------------------------------------------------------------------------+
|                            GLOBAL EDGE & CDN LAYER                                |
|  - Cloudflare / Google Cloud Armor Enterprise WAF & DDoS Protection               |
|  - Edge Anycast DNS with Geographic Routing (Egypt / MENA / EU / Global)          |
|  - Edge Asset Caching (Static JS, CSS, AVIF/WebP Media Thumbnails, TTL: 30d)     |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
|                        APPLICATION GATEWAY & LOAD BALANCER                        |
|  - Managed Envoy / NGINX Plus / Cloud Application Load Balancer                   |
|  - SSL Offloading & HTTP/3 + gRPC Support                                         |
|  - Layer 7 Rate Limiter (Token Bucket per IP / Account / API Key)                |
|  - Centralized Route Dispatch & Zero-Downtime Blue/Green Deployment               |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
|                        STATELESS APPLICATION SERVICE PODS                         |
|  [Identity & Auth]   [Activity & Directory]   [Medical Engine]   [Catalog & Cart] |
|  [Search Engine]     [Orders & WhatsApp]      [Advertising Hub]  [AI Service Hub] |
|  Horizontal Pod Autoscaler (HPA): Min 10 Pods -> Max 250 Pods based on CPU/RPS   |
+-----------------------------------------------------------------------------------+
          |                              |                                |
          v                              v                                v
+----------------------+      +----------------------+      +-----------------------+
|  DISTRIBUTED CACHE   |      |    DATABASE CLUSTER  |      |  EVENT & QUEUE BUS    |
|  - Redis Cluster     |      |  - PostgreSQL 16+    |      |  - Kafka / RabbitMQ   |
|  - 3 Master Nodes    |      |  - 1 Write Master    |      |  - Async Order Logger |
|  - 6 Read Replicas   |      |  - 5 Read Replicas   |      |  - Search Index Sync  |
|  - Sub-millisecond   |      |  - PgBouncer Pooling |      |  - Media Transcoder   |
+----------------------+      +----------------------+      +-----------------------+
```

---

## 3. Component Architecture Breakdown

### 3.1. Identity & Centralized Access Management
- **Target Scale**: 100,000,000 registered user accounts.
- **Tokens**: Short-lived stateless JWTs (15 min) + Refresh Tokens stored with cryptographic device fingerprinting in Redis with automated sliding expiration.
- **Authentication Providers**:
  - One-Click Google OAuth / Gmail Workspace.
  - Direct Password with bcrypt (cost factor 12) + Argon2id.
  - Mobile Phone OTP Verification via localized SMS Gateways.
- **RBAC Matrix**:
  - `super_admin`: Global platform controls, billing configuration, system observability.
  - `regional_manager`: Governorate and territorial management, dispute resolution.
  - `subscriber` / `merchant`: Business owner catalog, store profile, order logs.
  - `medical_staff`: Doctors, clinics, pharmacies management.
  - `customer`: Verified shopper, order history, review author.
  - `guest`: Read-only catalog browser.

### 3.2. Geographic Search Engine & Arabic NLP
- **Full Text Search**: Specialized Arabic linguistic analyzer.
  - Normalization of Alef variants (`أ`, `إ`, `آ`, `ٱ` -> `ا`).
  - Normalization of Taa Marbuta (`ة` -> `ه`).
  - Normalization of Yaa / Alef Maksura (`ى`, `ي` -> `ي`).
  - Stripping of Tashkeel (harakat: fathah, dammah, kasrah, tanween, sukun, shaddah).
  - Removal of Tatweel (`ـ`).
- **Spatial Geo-Search**:
  - Dynamic hierarchical indexing: `Country` -> `Governorate` -> `Markaz/City` -> `Village/District` -> `GeoPoint(lat, lng)`.
  - Spherical Haversine calculation for radius-based proximity sorting (`sort_by: distance_asc`).
  - Zero hardcoding of geographic regions to allow multi-country expansion.

### 3.3. Medical Directory & Healthcare Engine
- **Specialties**: Internal Medicine, Pediatrics, Orthopedics, Cardiology, Dermatology, Obstetrics & Gynecology, Dentistry, Ophthalmology, Neurology, Radiology, Clinical Labs, and Pharmacies.
- **Doctor Avatar Standard**: Verified official avatar placeholder (`https://play-lh.googleusercontent.com/0V8K7Jgj4E0DP0dsn2tnkaipdrUG1tbkslu7ajn6kADRRUL4e1lcFKBFU1W0971GMwV-IYW09XuI-E0n_7F9roI`).
- **Pharmacies**: Fast prescription uploads, stock inquiries, 24/7 night coverage indicators.
- **Default Visuals**: Business cover and logo are always rendered immediately even prior to administrative verification.

### 3.4. 5-Tier Verification Lifecycle
1. `unverified`: Newly self-registered business; allowed to draft catalog items. Visual badge indicates pending verification.
2. `under_review`: Merchant has submitted commercial registration or credentials; queue item sent to Admin Verification Hub.
3. `verified`: Administratively inspected; granted official green verified shield, priority search ranking boost (+35%), and trusted status.
4. `rejected`: Failed verification due to invalid paperwork or fake entity; merchant notified with corrective actions.
5. `suspended`: Temporarily frozen due to terms violations or overdue monthly subscription past the 5-day grace window.

---

## 4. Media Storage & Delivery Pipeline
- **Storage**: Object Storage (Google Cloud Storage / AWS S3) with Multi-Region redundancy.
- **Dynamic Transformation**: Sharp/WebP image optimization microservice generates 3 responsive tiers on upload:
  - `thumb`: 120x120px WebP (15KB) for directory lists.
  - `card`: 600x400px WebP (45KB) for storefront grid cards.
  - `cover`: 1600x600px WebP (110KB) for desktop banners.
- **No Database Bloat**: Absolute binary data is never stored in PostgreSQL columns; only secure signed URLs with immutable CDN hashing.

---

## 5. Orders, WhatsApp Dispatch & Paymob Gateway
- **Strict Role**: The platform remains an information and digital presence provider, not a material intermediary.
- **WhatsApp Direct**: Orders serialize the customer cart, items, address, and Paymob payment tokens into a structured WhatsApp message dispatched directly to the merchant's dedicated WhatsApp number.
- **Administrative WhatsApp**: Administrative inquiries, catalog requests, and enterprise sponsorships dispatch directly to the platform administration WhatsApp (`201010171770`).
- **Paymob Integration**: Merchant fee configuration (percentage and/or fixed fee) calculated transparently in Egyptian Pounds (ج.م).

---

## 6. AI Layer & Cost Management
- **Provider**: Google Gemini API via server-side proxy route.
- **Use Cases**: Natural language search semantic parser, business bio writer, catalog category tagger, customer preference recommendations.
- **Cost Controls**:
  - Request Rate Limiting per user session (max 5 AI calls/hour for guests).
  - Semantic In-Memory Caching: Identical natural-language search queries serve from Redis cache without model invocation.
  - Strict Token Budgeting (Max output tokens: 350 tokens per prompt).
