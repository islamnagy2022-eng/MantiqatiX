# MANTIQATIX ENTERPRISE 100M — SECURITY & ZERO TRUST PLAN
## Multi-Layer Defense, Identity Hardening & Compliance

---

## 1. Zero Trust Architectural Tenets
1. **Never Trust, Always Verify**: Every API request passing through the API Gateway is strictly authenticated and authorized regardless of source IP.
2. **Least Privilege Enforcement**: Microservices and application components interact using restricted scoped service accounts.
3. **Data Protection at Rest & In Transit**:
   - TLS 1.3 mandatory for all ingress and inter-pod communications.
   - AES-256 encryption on all database volumes and object storage buckets.
   - Encrypted field-level hashing for sensitive merchant keys and subscriber passwords.

---

## 2. Threat Vector Mitigations

| Threat Vector | Mitigation Strategy | Technology Employed |
|---|---|---|
| **DDoS (Volumetric / Layer 7)** | Edge Anycast filtering + Behavioral rate limiting | Cloudflare Magic Transit / Google Cloud Armor |
| **Credential Stuffing** | Token bucket rate limiting + Leaked password checks + Recaptcha v3 Enterprise on suspicious anomalies | Redis Rate Limiter + Argon2id password hash |
| **SQL Injection (SQLi)** | Parameterized queries exclusively via ORM; zero raw string concatenation | TypeScript typed schema builders |
| **Cross-Site Scripting (XSS)** | React JSX auto-escaping + Strict Content Security Policy (CSP) headers | HTTP Security Headers (`helmet`) |
| **Admin Privilege Escalation** | Multi-factor verification + Immutable Audit Log + IP range allow-listing | Audit Trail Database + Webhook alerts |
| **API Abuse / Scraping** | Sliding-window IP & Account rate limits; progressive delays on bulk scraping | NGINX / Envoy Rate Limiting |
| **Unauthorized Store Access** | Tenant Isolation checks: Subscribers can ONLY mutate products belonging to their explicit `businessId` | Context Role Guards & Middleware |

---

## 3. Identity & Session Lifecycle Hardening

- **Password Policy**: Minimum 8 characters, entropy check, hashed via bcrypt with salt factor 12.
- **Session Tokens**: Cryptographically signed HMAC-SHA256 tokens; stateless verification with Redis blacklist for immediate revocation.
- **Concurrent Session Policy**: Users can inspect and terminate active sessions across different devices (Mobile, Desktop, Tablet) directly from account management.
- **OTP Validation**: 6-digit cryptographic random tokens, valid for 180 seconds, rate-limited to maximum 3 attempts per phone number per 15 minutes to prevent brute forcing.

---

## 4. Legal Compliance & Platform Protection
- **No Financial Intermediation Disclaimer**: Prominently rendered in footers, checkout modals, and admin agreements. The platform holds no custody of merchant customer funds, eliminates financial escrow liabilities, and restricts payments to direct cash-on-delivery or certified direct merchant gateways (Paymob).
- **GDPR / Egypt Data Protection Law (Law 151/2020)**: Right to erasure, data export, and automated personal data sanitization upon account deactivation.
