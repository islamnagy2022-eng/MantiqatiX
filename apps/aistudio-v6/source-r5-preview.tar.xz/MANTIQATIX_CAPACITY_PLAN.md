# MANTIQATIX ENTERPRISE 100M — CAPACITY & SIZING PLAN
## Mathematical Sizing, Storage Projections & Compute Scaling

---

## 1. Workload Sizing Assumptions

| Metric | Target Year 1 (Launch) | Target Year 3 (Growth) | Target Year 5 (Hyperscale) |
|---|---|---|---|
| **Registered Users** | 2,000,000 | 25,000,000 | **100,000,000** |
| **Monthly Active Users (MAU)** | 600,000 | 7,500,000 | **25,000,000** |
| **Daily Active Users (DAU)** | 120,000 | 1,800,000 | **6,000,000** |
| **Registered Businesses** | 25,000 | 250,000 | **1,500,000** |
| **Active Catalog Products** | 1,250,000 | 15,000,000 | **90,000,000** |
| **Daily Search Queries** | 500,000 | 12,000,000 | **60,000,000** |
| **Peak Requests Per Sec (RPS)** | 1,200 req/s | 18,000 req/s | **125,000 req/s** |
| **Concurrent Virtual Users (Peak)** | 5,000 VUs | 75,000 VUs | **500,000 VUs** |

---

## 2. Storage Requirements (100M Users & 1.5M Businesses)

### 2.1. Relational Database (PostgreSQL)
- **User Accounts**: 100,000,000 records * ~400 bytes/row = **40 GB**
- **User Sessions & Auth Logs**: Partitioned rolling 90 days = **75 GB**
- **Businesses (Storefronts)**: 1,500,000 records * ~1.8 KB/row = **2.7 GB**
- **Catalog Items (Products/Services)**: 90,000,000 records * ~650 bytes/row = **58.5 GB**
- **Orders & Interaction Events**: Rolling 12 months = **180 GB**
- **Indexes & Overhead (+60%)**: ~215 GB
- **Total Relational Storage**: **~571.2 GB**
- *Conclusion*: A single well-tuned PostgreSQL primary with PgBouncer connection pooling and 5 read replicas comfortably handles relational data up to 100M accounts, with horizontal sharding by `country_id` or `governorate_id` ready for when catalog items exceed 200M rows.

### 2.2. Object Storage (Images, Documents & Assets)
- **Logos & Avatars**: 1.5M businesses * 25 KB = 37.5 GB
- **Doctor Avatars**: Shared canonical default (1 asset via CDN) + custom avatars (50k * 40 KB = 2 GB)
- **Cover Images (1-2 per business)**: 1.5M * 1.5 * 90 KB = 202.5 GB
- **Product Images**: 90M products * 65 KB avg WebP = **5.85 TB**
- **Verification Documents (Private bucket)**: 1.5M * 350 KB = 525 GB
- **Total Media Footprint**: **~6.62 TB** (Delivered 98.4% via CDN Edge Caching).

---

## 3. Distributed In-Memory Cache (Redis Cluster)

- **Hot Catalogs & Storefronts (Top 10% active)**: 150,000 stores * 12 KB = 1.8 GB
- **Geographic Indexes & Taxonomy**: 250 MB
- **Active User Sessions (DAU peak concurrency)**: 500,000 concurrent * 1.5 KB = 750 MB
- **Search Query Result Cache (TTL 15 min)**: 5 GB
- **Rate Limiting Token Buckets**: 1.2 GB
- **Redis Cluster Dimension**: Minimum 3 nodes with 16 GB RAM each (48 GB total cluster memory, 32 GB usable with 33% headroom).

---

## 4. Compute & Auto-Scaling Profile

```
           [Traffic Load]
                 |
      < 5,000 req/s  -->  12 Service Pods (4 vCPU, 8 GB RAM each)
 5,000 - 25,000 req/s -->  36 Service Pods (Auto-Scaled)
25,000 - 75,000 req/s -->  90 Service Pods (Auto-Scaled)
   > 75,000 req/s     --> 180 - 250 Service Pods (Peak Event Load)
```

- **HPA Metric**: 65% average CPU utilization OR > 350 active HTTP connections per pod.
- **Pod Spin-up Time**: Container image optimized under 85MB; readiness probe succeeds in < 6 seconds.
