# عقد ربط عضويات Supabase بأدوار V6

**التاريخ:** 5 نوفمبر 2026  
**المصدر:** فحص قراءة فقط لمشروع Supabase الحالي، مع مراجعة Edge Function `api` إصدار 17، و`catalog-admin` إصدار 20، و`catalog-platform-admin` إصدار 23.

## مصدر هوية المستخدم والعضويات
- `api /api/v1/me` يتحقق من JWT عبر `auth.getUser(token)` ثم يعيد `user.id` والعضويات ذات الحالة `ACTIVE` فقط.
- بيانات التفويض المعتمدة تأتي من `user_memberships` على الخادم: `tenant_id`, `organization_id`, `business_id`, `branch_id`, `role`, `permissions`, `status`.
- لا يجوز استعمال `user_metadata` أو Local Storage أو اسم دور يرسله المتصفح لتحديد الصلاحيات.
- يجب مقارنة `user.id` المعاد من الخادم مع `supabase.auth.getUser()` قبل قبول أي عضوية.
- يجب عرض اختيار العضوية عند وجود أكثر من مرشح. لا تُختَر أول عضوية تلقائيًا.

## الأدوار الفعلية المرصودة في جدول العضويات
إجمالي 33 عضوية نشطة وقت الفحص، موزعة كالتالي: `ADMIN` (1)، `BUSINESS_OWNER` (9)، `CUSTOMER` (13)، `EMPLOYEE` (1)، `MANAGER` (1)، `OWNER` (3)، `SERVICE_PROVIDER` (1)، `STAFF` (1)، `SUPER_ADMIN` (1)، `SUPPORT` (1)، `SUPPORT_MANAGER` (1).

## سياسة التحويل إلى V6
| دور Supabase | شرط إضافي | دور/حالة V6 |
|---|---|---|
| `SUPER_ADMIN` | لا `business_id` ولا `branch_id`، و`permissions.scope=PLATFORM` و`permissions.full_control=true` | `super_admin` |
| `BUSINESS_OWNER` | `tenant_id` و`business_id` صالحان | `subscriber` ضمن النشاط المحدد |
| `OWNER`, `ADMIN`, `MANAGER` | `tenant_id` و`business_id` صالحان | `subscriber` ضمن النشاط/الفرع المحدد؛ تظل الكتابات خاضعة لعقد الخادم |
| `OWNER` | مستأجر صالح بلا نشاط أو فرع | `requiresBusinessSelection`؛ لا تفتح لوحة حتى اختيار نشاط من API مصرح به |
| `CUSTOMER` | عضوية نشطة ومستأجر صالح | `customer`، بلا نطاق نشاط أو لوحة إدارة |
| `EMPLOYEE`, `STAFF`, `SERVICE_PROVIDER`, `SUPPORT`, `SUPPORT_MANAGER` | لا يوجد في V6 حاليًا مصفوفة قدرات مخصصة مطابقة | غير مفعلين في لوحات V6؛ يظلون بلا دور إداري حتى بناء صلاحياتهم |
| أدوار غير معروفة أو نطاقات ناقصة | أي حالة | تجاهل/رفض آمن |

**ملاحظة:** هذا التحويل يهيئ عرض الواجهة فقط. كل قراءة/كتابة خاصة يجب أن يعيد الخادم التحقق من هوية المستخدم والعضوية ونطاق المستأجر/النشاط/الفرع والـpermissions.

## التنفيذ المضاف
- `src/services/authMembership.ts`: يتحقق من شكل استجابة `/api/v1/me`، يقارن معرف المستخدم المتوقع، يصفي العضويات النشطة، ويخرج مرشحين منفصلين دون اختيار تلقائي.
- `toV6AuthSession()` يحول مرشحًا تم اختياره صراحة إلى نموذج جلسة V6 مع `userId`, `membershipId`, `tenantId`, `organizationId`, `businessId`, `branchId`, `backendRole`, `membershipPermissions`.
- `AuthSession` أضيفت إليه حقول مصدر العضوية؛ ولا يتم ملؤها من المتصفح.
- اختبارات تغطي Super Admin المشروط، Business Owner، Manager، Owner tenant-level، Customer، الأدوار غير المعتمدة، العضويات غير النشطة، تعدد العضويات، وعدم تطابق المستخدم.

## ما لم يتم تنفيذه بعد
- لم يتم دمج SDK `@supabase/supabase-js` أو تشغيل sign-in/OAuth/OTP/refresh/sign-out. السبب أن الحزمة غير متاحة في npm cache والاتصال الشبكي غير متوفر في بيئة التنفيذ، ولا يمكن إنشاء lockfile موثوق دون تثبيت فعلي.
- لا توجد واجهة اختيار عضوية بعد.
- لا تزال الجلسة الافتراضية `guest`؛ لا توجد أدوار قابلة للتفعيل محليًا.
- لا تغيير في قاعدة الإنتاج أو Edge Functions.

**المرحلة التالية:** إضافة إصدار مثبت من SDK وlockfile متوافق مع مدير الحزم، ثم sign-in/session lifecycle، واستخدام `/api/v1/me` مع مقارنة `userId`، ثم واجهة اختيار العضوية أو النشاط، ثم اختبارات عزل بين المستخدمين والمستأجرين والأنشطة والفروع.
