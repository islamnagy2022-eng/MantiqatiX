<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/e1f944a4-772e-480a-b554-0777f7e9bc47

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Supabase public directory connection

The public V6 directory reads approved activity/catalogue cards from the existing `public-catalog-directory` Edge Function. Configure these build-time browser variables:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
```

Only the publishable key belongs in a browser build. Never use `service_role`, `sb_secret_...`, or any database credential in `VITE_*` variables. The adapter performs read-only GET requests and maps only fields returned by the allowlisted public endpoint. If configuration or the public endpoint is unavailable, the directory does not substitute local seed records for real published activity data.

## Supabase Auth login

The login dialog uses Supabase's email OTP Auth endpoints. It requests a code only for an existing account (`create_user: false`), verifies the six-digit code, validates the returned user with the Auth user endpoint, and then loads active memberships from the existing `/functions/v1/api/api/v1/me` endpoint. A user must explicitly select one server-returned membership; V6 never chooses the first membership or reads a role from browser storage.

For direct business-scoped memberships, V6 offers each active server-returned membership as a separate choice. For a tenant-level `OWNER` without a `business_id`, V6 calls the existing `catalog-admin` Edge Function with `BUSINESS_LIST`; the server re-checks the OWNER membership and returns only active businesses in that tenant. Each business becomes its own explicit choice. No business is inferred from local state.

Access and refresh tokens are kept in React memory only, refreshed before expiry, and revoked on logout. The selected identity and active membership are re-checked after refresh. If the account has no eligible membership, the just-issued Auth session is revoked. Reloading the page ends this temporary session and requires another OTP. The OTP screen also supports changing the email address. The Auth flow uses the same `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` settings above; no Supabase SDK dependency or lockfile change was made in this offline pass.

**Important release boundary:** selecting a verified membership does not yet unlock the Super Admin, merchant, or member-messaging workspaces. Those screens still contain local/demo-backed operational state. Their routes remain blocked until their reads and writes are connected to the existing server-authorized Edge Function/RPC contracts and tested. No production schema, Auth configuration, Edge Function, or deployment was changed here.

For real email delivery to all users, confirm the project's custom SMTP configuration and set the Magic Link/OTP email template to include `{{ .Token }}`. Supabase's built-in email provider may restrict recipients; do not treat successful OTP API tests as proof that production mail delivery is configured.

Unit tests can be run with `npm test` after installing dependencies.
